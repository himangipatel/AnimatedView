/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.model.CountryListModel;
import com.bumptech.glide.Glide;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */

public class CityAdapter extends BaseRecyclerAdapter<CityAdapter.ViewHolder> {
  private List<CountryListModel> cityList;
  private Context context;

  public CityAdapter(Context context, List<CountryListModel> cityList) {
    this.context = context;
    this.cityList = cityList;
  }

  @Override public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    return new ViewHolder(
        LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_city, parent, false));
  }

  @Override public void onBindViewHolder(ViewHolder holder, int position) {
    CountryListModel city = getItem(position);
    holder.tvTitle.setText(city.getName());
    holder.tvNumberCity.setText(context.getString(R.string.more_than_250_offers,city.getCount()));
    Glide.with(context)
        .load(city.getImageUrl())
        .placeholder(R.drawable.placeholder)
        .dontAnimate()
        .into(holder.ivCityImage);
  }

  private CountryListModel getItem(int position) {
    return cityList.get(position);
  }

  @Override public int getItemCount() {
    return cityList.size();
  }

  public class ViewHolder extends BaseRecyclerAdapter.ViewHolder {
    @BindView(R.id.ivCityImage) ImageView ivCityImage;
    @BindView(R.id.tvTitle) TextView tvTitle;
    @BindView(R.id.tvNumberCity) TextView tvNumberCity;

    public ViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
      clickableViews(itemView);
    }
  }
}
