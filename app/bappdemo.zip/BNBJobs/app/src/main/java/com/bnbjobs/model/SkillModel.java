/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;

/**
 * @author Harsh
 * @version 1.0
 */
public class SkillModel {

  @SerializedName("ups_id") private String id;
  @SerializedName("ups_u_id") private String uId;
  @SerializedName("ups_title") private String title;
  @SerializedName("ups_rate") private int rate;
  @SerializedName("ups_status") private int status;

  private int profileStatus;

  public int getProfileStatus() {
    return profileStatus;
  }

  public void setProfileStatus(int profileStatus) {
    this.profileStatus = profileStatus;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getuId() {
    return uId;
  }

  public void setuId(String uId) {
    this.uId = uId;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public int getRate() {
    return rate;
  }

  public void setRate(int rate) {
    this.rate = rate;
  }

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }
}

