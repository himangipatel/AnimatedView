/*
 * Copyright (c) 2017 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import com.bnbjobs.R;
import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.JobModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.GetReverseGeoCoding;
import com.bnbjobs.view.CountryJobView;
import com.google.android.gms.maps.model.LatLng;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.orhanobut.logger.Logger;
import java.lang.reflect.Type;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;
import rx.subscriptions.CompositeSubscription;

import static com.bnbjobs.utils.Constants.FOR_ALL_CONTRACT;
import static com.bnbjobs.utils.Constants.PER_PAGE;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class CountryJobPresenter extends BasePresenter implements Presenter<CountryJobView> {

  private CountryJobView mView;
  private CompositeSubscription subscription = new CompositeSubscription();
  private boolean mOfferLoading, mCountryLoading;

  @Override public void attachView(CountryJobView view) {
    mView = view;
  }

  @Override public void detachView() {
    mView = null;
    if (subscription != null) subscription.clear();
  }

  public void getOfferAround(int page) {
    if (hasNetworkConnectivity()) {
      mOfferLoading = true;
      showProgress(page);
      HashMap<String, String> params = new HashMap<>(8);
      params.put("apiName", "get1KmJobOffers");
      params.put("perPage", String.valueOf(PER_PAGE));
      params.put("contractType", FOR_ALL_CONTRACT);
      LatLng latLng = mView.getLatLng();
      if (latLng != null) {
        params.put("latitude", String.valueOf(latLng.latitude));
        params.put("longitude", String.valueOf(latLng.longitude));
      }
      params.putAll(addParams(params));
      if (page > 0) {
        params.put("page", String.valueOf(page));
      }
      subscription.add(RestClient.getInstance(params).subscribe(getKmJobOfferSubscriber()));
    }
  }

  private void showProgress(int page) {
    if (page == 1 && !mView.isRefreshing()) {
      mView.showProgress();
    }
  }

  private Subscriber<String> getKmJobOfferSubscriber() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mOfferLoading = false;
        hideProgress();
      }

      @Override public void onNext(String s) {
        mOfferLoading = false;
        hideProgress();
        GsonBuilder builder = new GsonBuilder();
        Type collectionType = new TypeToken<BaseContainer<JobModel>>() {
        }.getType();
        BaseContainer<JobModel> jobSearchBaseContainer = builder.create().fromJson(s, collectionType);
        mView.onNearJobSuccess(jobSearchBaseContainer, jobSearchBaseContainer.getCurrentPage() == 1);
      }
    };
  }

  public void getCountryOffer(int page) {
    if (!hasNetworkConnectivity()) return;
    mCountryLoading = true;
    showProgress(page);
    HashMap<String, String> params = new HashMap<>(14);
    params.put("apiName", "getAllJobOffersForCountries");
    params.put("countryName", mView.getCountryName());
    params.put("contractType", FOR_ALL_CONTRACT);
    params.put("page", String.valueOf(page));
    params.put("perPage", "10");
    params.putAll(addParams(params));

    subscription.add(RestClient.getInstance(params).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mCountryLoading = false;
        hideProgress();
      }

      @Override public void onNext(String s) {
        mCountryLoading = false;
        LOGI(TAG, "OnCountry");
        Logger.json(s);
        hideProgress();
        GsonBuilder builder = new GsonBuilder();
        Type collectionType = new TypeToken<BaseContainer<JobModel>>() {
        }.getType();
        BaseContainer<JobModel> jobSearchBaseContainer = builder.create().fromJson(s, collectionType);
        mView.onCountryJobSuccess(jobSearchBaseContainer, jobSearchBaseContainer.getCurrentPage() == 1);
      }
    }));
  }

  public void getAddress(final LatLng location) {
    mView.showProgress();
    Observable.just(location).map(new Func1<LatLng, String>() {
      @Override public String call(LatLng latLng) {
        GetReverseGeoCoding getReverseGeoCoding = new GetReverseGeoCoding();
        getReverseGeoCoding.getAddress(latLng);
        return getReverseGeoCoding.getCountry();
      }
    }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mView.hideProgress();
        String error = getBaseContext().getString(R.string.error_other);
        if (e instanceof SocketTimeoutException) {
          error = getBaseContext().getString(R.string.error_timeout);
        }
        showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error, getBaseContext().getString(R.string.retry),
            new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                getAddress(location);
              }
            }).show();
      }

      @Override public void onNext(String s) {
        mView.setCountry(s);
      }
    });
  }

  private void hideProgress() {
    if (!mOfferLoading && !mCountryLoading) mView.hideProgress();
  }

  @Override protected Context getBaseContext() {
    return mView.getContext();
  }
}
