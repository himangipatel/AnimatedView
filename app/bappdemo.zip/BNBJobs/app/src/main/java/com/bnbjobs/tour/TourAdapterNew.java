/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.tour;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.LandingScreen;
import com.bnbjobs.utils.Constants;
import java.util.ArrayList;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.ActivityUtils.launchActivity;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */

class TourAdapterNew extends RecyclerView.Adapter<TourAdapterNew.SimpleViewHolder> {

  private static final String TAG = makeLogTag(TourAdapterNew.class);
  private ArrayList<Integer> mSrc = new ArrayList<>(4);
  private ArrayList<Integer> mCenter = new ArrayList<>(4);
  private ArrayList<Integer> mBottom = new ArrayList<>(4);
  private String[] titleArray;
  private String[] detailArray;
  private Context mContext;

  TourAdapterNew(Context context) {
    mContext = context;
    titleArray = context.getResources().getStringArray(R.array.tour_array_title);
    detailArray = context.getResources().getStringArray(R.array.tour_array_detail);

    mSrc.add(R.drawable.round_blue_drawable);
    mSrc.add(R.drawable.intro_second_one);
    mSrc.add(R.drawable.round_pink_drawable);
    mSrc.add(R.drawable.round_violet_drawable); // dummay

    mCenter.add(R.drawable.intro_first_two);
    mCenter.add(R.drawable.intro_second_two);
    mCenter.add(R.drawable.intro_third_one);

    mBottom.add(R.drawable.intro_first_one);
    mBottom.add(R.drawable.intro_second_three);
    mBottom.add(R.drawable.intro_third_two);
  }

  @Override public SimpleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    final View view =
        LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_tour_new, parent, false);
    return new SimpleViewHolder(view);
  }

  @Override public void onBindViewHolder(SimpleViewHolder holder, int position) {

    if (position == mSrc.size() - 1) {
      holder.mRelativeFour.setVisibility(View.VISIBLE);
      holder.mRelativeDetail.setVisibility(View.GONE);
      holder.mRelativeTop.setVisibility(View.GONE);
      holder.imageViewBottom.setVisibility(View.GONE);
    } else {

      holder.imageviewMain.setBackgroundResource(mSrc.get(position));
      if (position == 1) {
        holder.imageviewMain.setBackgroundResource(R.drawable.round_violet_drawable);
      }

      holder.imageviewMain.setImageResource(mSrc.get(position));

      holder.imageViewCenter.setImageResource(mCenter.get(position));
      holder.imageViewBottom.setImageResource(mBottom.get(position));
      setImageHeight(holder);
      holder.tvTitle.setText(Html.fromHtml(titleArray[position]));
      holder.tvDetails.setText(detailArray[position]);
      holder.mRelativeDetail.setVisibility(View.VISIBLE);
      holder.mRelativeTop.setVisibility(View.VISIBLE);
      holder.imageViewBottom.setVisibility(View.VISIBLE);
      holder.mRelativeFour.setVisibility(View.GONE);
    }
  }

  private void setImageHeight(final SimpleViewHolder holder) {
    Drawable drawable = holder.imageViewBottom.getDrawable();
    int height = drawable.getIntrinsicHeight() / 2;
    RelativeLayout.LayoutParams params =
        (RelativeLayout.LayoutParams) holder.imageViewBottom.getLayoutParams();
    params.setMargins(0, -height, 0, 0);
    holder.imageViewBottom.setLayoutParams(params);
  }

  @Override public int getItemCount() {
    return mSrc.size();
  }

  class SimpleViewHolder extends RecyclerView.ViewHolder {
    int mPosition;
    private ImageView imageviewMain, imageViewBottom, imageViewCenter;
    private TextView tvCandidate;
    private TextView tvRecruiter;
    private RelativeLayout mRelativeTop, mRelativeDetail, mRelativeFour;
    private TextView tvTitle, tvDetails;

    SimpleViewHolder(final View itemView) {
      super(itemView);
      imageviewMain = (ImageView) itemView.findViewById(R.id.mainImageView);
      imageViewCenter = (ImageView) itemView.findViewById(R.id.secondImageView);
      imageViewBottom = (ImageView) itemView.findViewById(R.id.imageViewBottom);
      tvTitle = (TextView) itemView.findViewById(R.id.tvTitle);
      tvDetails = (TextView) itemView.findViewById(R.id.tvDetails);
      tvCandidate = (TextView) itemView.findViewById(R.id.tvCandidate);
      tvRecruiter = (TextView) itemView.findViewById(R.id.tvRecruiter);
      mRelativeTop = (RelativeLayout) itemView.findViewById(R.id.relativeTop);
      mRelativeFour = (RelativeLayout) itemView.findViewById(R.id.relativeLayout);
      mRelativeDetail = (RelativeLayout) itemView.findViewById(R.id.relativeDetail);

      tvCandidate.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          getPrefs(mContext).save(QuickstartPreferences.USER_TYPE, Constants.CANDIDATE);
          launchActivity((TourActivity) itemView.getContext(), LandingScreen.class, true);
        }
      });

      tvRecruiter.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          getPrefs(mContext).save(QuickstartPreferences.USER_TYPE, Constants.RECRUITER);
          launchActivity((TourActivity) itemView.getContext(), LandingScreen.class, true);
        }
      });
    }
  }
}