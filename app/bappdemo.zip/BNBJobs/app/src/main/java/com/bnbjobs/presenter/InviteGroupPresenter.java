/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import com.bnbjobs.R;
import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.UserModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.EndlessRecyclerViewScrollListener;
import com.bnbjobs.view.InviteGroupView;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import rx.Subscriber;
import rx.Subscription;

import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class InviteGroupPresenter extends BasePresenter implements Presenter<InviteGroupView> {

  private InviteGroupView mInviteGroupView;
  private Subscription subscription;
  private int groupListCurrentPage;
  private int groupListTotalPages;
  private boolean groupListLoading;
  private EndlessRecyclerViewScrollListener mEndlessRecyclerViewScrollListener;
  private final int LOAD_MORE_START_INDEX = 3;
  @Override public void attachView(InviteGroupView view) {
    mInviteGroupView = view;
    final RecyclerView recyclerView = view.getRecyclerView();
    mEndlessRecyclerViewScrollListener = new EndlessRecyclerViewScrollListener(
        (GridLayoutManager) recyclerView.getLayoutManager()) {

      @Override public void onLoadMore(int page, int totalItemsCount) {
        InviteGroupPresenter.this.onLoadMore();
      }
    }.setVisibleThreshold(LOAD_MORE_START_INDEX);
    recyclerView.addOnScrollListener(mEndlessRecyclerViewScrollListener);
  }

  private void onLoadMore() {
    if (groupListCurrentPage < groupListTotalPages&& !groupListLoading) {
      getCandidates(groupListCurrentPage++);
    }
  }

  @Override public void detachView() {
    mInviteGroupView = null;
    if (subscription != null && !subscription.isUnsubscribed()) {
      subscription.unsubscribe();
    }
  }

  public void getCandidates(final int page) {

    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "search_candidate");
    String search = mInviteGroupView.getSearchString();
    boolean isSearch = !TextUtils.isEmpty(search);
    if (isSearch) {
      params.put("keyword", search);
    }
    params.put("radius", mInviteGroupView.getRadius());
    params.put("active_flag", mInviteGroupView.getActiveFlag());
    params.put("page", String.valueOf(page));
    if(page==1)
      mInviteGroupView.showProgress();
    params.putAll(addDefaultParamsWitLat(params));
    subscription = RestClient.getInstance(params).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        hideProgress();
        String error;
        if (e instanceof SocketTimeoutException) {
          error = getBaseContext().getString(R.string.error_timeout);
        } else {
          error = getBaseContext().getString(R.string.error_other);
        }
        showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
            getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
               getCandidates(page);
              }
            }).show();
      }

      @Override public void onNext(String s) {
        hideProgress();
        GsonBuilder builder = new GsonBuilder();
        Type collectionType = new TypeToken<BaseContainer<UserModel>>() {
        }.getType();
        BaseContainer<UserModel> jobSearchBaseContainer =  builder.create().fromJson(s, collectionType);
        groupListCurrentPage = jobSearchBaseContainer.getCurrentPage();
        groupListTotalPages = jobSearchBaseContainer.getTotalPages();
        mInviteGroupView.onSuccess(jobSearchBaseContainer.getDataList(),jobSearchBaseContainer.getCurrentPage()==1);
      }
    });
  }
  private void hideProgress() {
    if (mEndlessRecyclerViewScrollListener != null) {
      mEndlessRecyclerViewScrollListener.setLoading(false);
    }
    mInviteGroupView.hideProgress();
  }
  @Override protected Context getBaseContext() {
    return mInviteGroupView.getContext();
  }
}
