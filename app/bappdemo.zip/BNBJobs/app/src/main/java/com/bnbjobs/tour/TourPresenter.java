/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.tour;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import com.bnbjobs.customui.looppager.LoopRecyclerViewPager;
import com.bnbjobs.customui.looppager.RecyclerViewPager;
import com.bnbjobs.presenter.Presenter;

import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class TourPresenter implements Presenter<TourView> {

  private static final String TAG = makeLogTag(TourPresenter.class);
  private TourView tourView;
  private LoopRecyclerViewPager mRecyclerViewPager;

  @Override public void attachView(TourView view) {
    tourView = view;
  }

  @Override public void detachView() {
    tourView = null;
    mRecyclerViewPager = null;
  }

  public void setUpRecyclePager(LoopRecyclerViewPager mRecyclerView) {
    this.mRecyclerViewPager = mRecyclerView;
    this.mRecyclerViewPager.addOnScrollListener(new RecyclerView.OnScrollListener() {
      @Override public void onScrollStateChanged(RecyclerView recyclerView, int scrollState) {
      }

      @Override public void onScrolled(RecyclerView recyclerView, int i, int i2) {
        // mPositionText.setText("First: " + mRecyclerViewPager.getFirstVisiblePosition());

        int childCount = mRecyclerViewPager.getChildCount();
        int width = mRecyclerViewPager.getChildAt(0).getWidth();
        int padding = (mRecyclerViewPager.getWidth() - width) / 2;
        for (int j = 0; j < childCount; j++) {
          View v = recyclerView.getChildAt(j);
          //From left padding to - (v.getWidth () - padding) process, descending
          float rate = 0;
          if (v.getLeft() <= padding) {
            if (v.getLeft() >= padding - v.getWidth()) {
              rate = (padding - v.getLeft()) * 1f / v.getWidth();
              v.setAlpha(1f);
            } else {
              rate = 1;
            }
            //v.setScaleX(1 + rate * 0.1f);
            v.setScaleY(1 - rate * 0.1f);
          } else {
            //Right from padding to recyclerView.getWidth () - padding process, descending
            if (v.getLeft() <= recyclerView.getWidth() - padding) {
              rate = (recyclerView.getWidth() - padding - v.getLeft()) * 1f / v.getWidth();
              v.setAlpha(1f);
            }
            //v.setScaleX(2.0f + rate * 0.1f);
            v.setScaleY(0.9f + rate * 0.1f);
          }
        }
      }
    });
    mRecyclerViewPager.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
      @Override
      public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft,
          int oldTop, int oldRight, int oldBottom) {
        if (mRecyclerViewPager.getChildCount() < 3) {
          if (mRecyclerViewPager.getChildAt(1) != null) {
            View v1 = mRecyclerViewPager.getChildAt(1);
            v1.setScaleY(0.9f);
          }
        } else {
          if (mRecyclerViewPager.getChildAt(0) != null) {
            View v0 = mRecyclerViewPager.getChildAt(0);
            v0.setScaleY(0.9f);
          }
          if (mRecyclerViewPager.getChildAt(2) != null) {
            View v2 = mRecyclerViewPager.getChildAt(2);

            v2.setScaleY(0.9f);
          }
        }
      }
    });

    mRecyclerViewPager.addOnPageChangedListener(new RecyclerViewPager.OnPageChangedListener() {
      @Override public void OnPageChanged(int oldPosition, int newPosition) {
        if (tourView != null) {
          tourView.setIndicator(newPosition % 4);
        }
      }
    });
  }
}
