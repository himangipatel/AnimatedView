/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.widget.EditText;
import com.bnbjobs.R;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.CandidateContainer;
import com.bnbjobs.model.CandidateModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.view.HomeRecruiterView;
import com.google.android.gms.maps.model.LatLng;
import com.google.gson.Gson;
import com.jakewharton.rxbinding.widget.RxTextView;
import com.jakewharton.rxbinding.widget.TextViewTextChangeEvent;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class HomeRecruiterPresenter extends BasePresenter implements Presenter<HomeRecruiterView> {

  private static final String TAG = makeLogTag(HomeRecruiterPresenter.class);
  private static final int REGULAR_TYPE = 1;
  private static final int PULL_TYPE = 2;
  private static final  int SEARCH_TYPE = 3;
  private boolean loadMore;
  private HomeRecruiterView mHomeRecruiterView;
  private Fragment fragment;
  private int page = 1;
  private static final int PER_PAGE = 10;
  private static final int SIZE = 10;
  private Subscription subscription;
  private int requestType;
  private String searchText;
  private boolean showProgress = true;
  private String filter = "";
  private String designationId;
  private boolean isSearchDetail;
  private double lat;
  private double lng;
  private int limit;

  @Override public void attachView(HomeRecruiterView view) {
    mHomeRecruiterView = view;
  }

  @Override public void detachView() {
    if (subscription != null && !subscription.isUnsubscribed()) {
      subscription.unsubscribe();
    }
    mHomeRecruiterView = null;
  }

  public void resetRequest(int requestType) {
    this.requestType = requestType;
    page = 1;
    loadMore = false;
    showProgress = false;
    getCandidates(requestType);
  }

  public void getCandidates(int requestType) {
    this.requestType = requestType;
    if (showProgress) {
      mHomeRecruiterView.showProgress();
    }
    HashMap<String, String> params = new HashMap<>(15);
    params.put("apiName", "getAllCandidates");
    params.put("perPage", String.valueOf(PER_PAGE));
    if (loadMore) {
      params.put("page", String.valueOf(page));
    }
    if (requestType == SEARCH_TYPE || !isEmpty(searchText)) {
      params.put("userName", searchText);
    }
    params.putAll(addDefaultParamsWitLat(params));
    if (isSearchDetail) {
      params.put("designationId", designationId);
      params.put("latitude", Double.toString(lat));
      params.put("longitude", Double.toString(lng));
    } else {
      params.put("designationId", filter);
    }
    mHomeRecruiterView.loadMore(false);
    if (subscription != null && !subscription.isUnsubscribed()) {
      subscription.unsubscribe();
    }
    subscription =
        RestClient.getInstance(params).compose(getBindEvent()).subscribe(getSubscriber());
  }

  private Subscriber<String> getSubscriber() {
    if (!isNotNull()) {
      return getEmpty();
    }
    if (requestType == REGULAR_TYPE) {
      return getRegularResponse();
    } else if (requestType == PULL_TYPE) {
      return pullToSubscribe();
    } else {
      return searchSubscriber();
    }
  }

  public void setSearchDetail(Bundle bundle) {
    if (bundle != null) {
      isSearchDetail = true;
      LatLng latLng = bundle.getParcelable(Constants.KEY_POSITION);
      if (latLng != null) {
        lat = latLng.latitude;
        lng = latLng.longitude;
      }
      designationId = bundle.getString(Constants.KEY_ID);
    }
  }

  private Subscriber<String> getEmpty() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
      }

      @Override public void onNext(String s) {
      }
    };
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).<String>bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  private boolean isNotNull() {
    return mHomeRecruiterView != null;
  }

  private Subscriber<String> getRegularResponse() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mHomeRecruiterView.hideProgress();
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        showProgress = false;
        CandidateContainer candidateContainer = new Gson().fromJson(s, CandidateContainer.class);
        setData(candidateContainer);
      }
    };
  }

  private Subscriber<String> searchSubscriber() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mHomeRecruiterView.hideProgress();
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        CandidateContainer candidateContainer = new Gson().fromJson(s, CandidateContainer.class);
        setData(candidateContainer);
      }
    };
  }

  private Subscriber<String> pullToSubscribe() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mHomeRecruiterView.hideProgress();
        if(e.getMessage()!=null)
        mHomeRecruiterView.onError(e.getMessage());
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        mHomeRecruiterView.hideProgress();
        CandidateContainer candidateContainer = new Gson().fromJson(s, CandidateContainer.class);
        setData(candidateContainer);
      }
    };
  }

  private void setData(CandidateContainer container) {
    if (container.isSuccess()) {
      page = container.getCurrentPage() + 1;
      loadMore = container.getTotalPage() != container.getCurrentPage();
      mHomeRecruiterView.loadMore(loadMore);
      setUpData(container.getCandidateModelList(),container.getCurrentPage());
    } else {
      mHomeRecruiterView.hideProgress();
      loadMore = false;
      mHomeRecruiterView.loadMore(false);
      mHomeRecruiterView.setAdapter(new ArrayList<CandidateModel>(),true);
    }
  }

  private void setUpData(List<CandidateModel> models, final int page) {
    Observable.just(models)
        .map(new Func1<List<CandidateModel>, List<CandidateModel>>() {
          @Override public List<CandidateModel> call(List<CandidateModel> candidateModels) {
            List<CandidateModel> mList = new ArrayList<>();
            for (CandidateModel model : candidateModels) {
              model.setAddress(getAddress(model.getuLat(), model.getuLng()));
              model.setDistance(getKm(Double.parseDouble(model.getDistance())));
              mList.add(model);
            }
            return mList;
          }
        })
        .subscribeOn(Schedulers.io())
        .compose(((BaseFragment) fragment).<List<CandidateModel>>bindUntilEvent(FragmentEvent.DESTROY_VIEW))
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<List<CandidateModel>>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            if (!isNotNull()) {
              return;
            }
            mHomeRecruiterView.hideProgress();
            LOGE(TAG, e.getMessage(), e);
          }

          @Override public void onNext(List<CandidateModel> candidateModels) {
            if (!isNotNull()) {
              return;
            }
            mHomeRecruiterView.hideProgress();
            mHomeRecruiterView.setAdapter(candidateModels,page ==1);
          }
        });
  }

  public void onSearch(final EditText editText) {
    RxTextView.textChangeEvents(editText)
        .debounce(400, TimeUnit.MILLISECONDS)
        .observeOn(AndroidSchedulers.mainThread())
        .compose(((BaseFragment) fragment).<TextViewTextChangeEvent>bindUntilEvent(
            FragmentEvent.DESTROY_VIEW))
        .subscribe(new Subscriber<TextViewTextChangeEvent>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
          }

          @Override public void onNext(TextViewTextChangeEvent textViewTextChangeEvent) {
            if (!isNotNull()) {
              return;
            }
            searchText = String.valueOf(textViewTextChangeEvent.text());
            if (!editText.hasFocus()) {
              return;
            }
            page = 1;
            loadMore = false;
            showProgress = true;
            mHomeRecruiterView.clearData();
            if (isEmpty(searchText)) {
              getCandidates(REGULAR_TYPE);
            } else {
              getCandidates(SEARCH_TYPE);
            }
          }
        });
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(final Throwable e) {
    String error = "";
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            getCandidates(requestType);
          }
        }).show();
  }

  public void setFilterString(String filter) {
    this.filter = filter;
  }

  @Override protected Context getBaseContext() {
    return mHomeRecruiterView.getContext();
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }

  public void getFavoriteList(final boolean pullRefresh) {
    if (!loadMore) {
      mHomeRecruiterView.showSmallProgress(true);
    }
    HashMap<String, String> params = new HashMap<>(9);
    params.put("apiName", "recruiterDashboardCandidateLoadMore");
    params.put("loadMoreTab", "4");
    if(pullRefresh)
    params.put("page", "0");
    else
    params.put("page", mHomeRecruiterView.getOffset());
    if(pullRefresh)
      limit = 0;
    limit += 10;
    params.put("perPage", Integer.toString(limit));
    params.putAll(addDefaultParamsWitLat(params));
    RestClient.getInstance(params)
        .compose(getBindEvent())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            mHomeRecruiterView.showSmallProgress(false);
          }

          @Override public void onNext(String s) {
            mHomeRecruiterView.showSmallProgress(false);
            CandidateContainer candidateContainer = new Gson().fromJson(s, CandidateContainer.class);
            loadMore = candidateContainer.getCandidateModelList().size() == SIZE;
            mHomeRecruiterView.setLoadMore(loadMore);
            if (candidateContainer.isSuccess()) {
              mHomeRecruiterView.setFavAdapter(candidateContainer.getCandidateModelList(),pullRefresh || Integer.parseInt(mHomeRecruiterView.getOffset())==0);
            } else {
              showDialogMessage(candidateContainer.getMessage());
            }
          }
        });
  }

  public void favoriteCandidate(final CandidateModel model) {
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "favoriteCandidate");
    params.putAll(addParams(params));
    params.put("candidateId", model.getuId());
    RestClient.getInstance(params).compose(bindEvent(fragment)).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        mHomeRecruiterView.hideProgress();
        LOGE(TAG, e.getMessage(), e);
        String error;
        if (e instanceof SocketTimeoutException) {
          error = getBaseContext().getString(R.string.error_timeout);
        } else {
          error = getBaseContext().getString(R.string.error_other);
        }
        showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
            getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                favoriteCandidate(model);
              }
            }).show();
      }

      @Override public void onNext(String s) {
        mHomeRecruiterView.hideProgress();
        JSONObject object;
        String msg="";
        try {
          object = new JSONObject(s);
          msg = object.optString("message");
        } catch (JSONException e) {
          e.printStackTrace();
        }
        if (isResponseSuccess(s)) {
          model.setFavorite(model.isFavorite()?0:1); // reverse
          mHomeRecruiterView.changeFavoriteStatus(model);
        }else{
          mHomeRecruiterView.onError(msg);
        }

        //EventBus.getDefault().post(new UpdateFavorite(favoriteFlag));
      }
    });
  }
}
