/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

/**
 * @author Harsh
 * @version 1.0
 */
public interface RegisterView extends MainView {

  void onRegister();

  void showProgress();

  void hideProgress();
}
