/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.ImageModel;
import com.bumptech.glide.Glide;
import java.io.File;
import java.util.List;

import static com.bnbjobs.R.id.iv_profile_photos;
import static com.bnbjobs.R.id.rel_profile_photos;

/**
 * @author Harsh
 * @version 1.0
 */
public class OfferImagesAdapter extends RecyclerView.Adapter<OfferImagesAdapter.MyViewHolder> {

  private final Context mContext;
  private final ClickImpl<ImageModel> clickImpl;
  private List<ImageModel> imageModelList;
  private boolean isAddImage;
  private boolean edit;

  public OfferImagesAdapter(Context mContext, List<ImageModel> imageModelList, Fragment fragment) {
    this.mContext = mContext;
    this.imageModelList = imageModelList;
    this.clickImpl = (ClickImpl<ImageModel>) fragment;
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.photo_item_inflater, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {

    if (isAddImage && position == imageModelList.size()) {
      holder.linearRemove.setVisibility(View.GONE);
      holder.ivProfilePhotos.setImageResource(R.drawable.add_photo);
    } else {
      if (imageModelList.get(position).isEdit()) {
        holder.linearRemove.setVisibility(View.VISIBLE);
      } else {
        holder.linearRemove.setVisibility(View.GONE);
      }
      if (!TextUtils.isEmpty(imageModelList.get(position).getImageThumbUrl())
          && imageModelList.get(
          position).getImageThumbUrl().startsWith("http")) {
        Glide.with(mContext)
            .load(imageModelList.get(position).getImageThumbUrl())
            .error(R.drawable.add_photo)
            .placeholder(R.drawable.add_photo)
            .dontAnimate()
            .fitCenter()
            .into(holder.ivProfilePhotos);
      } else {
        File file = new File(imageModelList.get(position).getImage());
        Uri imageUri = Uri.fromFile(file);
        Glide.with(mContext)
            .load(imageUri)
            .error(R.drawable.add_photo)
            .placeholder(R.drawable.add_photo)
            .dontAnimate()
            .fitCenter()
            .into(holder.ivProfilePhotos);
      }
    }
  }

  @Override public int getItemCount() {
    isAddImage = imageModelList.size() < 4;
    if (isAddImage) {
      return imageModelList.size() + 1;
    } else {
      return imageModelList.size();
    }
  }

  public void setEdit(boolean edit) {
    this.edit = edit;
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {
    @BindView(iv_profile_photos) ImageView ivProfilePhotos;
    @BindView(R.id.imageRemove) ImageView imageRemove;
    @BindView(R.id.linearRemove) LinearLayout linearRemove;
    @BindView(rel_profile_photos) RelativeLayout relProfilePhotos;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
    }

    @OnClick({ R.id.imageRemove, R.id.iv_profile_photos }) void onItemClick(View view) {
      if (!edit) return;
      if (view.getId() == R.id.imageRemove) {
        clickImpl.onClick(view, imageModelList.get(getLayoutPosition()), getLayoutPosition());
      } else {
        clickImpl.onClick(view, new ImageModel(), getLayoutPosition());
      }
    }
  }
}
