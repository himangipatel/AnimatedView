/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnEditorAction;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.adapter.InviteAdapter;
import com.bnbjobs.adapter.InviteFbAdapter;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.fragments.InviteFragment;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.FbFriends;
import com.bnbjobs.model.InviteModel;
import com.bnbjobs.model.LandingEvent;
import com.bnbjobs.presenter.InvitePresenter;
import com.bnbjobs.services.DesignationService;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.InviteView;
import com.facebook.share.model.AppInviteContent;
import com.facebook.share.widget.AppInviteDialog;
import com.jakewharton.rxbinding.widget.TextViewTextChangeEvent;
import java.util.ArrayList;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnNeverAskAgain;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.ActivityUtils.launchActivity;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.hasMarshmallow;

/**
 * @author Harsh
 * @version 1.0
 */
@RuntimePermissions public class InviteActivity extends BaseActivity
    implements InviteView, ClickImpl<InviteModel> {

  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.imageCenterLogo) ImageView imageCenterLogo;
  @BindView(R.id.etSearch) EditText etSearch;
  @BindView(R.id.recyclerView) RecyclerView recyclerView;
  @BindView(R.id.relativeSearch) RelativeLayout relativeSearch;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.linearSearch) LinearLayout linearSearch;
  @BindView(R.id.inviteFb) ImageView inviteFb;
  private String TAG = makeLogTag(InviteActivity.class);
  private InviteAdapter mAdapter;
  private List<InviteModel> mInviteModelList = new ArrayList<>();
  private InvitePresenter presenter;
  private int inviteFrom = 0;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_invite);
    ButterKnife.bind(this);
    //start service for designation
    startService(new Intent(this, DesignationService.class));
    EventBus.getDefault().post(new LandingEvent(true));
    presenter = new InvitePresenter();
    presenter.attachView(this);
    recyclerView.setLayoutManager(new LinearLayoutManager(this));
    imageCenterLogo.setVisibility(View.VISIBLE);
    Bundle bundle = getIntent().getExtras();
    if (bundle != null) {
      inviteFrom = bundle.getInt(Constants.INVITE_FRIENDS_FROM, 0);
    }
    EventBus.getDefault().post(new LandingEvent(true));
    presenter = new InvitePresenter();
    presenter.attachView(this);
    recyclerView.setLayoutManager(new LinearLayoutManager(this));
    imageCenterLogo.setVisibility(View.VISIBLE);
    if (inviteFrom == 0) {
      new Handler().postDelayed(new Runnable() {
        @Override public void run() {
          InviteFragment inviteFragment = new InviteFragment();
          Bundle bundle = new Bundle();
          bundle.putInt(Constants.KEY_DIALOG_TYPE, Constants.INVITE_IMAGE_TICK);
          inviteFragment.setArguments(bundle);
          inviteFragment.show(getSupportFragmentManager(), InviteFragment.class.getCanonicalName());
        }
      }, 500);
    }
    if (inviteFrom != 0) {
      if (inviteFrom == Constants.INVITE_FRIENDS_FROM_CONTACT) {
        showContact();
      } else {
        linearProgress.setVisibility(View.GONE);
        linearSearch.setVisibility(View.GONE);
        inviteFb.setVisibility(View.VISIBLE);
        presenter.getFriendsList();
      }
    } else {
      if (getPrefs(this).getBoolean(QuickstartPreferences.IS_NORMAL_USER, true)) {
        showContact();
      } else {
        linearProgress.setVisibility(View.GONE);
        linearSearch.setVisibility(View.GONE);
        inviteFb.setVisibility(View.VISIBLE);
        presenter.getFriendsList();
      }
    }
    recyclerView.setOnTouchListener(new View.OnTouchListener() {
      @Override public boolean onTouch(View v, MotionEvent event) {
        if (etSearch.hasFocus()) {
          clearFocus();
        }
        return false;
      }
    });
  }

  private void showContact() {
    mAdapter = new InviteAdapter(this);
    mAdapter.setAdapter(mInviteModelList);
    recyclerView.setAdapter(mAdapter);
    linearProgress.setVisibility(View.VISIBLE);
    presenter.onSearchText(etSearch);
    if (!hasMarshmallow() || inviteFrom != 0) {
      checkPermission();
    }
  }

  public void scrollToFirst() {
    recyclerView.smoothScrollToPosition(0);
  }

  @Override protected void onDestroy() {
    presenter.detachView();
    super.onDestroy();
  }

  @OnClick(R.id.imageBack) void onBack() {
    if (inviteFrom != 0) {
      super.onBackPressed();
    } else {
      launchActivity(this, HomeActivity.class, true);
    }
  }

  @OnClick(R.id.inviteFb) void onFbInvite() {
    if (AppInviteDialog.canShow()) {
      //// TODO: 6/1/17  change icon
      AppInviteContent content =
          new AppInviteContent.Builder().setApplinkUrl("https://fb.me/1146829332042850")
              .setPreviewImageUrl("https://lh4.ggpht.com/qUs2_ntWQrWgNElAdHNVNpK_P4xuhPbX8WOcncUS0f5yQVdYtrGH9xit_aBkgwCz0mA=w300")
              .build();
      AppInviteDialog.show(this, content);
    }
  }

  private void clearFocus() {
    etSearch.clearFocus();
    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.hideSoftInputFromWindow(etSearch.getWindowToken(), 0);
  }

  @OnEditorAction(R.id.etSearch) boolean onSearchPress(TextView v, int actionId, KeyEvent event) {
    if (actionId == EditorInfo.IME_ACTION_SEARCH) {
      clearFocus();
      return true;
    }
    return false;
  }

  @Override public void onBackPressed() {
    onBack();
  }

  @NeedsPermission(Manifest.permission.READ_CONTACTS) void getContacts() {
    presenter.getContacts();
  }

  @OnShowRationale(Manifest.permission.READ_CONTACTS) void showRationaleForContact(
      final PermissionRequest request) {
    Utils.showDialog(this, getString(R.string.alert),
        getString(R.string.permission_location_rationale), getString(R.string.button_allow),
        getString(R.string.button_deny), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.proceed();
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.cancel();
          }
        }).show();
  }

  @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
      @NonNull int[] grantResults) {
    InviteActivityPermissionsDispatcher.onRequestPermissionsResult(this, requestCode, grantResults);
  }

  @OnPermissionDenied(Manifest.permission.READ_CONTACTS) void showDeniedForLocation() {
    hideProgress();
    showPermissionDialog();
  }

  @OnNeverAskAgain(Manifest.permission.READ_CONTACTS) void showNeverAskForLocation() {
    hideProgress();
    showPermissionDialog();

  }

  private void showPermissionDialog() {
    Utils.showDialog(this, getString(R.string.alert),
        getString(R.string.permission_contact_never_askagain), getString(android.R.string.ok),
        new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }

  @Override public void checkPermission() {
    InviteActivityPermissionsDispatcher.getContactsWithCheck(this);
  }

  @Override public void setAdapter(@NonNull List<InviteModel> mInviteModelList) {
    this.mInviteModelList.addAll(mInviteModelList);
    mAdapter.setOriginalList(mInviteModelList);
    mAdapter.setAdapter(mInviteModelList);
  }

  @Override public void onContactSearch(TextViewTextChangeEvent textViewTextChangeEvent) {
    if (isEmpty(textViewTextChangeEvent.text())) {
      mAdapter.setAdapter(mInviteModelList);
    } else {
      mAdapter.getFilter().filter(Utils.getText(etSearch));
    }
  }

  @Override public void showFbFriends(List<FbFriends.FbFriendsList> fbFriendsLists) {
    if (fbFriendsLists.isEmpty()) {
      recyclerView.setAdapter(new InviteFbAdapter(this, fbFriendsLists));
    }
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void onClick(View view, InviteModel object, int position) {
    String uri = "smsto:" + object.getPhoneNumber();
    Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse(uri));
    intent.putExtra("sms_body","Hi, Please download this app: market://details?id=" + getPackageName());
    intent.putExtra("compose_mode", true);
    startActivity(intent);
  }
}
