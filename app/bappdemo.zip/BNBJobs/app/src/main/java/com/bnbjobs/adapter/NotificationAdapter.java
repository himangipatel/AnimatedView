/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.CircleImageView;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.NotificationModel;
import com.bnbjobs.utils.Constants;
import com.bumptech.glide.Glide;
import java.util.Calendar;
import java.util.List;

import static com.bnbjobs.main.AppClass.getPrefs;

/**
 * @author Harsh
 * @version 1.0
 */
public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.MyViewHolder> {

  private Context mContext;
  private List<NotificationModel> mNotificationModelList;
  private Calendar calendar;
  private ClickImpl mClick;

  public NotificationAdapter(Context mContext, List<NotificationModel> mNotificationModelList,
      Fragment fragment) {
    this.mContext = mContext;
    this.mNotificationModelList = mNotificationModelList;
    calendar = Calendar.getInstance();
    mClick = (ClickImpl) fragment;
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.adapter_notification, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {
    Glide.with(mContext)
        .load(mNotificationModelList.get(position).getImageThumbUrl())
        .placeholder(R.drawable.user_placeholder)
        .dontAnimate()
        .into(holder.imgNotification);
    holder.tvNotificationTitle.setText(
        Html.fromHtml(mNotificationModelList.get(position).getTitileNotification(mContext)));
    holder.tvNotificationDetail.setText(mNotificationModelList.get(position).getText());
    if (isCandidate()) {
      if (mNotificationModelList.get(position).getNotification() == 1) { // 1 for accept candidate
        holder.linearChat.setVisibility(View.VISIBLE);
      } else {
        holder.linearChat.setVisibility(View.GONE);
      }
    } else {
      if (mNotificationModelList.get(position).getNotification() == 3) { // 3 for accept Recruiter
        holder.linearChat.setVisibility(View.VISIBLE);
      } else {
        holder.linearChat.setVisibility(View.GONE);
      }
    }
    //Dans in
    Long current = Long.parseLong(mNotificationModelList.get(position).getCreatedAt()) * 1000;
    String time = DateUtils.getRelativeTimeSpanString(current, calendar.getTimeInMillis(),
        DateUtils.SECOND_IN_MILLIS, DateUtils.FORMAT_NO_NOON).toString();
    //String time = getRelativeTimeSpanString((Long.parseLong(mNotificationModelList.get(position).getCreatedAt())) * 1000).toString();
    holder.tvTime.setText(time);
  }

  private boolean isCandidate() {
    return getPrefs(mContext).getString(QuickstartPreferences.USER_TYPE, "")
        .equalsIgnoreCase(Constants.CANDIDATE);
  }

  @Override public int getItemCount() {
    return mNotificationModelList.size();
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.imgNotification) CircleImageView imgNotification;
    @BindView(R.id.tvNotificationTitle) TextView tvNotificationTitle;
    @BindView(R.id.tvNotificationDetail) TextView tvNotificationDetail;
    @BindView(R.id.tvTime) TextView tvTime;
    @BindView(R.id.linearChat) LinearLayout linearChat;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
      itemView.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          if (mNotificationModelList.get(getLayoutPosition()).getOfferId() != 0) {
            mClick.onClick(v, mNotificationModelList.get(getLayoutPosition()), getLayoutPosition());
          }
        }
      });
    }
  }
}
