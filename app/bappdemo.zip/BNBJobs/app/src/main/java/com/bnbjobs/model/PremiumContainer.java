/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by jay shah on 2/8/16.
 */
public class PremiumContainer {

  private boolean success;
  private String message;

  @SerializedName("data") private PremiumDataModel premiumDataModel;

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public PremiumDataModel getPremiumDataModel() {
    return premiumDataModel;
  }

  public void setPremiumDataModel(PremiumDataModel premiumDataModel) {
    this.premiumDataModel = premiumDataModel;
  }
}

