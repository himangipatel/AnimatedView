/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.activity.DesignationActivity;
import com.bnbjobs.model.DesignationModel;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class DesignationAdapter extends RecyclerView.Adapter<DesignationAdapter.MyViewHolder>
    implements Filterable {

  private Context mContext;
  private List<DesignationModel> designationModelList;
  private List<DesignationModel> mOriginalList;

  public DesignationAdapter(Context mContext) {
    this.mContext = mContext;
  }

  public void setOriginalList(List<DesignationModel> mOriginalList) {
    this.mOriginalList = mOriginalList;
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.inflater_designation, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {
    holder.tvSuggestion.setText(designationModelList.get(position).getD_title());
  }

  public void setAdapter(List<DesignationModel> mInviteModelList) {
    this.designationModelList = mInviteModelList;
    notifyDataSetChanged();
  }

  @Override public int getItemCount() {
    return designationModelList.size();
  }

  @Override public Filter getFilter() {
    return new UserFilter(this, mOriginalList);
  }

  private static class UserFilter extends Filter {
    private final DesignationAdapter adapter;
    private final List<DesignationModel> originalList;
    private final List<DesignationModel> filteredList;
    private List<DesignationModel> mFilterInviteModelList;

    private UserFilter(DesignationAdapter adapter, List<DesignationModel> originalList) {
      super();
      this.adapter = adapter;
      this.originalList = new LinkedList<>(originalList);
      filteredList = new ArrayList<>();
      mFilterInviteModelList = new ArrayList<>();
    }

    @Override protected FilterResults performFiltering(CharSequence constraint) {
      filteredList.clear();
      final FilterResults results = new FilterResults();

      if (constraint.length() == 0) {
        filteredList.addAll(originalList);
      } else {
        String filterPattern = constraint.toString().toLowerCase().trim();
        for (DesignationModel user : originalList) {
          if (user.getD_title().toLowerCase().contains(filterPattern)) {
            filteredList.add(user);
          }
        }
      }
      results.values = filteredList;
      results.count = filteredList.size();
      return results;
    }

    @Override protected void publishResults(CharSequence constraint, FilterResults results) {
      mFilterInviteModelList.clear();
      mFilterInviteModelList.addAll(((ArrayList<DesignationModel>) results.values));
      adapter.setAdapter(mFilterInviteModelList);
      ((DesignationActivity) adapter.mContext).scrollToFirst();
    }
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {
    @BindView(R.id.tvSuggestion) TextView tvSuggestion;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);

      itemView.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          ((DesignationActivity) mContext).onUpdate(
              designationModelList.get(getLayoutPosition()).getD_id());
        }
      });
    }
  }
}
