/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by jay shah on 2/8/16.
 */
public class PremiumDataModel {

  @SerializedName("p_id") private int premiumId;
  @SerializedName("p_1_week") private String priceOneWeek;
  @SerializedName("p_2_week") private String priceTwoWeek;
  @SerializedName("p_monthly") private String priceMonthly;
  @SerializedName("p_yearly") private String priceYearly;
  @SerializedName("p_plan_type") private int planType;
  @SerializedName("p_status") private int planStatus;
  @SerializedName("p_created_at") private String planCreatedAt;
  @SerializedName("p_updated_at") private String planUpdatedAt;

  public int getPremiumId() {
    return premiumId;
  }

  public void setPremiumId(int premiumId) {
    this.premiumId = premiumId;
  }

  public String getPriceOneWeek() {
    return priceOneWeek;
  }

  public void setPriceOneWeek(String priceOneWeek) {
    this.priceOneWeek = priceOneWeek;
  }

  public String getPriceTwoWeek() {
    return priceTwoWeek;
  }

  public void setPriceTwoWeek(String priceTwoWeek) {
    this.priceTwoWeek = priceTwoWeek;
  }

  public String getPriceMonthly() {
    return priceMonthly;
  }

  public void setPriceMonthly(String priceMonthly) {
    this.priceMonthly = priceMonthly;
  }

  public String getPriceYearly() {
    return priceYearly;
  }

  public void setPriceYearly(String priceYearly) {
    this.priceYearly = priceYearly;
  }

  public int getPlanType() {
    return planType;
  }

  public void setPlanType(int planType) {
    this.planType = planType;
  }

  public int getPlanStatus() {
    return planStatus;
  }

  public void setPlanStatus(int planStatus) {
    this.planStatus = planStatus;
  }

  public String getPlanCreatedAt() {
    return planCreatedAt;
  }

  public void setPlanCreatedAt(String planCreatedAt) {
    this.planCreatedAt = planCreatedAt;
  }

  public String getPlanUpdatedAt() {
    return planUpdatedAt;
  }

  public void setPlanUpdatedAt(String planUpdatedAt) {
    this.planUpdatedAt = planUpdatedAt;
  }
}
