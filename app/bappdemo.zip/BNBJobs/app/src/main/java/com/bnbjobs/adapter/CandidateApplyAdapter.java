/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.JobApplyModel;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class CandidateApplyAdapter
    extends RecyclerView.Adapter<CandidateApplyAdapter.MyViewHolder> {


  private List<JobApplyModel> mJobApplyModels;
  private ClickImpl mClick;
  private Spanned message;

  public CandidateApplyAdapter(Context context, List<JobApplyModel> jobApplyModels,
      Fragment fragment) {
    mJobApplyModels = jobApplyModels;
    mClick = (ClickImpl) fragment;
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.adapter_apply_candidate, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {
    holder.mTvRecruiterMessage.setText(message);
    holder.mTvDesignationTitle.setText("\"" + mJobApplyModels.get(position).getdTitle() + "\"");
  }

  @Override public int getItemCount() {
    return mJobApplyModels.size();
  }

  public void setMessage(Spanned message) {
    this.message = message;
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.tvRecruiterMessage) TextView mTvRecruiterMessage;
    @BindView(R.id.tvDesignationTitle) TextView mTvDesignationTitle;
    @BindView(R.id.ivReject) ImageView mIvReject;
    @BindView(R.id.ivAccept) ImageView mIvAccept;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
    }

    @OnClick({ R.id.ivAccept, R.id.ivReject }) void onApply(View v) {
      mClick.onClick(v, mJobApplyModels.get(getLayoutPosition()), getLayoutPosition());
    }
  }
}
