/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class GroupModel implements Parcelable{
  @SerializedName("distance")
  private double distance;
  @SerializedName("g_id")
  private int gId;
  @SerializedName("g_title")
  private String title;
  @SerializedName("g_location")
  private String location;
  @SerializedName("g_latitude")
  private String lat;
  @SerializedName("g_longitude")
  private String lng;
  @SerializedName("g_start_time")
  private String startTime;
  @SerializedName("g_end_time")
  private String endTime;
  @SerializedName("g_max_member")
  private int maxMember;
  @SerializedName("u_id")
  private int uId;
  @SerializedName("u_fname")
  private String uFname;
  @SerializedName("g_description")
  private String gDescription;
  @SerializedName("u_lname")
  private String uLname;
  @SerializedName("total_member")
  private int totalMember;
  @SerializedName("member_flag")
  private int member_flag;
  @SerializedName("g_image_url")
  private String groupImageUrl;
  @SerializedName("g_image_thumb_url")
  private String groupThumbImageUrl;
  @SerializedName("u_image_url")
  private String uImageUrl;
  @SerializedName("u_image_thumb_url")
  private String uThumbImageUrl;
  @SerializedName("invited_user_data")
  private List<UserModel> userModels;

  private boolean showAdd;
  protected GroupModel(Parcel in) {
    distance = in.readDouble();
    gId = in.readInt();
    title = in.readString();
    location = in.readString();
    lat = in.readString();
    lng = in.readString();
    startTime = in.readString();
    endTime = in.readString();
    maxMember = in.readInt();
    uId = in.readInt();
    uFname = in.readString();
    gDescription = in.readString();
    uLname = in.readString();
    totalMember = in.readInt();
    member_flag = in.readInt();
    groupImageUrl = in.readString();
    groupThumbImageUrl = in.readString();
    uImageUrl = in.readString();
    uThumbImageUrl = in.readString();
    userModels = in.createTypedArrayList(UserModel.CREATOR);
    showAdd = in.readByte() != 0;
  }

  public static final Creator<GroupModel> CREATOR = new Creator<GroupModel>() {
    @Override public GroupModel createFromParcel(Parcel in) {
      return new GroupModel(in);
    }

    @Override public GroupModel[] newArray(int size) {
      return new GroupModel[size];
    }
  };

  public GroupModel(boolean showAdd) {
    this.showAdd = showAdd;
  }

  public GroupModel() {
  }

  public String getgDescription() {
    return gDescription;
  }

  public void setgDescription(String gDescription) {
    this.gDescription = gDescription;
  }

  public List<UserModel> getUserModels() {
    return userModels;
  }

  public void setUserModels(List<UserModel> userModels) {
    this.userModels = userModels;
  }

  public double getDistance() {
    return distance;
  }

  public void setDistance(double distance) {
    this.distance = distance;
  }

  public int getgId() {
    return gId;
  }

  public void setgId(int gId) {
    this.gId = gId;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public String getLat() {
    return lat;
  }

  public void setLat(String lat) {
    this.lat = lat;
  }

  public String getLng() {
    return lng;
  }

  public void setLng(String lng) {
    this.lng = lng;
  }

  public String getStartTime() {
    return startTime;
  }

  public void setStartTime(String startTime) {
    this.startTime = startTime;
  }

  public String getEndTime() {
    return endTime;
  }

  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }

  public int getMaxMember() {
    return maxMember;
  }

  public void setMaxMember(int maxMember) {
    this.maxMember = maxMember;
  }

  public int getuId() {
    return uId;
  }

  public void setuId(int uId) {
    this.uId = uId;
  }

  public String getuFname() {
    return uFname;
  }

  public void setuFname(String uFname) {
    this.uFname = uFname;
  }

  public String getuLname() {
    return uLname;
  }

  public void setuLname(String uLname) {
    this.uLname = uLname;
  }

  public int getTotalMember() {
    return totalMember;
  }

  public void setTotalMember(int totalMember) {
    this.totalMember = totalMember;
  }

  public String getGroupImageUrl() {
    return groupImageUrl;
  }

  public void setGroupImageUrl(String groupImageUrl) {
    this.groupImageUrl = groupImageUrl;
  }

  public String getGroupThumbImageUrl() {
    return groupThumbImageUrl;
  }

  public void setGroupThumbImageUrl(String groupThumbImageUrl) {
    this.groupThumbImageUrl = groupThumbImageUrl;
  }

  public String getuImageUrl() {
    return uImageUrl;
  }

  public void setuImageUrl(String uImageUrl) {
    this.uImageUrl = uImageUrl;
  }

  public String getuThumbImageUrl() {
    return uThumbImageUrl;
  }

  public void setuThumbImageUrl(String uThumbImageUrl) {
    this.uThumbImageUrl = uThumbImageUrl;
  }

  public boolean getMemberFlag() {
    return member_flag == 1; // 1 means is member of group
  }

  public void setMember_flag(int member_flag) {
    this.member_flag = member_flag;
  }

  public boolean isShowAdd() {
    return showAdd;
  }

  public void setShowAdd(boolean showAdd) {
    this.showAdd = showAdd;
  }

  @Override public int describeContents() {
    return 0;
  }

  @Override public void writeToParcel(Parcel dest, int flags) {
    dest.writeDouble(distance);
    dest.writeInt(gId);
    dest.writeString(title);
    dest.writeString(location);
    dest.writeString(lat);
    dest.writeString(lng);
    dest.writeString(startTime);
    dest.writeString(endTime);
    dest.writeInt(maxMember);
    dest.writeInt(uId);
    dest.writeString(uFname);
    dest.writeString(gDescription);
    dest.writeString(uLname);
    dest.writeInt(totalMember);
    dest.writeInt(member_flag);
    dest.writeString(groupImageUrl);
    dest.writeString(groupThumbImageUrl);
    dest.writeString(uImageUrl);
    dest.writeString(uThumbImageUrl);
    dest.writeTypedList(userModels);
    dest.writeByte((byte) (showAdd ? 1 : 0));
  }
}
