/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import android.graphics.Color;
import android.text.Html;
import android.text.Spanned;
import com.bnbjobs.R;
import com.bnbjobs.utils.LocaleHelper;
import com.bnbjobs.utils.Utils;
import com.google.gson.annotations.SerializedName;
import java.util.List;

import static android.text.TextUtils.isEmpty;

/**
 * @author Harsh
 * @version 1.0
 */
public class JobModel {

  private String distance;
  @SerializedName("rp_id") private String rpId;
  @SerializedName("rp_video") private String rpVideo;
  @SerializedName("d_title_1") private String d_title_1;
  @SerializedName("d_title_2") private String d_title_2;
  @SerializedName("d_title_3") private String d_title_3;
  @SerializedName("d_title") private String dTitle;
  @SerializedName("rp_description") private String rpDescription;
  @SerializedName("rp_salary") private String rpSalary;
  @SerializedName("rp_location") private String rpLocation;
  @SerializedName("rp_latitude") private String rpLatitude;
  @SerializedName("rp_longitude") private String rpLongitude;
  @SerializedName("planPurchase") private int planPurchase;
  @SerializedName("rp_video_url") private String rpVideoUrl;
  @SerializedName("applyJobBtnFlag") private int applyJobBtnFlag;
  @SerializedName("rp_images") private List<JobImages> mImages;

  public String getImage() {
    return getImageUrl();
  }

  private String getImageUrl() {
    if (getmImages() != null && getmImages().size() > 0) {
      return getmImages().get(0).getRpImageUrl();
    }
    return "";
  }

  public Spanned getSalaryPrice(String month) {
    if (isEmpty(getRpSalary())) {
      return Html.fromHtml("");
    } else {
      return Html.fromHtml(Utils.decimalFormat(Double.parseDouble(getRpSalary()))
          + "<small><sup>\u20ac/"
          + month
          + "</sup></small>");
    }
  }

  public String getDistance() {
    return distance;
  }

  public void setDistance(String distance) {
    this.distance = distance;
  }

  public String getRpId() {
    return rpId;
  }

  public void setRpId(String rpId) {
    this.rpId = rpId;
  }

  public String getRpVideo() {
    return rpVideo;
  }

  public void setRpVideo(String rpVideo) {
    this.rpVideo = rpVideo;
  }

  public String getdTitle() {
    if (LocaleHelper.isFrench()) {
      return Utils.capitalize(getD_title_2());
    } else if (LocaleHelper.isSpanish()) {
      return Utils.capitalize(getD_title_2());
    } else {
      return Utils.capitalize(getD_title_1());
    }
  }



  public String getD_title_1() {
    return d_title_1;
  }

  public void setD_title_1(String d_title_1) {
    this.d_title_1 = d_title_1;
  }

  public String getD_title_2() {
    return d_title_2;
  }

  public void setD_title_2(String d_title_2) {
    this.d_title_2 = d_title_2;
  }

  public String getD_title_3() {
    return d_title_3;
  }

  public void setD_title_3(String d_title_3) {
    this.d_title_3 = d_title_3;
  }

  public void setdTitle(String dTitle) {
    this.dTitle = dTitle;
  }

  public String getRpDescription() {
    return rpDescription;
  }

  public void setRpDescription(String rpDescription) {
    this.rpDescription = rpDescription;
  }

  public String getRpSalary() {
    return rpSalary;
  }

  public void setRpSalary(String rpSalary) {
    this.rpSalary = rpSalary;
  }

  public String getRpLocation() {
    return rpLocation;
  }

  public void setRpLocation(String rpLocation) {
    this.rpLocation = rpLocation;
  }

  public String getRpLatitude() {
    return rpLatitude;
  }

  public void setRpLatitude(String rpLatitude) {
    this.rpLatitude = rpLatitude;
  }

  public String getRpLongitude() {
    return rpLongitude;
  }

  public void setRpLongitude(String rpLongitude) {
    this.rpLongitude = rpLongitude;
  }

  public int getPlanPurchase() {
    return planPurchase;
  }

  public void setPlanPurchase(int planPurchase) {
    this.planPurchase = planPurchase;
  }

  public String getRpVideoUrl() {
    return rpVideoUrl;
  }

  public void setRpVideoUrl(String rpVideoUrl) {
    this.rpVideoUrl = rpVideoUrl;
  }

  public int getApplyJobBtnFlag() {
    return applyJobBtnFlag;
  }

  public void setApplyJobBtnFlag(int applyJobBtnFlag) {
    this.applyJobBtnFlag = applyJobBtnFlag;
  }

  public List<JobImages> getmImages() {
    return mImages;
  }

  public void setmImages(List<JobImages> mImages) {
    this.mImages = mImages;
  }

  public int getAppliedColor() {
    if (getApplyJobBtnFlag() == 1) { //green
      return R.drawable.rect_border_pink; //pink
    } else if (getApplyJobBtnFlag() == 4) { // reject
      return R.drawable.rect_drawable_red;
    } else {
      return R.drawable.rect_drawable_green;
    }
  }

  public int getColor() {
      if (getApplyJobBtnFlag() == 1) {
        return Color.parseColor("#F21770");
      } else if (getApplyJobBtnFlag() == 4) {
        return Color.parseColor("#f71020");
      } else {
        return Color.parseColor("#54cb2a");
      }
  }
}


