/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.main;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.multidex.MultiDex;
import com.bnbjobs.BuildConfig;
import com.bnbjobs.ProHelperImpl;
import com.bnbjobs.R;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.model.MyMigration;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.LocaleHelper;
import com.bnbjobs.utils.Prefs;
import com.crashlytics.android.Crashlytics;
import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.facebook.stetho.Stetho;
import com.orhanobut.logger.LogLevel;
import com.orhanobut.logger.Logger;
import com.uphyca.stetho_realm.RealmInspectorModulesProvider;
import io.fabric.sdk.android.Fabric;
import io.realm.Realm;
import io.realm.RealmConfiguration;
import net.danlew.android.joda.JodaTimeAndroid;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

import static com.bnbjobs.utils.LogUtils.LOGI;

/**
 * @author Harsh
 * @version 1.0
 */
public class AppClass extends Application {

  private static AppClass instance;
  private boolean isAppRunning;
  private static final String TAG = AppClass.class.getSimpleName();

  public static Prefs getPrefs(Context mContext) {
    return Prefs.with(mContext.getApplicationContext());
  }

  public static AppClass getInstance() {
    return instance;
  }

  public static boolean hasNetwork() {
    return instance.checkIfHasNetwork();
  }

  @Override public void onCreate() {
    super.onCreate();
    instance = this;
    if (BuildConfig.DEBUG) {
      Stetho.initialize(Stetho.newInitializerBuilder(this)
          .enableDumpapp(Stetho.defaultDumperPluginsProvider(this))
          .enableWebKitInspector(RealmInspectorModulesProvider.builder(this).build())
          .build());


    }
    Logger.init(TAG).logLevel(BuildConfig.DEBUG?LogLevel.FULL:LogLevel.NONE);
    RestClient.init(this);

    Realm.init(this);
    // Configure Realm for the application
    RealmConfiguration realmConfiguration = new RealmConfiguration.Builder().name("BNB.realm")
        .schemaVersion(1)
        .migration(new MyMigration())
        .build();


    // Make this Realm the default
    Realm.setDefaultConfiguration(realmConfiguration);

    LOGI(TAG, "version: " + Realm.getDefaultInstance().getVersion());

    FacebookSdk.sdkInitialize(getApplicationContext());
    AppEventsLogger.activateApp(this);
    JodaTimeAndroid.init(this);
    if (new ProHelperImpl().isPro()) {
      LocaleHelper.setLocale(this, "fr");
      Fabric.with(this, new Crashlytics());
    }
    //end fb session if session is cont.
    LoginManager.getInstance().logOut();
    CalligraphyConfig.initDefault(new CalligraphyConfig.Builder().setDefaultFontPath(
        "fonts/AvenirLTStd-Medium.otf") // when define app's default font
        .setFontAttrId(R.attr.fontPath).build());

    registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
      @Override public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
        LOGI("AppClass", "onActivityCreated");
        isAppRunning = true;
      }

      @Override public void onActivityStarted(Activity activity) {
        isAppRunning = true;
      }

      @Override public void onActivityResumed(Activity activity) {
      }

      @Override public void onActivityPaused(Activity activity) {
      }

      @Override public void onActivityStopped(Activity activity) {
        LOGI("AppClass", "onActivityStopped");
        if (activity instanceof HomeActivity) isAppRunning = false;
      }

      @Override public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
      }

      @Override public void onActivityDestroyed(Activity activity) {
        if (activity instanceof HomeActivity) isAppRunning = false;
      }
    });
  }

  public boolean isAppRunning() {
    return isAppRunning;
  }

  @Override protected void attachBaseContext(Context base) {
    super.attachBaseContext(base);
    MultiDex.install(this);
  }

  public boolean checkIfHasNetwork() {
    ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
    NetworkInfo networkInfo = cm.getActiveNetworkInfo();
    return networkInfo != null && networkInfo.isConnected();
  }
}

