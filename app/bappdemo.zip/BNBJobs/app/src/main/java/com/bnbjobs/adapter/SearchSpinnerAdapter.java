/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.model.DesignationModel;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class SearchSpinnerAdapter extends BaseAdapter {

  private Context context;
  private List<DesignationModel> designationModelList;

  public SearchSpinnerAdapter(Context context, List<DesignationModel> designationModelList) {
    this.context = context;
    this.designationModelList = designationModelList;
  }

  @Override public int getCount() {
    return designationModelList.size();
  }

  @Override public Object getItem(int position) {
    return designationModelList.get(position);
  }

  @Override public long getItemId(int position) {
    return position;
  }

  @Override public View getView(int position, View convertView, ViewGroup parent) {
    ViewHolder holder;
    if (convertView == null) {
      convertView = LayoutInflater.from(parent.getContext())
          .inflate(android.R.layout.simple_list_item_1, parent, false);
      holder = new ViewHolder(convertView);
      convertView.setTag(holder);
    } else {
      holder = (ViewHolder) convertView.getTag();
    }
    holder.textView.setText(designationModelList.get(position).getD_title());
    return convertView;
  }

  class ViewHolder {
    @BindView(android.R.id.text1) TextView textView;

    public ViewHolder(View itemView) {
      ButterKnife.bind(this, itemView);
    }
  }
}
