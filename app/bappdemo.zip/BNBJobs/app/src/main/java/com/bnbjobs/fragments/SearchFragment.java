/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.CountryJobFragment;
import com.bnbjobs.activity.DesignationSelectActivity;
import com.bnbjobs.customui.views.GradientView;
import com.bnbjobs.model.DesignationDbModel;
import com.bnbjobs.presenter.SearchPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.SearchView;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.maps.model.LatLng;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class SearchFragment extends BaseFragment implements SearchView {

  private static final String TAG = makeLogTag(SearchFragment.class);
  private static final int FILTER_CODE = 7777;
  @BindView(R.id.imgLogo) ImageView imgLogo;
  @BindView(R.id.etJobSearchLocation) EditText etJobSearchLocation;
  @BindView(R.id.linearSearchDetail) LinearLayout linearSearchDetail;
  @BindView(R.id.tvSearch) GradientView tvSearch;
  @BindView(R.id.relativeLogin) FrameLayout relativeLogin;
  @BindView(R.id.linearBottom) LinearLayout linearBottom;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.imgBack) ImageView imgBack;
  @BindView(R.id.tvDesignationSelect) TextView tvDesignationSelect;
  private Unbinder unBinder;
  private SearchPresenter presenter;
  private static final int PLACE_AUTOCOMPLETE_REQUEST_CODE = 1111;
  private LatLng latLng;
  private String placeName;
  private String dId;
  private static final int SINGLE_SELECT = 1;
  private String dTitle;

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_search, container, false);
    unBinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    if (presenter == null) {
      presenter = new SearchPresenter();
      presenter.attachView(this);
      presenter.setFragment(this);

    }
    String lastAddress = getPrefs(getActivity()).getString(QuickstartPreferences.KEY_SEARCH_ADDRESS, "");
    if(!isEmpty(lastAddress)){
      String lat = getPrefs(getActivity()).getString(QuickstartPreferences.KEY_SEARCH_ADDRESS_LAT,"");
      String lng = getPrefs(getActivity()).getString(QuickstartPreferences.KEY_SEARCH_ADDRESS_LNG,"");
      latLng = new LatLng(Double.parseDouble(lat),Double.parseDouble(lng));
    }
    etJobSearchLocation.setText(lastAddress);

    if (isCandidate()) {
      imgBack.setVisibility(View.GONE);
    } else {
      imgBack.setVisibility(View.VISIBLE);
    }

    if (getTargetFragment() instanceof HomeNewFragment || getTargetFragment() instanceof CountryJobFragment){
      imgBack.setVisibility(View.VISIBLE);
    }
    tvDesignationSelect.setText(dTitle);
  }

  @Override public void onResume() {
    super.onResume();
    showToolbar(false);
  }

  @Override public void onDestroyView() {
    unBinder.unbind();
    super.onDestroyView();
  }

  @OnClick({ R.id.imgBack, R.id.etJobSearchLocation, R.id.linearProgress }) void onClick(
      View view) {
    int id = view.getId();
    switch (id) {
      case R.id.imgBack:
        getActivity().onBackPressed();
        break;
      case R.id.etJobSearchLocation:
        findPlace();
        break;
      case R.id.linearProgress:
      default:
        break;
    }
  }

  @OnClick(R.id.tvDesignationSelect) void onDesignation() {
    Intent intent = new Intent(getActivity(), DesignationSelectActivity.class);
    intent.putExtra(Constants.KEY_TYPE, SINGLE_SELECT);
    startActivityForResult(intent, FILTER_CODE);
  }

  private void findPlace() {
    try {
      Intent intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY).build(getActivity());
      startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
    } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
      LOGE(TAG, e.getMessage(), e);
    }
  }

  @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
    Utils.hideKeyboard(etJobSearchLocation, getActivity());
    if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
      if (resultCode == Activity.RESULT_OK) {
        Place place = PlaceAutocomplete.getPlace(getContext(), data);
        etJobSearchLocation.setText(place.getName());
        latLng = place.getLatLng();
        placeName = (String) place.getName();
        getPrefs(getActivity()).save(QuickstartPreferences.KEY_SEARCH_ADDRESS, placeName);
        String lat = String.valueOf(latLng.latitude);
        String lng = String.valueOf(latLng.longitude);
        getPrefs(getActivity()).save(QuickstartPreferences.KEY_SEARCH_ADDRESS_LAT, lat);
        getPrefs(getActivity()).save(QuickstartPreferences.KEY_SEARCH_ADDRESS_LNG, lng);
        LOGI(TAG, "Location Stored");
      } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
        Status status = PlaceAutocomplete.getStatus(getContext(), data);
        LOGI(TAG, status.getStatusMessage());
      } else if (resultCode == Activity.RESULT_CANCELED) {
        LOGI(TAG, "User cancel");
      }
    } else if (requestCode == FILTER_CODE && resultCode == Activity.RESULT_OK) {
      dId = data.getStringExtra(Constants.KEY_TEXT);
      DesignationDbModel model = DesignationDbModel.getDesignation(dId);
      dTitle = model.getTitle();
      tvDesignationSelect.setText(dTitle);
    }
  }

  /**
   * onSearch result
   */
  @OnClick(R.id.tvSearch) void onSearch() {
    if (isEmpty(Utils.getText(tvDesignationSelect))) {
      Utils.showMessage(getActivity(), getString(R.string.enter_designation));
      return;
    }
    if (!isEmpty(Utils.getText(etJobSearchLocation))) {
      Fragment fragment;
      if (isCandidate()) {
        fragment = new SearchDetailFragment();
      } else {
        fragment = new SearchRecruiterDetailFragment();
      }
      Bundle bundle = new Bundle();
      bundle.putString(Constants.KEY_TEXT, Utils.getText(tvDesignationSelect));
      bundle.putParcelable(Constants.KEY_POSITION, latLng);
      bundle.putString(Constants.KEY_TYPE, Utils.getText(etJobSearchLocation));
      bundle.putString(Constants.KEY_ID, dId);
      fragment.setArguments(bundle);
      addFragment(fragment, true);
    } else {
      Utils.showMessage(getActivity(), getString(R.string.select_location));
    }
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    if (linearProgress != null) {
      linearProgress.setVisibility(View.GONE);
    }
  }
}
