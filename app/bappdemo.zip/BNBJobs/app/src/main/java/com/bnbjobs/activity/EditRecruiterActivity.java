/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.CircleImageView;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.UserModel;
import com.bnbjobs.presenter.EditRecruiterPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.EditRecruiterView;
import com.bumptech.glide.Glide;
import java.io.File;
import org.greenrobot.eventbus.EventBus;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnNeverAskAgain;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
@RuntimePermissions public class EditRecruiterActivity extends BaseActivity
    implements EditRecruiterView {

  private static final String TAG = makeLogTag(EditRecruiterActivity.class);
  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.rightImage) TinTableImageView rightImage;
  @BindView(R.id.toolbar) Toolbar toolbar;
  @BindView(R.id.imgBanner) ImageView imgBanner;
  @BindView(R.id.ivCircle) CircleImageView ivCircle;
  @BindView(R.id.tvUploadProfile) TextView tvUploadProfile;
  @BindView(R.id.etFirstName) EditText etFirstName;
  @BindView(R.id.etLastName) EditText etLastName;
  @BindView(R.id.etPassword) EditText etPassword;
  @BindView(R.id.etPhoneNumber) EditText etPhoneNumber;
  @BindView(R.id.etEmailAddress) EditText etEmailAddress;
  @BindView(R.id.tvAddress) TextView tvAddress;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.scrollProfile) ScrollView scrollProfile;
  @BindView(R.id.etCompanyName) EditText etCompanyName;
  @BindView(R.id.linearLogout) LinearLayout linearLogout;
  private UserModel model;
  private EditRecruiterPresenter presenter;
  private String path = null;
  private String bannerPath;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_recruiter_edit);
    ButterKnife.bind(this);
    presenter = new EditRecruiterPresenter();
    presenter.attachView(this);
    tvTitle.setText(R.string.profile);
    tvTitle.setVisibility(View.VISIBLE);
    rightImage.setVisibility(View.VISIBLE);
    rightImage.setImageResource(R.drawable.edit_gray);
    disableEnableControls(false, scrollProfile);
    linearLogout.setEnabled(true);
    model = getIntent().getParcelableExtra(Constants.KEY_OBJECT);
    if (model != null) {
      setUserData();
    }
  }

  private void setUserData() {
    etFirstName.setText(model.getfName());
    etLastName.setText(model.getlName());
    etEmailAddress.setText(model.getU_email());
    etPhoneNumber.setText(model.getU_phone());
    tvAddress.setText(model.getLocalLocation());
    tvUploadProfile.setVisibility(View.GONE);
    etCompanyName.setText(model.getU_company());
    Glide.with(this)
        .load(model.getImageThumb())
        .placeholder(R.drawable.upload_pic_placeholder)
        .dontAnimate()
        .into(ivCircle);
    Glide.with(this)
        .load(model.getBannerImageUrl())
        .placeholder(R.drawable.placeholder)
        .dontAnimate()
        .into(imgBanner);
  }

  @OnClick(R.id.etPhoneNumber) void onPhoneClick(){
    Intent intent = new Intent(this, PhoneNumberActivity.class);
    intent.putExtra(Constants.KEY_SHOW_BACK, true);
    startActivity(intent);
  }

  @OnClick({
      R.id.imageBack, R.id.ivCircle,
      R.id.rightImage, R.id.tvUploadProfile,
      R.id.linearProgress
  }) void onClick(View view) {
    if (view.getId() == R.id.rightImage) {
      tvUploadProfile.setVisibility(View.VISIBLE);
      if (etLastName.isEnabled()) {
        Utils.hideKeyboard(etLastName, this);
        presenter.updateProfile();
      }
      if (!etLastName.isEnabled()) {
        disableEnableControls(true, scrollProfile);
        rightImage.setImageResource(R.drawable.top_check);
      }
    } else if (view.getId() == R.id.ivCircle) {
      presenter.showChangePhotoDialog();
    } else if (view.getId() == R.id.tvUploadProfile) {
      presenter.showChangeBannerDialog();
    } else if (view.getId() == R.id.linearProgress) {
    } else {
      onBackPressed();
    }
  }

  @OnClick(R.id.linearLogout) void onLogout() {
    getPrefs(this).save(QuickstartPreferences.IS_LOGIN, false);
    getPrefs(this).save(QuickstartPreferences.KEY_SEARCH_ADDRESS, "");
    Intent intent = new Intent(this, LandingScreen.class);
    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
    startActivity(intent);
    finish();
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public File getProfilePhoto() {
    return path != null ? new File(path) : null;
  }

  @Override public File getBannerImage() {
    return bannerPath != null ? new File(bannerPath) : null;
  }

  @Override public void openCamera(boolean banner) {
    EditRecruiterActivityPermissionsDispatcher.showCameraWithCheck(this, true, banner);
  }

  @Override public void openGallery(boolean banner) {
    EditRecruiterActivityPermissionsDispatcher.showCameraWithCheck(this, false, banner);
  }

  @Override public void showPhoto(String path) {
    this.path = path;
    Glide.with(this).load(new File(path)).dontAnimate().into(ivCircle);
  }

  @Override public void showBannerPath(String path) {
    bannerPath = path;
    Glide.with(this).load(new File(path)).dontAnimate().into(imgBanner);
  }

  @Override public void setDefault(boolean banner) {
    if (banner) {
      Glide.with(this).load(R.drawable.placeholder).dontAnimate().into(imgBanner);
    } else {
      Glide.with(this).load(R.drawable.upload_pic_placeholder).dontAnimate().into(ivCircle);
    }
  }

  @Override public boolean isImageSet() {
    return false;
  }

  @Override public String getEmail() {
    return Utils.getText(etEmailAddress);
  }

  @Override public String getPassword() {
    return Utils.getText(etPassword);
  }

  @Override public String getAddress() {
    return Utils.getText(tvAddress);
  }

  @Override public String getFirstName() {
    return Utils.getText(etFirstName);
  }

  @Override public String getLastName() {
    return Utils.getText(etLastName);
  }

  @Override public String getPhoneNumber() {
    return Utils.getText(etPhoneNumber);
  }

  @Override public String getCompanyName() {
    return Utils.getText(etCompanyName);
  }

  @Override public void onUpdated(UserModel mData) {
    EventBus.getDefault().post(mData);
    finish();
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    presenter.onActivityResult(requestCode, resultCode, data);
  }

  @Override protected void onDestroy() {
    presenter.detachView();
    super.onDestroy();
  }

  @NeedsPermission({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showCamera(boolean isCamera, boolean banner) {
    if (isCamera) {
      if (banner) {
        presenter.openCameraBanner();
      } else {
        presenter.openCamera();
      }
    } else {
      if (banner) {
        presenter.openGalleryBanner();
      } else {
        presenter.openGallery();
      }
    }
  }

  @OnShowRationale({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showRationaleForCamera(final PermissionRequest request) {
    Utils.showDialog(this, getString(R.string.alert),
        getString(R.string.permission_camera_rationale), getString(R.string.button_allow), getString(R.string.button_deny), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.proceed();
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.cancel();
          }
        }).show();
  }

  @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
      @NonNull int[] grantResults) {
    EditRecruiterActivityPermissionsDispatcher.onRequestPermissionsResult(this, requestCode,
        grantResults);
  }

  @OnPermissionDenied({android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showDeniedForCamera() {
    showPermissionDialog();
  }

  @OnNeverAskAgain({android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showNeverAskForCamera() {
    showPermissionDialog();
  }

  private void showPermissionDialog() {
    Utils.showDialog(this, getString(R.string.alert),getString(R.string.permission_camera_never_askagain), getString(android.R.string.ok),new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }
}
