/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.ChooseOfferItem;
import com.bnbjobs.utils.Utils;
import java.util.ArrayList;

public class ChooseOfferAdapter extends RecyclerView.Adapter<ChooseOfferAdapter.ViewHolder> {

  private final ClickImpl<ChooseOfferItem> clickImpl;
  private ArrayList<ChooseOfferItem> offerItemArrayList;
  private Context context;

  public ChooseOfferAdapter(Context context, ArrayList<ChooseOfferItem> offerItemArrayList,
      Fragment fragment) {
    this.offerItemArrayList = offerItemArrayList;
    this.context = context;
    this.clickImpl = (ClickImpl<ChooseOfferItem>) fragment;
  }

  @Override public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View itemLayoutView =
        LayoutInflater.from(parent.getContext()).inflate(R.layout.item_choose_offer, parent, false);
    return new ViewHolder(itemLayoutView);
  }

  @Override public void onBindViewHolder(ViewHolder holder, int position) {
    ChooseOfferItem chooseOfferItem = offerItemArrayList.get(position);
    holder.tv_offer_type.setText(chooseOfferItem.getOfferType());
    holder.tv_description.setText(chooseOfferItem.getOfferDescription());
    if (!TextUtils.isEmpty(chooseOfferItem.getPrice())) {
      holder.tv_price.setText(Html.fromHtml(chooseOfferItem.getPrice() + "<sup>€</sup>"));
    }
    if (!chooseOfferItem.getDiscount().equalsIgnoreCase("0%")) {
      holder.tv_discount.setText(chooseOfferItem.getDiscount());
      holder.tv_discount_text.setVisibility(View.VISIBLE);
      holder.tv_discount_text.setText(chooseOfferItem.getDiscountLabel());
      holder.tv_sub_discount_text.setVisibility(View.GONE);
      holder.tv_discount.setVisibility(View.VISIBLE);
    } else {
      holder.tv_sub_discount_text.setText(chooseOfferItem.getDiscountLabel());
      holder.tv_discount_text.setVisibility(View.GONE);
      holder.tv_sub_discount_text.setVisibility(View.VISIBLE);
      holder.tv_discount.setVisibility(View.GONE);
    }
    GradientDrawable bgShape = (GradientDrawable) holder.linear_discount_block.getBackground();
    bgShape.setColor(Color.parseColor(chooseOfferItem.getColor()));
  }

  @Override public int getItemCount() {
    return offerItemArrayList.size();
  }

  public class ViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.tv_offer_type) TextView tv_offer_type;
    @BindView(R.id.tv_description) TextView tv_description;
    @BindView(R.id.tv_price) TextView tv_price;
    @BindView(R.id.tv_discount) TextView tv_discount;
    @BindView(R.id.tv_discount_text) TextView tv_discount_text;
    @BindView(R.id.tv_sub_discount_text) TextView tv_sub_discount_text;
    @BindView(R.id.linear_discount_block) LinearLayout linear_discount_block;

    public ViewHolder(View itemLayoutView) {
      super(itemLayoutView);
      ButterKnife.bind(this, itemView);
      linear_discount_block.getLayoutParams().width = (int) (Utils.getScreenWidth(context) * 0.28f);
      linear_discount_block.getLayoutParams().height =
          (int) (Utils.getScreenWidth(context) * 0.28f);
    }

    @OnClick({ R.id.linear_choose_offer_root }) void onItemClick(View view) {
      if (view.getId() == R.id.linear_choose_offer_root) {
        clickImpl.onClick(view, offerItemArrayList.get(getLayoutPosition()), getLayoutPosition());
      }
    }
  }
}
