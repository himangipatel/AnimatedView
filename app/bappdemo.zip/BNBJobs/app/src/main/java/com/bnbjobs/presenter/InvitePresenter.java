/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.util.Log;
import android.widget.EditText;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.InviteActivity;
import com.bnbjobs.model.FbFriends;
import com.bnbjobs.model.InviteModel;
import com.bnbjobs.model.UserExistBean;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.InviteView;
import com.facebook.AccessToken;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.google.gson.Gson;
import com.jakewharton.rxbinding.widget.RxTextView;
import com.jakewharton.rxbinding.widget.TextViewTextChangeEvent;
import com.trello.rxlifecycle.ActivityEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func0;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class InvitePresenter extends BasePresenter implements Presenter<InviteView> {
  private static final String TAG = makeLogTag(InvitePresenter.class);
  private InviteView mInviteView;
  private List<String> allNumber = new ArrayList<>();
  private List<InviteModel> mInviteModelList = new ArrayList<>();

  @Override public void attachView(InviteView view) {
    mInviteView = view;
  }

  @Override public void detachView() {
    mInviteView = null;
  }

  private Cursor getCursor() {
    //contentUri = Uri.withAppendedPath(ContactsQuery.FILTER_URI, Uri.encode("A"));
    return getContext().getContentResolver()
        .query(ContactsQuery.CONTENT_URI, ContactsQuery.PROJECTION, ContactsQuery.SELECTION_NEW,
            null, ContactsQuery.SORT_ORDER);
  }

  public void getContacts() {
    Observable.defer(new Func0<Observable<Cursor>>() {
      @Override public Observable<Cursor> call() {
        return Observable.just(getCursor());
      }
    })
        .map(new Func1<Cursor, List<InviteModel>>() {
          @Override public List<InviteModel> call(Cursor cursor) {
            List<InviteModel> mInviteModelList = new ArrayList<>();
            while (cursor.moveToNext()) {


              String number = cursor.getString(ContactsQuery.PHONE_NUMBER);
              number = number.replaceAll("\\p{P}", "").replaceAll("[*-+.^:,]", "").replace(" ", "");
              if (!allNumber.contains(number)) {
                allNumber.add(number);
                InviteModel mInviteModel = new InviteModel();
                mInviteModel.setName(cursor.getString(ContactsQuery.DISPLAY_NAME));
                mInviteModel.setComparePhoneNumber(number);
                final Uri uri = ContactsContract.Contacts.getLookupUri(cursor.getLong(ContactsQuery.ID),cursor.getString(ContactsQuery.LOOKUP_KEY));
                final Uri mUri = Uri.withAppendedPath(uri, ContactsContract.Contacts.Data.CONTENT_DIRECTORY);
                Cursor mAddressCursor = getContext().getContentResolver().query(mUri, ContactAddressQuery.PROJECTION, ContactAddressQuery.SELECTION,null, null);
                String address = "";
                if (mAddressCursor != null) {
                  if (mAddressCursor.moveToFirst()) {
                    do {
                      address = mAddressCursor.getString(ContactAddressQuery.ADDRESS);
                    } while (mAddressCursor.moveToNext());
                  }
                  mAddressCursor.close();
                }
                mInviteModel.setAddress(address);
                mInviteModel.setPhoneNumber(cursor.getString(ContactsQuery.PHONE_NUMBER));
                mInviteModel.setPhotoId(cursor.getString(ContactsQuery.PHOTO_THUMBNAIL_DATA));
                int phoneType = cursor.getInt(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE));
                if(phoneType== ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE){
                  mInviteModelList.add(mInviteModel);
                }
              }
            }
            cursor.close();
            return mInviteModelList;
          }
        })
        .compose(getContext().<List<InviteModel>>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<List<InviteModel>>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            mInviteView.hideProgress();
            LOGE(TAG, Log.getStackTraceString(e));
          }

          @Override public void onNext(List<InviteModel> inviteModels) {
            mInviteModelList.clear();
            mInviteModelList.addAll(inviteModels);
            checkInvites();
          }
        });
  }

  private void checkInvites() {

    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "getExistUsers");
    params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
    params.put("accessToken",
        getPrefs(getBaseContext()).getString(QuickstartPreferences.ACCESS_TOKEN, ""));
    params.put("phoneNumber", String.valueOf(new JSONArray(allNumber)));
    params.put("language", getLanguage());
    RestClient.getInstance(params)
        .compose(getContext().<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            mInviteView.hideProgress();
            LOGE(TAG, e.getMessage(), e);
          }

          @Override public void onNext(String s) {
            try {
              JSONObject object = new JSONObject(s);
              if (isResponseSuccess(s)) {
                UserExistBean bean = new Gson().fromJson(s, UserExistBean.class);
                compareContact(bean);
              } else {
                mInviteView.hideProgress();
                showDialog(getContext(), getContext().getString(R.string.alert),
                    object.getString("message"), getContext().getString(android.R.string.ok),
                    new DialogInterface.OnClickListener() {
                      @Override public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                      }
                    }).show();
              }
            } catch (JSONException e) {
              mInviteView.hideProgress();
              e.printStackTrace();
            }
          }
        });
  }

  public void getFriendsList() {
    new GraphRequest(AccessToken.getCurrentAccessToken(), "/me/friends", null, HttpMethod.GET,
        new GraphRequest.Callback() {
          public void onCompleted(GraphResponse response) {
            LOGI(TAG, "Friend Response: " + response.getRawResponse());
            FbFriends fbFriends = new Gson().fromJson(response.getRawResponse(), FbFriends.class);
            mInviteView.showFbFriends(fbFriends.getmFbFriendsList());
          }
        }).executeAsync();
  }

  private void compareContact(final UserExistBean bean) {
    Observable.defer(new Func0<Observable<UserExistBean>>() {
      @Override public Observable<UserExistBean> call() {
        return Observable.just(bean);
      }
    })
        .map(new Func1<UserExistBean, List<InviteModel>>() {
          @Override public List<InviteModel> call(UserExistBean userExistBean) {
            if (userExistBean.getData().size() > 0) {
              for (int i = 0; i < mInviteModelList.size(); i++) {
                if (bean.getData().contains(mInviteModelList.get(i).getComparePhoneNumber())) {
                  mInviteModelList.remove(i);
                }
              }
            }
            return mInviteModelList;
          }
        })
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<List<InviteModel>>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            mInviteView.hideProgress();
            LOGE(TAG, e.getMessage(), e);
          }

          @Override public void onNext(List<InviteModel> inviteModels) {
            mInviteView.hideProgress();
            mInviteView.setAdapter(inviteModels);
          }
        });
  }

  public void onSearchText(EditText editText) {
    RxTextView.textChangeEvents(editText)
        .debounce(400, TimeUnit.MILLISECONDS)
        .observeOn(AndroidSchedulers.mainThread())
        .compose(getContext().<TextViewTextChangeEvent>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Subscriber<TextViewTextChangeEvent>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
          }

          @Override public void onNext(TextViewTextChangeEvent textViewTextChangeEvent) {
            mInviteView.onContactSearch(textViewTextChangeEvent);
          }
        });
  }

  @Override protected Context getBaseContext() {
    return getContext();
  }

  private InviteActivity getContext() {
    return (InviteActivity) mInviteView.getContext();
  }

  /**
   * address params
   */
  private interface ContactAddressQuery {
    String[] PROJECTION = {
        ContactsContract.CommonDataKinds.StructuredPostal._ID,
        ContactsContract.CommonDataKinds.StructuredPostal.FORMATTED_ADDRESS,
        ContactsContract.CommonDataKinds.StructuredPostal.TYPE,
        ContactsContract.CommonDataKinds.StructuredPostal.LABEL,
    };
    String SELECTION = ContactsContract.Data.MIMETYPE
        + "='"
        + ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE
        + "'";
    int ADDRESS = 1;
  }

  /**
   * This interface defines constants for the Cursor and CursorLoader, based on constants defined
   * in the {@link ContactsContract.CommonDataKinds.Phone} class.
   */
  private interface ContactsQuery {

    Uri CONTENT_URI = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;

    //final static Uri FILTER_URI = ContactsContract.Contacts.CONTENT_FILTER_URI;
    Uri FILTER_URI = ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI;

    String SELECTION_NEW = (Utils.hasHoneycomb() ? ContactsContract.CommonDataKinds.Phone.NUMBER
        : ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME) +
        "<>''" + " AND " + ContactsContract.CommonDataKinds.Phone.IN_VISIBLE_GROUP + "=1";

    String SORT_ORDER =
        Utils.hasHoneycomb() ? ContactsContract.CommonDataKinds.Phone.SORT_KEY_PRIMARY
            : ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME;



    String[] PROJECTION = {
        ContactsContract.CommonDataKinds.Phone._ID,
        ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY,
        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
        ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI,
        ContactsContract.CommonDataKinds.Phone.NUMBER, SORT_ORDER,
        ContactsContract.CommonDataKinds.Phone.TYPE
    };

    // The query column numbers which map to each value in the projection
    int ID = 0;
    int LOOKUP_KEY = 1;
    int DISPLAY_NAME = 2;
    int PHOTO_THUMBNAIL_DATA = 3;
    int PHONE_NUMBER = 4;
    int SORT_KEY = 5;
  }
}
