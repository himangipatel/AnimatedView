/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */
package com.bnbjobs.utils;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Shader;
import android.net.Uri;
import android.provider.MediaStore;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import static com.bnbjobs.utils.LogUtils.LOGI;

/**
 * Utility functions related to bitmap
 *
 * @author harsh
 *         Add new API to convert Bitmap to gray scale
 */
public class BitmapUtils {

  public static String SIGN_PATH = "temp";
  public static String LOGO_PATH = "Logo";
  private static String TAG = BitmapUtils.class.getSimpleName();

  /**
   * Save the bitmap locally
   *
   * @param context context
   * @param name the name of the file
   * @param bitmap the bitmap to save
   * @return the path of the bitmap
   * @throws IOException
   */
  public static String saveBitmapLocally(Context context, String name, Bitmap bitmap)
      throws IOException {
    if (bitmap == null) {
      return null;
    }

    // Write file
    File outputDir = context.getCacheDir();
    File outputFile = File.createTempFile(name, "jpg", outputDir);
    FileOutputStream stream = new FileOutputStream(outputFile);
    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);

    // Cleanup
    stream.close();
    bitmap.recycle();

    return outputFile.getPath();
  }

  /**
   * Save the bitmap locally
   *
   * @param context context
   * @param bitmap the bitmap to save
   * @return the path of the bitmap
   * @throws IOException
   */
  public static Uri saveImageLocally(Context context, Bitmap bitmap) throws IOException {
    if (bitmap == null) {
      return null;
    }

    LOGI(TAG,"here bitmap size " + bitmap.getWidth() + " height " + bitmap.getHeight());

    // Write file
    File outputDir = new File(context.getCacheDir() + File.separator + SIGN_PATH);
    outputDir.mkdirs();

    File outputFile = new File(outputDir.getAbsolutePath()
        + File.separator
        + String.valueOf(System.currentTimeMillis())
        + ".png");

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos);
    byte[] bitmapdata = bos.toByteArray();

    //write the bytes in file
    FileOutputStream fos = new FileOutputStream(outputFile);
    fos.write(bitmapdata);
    fos.flush();
    fos.close();

    return Uri.fromFile(outputFile);
  }



 /**
   * Save the bitmap locally
   *
   * @param bitmap the bitmap to save
   * @return the path of the bitmap
   * @throws IOException
   */
  public static void saveImageLocally(Bitmap bitmap,String filePath) throws IOException {
    if (bitmap == null) {
      return;
    }

    LOGI(TAG,"here bitmap size " + bitmap.getWidth() + " height " + bitmap.getHeight());


    File outputFile = new File(filePath);

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos);
    byte[] bitmapdata = bos.toByteArray();

    //write the bytes in file
    FileOutputStream fos = new FileOutputStream(outputFile);
    fos.write(bitmapdata);
    fos.flush();
    fos.close();
  }

  /**
   * Save the bitmap locally
   *
   * @param context context
   * @param bitmap the bitmap to save
   * @return the path of the bitmap
   * @throws IOException
   */
  public static Uri saveLogoLocally(Context context, Bitmap bitmap) throws IOException {
    if (bitmap == null) {
      return null;
    }

    // Write file
    File outputDir = new File(context.getExternalCacheDir() + File.separator + LOGO_PATH);
    outputDir.mkdirs();
    //File outputFile =  File.createTempFile(String.valueOf(System.currentTimeMillis()), ".jpg", outputDir);
    File outputFile = new File(outputDir.getAbsolutePath()
        + File.separator
        + String.valueOf(System.currentTimeMillis())
        + ".jpg");

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos);
    byte[] bitmapdata = bos.toByteArray();

    //write the bytes in file
    FileOutputStream fos = new FileOutputStream(outputFile);
    fos.write(bitmapdata);
    fos.flush();
    fos.close();

    return Uri.fromFile(outputFile);
  }

  public static void addImageToGallery(final String filePath, final Context context) {

    ContentValues values = new ContentValues();

    values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
    values.put(MediaStore.Images.Media.MIME_TYPE, "image/*");
    values.put(MediaStore.MediaColumns.DATA, filePath);

    context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
  }

  public static Uri getLocalBitmap(Context context, String name) {
    File fileDir = new File(context.getCacheDir() + File.separator + name);
    return Uri.fromFile(fileDir);
  }

  /**
   * Creates a circular bitmap from the given bitmap
   *
   * @param photoBitmap the source bitmap
   * @param dimension the dimension of the resulting bitmap
   * @return the circular bitmap
   */
  public static Bitmap createCircularBitmap(Bitmap photoBitmap, int dimension) {
    Bitmap squareBitmap = null;
    if (photoBitmap.getWidth() > photoBitmap.getHeight()) {
      squareBitmap =
          Bitmap.createBitmap(photoBitmap, photoBitmap.getWidth() / 2 - photoBitmap.getHeight() / 2,
              0, photoBitmap.getHeight(), photoBitmap.getHeight());
    } else {
      squareBitmap = Bitmap.createBitmap(photoBitmap, 0,
          photoBitmap.getHeight() / 2 - photoBitmap.getWidth() / 2, photoBitmap.getWidth(),
          photoBitmap.getWidth());
    }

    squareBitmap = Bitmap.createScaledBitmap(squareBitmap, dimension, dimension, false);

    Bitmap circlePhotoBitmap =
        Bitmap.createBitmap(squareBitmap.getWidth(), squareBitmap.getHeight(),
            Bitmap.Config.ARGB_8888);

    BitmapShader shader =
        new BitmapShader(squareBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
    Paint paint = new Paint();
    paint.setShader(shader);
    paint.setAntiAlias(true);
    Canvas c = new Canvas(circlePhotoBitmap);
    c.drawCircle(squareBitmap.getWidth() / 2, squareBitmap.getHeight() / 2,
        squareBitmap.getWidth() / 2, paint);
    return circlePhotoBitmap;
  }

  /**
   * Convert a bitmap to gray scale
   *
   * @param bmpOriginal original bitmap
   * @return the gray scale bitmap
   */
  public static Bitmap toGrayScale(Bitmap bmpOriginal) {
    int width, height;
    height = bmpOriginal.getHeight();
    width = bmpOriginal.getWidth();

    Bitmap bmpGrayscale = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
    Canvas c = new Canvas(bmpGrayscale);
    Paint paint = new Paint();
    ColorMatrix cm = new ColorMatrix();
    cm.setSaturation(0);
    ColorMatrixColorFilter f = new ColorMatrixColorFilter(cm);
    paint.setColorFilter(f);
    c.drawBitmap(bmpOriginal, 0, 0, paint);
    return bmpGrayscale;
  }
}
