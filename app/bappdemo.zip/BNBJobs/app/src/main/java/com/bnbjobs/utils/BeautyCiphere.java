/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.utils;

import android.util.Base64;
import android.util.Log;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class BeautyCiphere {

  private static byte[] keyBytes;
  private static byte[] ivBytes = new byte[] {
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
  };

  public static String encrypt(String data, final String keyValue)
      throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException,
      InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException,
      BadPaddingException {

    String str = "";
    if (keyValue != null && !keyValue.equalsIgnoreCase("")) {
      Log.e("Keyvalue", keyValue);

      String key = keyValue.substring(0, 16);//this is the key for encryption
      Log.e("Key", key);
      try {
        keyBytes = key.getBytes("UTF-8");//this method create the keybytes
      } catch (UnsupportedEncodingException e) {
        e.printStackTrace();
      }
      if (data != null && !data.equalsIgnoreCase("")) {
        byte[] textBytes = data.getBytes("UTF-8");
        byte[] enc_byte;

        ivBytes = key.getBytes("UTF-8");

        AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
        SecretKeySpec newKey = new SecretKeySpec(keyBytes, "AES");
        Cipher cipher = null;
        cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, newKey, ivSpec);
        enc_byte = cipher.doFinal(textBytes);
        str = Base64.encodeToString(enc_byte, Base64.DEFAULT).trim();
      }
    }
    return str;
  }

  public static String decrypt(final String enc_data, final String keyVaue)
      throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException,
      InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException,
      BadPaddingException {
    String res = "";
    if (keyVaue != null && !keyVaue.equalsIgnoreCase("")) {
      String key = keyVaue.substring(0, 16);//this is the key for encryption

      try {
        keyBytes = key.getBytes("UTF-8");//this method create the keybytes
      } catch (UnsupportedEncodingException e) {
        e.printStackTrace();
      }

      if (enc_data != null && !enc_data.equalsIgnoreCase("")) {
        byte[] textBytes = Base64.decode(enc_data, Base64.DEFAULT);
        byte[] dec_byte;
        ivBytes = key.getBytes("UTF-8");

        AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
        SecretKeySpec newKey = new SecretKeySpec(keyBytes, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");//PKCS5Padding
        cipher.init(Cipher.DECRYPT_MODE, newKey, ivSpec);
        /*byte[] dec = Base64.decode(textBytes, Base64.DEFAULT);*/
        dec_byte = cipher.doFinal(textBytes);
        /*dec_byte = Base64.decode(dec_byte, Base64.DEFAULT);*/
        res = new String(dec_byte, "UTF-8").trim();
      }
    }
    return res;
  }

  //--------------------------------------------------------------------------------------------------------------------------------------
  /////////////////////////////////////////bellow are unused method for now.........//////////////////////////////////////////////////////////////////////////////////////////////////////
  //--------------------------------------------------------------------------------------------------------------------------------------

  public static byte[] removeTrailingNulls(byte[] source) {
    int i = source.length;
    while (source[i - 1] == 0x00) {
      i--;
    }

    byte[] result = new byte[i];
    System.arraycopy(source, 0, result, 0, i);

    return result;
  }

  public static String bytesToHex(byte[] data) {
    if (data == null) {
      return null;
    }

    int len = data.length;
    String str = "";
    for (byte aData : data) {
      if ((aData & 0xFF) < 16) {
        str += "0" + Integer.toHexString(aData & 0xFF);
      } else {
        str += Integer.toHexString(aData & 0xFF);
      }
    }
    return str;
  }

  public static byte[] hexToBytes(String str) {
    if (str == null) {
      return null;
    } else if (str.length() < 2) {
      return null;
    } else {
      int len = str.length() / 2;
      byte[] buffer = new byte[len];
      for (int i = 0; i < len; i++) {
        buffer[i] = (byte) Integer.parseInt(str.substring(i * 2, i * 2 + 2), 16);
      }
      return buffer;
    }
  }

  public static byte[] padString(byte[] source1) {
    String source = new String(source1);
    char paddingChar = ' ';
    int size = 16;
    int x = source.length() % size;
    int padLength = size - x;

    for (int i = 0; i < padLength; i++) {
      source += paddingChar;
    }
    byte[] s1 = source.getBytes();
    return s1;
  }
}
