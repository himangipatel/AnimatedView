/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class DesignationContainer {

  private boolean success;
  private String message;
  @SerializedName("data") private List<DesignationModel> designationModelsList;

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public List<DesignationModel> getDesignationModelsList() {
    return designationModelsList;
  }

  public void setDesignationModelsList(List<DesignationModel> designationModelsList) {
    this.designationModelsList = designationModelsList;
  }
}
