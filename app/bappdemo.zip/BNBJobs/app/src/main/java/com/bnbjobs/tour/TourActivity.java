/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.tour;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.customui.looppager.LoopRecyclerViewPager;

import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class TourActivity extends BaseActivity implements TourView {

  private final static String TAG = makeLogTag(TourActivity.class);
  @BindView(R.id.viewpager) LoopRecyclerViewPager mRecyclerViewPager;
  @BindView(R.id.linear_indicator) LinearLayout linearIndicator;
  private TourPresenter presenter;

  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    presenter = new TourPresenter();
    presenter.attachView(this);
    setContentView(R.layout.activity_tour);
    ButterKnife.bind(this);
    LinearLayoutManager layout =
        new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
    //mRecyclerViewPager.setTriggerOffset(0.005f);
    mRecyclerViewPager.setTriggerOffset(0.15f);
    mRecyclerViewPager.setLayoutManager(layout);
    mRecyclerViewPager.setAdapter(new TourAdapterNew(this));
    mRecyclerViewPager.setHasFixedSize(true);
    initView();
    presenter.setUpRecyclePager(mRecyclerViewPager);
  }

  private void initView() {
    int NUM_VIEWS = 4;
    linearIndicator.removeAllViews();
    for (int i = 0; i < NUM_VIEWS; i++) {
      ImageView ind = new ImageView(this);
      if (i == 0) {
        ind.setBackgroundResource(R.drawable.black_dot);
      } else {
        ind.setBackgroundResource(R.drawable.white_dot);
      }
      LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(15, 15);
      param.setMargins(25, 0, 0, 0);
      linearIndicator.addView(ind, param);
    }
  }

  @Override public void setIndicator(int position) {
    int n = linearIndicator.getChildCount();
    for (int i = 0; i < n; i++) {
      if (position == i) {
        linearIndicator.getChildAt(i).setBackgroundResource(R.drawable.black_dot);
      } else {
        linearIndicator.getChildAt(i).setBackgroundResource(R.drawable.white_dot);
      }
    }
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {

  }

  @Override public void hideProgress() {

  }

  @Override protected void onDestroy() {
    if (presenter != null) {
      presenter.detachView();
    }
    super.onDestroy();
  }
}



