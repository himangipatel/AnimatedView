/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

/**
 * @author Harsh
 * @version 1.0
 */
public class CandidateRequest {

  private String candidateName;
  private String candidateJobName;
  private String candidateProfileImage;

  public String getCandidateProfileImage() {
    return candidateProfileImage;
  }

  public void setCandidateProfileImage(String candidateProfileImage) {
    this.candidateProfileImage = candidateProfileImage;
  }

  public String getCandidateName() {
    return candidateName;
  }

  public void setCandidateName(String candidateName) {
    this.candidateName = candidateName;
  }

  public String getCandidateJobName() {
    return candidateJobName;
  }

  public void setCandidateJobName(String candidateJobName) {
    this.candidateJobName = candidateJobName;
  }
}
