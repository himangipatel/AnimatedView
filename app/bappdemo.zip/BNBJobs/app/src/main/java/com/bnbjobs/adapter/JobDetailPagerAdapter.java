/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.model.PhotoModel;
import com.bnbjobs.utils.RoundedCornersTransformation;
import com.bumptech.glide.Glide;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class JobDetailPagerAdapter
    extends RecyclerView.Adapter<JobDetailPagerAdapter.MyViewHolder> {

  private Context mContext;
  private List<PhotoModel> mPhotoList;

  public JobDetailPagerAdapter(Context mContext, List<PhotoModel> mPhotoList) {
    this.mContext = mContext;
    this.mPhotoList = mPhotoList;
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.adapter_job_detail, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {
    Glide.with(mContext)
        .load(mPhotoList.get(position).getImageThumbUrl())
        .placeholder(R.drawable.placeholder)
        .dontAnimate()
        .bitmapTransform(new RoundedCornersTransformation(mContext, 10, 0))
        .into(holder.imageView);
  }

  @Override public int getItemCount() {
    return mPhotoList.size();
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {
    int mPosition; // just for reflection use
    @BindView(R.id.imageView) ImageView imageView;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
    }
  }
}
