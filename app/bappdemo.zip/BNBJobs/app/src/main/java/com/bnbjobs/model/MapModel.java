/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.bnbjobs.utils.LocaleHelper;
import com.google.gson.annotations.SerializedName;

/**
 * @author Harsh
 * @version 1.0
 */

public class MapModel {

  @SerializedName("distance")
  private double distance;
  @SerializedName("rp_id")
  private int id;
  private String d_title_1;
  private String d_title_2;
  private String d_title_3;
  @SerializedName("rp_location")
  private String location;
  @SerializedName("rp_latitude")
  private String lat;
  @SerializedName("rp_longitude")
  private String lng;
  private int planPurchase;

  public double getDistance() {
    return distance;
  }

  public void setDistance(double distance) {
    this.distance = distance;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getD_title_1() {
    return d_title_1;
  }

  public void setD_title_1(String d_title_1) {
    this.d_title_1 = d_title_1;
  }

  public String getD_title_2() {
    return d_title_2;
  }

  public void setD_title_2(String d_title_2) {
    this.d_title_2 = d_title_2;
  }

  public String getD_title_3() {
    return d_title_3;
  }

  public void setD_title_3(String d_title_3) {
    this.d_title_3 = d_title_3;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public String getLat() {
    return lat;
  }

  public void setLat(String lat) {
    this.lat = lat;
  }

  public String getLng() {
    return lng;
  }

  public void setLng(String lng) {
    this.lng = lng;
  }

  public int getPlanPurchase() {
    return planPurchase;
  }

  public void setPlanPurchase(int planPurchase) {
    this.planPurchase = planPurchase;
  }

  public String getTitle() {
    if (LocaleHelper.isFrench()) {
      return getD_title_2();
    } else if (LocaleHelper.isSpanish()) {
      return getD_title_3();
    } else {
      return getD_title_1();
    }
  }
}
