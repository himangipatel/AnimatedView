/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.bnbjobs.utils.LocaleHelper;
import io.realm.Realm;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class DesignationDbModel extends RealmObject {

  @PrimaryKey private int d_id;
  private String d_title_1;
  private String d_title_2;
  private String d_title_3;
  private int d_parent_id;
  private int d_status;
  private String d_created_at;
  private String d_updated_at;

  public int getD_id() {
    return d_id;
  }

  public void setD_id(int d_id) {
    this.d_id = d_id;
  }

  public String getD_title_1() {
    return d_title_1;
  }

  public void setD_title_1(String d_title_1) {
    this.d_title_1 = d_title_1;
  }

  public String getD_title_2() {
    return d_title_2;
  }

  public void setD_title_2(String d_title_2) {
    this.d_title_2 = d_title_2;
  }

  public String getD_title_3() {
    return d_title_3;
  }

  public void setD_title_3(String d_title_3) {
    this.d_title_3 = d_title_3;
  }

  public int getD_parent_id() {
    return d_parent_id;
  }

  public void setD_parent_id(int d_parent_id) {
    this.d_parent_id = d_parent_id;
  }

  public int getD_status() {
    return d_status;
  }

  public void setD_status(int d_status) {
    this.d_status = d_status;
  }

  public String getD_created_at() {
    return d_created_at;
  }

  public void setD_created_at(String d_created_at) {
    this.d_created_at = d_created_at;
  }

  public String getD_updated_at() {
    return d_updated_at;
  }

  public void setD_updated_at(String d_updated_at) {
    this.d_updated_at = d_updated_at;
  }

  public String getTitle() {
    if (LocaleHelper.isFrench()) {
      return getD_title_2();
    } else if (LocaleHelper.isSpanish()) {
      return getD_title_3();
    } else {
      return getD_title_1();
    }
  }

  public static DesignationDbModel getDesignation(String dId) {
    Realm mRealm = Realm.getDefaultInstance();
    DesignationDbModel model = mRealm.where(DesignationDbModel.class).equalTo("d_id", Integer.parseInt(dId)).findFirst();
    mRealm.close();
    return model;
  }

  public static List<DesignationDbModel> getDesignationList(int parentId) {
    Realm mRealm = Realm.getDefaultInstance();
    List<DesignationDbModel> mList =
        mRealm.where(DesignationDbModel.class).equalTo("d_parent_id", parentId).findAll();
    mRealm.close();
    return mList;
  }
}
