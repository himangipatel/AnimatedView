/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.CircleImageView;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.GroupModel;
import com.bnbjobs.model.InviteSelectModel;
import com.bnbjobs.model.InviteSendEvent;
import com.bnbjobs.model.UpdateEvent;
import com.bnbjobs.model.UserModel;
import com.bnbjobs.presenter.AddGroupPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.OverlapDecoration;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.AddGroupView;
import com.bumptech.glide.Glide;
import com.facebook.stetho.common.StringUtil;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.maps.model.LatLng;
import com.nispok.snackbar.Snackbar;
import com.nispok.snackbar.enums.SnackbarType;
import java.io.File;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnNeverAskAgain;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.presenter.BasePresenter.toRequestBody;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */
@RuntimePermissions public class AddGroupActivity extends BaseActivity implements AddGroupView {

  private static final int PLACE_AUTOCOMPLETE_REQUEST_CODE = 1001;
  private static final int REQUEST_CODE_CAMERA = 999;
  private static final int REQUEST_CODE_GALLERY = 111;
  private static final int FILE_TYPE_GALLARY = 1;
  @BindView(R.id.tvAddGroupName) EditText etAddGroupName;
  @BindView(R.id.tvLocationName) TextView tvLocationName;
  @BindView(R.id.tvDate) TextView tvDate;
  @BindView(R.id.tvHour) TextView tvHour;
  @BindView(R.id.etDescription) EditText etDescription;
  @BindView(R.id.etPersonNumber) EditText etPersonNumber;
  @BindView(R.id.recyclerView) RecyclerView recyclerView;
  @BindView(R.id.ivAddProfile) ImageView ivAddProfile;
  @BindView(R.id.imageBack) TinTableImageView mImageBack;
  @BindView(R.id.rightImage) TinTableImageView rightImage;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.frameImage) FrameLayout frameImage;
  @BindView(R.id.tvEndDate) TextView tvEndDate;
  @BindView(R.id.tvEndHour) TextView tvEndTime;
  @BindView(R.id.tvMemberMax) TextView tvMemberMax;
  @BindView(R.id.ivGroupImage) ImageView ivGroupImage;
  @BindView(R.id.tvPhotoHint) TextView tvPhotoHint;
  private static final String TAG = makeLogTag(AddGroupActivity.class);
  private AddGroupPresenter presenter;
  private LatLng coordinates;
  private String mCameraOutputPath;
  private String filePath;
  private boolean isImageSet;
  private long sDate;
  private long eDate;
  private ArrayList<InviteSelectModel> mSelectModel = new ArrayList<>();
  private String uids = "";
  private boolean isEdit;
  private boolean isShowed;

  @Override public void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_add_group);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    isEdit = getIntent().getBooleanExtra(Constants.KEY_EDIT, false);
    presenter = new AddGroupPresenter();
    presenter.attachView(this);

    tvTitle.setVisibility(View.VISIBLE);
    if (isEdit) {
      tvTitle.setText(R.string.update_group);
    } else {
      tvTitle.setText(R.string.create_group);
    }

    rightImage.setVisibility(View.VISIBLE);
    rightImage.setImageResource(R.drawable.top_check);
    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
    recyclerView.setLayoutManager(linearLayoutManager);
    recyclerView.addItemDecoration(new OverlapDecoration());
    recyclerView.setAdapter(new GroupInviteAdapter(this, mSelectModel));
    if (isEdit) {
      presenter.getGroupDetail(String.valueOf(getIntent().getIntExtra(Constants.KEY_GROUP_ID, 0)));
    }

    etPersonNumber.setOnEditorActionListener(new TextView.OnEditorActionListener() {
      @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE) {
          checkMemberValidate(false);
        }
        return false;
      }
    });
    etPersonNumber.setOnFocusChangeListener(new View.OnFocusChangeListener() {
      @Override public void onFocusChange(View v, boolean hasFocus) {
        if (hasFocus && !mSelectModel.isEmpty()) {
          showMemberError();
        }
      }
    });
  }

  private void checkMemberValidate(boolean call){
    etPersonNumber.clearFocus();
    Utils.hideKeyboard(etPersonNumber, getContext());
    if (!isEmpty(Utils.getText(etPersonNumber))) {
      long number = Long.parseLong(Utils.getText(etPersonNumber));
      if (number < mSelectModel.size()) {
        uids="";
        mSelectModel.clear();
        recyclerView.getAdapter().notifyDataSetChanged();
      }
      if (number <= 32) {
        tvMemberMax.setText(getString(R.string.max_12, String.valueOf(number)));
        if(call && !mSelectModel.isEmpty()){
          validateForm();
        }
      } else {
        tvMemberMax.setText("");
        etPersonNumber.setText("");
        Utils.showMessage(AddGroupActivity.this, getString(R.string.max_limit));
      }
    } else {
      etPersonNumber.setText("");
      tvMemberMax.setText("");
    }
  }

  private void showMemberError() {
    if (!isShowed) {
      isShowed = true;
      Snackbar.with(this).type(SnackbarType.MULTI_LINE).text("If you change member length below than already invited then list will be clear.").show(this);
    }
  }

  private void setData(GroupModel model) {
    etAddGroupName.setText(model.getTitle());
    tvLocationName.setText(model.getLocation());
    Glide.with(this).load(model.getGroupImageUrl()).placeholder(R.drawable.upload_btn_update).dontAnimate().into(ivGroupImage);
    isImageSet = true;
    showCameraHint(false);
    tvDate.setText(Utils.getDate(Long.parseLong(model.getStartTime())));
    tvHour.setText(Utils.getTime(Long.parseLong(model.getStartTime())));
    tvEndDate.setText(Utils.getDate(Long.parseLong(model.getEndTime())));
    tvEndTime.setText(Utils.getTime(Long.parseLong(model.getEndTime())));
    etDescription.setText(model.getgDescription());
    etPersonNumber.setText(String.valueOf(model.getMaxMember()));
    coordinates = new LatLng(Double.parseDouble(model.getLat()), Double.parseDouble(model.getLng()));
    StringBuilder builder = new StringBuilder();
    for (UserModel uModel : model.getUserModels()) {
      builder.append(",").append(uModel.getId());
      InviteSelectModel inviteSelectModel = new InviteSelectModel();
      inviteSelectModel.setuId(uModel.getId());
      inviteSelectModel.setImageUrl(uModel.getImageUrl());
      mSelectModel.add(inviteSelectModel);
    }
    uids = StringUtil.removePrefix(builder.toString(), ",");
    LOGI(TAG, "uids are " + uids);
    recyclerView.getAdapter().notifyDataSetChanged();
  }

  @OnClick(R.id.ivAddProfile) void onInvite() {
    if (!isEmpty(Utils.getText(etPersonNumber))) {
      Intent intent = new Intent(this, InviteGroupActivity.class);
      intent.putExtra(Constants.KEY_NUMBER, Integer.parseInt(Utils.getText(etPersonNumber)));
      intent.putExtra(Constants.KEY_COUNT, recyclerView.getAdapter().getItemCount());
      intent.putExtra(Constants.KEY_LIST, uids);
      intent.putExtra(Constants.KEY_OBJECT, mSelectModel);
      startActivity(intent);
    } else {
      Utils.showMessage(this, getString(R.string.enter_number_participants));
    }
  }

  @OnClick(R.id.rightImage) void onRightImage() {
    checkMemberValidate(true);
  }

  private void validateForm() {
    if (isEmpty(Utils.getText(etAddGroupName))) {
      showMessage(this, getString(R.string.group_name));
    } else if (isEmpty(Utils.getText(tvLocationName))) {
      showMessage(this, getString(R.string.group_location));
    } else if (isEmpty(Utils.getText(tvDate))) {
      showMessage(this, getString(R.string.group_start_date));
    } else if (isEmpty(Utils.getText(tvHour))) {
      showMessage(this, getString(R.string.group_start_time));
    } else if (isEmpty(Utils.getText(tvEndDate))) {
      showMessage(this, getString(R.string.group_end_date));
    } else if (isEmpty(Utils.getText(tvEndTime))) {
      showMessage(this, getString(R.string.group_end_time));
    } else if (!isDateValid()) {
      showMessage(this, getString(R.string.end_start_condition));
    } else if (isEmpty(Utils.getText(etDescription))) {
      showMessage(this, getString(R.string.group_description));
    } else if (isEmpty(Utils.getText(etPersonNumber))) {
      showMessage(this, getString(R.string.number_participants));
    } else if (isEmpty(filePath) && !isImageSet) {
      showMessage(this, getString(R.string.group_image));
    } else {
      presenter.addGroup(getParams());
    }
  }

  private boolean isDateValid() {
    try {
      sDate = Utils.getTimeStamp(Utils.getText(tvDate) + " " + Utils.getText(tvHour));
      eDate = Utils.getTimeStamp(Utils.getText(tvEndDate) + " " + Utils.getText(tvEndTime));

      return eDate > sDate;
    } catch (ParseException e) {
      e.printStackTrace();
    }
    return false;
  }

  @Override protected void onDestroy() {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  private HashMap<String, RequestBody> getParams() {
    HashMap<String, RequestBody> params = new HashMap<>();

    if (isEdit) {
      params.put("apiName", toRequestBody("edit_group"));
      params.put("group_id", toRequestBody(String.valueOf(getIntent().getIntExtra(Constants.KEY_GROUP_ID, 0))));
    } else {
      params.put("apiName", toRequestBody("add_group"));
    }
    params.put("group_title", toRequestBody(Utils.getText(etAddGroupName)));
    params.put("group_location", toRequestBody(Utils.getText(tvLocationName)));
    params.put("group_latitude", toRequestBody(String.valueOf(coordinates.latitude)));
    params.put("group_longitude", toRequestBody(String.valueOf(coordinates.longitude)));
    params.put("group_start_time", toRequestBody(String.valueOf(sDate)));
    params.put("group_end_time", toRequestBody(String.valueOf(eDate)));
    params.put("group_desc", toRequestBody(Utils.getText(etDescription)));
    params.put("group_max_member", toRequestBody(Utils.getText(etPersonNumber)));
    params.put("group_members", toRequestBody(uids));

    if (filePath != null && new File(filePath).exists()) {
      params.put("group_image\"; filename=\"pp.png\"", RequestBody.create(MediaType.parse("image"), new File(filePath)));
    }
    return params;
  }

  @OnClick(R.id.imageBack) void onBack() {
    onBackPressed();
  }

  @OnClick({ R.id.tvDate, R.id.tvHour, R.id.tvEndDate, R.id.tvEndHour }) void onTimer(View view) {
    Utils.hideKeyboard(etDescription, this);
    if (view.getId() == R.id.tvDate || view.getId() == R.id.tvEndDate) {
      showDatePickerDialog(view);
    } else if (view.getId() == R.id.tvHour || view.getId() == R.id.tvEndHour) {
      showTimerPickerDialog(view);
    }
  }

  @Subscribe public void onEvent(InviteSendEvent model) {
    mSelectModel.clear();
    mSelectModel.addAll(model.getmInviteSelectModel());
    uids = model.getuIds().replaceFirst(",", "");
    recyclerView.getAdapter().notifyDataSetChanged();
  }

  @OnClick(R.id.tvLocationName) void onLocation() {
    openPlaceApiIntent();
  }

  @OnClick(R.id.frameImage) void uploadImage() {
    presenter.showChangePhotoDialog();
  }

  @NeedsPermission({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showCamera(boolean isCamera) {
    if (isCamera) {
      requestImageFromCamera();
    } else {
      requestImageFromGallery();
    }
  }

  @OnShowRationale({ android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE }) void showRationaleForCamera(
      final PermissionRequest request) {
    Utils.showDialog(this, getString(R.string.alert), getString(R.string.permission_camera_rationale), getString(R.string.button_allow),
        getString(R.string.button_deny), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.proceed();
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.cancel();
          }
        }).show();
  }

  @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    AddGroupActivityPermissionsDispatcher.onRequestPermissionsResult(this, requestCode, grantResults);
  }

  @OnPermissionDenied({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showDeniedForCamera() {
    showPermissionDialog();
  }

  @OnNeverAskAgain({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showNeverAskForCamera() {
    showPermissionDialog();
  }

  private void showPermissionDialog() {
    Utils.showDialog(this, getString(R.string.alert), getString(R.string.permission_camera_never_askagain), getString(android.R.string.ok),
        new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }

  protected void requestImageFromCamera() {
    try {
      File outputDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "temp");
      if (!outputDir.exists()) {
        if (!outputDir.mkdir()) {
          LOGI(TAG, "Error creating image file for camera output.");
          return;
        }
      }
      File outputFile = File.createTempFile(String.valueOf(System.currentTimeMillis()), ".jpg", outputDir);
      mCameraOutputPath = outputFile.getAbsolutePath();
      Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
      intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(outputFile));
      startActivityForResult(intent, REQUEST_CODE_CAMERA);
    } catch (Exception e) {
      LOGI(TAG, "Error requesting photo from camera. " + e.getMessage());
    }
  }

  /**
   * requestImageFromGallery
   * Open photo gallery to choose a photo
   */
  protected void requestImageFromGallery() {
    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
    intent.setType("image/*");
    startActivityForResult(Intent.createChooser(intent, getBaseContext().getString(R.string.change_photo_gallery)), REQUEST_CODE_GALLERY);
  }

  /**
   * open date picker
   */
  private void showDatePickerDialog(final View textView) {
    final Calendar c = Calendar.getInstance();
    int mYear = c.get(Calendar.YEAR);
    int mMonth = c.get(Calendar.MONTH);
    int mDay = c.get(Calendar.DAY_OF_MONTH);
    TextView tView = (TextView) textView;
    String text = Utils.getText(tView);
    if (!isEmpty(text)) {
      List<String> splits = Arrays.asList(text.split("-"));
      mDay = Integer.parseInt(splits.get(0));
      mMonth = Integer.parseInt(splits.get(1)) - 1;
      mYear = Integer.parseInt(splits.get(2));
    }
    DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

      @Override public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
        ((TextView) textView).setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
        if (textView == tvEndDate) {
          validateDate();
        }
      }
    }, mYear, mMonth, mDay);
    datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
    datePickerDialog.show();
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE && data != null) {
      if (resultCode == RESULT_OK) {
        Place place = PlaceAutocomplete.getPlace(this, data);
        tvLocationName.setText(place.getName());
        coordinates = place.getLatLng();
      } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
        Status status = PlaceAutocomplete.getStatus(this, data);
        showMessage(this, status.getStatusMessage());
      } else if (resultCode == RESULT_CANCELED) {
        // The user canceled the operation.
        tvLocationName.setText("");
      }
    } else {
      if (resultCode == Activity.RESULT_OK) {
        Uri uri;
        if (requestCode == REQUEST_CODE_CAMERA) {
          filePath = mCameraOutputPath;
          if (Utils.isFileSizeValid(getBaseContext(), filePath, FILE_TYPE_GALLARY)) {
            isImageSet = true;
            Glide.with(this).load(filePath).into(ivGroupImage);
            showCameraHint(false);
          }
        } else if (requestCode == REQUEST_CODE_GALLERY) {
          uri = data.getData();
          filePath = getRealPathFromURI(uri);
          if (Utils.isFileSizeValid(getBaseContext(), filePath, FILE_TYPE_GALLARY)) {
            isImageSet = true;
            Glide.with(this).load(filePath).into(ivGroupImage);
            showCameraHint(false);
          }
        }
      }
    }
  }

  private void showCameraHint(boolean show) {
    if (show) {
      tvPhotoHint.setVisibility(View.VISIBLE);
    } else {
      tvPhotoHint.setVisibility(View.GONE);
    }
  }

  public void openPlaceApiIntent() {
    try {
      Intent intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY).build(this);
      startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
    } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
      LOGE(TAG, e.getMessage(), e);
    }
  }

  private void validateDate() {
    if (isEmpty(Utils.getText(tvDate)) || isEmpty(Utils.getText(tvHour))) {
      showMessage(this, getString(R.string.enter_sdate_edate));
      tvEndDate.setText("");
      tvEndTime.setText("");
    }
  }

  /**
   * open tim picker
   */
  private void showTimerPickerDialog(final View textView) {
    // Get Current Time
    final Calendar c = Calendar.getInstance();
    int mHour = c.get(Calendar.HOUR_OF_DAY);
    int mMinute = c.get(Calendar.MINUTE);
    TextView tView = (TextView) textView;
    String text = Utils.getText(tView);
    if (!isEmpty(text)) {
      List<String> splits = Arrays.asList(text.split(":"));
      mHour = Integer.parseInt(splits.get(0));
      mMinute = Integer.parseInt(splits.get(1));
    }
    // Launch Time Picker Dialog
    TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {

      @Override public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        ((TextView) textView).setText(String.format(Locale.ENGLISH, "%02d:%02d", hourOfDay, minute));
        if (textView == tvEndTime) {
          validateDate();
        }
      }
    }, mHour, mMinute, false);
    timePickerDialog.show();
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void openCamera() {
    AddGroupActivityPermissionsDispatcher.showCameraWithCheck(this, true);
  }

  @Override public void openGallery() {
    AddGroupActivityPermissionsDispatcher.showCameraWithCheck(this, false);
  }

  @Override public void setDefault() {
    filePath = null;
    isImageSet = false;
    showCameraHint(true);
    ivGroupImage.setImageResource(R.drawable.upload_btn_update);
  }

  @Override public boolean isImageSet() {
    return isImageSet;
  }

  @Override public void onSuccess(GroupModel groupModel) {
    UpdateEvent event = new UpdateEvent(true);
    event.setGroupModel(groupModel);
    if (isEdit) {
      Utils.showMessage(this, getString(R.string.group_update));
    } else {
      Utils.showMessage(this, getString(R.string.group_created));
    }
    EventBus.getDefault().post(event);
    finish();
  }

  @Override public void onError(String message) {
    showMessage(this, message);
  }

  @Override public void onSuccessDetail(GroupModel model) {
    setData(model);
  }

  static class GroupInviteAdapter extends RecyclerView.Adapter<GroupInviteAdapter.MyViewHolder> {

    private Context context;
    private List<InviteSelectModel> mInviteSelectModel;

    GroupInviteAdapter(Context context, List<InviteSelectModel> mInviteSelectModel) {
      this.context = context;
      this.mInviteSelectModel = mInviteSelectModel;
    }

    @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
      View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_group_invite, parent, false);
      return new MyViewHolder(view);
    }

    @Override public void onBindViewHolder(MyViewHolder holder, int position) {
      Glide.with(context)
          .load(mInviteSelectModel.get(position).getImageUrl())
          .placeholder(R.drawable.placeholder)
          .dontAnimate()
          .into(holder.ivUserImage);
    }

    @Override public int getItemCount() {
      return mInviteSelectModel.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

      @BindView(R.id.ivUserImage) CircleImageView ivUserImage;

      public MyViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
      }
    }
  }
}
