/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.bnbjobs.customui.looppager.RecyclerViewPager;
import com.bnbjobs.model.DashboardData;
import com.bnbjobs.model.JobOfferData;
import com.bnbjobs.model.UserModel;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public interface DashboardView extends MainView {

  RecyclerViewPager getRecyclerViewPager();

  void setUserDetail(UserModel userDetail);

  void setJobOffer(List<JobOfferData> jobOffer);

  void setCount(DashboardData dashboardData);

  void setAddress(String address);

  void setPagerAdapter();
}
