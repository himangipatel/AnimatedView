/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.keyboard;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import com.bnbjobs.utils.Utils;

/**
 * Created by jay shah on 13/5/16.
 */
public class DismissKeyboardListener implements View.OnClickListener {

  Activity mAct;

  public DismissKeyboardListener(Activity act) {
    this.mAct = act;
  }

  @Override public void onClick(View v) {
    if (v instanceof ViewGroup) {
      Utils.hideKeyboard(mAct);
    }
  }
}
