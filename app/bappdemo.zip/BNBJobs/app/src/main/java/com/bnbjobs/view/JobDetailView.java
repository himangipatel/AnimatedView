/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.bnbjobs.customui.looppager.RecyclerViewPager;
import com.bnbjobs.model.JobDetail;

/**
 * @author Harsh
 * @version 1.0
 */
public interface JobDetailView extends MainView {
  String getJobId();

  void setJobDetail(JobDetail jobDetail);

  RecyclerViewPager getRecyclerPager();

  void setAddress(String address);

  int getProfilePercentage();

  void showProfileCompleteDialog();

  void showAppliedDialog();

  void changeFavorite();

  void showError(String s);
}
