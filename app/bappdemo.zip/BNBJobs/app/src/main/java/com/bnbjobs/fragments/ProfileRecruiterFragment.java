/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.bnbjobs.R;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.JobOfferData;
import java.util.ArrayList;
import java.util.List;

import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class ProfileRecruiterFragment extends BaseFragment {

  private static String TAG = makeLogTag(ProfileRecruiterFragment.class);
  private TextView tvCount;
  private List<JobOfferData> mJobOfferData = new ArrayList<>();
  private View view;

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    if (view == null) {
      view = inflater.inflate(R.layout.fragment_recruiter_profile, container, false);
    }
    FragmentTabHost tabHost = (FragmentTabHost) view.findViewById(android.R.id.tabhost);
    Integer[] tabImages = new Integer[] {
        R.drawable.dashboard_unselect, R.drawable.alertes_unselect,
        R.drawable.condidatures_unselect, R.drawable.annonces_unselect
    };
    String[] tabNames = new String[] {
        getString(R.string.dashboard), getString(R.string.alerts), getString(R.string.announces),
        getString(R.string.candidatures)
    };
    tabHost.setup(getActivity(), getChildFragmentManager(), R.id.realTabContent);
    Class[] className = new Class[] {
        DashboardFragment.class, AlertFragment.class, AnnounceFragment.class,
        CandidateFragment.class
    };
    if (tabHost.getTabWidget().getChildCount() < 1) {
      for (int i = 0; i < tabImages.length; i++) {
        tabHost.addTab(
            tabHost.newTabSpec(tabNames[i]).setIndicator(createTabView(tabNames[i], tabImages[i])),
            className[i], null);
      }
    }
    return tabHost;
  }

  public List<JobOfferData> getJobOfferData() {
    return mJobOfferData;
  }

  public void setJobOfferData(List<JobOfferData> mJobOfferData) {
    this.mJobOfferData = mJobOfferData;
  }

  @Override public void onResume() {
    super.onResume();
    showToolbar(true);
    setBackImageColor(ActivityCompat.getColor(getActivity(), android.R.color.transparent));
    ((HomeActivity) getActivity()).setSelectedTab(0);
  }

  /**
   * create tab view
   *
   * @param tabText tab text
   * @param imgRes tab image
   * @return tab view
   */
  private View createTabView(String tabText, int imgRes) {
    View view = LayoutInflater.from(getActivity()).inflate(R.layout.tab_dashboard_custom, null, false);
    TextView tv = (TextView) view.findViewById(R.id.tvTabText);
    tv.setText(tabText);
    tv.setTextColor(customCreateList());
    TinTableImageView imgTab;
    imgTab = (TinTableImageView) view.findViewById(R.id.imgTab);
    tvCount = (TextView) view.findViewById(R.id.tvCount);
    view.findViewById(R.id.viewLine).setVisibility(View.GONE);
    imgTab.setCustomFilter(customCreateList());
    imgTab.setVisibility(View.VISIBLE);
    imgTab.setImageResource(imgRes);
    return view;
  }

  public void setTvCount(String text) {
    tvCount.setText(text);
    tvCount.setVisibility(View.VISIBLE);
  }

  @Override public void onBack(View view) {
    getActivity().onBackPressed();
  }

  /**
   * create custom color list
   *
   * @return custom ColorStateList
   */
  private ColorStateList customCreateList() {
    int[][] states = new int[][] {
        new int[] { android.R.attr.state_selected }, // selected
        new int[] { android.R.attr.state_pressed },  // unPressed
        new int[] { -android.R.attr.state_selected }, // unSelected
        new int[] { -android.R.attr.state_pressed } // pressed
    };
    int[] colors = new int[] {
        ActivityCompat.getColor(getActivity(), R.color.theme_pink),
        ActivityCompat.getColor(getActivity(), R.color.theme_pink), Color.WHITE, Color.WHITE
    };
    return new ColorStateList(states, colors);
  }

  /**
   * onDestroyView
   */
  @Override public void onDestroyView() {
    super.onDestroyView();
  }
}
