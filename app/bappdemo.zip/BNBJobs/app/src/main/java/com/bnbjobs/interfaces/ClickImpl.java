/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.interfaces;

import android.view.View;

/**
 * @author Harsh
 * @version 1.0
 */
public interface ClickImpl<T> {
  void onClick(View view, T object, int position);
}
