/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.JobOfferData;
import com.bnbjobs.model.PhotoModel;
import com.bumptech.glide.Glide;
import java.util.List;

public class JobProviderRecyclePager
    extends RecyclerView.Adapter<JobProviderRecyclePager.SimpleViewHolder> {

  private final List<JobOfferData> jobPostDetailsList;
  private Context context;
  private ClickImpl mClickImpl;

  public JobProviderRecyclePager(Context context, List<JobOfferData> jobPostDetailsList,
      Fragment fragment) {
    this.context = context;
    this.jobPostDetailsList = jobPostDetailsList;
    mClickImpl = (ClickImpl) fragment;
  }

  @Override public SimpleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    return new SimpleViewHolder(LayoutInflater.from(parent.getContext())
        .inflate(R.layout.job_vacancy_inflater, parent, false));
  }

  @Override public void onBindViewHolder(SimpleViewHolder holder, final int position) {
    List<PhotoModel> photoModelList = jobPostDetailsList.get(position).getmPhotoList();
    if (photoModelList != null && photoModelList.size() > 0) {
      Glide.with(context)
          .load(photoModelList.get(0).getImageUrl())
          .dontAnimate()
          .into(holder.ivJobLocationImage);
    } else {
      Glide.with(context)
          .load(R.drawable.placeholder)
          .dontAnimate()
          .into(holder.ivJobLocationImage);
    }

    holder.tvJobTitle.setText(jobPostDetailsList.get(position).getdTitle());
    holder.tvJobLocation.setText(jobPostDetailsList.get(position).getLocation());
    holder.tvJobAmount.setText(jobPostDetailsList.get(position).salaryDisplay());
    holder.tvJobShortDescription.setText(jobPostDetailsList.get(position).getDescription());
  }

  @Override public int getItemCount() {
    return jobPostDetailsList.size();
  }

  class SimpleViewHolder extends RecyclerView.ViewHolder {
    @BindView(R.id.ivJobLocationImage) ImageView ivJobLocationImage;
    @BindView(R.id.tvJobTitle) TextView tvJobTitle;
    @BindView(R.id.tvJobLocation) TextView tvJobLocation;
    @BindView(R.id.tvJobShortDescription) TextView tvJobShortDescription;
    @BindView(R.id.tvJobAmount) TextView tvJobAmount;
    private int mPosition;
    private JobOfferData offerData;

    SimpleViewHolder(View view) {
      super(view);
      ButterKnife.bind(this, view);
      offerData = new JobOfferData();
      view.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          mClickImpl.onClick(v, offerData, getLayoutPosition());
        }
      });
    }
  }
}
