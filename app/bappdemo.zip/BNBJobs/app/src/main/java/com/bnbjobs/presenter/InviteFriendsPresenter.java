/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import com.bnbjobs.R;
import com.bnbjobs.activity.InviteFriendsActivity;
import com.bnbjobs.view.InviteFriendsView;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import java.util.Arrays;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * Created by krupal on 9/8/16.
 */

public class InviteFriendsPresenter extends BasePresenter implements Presenter<InviteFriendsView> {

  private InviteFriendsView mInviteFriendsView;
  private CallbackManager callbackManager;
  private AccessToken accessToken;

  @Override protected Context getBaseContext() {
    return getContext();
  }

  @Override public void attachView(InviteFriendsView view) {
    mInviteFriendsView = view;
    callbackManager = CallbackManager.Factory.create();
  }

  @Override public void detachView() {
    mInviteFriendsView = null;
  }

  private InviteFriendsActivity getContext() {
    return (InviteFriendsActivity) mInviteFriendsView.getContext();
  }

  public void onFbLogin() {
    LoginManager.getInstance()
        .logInWithReadPermissions(getContext(),
            Arrays.asList("public_profile", "email", "user_friends"));
    LoginManager.getInstance()
        .registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
          @Override public void onSuccess(LoginResult loginResult) {
            // App code
            LOGI(TAG, "onSuccess");
            LOGI(TAG, loginResult.getAccessToken() + "");
            mInviteFriendsView.onFacebookLogin();
          }

          @Override public void onCancel() {
            // App code
            LOGI(TAG, "onCancel");
          }

          @Override public void onError(FacebookException exception) {
            // App code
            if (exception.getMessage() != null) {
              showDialog(getContext(), getContext().getString(R.string.alert),
                  exception.getMessage(), getContext().getString(android.R.string.ok),
                  new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                      dialog.dismiss();
                    }
                  }).show();
            }
            LOGI(TAG, "exception");
            LOGE(TAG, Log.getStackTraceString(exception));
          }
        });
  }

  public void setResult(int requestCode, int resultCode, Intent data) {
    callbackManager.onActivityResult(requestCode, resultCode, data);
  }
}
