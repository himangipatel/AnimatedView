/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.util.Log;
import com.bnbjobs.R;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.ImageModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.LogUtils;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.MediaView;
import com.bnbjobs.view.OfferFragmentView;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.maps.model.LatLng;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import okhttp3.RequestBody;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;
import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.Utils.hideKeyboard;
import static com.bnbjobs.utils.Utils.isResponseSuccess;

/**
 * @author Harsh
 * @version 1.0
 */

public class OfferPresenter extends MediaPresenter {

  private static final int PLACE_AUTOCOMPLETE_REQUEST_CODE = 10001;
  private static final int FILE_TYPE_GALLARY = 1;
  private static final int FILE_TYPE_VIDEO = 2;
  /**
   * showChangePhotoDialog
   * Show the dialog for photo selection options
   */
  public int posSel = 0;
  private Fragment fragment;
  private OfferFragmentView offerView;
  private int clickStart = 0;

  @Override public void attachView(MediaView view) {
    super.attachView(view);
    this.offerView = (OfferFragmentView) view;
  }

  @Override public void setFragment(Fragment fragment) {
    this.fragment = fragment;
    super.setFragment(fragment);
  }

  private boolean isNotNull() {
    return offerView != null;
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    handleAutoComplagePlaceAPi(requestCode, resultCode, data);
  }

  public void openPlaceApiIntent() {
    try {
      Intent intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY).build(
          fragment.getActivity());
      fragment.startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
    } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
      LOGE(TAG, e.getMessage(), e);
    }
  }

  public void setStarAndEndAddressClick(int click) {
    this.clickStart = click;
  }

  private void handleAutoComplagePlaceAPi(int requestCode, int resultCode, Intent data) {
    if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE && data != null) {
      if (resultCode == RESULT_OK) {
        Place place = PlaceAutocomplete.getPlace(offerView.getContext(), data);
        Log.i("Place", "Place: " + place.getName());
        LatLng coordinates = place.getLatLng(); // Get the coordinates from your place
        Geocoder geocoder = new Geocoder(getBaseContext(), Locale.getDefault());

        List<Address> addresses = null; // Only retrieve 1 address
        try {
          addresses = geocoder.getFromLocation(coordinates.latitude, coordinates.longitude, 1);
          Address address = addresses.get(0);
          if (address != null && !isEmpty(address.getCountryName())) {
            offerView.addCountry(address.getCountryName());
          } else {
            offerView.addCountry("France");
          }
        } catch (IOException e) {
          e.printStackTrace();
        }
        offerView.setPlaceInView(place, clickStart);
      } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
        Status status = PlaceAutocomplete.getStatus(offerView.getContext(), data);
        Log.i("Place", status.getStatusMessage());
        offerView.setCancelSearchPlace(status.getStatusMessage());
      } else if (resultCode == RESULT_CANCELED) {
        // The user canceled the operation.
        offerView.setCancelSearchPlace("");
      }
    } else {
      handleCameraResult(requestCode, resultCode, data);
    }
  }

  private void handleCameraResult(int requestCode, int resultCode, Intent data) {
    Uri uri;
    String path = "";
    if (resultCode == RESULT_OK) {
      if (requestCode == REQUEST_CODE_CAMERA) {
        path = mCameraOutputPath;
        if (Utils.isFileSizeValid(getBaseContext(), path, FILE_TYPE_GALLARY)) {
          addImageInList(path);
        }
      } else if (requestCode == REQUEST_CODE_GALLERY && data != null) {
        uri = data.getData();
        path = getRealPathFromURI(uri);
        if (Utils.isFileSizeValid(getBaseContext(), path, FILE_TYPE_GALLARY)) {
          addImageInList(path);
        }
      } else if (requestCode == REQUEST_CODE_VIDEO || requestCode == REQUEST_CODE_VIDEO_CAMERA) {
        if (requestCode == REQUEST_CODE_VIDEO_CAMERA) {
          if (filePath != null) {
            path = filePath;
          }
        } else if (data != null) {
          uri = data.getData();
          path = getRealPathFromURIVideo(uri);
        }
        if (path != null) {
          LOGI(TAG, "Video Path: " + path);
          if (Utils.isFileSizeValid(getBaseContext(), path, FILE_TYPE_VIDEO)) {
            uploadVideo(path);
          }
        }
      }
    }
  }

  private void addImageInList(String path) {
    ImageModel imageModel = new ImageModel();
    imageModel.setImageId(-1);
    imageModel.setImageUrl(path);
    imageModel.setImageThumbUrl(path);
    imageModel.setImage(path);
    imageModel.setEdit(true);
    offerView.addImage(imageModel, -1);
  }

  private void uploadVideo(String path) {
    ImageModel imageModel = new ImageModel();
    imageModel.setImageId(-1);
    imageModel.setImageUrl(path);
    imageModel.setImageThumbUrl(path);
    imageModel.setImage(path);
    imageModel.setEdit(true);
    offerView.addVideo(imageModel);
  }
  // image chooser

  public boolean _isValidDate(int year, int monthOfYear, int dayOfMonth) {
    Calendar curCal = Calendar.getInstance();
    Calendar calendar = Calendar.getInstance();
    calendar.set(year, monthOfYear, dayOfMonth);
    Date date = new Date(calendar.getTimeInMillis());
    Date curdate = new Date(curCal.getTimeInMillis());
    return date.after(curdate) || curdate.equals(date);
  }

  public void showChangePhotoDialog(int posSel) {
    this.posSel = posSel;
    imagePicker(new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        if (which == 0) {
          offerView.openCamera();
        } else if (which == 1) {
          offerView.openGallery();
        } else {
          offerView.setDefault();
        }
      }
    }, offerView.isImageSet()).show();
  }

  public void ShowVideoCaptureDialog() {
    videoPicker(new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        if (which == 0) {
          offerView.opeVideoCamera();
        } else if (which == 1) {
          offerView.openVideoGallery();
        }
      }
    }).show();
  }

  public void callAddOff(HashMap<String, RequestBody> hashMapRequest) {
    hideKeyboard(fragment.getActivity());
    if (hasNetworkConnectivity()) {
      addOfferApiCalling(hashMapRequest);
    } else {
      showNetworkError();
    }
  }

  private void addOfferApiCalling(HashMap<String, RequestBody> hashMapRequest) {
    offerView.showProgress();
    RestClient.getInstance()
        .apiCallImage(hashMapRequest)
        .compose(getBindEvent())
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<String>() {

          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            offerView.hideProgress();
            LOGE(TAG, Log.getStackTraceString(e));
          }

          @Override public void onNext(String s) {
            LOGI(TAG, "response: " + s);
            offerView.hideProgress();
            try {
              JSONObject job = new JSONObject(s);
              if (job.has("success")) {
                if (Boolean.parseBoolean(job.optString("success"))) {
                  Utils.showMessage(offerView.getContext(), job.optString("message"));
                  //offerView.clearData();
                  offerView.navigateToBack();
                } else {
                  Utils.showMessage(offerView.getContext(), "There is something wrong.");
                }
              }
            } catch (Exception e) {
              LogUtils.LOGW("Offer presenter", e.toString());
            }
          }
        });
  }

  public void onDeleteOffer(String jobOfferId) {
    offerView.showProgress();
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "deleteJobOffer");
    params.put("jobOfferId", jobOfferId);
    params.putAll(addParams(params));

    RestClient.getInstance(params).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        offerView.hideProgress();
        LOGE(TAG, e.getMessage(), e);
        if (e.getMessage() != null) {
          Utils.showMessage(getBaseContext(), e.getMessage());
        }
      }

      @Override public void onNext(String s) {
        offerView.hideProgress();
        try {
          JSONObject object = new JSONObject(s);
          if (isResponseSuccess(s)) {
            offerView.onDelete(getBaseContext().getString(R.string.delete_job));
          } else {
            Utils.showMessage(getBaseContext(), object.optString("message"));
          }
        } catch (JSONException e) {
          e.printStackTrace();
        }
      }
    });
  }
}



