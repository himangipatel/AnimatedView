/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import java.util.HashMap;

/**
 * @author Harsh
 * @version 1.0
 */

public class AddressPresenter {


  public void getAddress(String address){

    HashMap<String,String> params = new HashMap<>();
    params.put("address",address);




  }




}
