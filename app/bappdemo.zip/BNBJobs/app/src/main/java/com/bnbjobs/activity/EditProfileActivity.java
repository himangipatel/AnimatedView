package com.bnbjobs.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.DesignationDbModel;
import com.bnbjobs.model.ProfileData;
import com.bnbjobs.presenter.EditProfilePersonalPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.MyDatePicker;
import com.bnbjobs.utils.TimeUtils;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.EditPersonalProfileView;
import com.kyleduo.switchbutton.SwitchButton;
import org.greenrobot.eventbus.EventBus;

import static com.bnbjobs.main.AppClass.getPrefs;

public class EditProfileActivity extends BaseActivity implements EditPersonalProfileView {
  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.linearHeader) LinearLayout linearHeader;
  @BindView(R.id.tvAbout) TextView tvAbout;
  @BindView(R.id.edtDescription) EditText edtDescription;
  @BindView(R.id.tvCharacter) TextView tvCharacter;
  @BindView(R.id.tvName) TextView tvName;
  @BindView(R.id.tvFirstNameLabel) TextView tvFirstNameLabel;
  @BindView(R.id.edtFirstNameValue) EditText edtFirstNameValue;
  @BindView(R.id.tvSurNameLabel) TextView tvSurNameLabel;
  @BindView(R.id.edtSurNameValue) EditText edtSurNameValue;
  @BindView(R.id.tvInformationPrivates) TextView tvInformationPrivates;
  @BindView(R.id.tvMan) TextView tvMan;
  @BindView(R.id.tvFemale) TextView tvFemale;
  @BindView(R.id.tvOther) TextView tvOther;
  @BindView(R.id.tvDateOfBirthLabel) TextView tvDateOfBirthLabel;
  @BindView(R.id.tvDateOfBirthValue) TextView tvDateOfBirthValue;
  @BindView(R.id.tvEmailLabel) TextView tvEmailLabel;
  @BindView(R.id.edtEmailValue) EditText edtEmailValue;
  @BindView(R.id.tvPhoneLabel) TextView tvPhoneLabel;
  @BindView(R.id.edtPhoneValue) EditText edtPhoneValue;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.scrollProfile) ScrollView scrollProfile;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.rightImage) TinTableImageView rightImage;
  @BindView(R.id.tvDesignation) TextView tvDesignation;
  @BindView(R.id.tvDesignationValue) TextView tvDesignationValue;
  @BindView(R.id.tvChangePwd) TextView tvChangePwd;
  @BindView(R.id.edtChangePwd) EditText edtChangePwd;
  @BindView(R.id.sbSearchSwitch) SwitchButton sbSearchSwitch;

  private EditProfilePersonalPresenter presenter;

  private MyDatePicker myDatePicker;
  private static final int FILTER_CODE = 7777;
  private static final int SINGLE_SELECT = 1;
  private String did = "";
  private long UTCTimeStamp;
  private int gender = 0;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_edit_profile);
    ButterKnife.bind(this);
    presenter = new EditProfilePersonalPresenter();
    presenter.attachView(this);
    setupUI(scrollProfile);
    tvTitle.setText(R.string.profile);
    tvTitle.setVisibility(View.VISIBLE);
    rightImage.setVisibility(View.VISIBLE);
    rightImage.setImageResource(R.drawable.top_check);
    presenter.getCandidateProfile();
    myDatePicker = new MyDatePicker(this);
    edtDescription.addTextChangedListener(presenter.descriptionWatcher);
  }

  @OnClick({
      R.id.imageBack, R.id.rightImage, R.id.linearProgress, R.id.tvDateOfBirthValue, R.id.tvMan,
      R.id.tvFemale, R.id.tvOther, R.id.tvDesignationValue,R.id.linearLogout
  }) void onClick(View view) {
    if (view.getId() == R.id.rightImage) {
      presenter.updateProfile();
    } else if (view.getId() == R.id.linearProgress) {
      // do nothing..
    } else if (view.getId() == R.id.tvDateOfBirthValue) {
      ShowDatePicker();
    } else if (view.getId() == R.id.imageBack) {
      onBackPressed();
    } else if (view.getId() == R.id.linearLogout) {
      getPrefs(this).save(QuickstartPreferences.IS_LOGIN, false);
      getPrefs(this).save(QuickstartPreferences.KEY_SEARCH_ADDRESS, "");
      Intent intent = new Intent(this, LandingScreen.class);
      intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
      startActivity(intent);
      finish();
    } else if (view.getId() == R.id.tvMan) {
      gender = 1;
      tvMan.setTextColor(getColorObj(R.color.color_pink));
      tvFemale.setTextColor(getColorObj(R.color.color_edit_text));
      tvOther.setTextColor(getColorObj(R.color.color_edit_text));
    } else if (view.getId() == R.id.tvFemale) {
      gender = 2;
      tvFemale.setTextColor(getColorObj(R.color.color_pink));
      tvMan.setTextColor(getColorObj(R.color.color_edit_text));
      tvOther.setTextColor(getColorObj(R.color.color_edit_text));
    } else if (view.getId() == R.id.tvOther) {
      gender = 3;
      tvOther.setTextColor(getColorObj(R.color.color_pink));
      tvFemale.setTextColor(getColorObj(R.color.color_edit_text));
      tvMan.setTextColor(getColorObj(R.color.color_edit_text));
    } else if (view.getId() == R.id.tvDesignationValue) {
      Intent intent = new Intent(this, DesignationSelectActivity.class);
      intent.putExtra(Constants.KEY_TYPE, SINGLE_SELECT);
      startActivityForResult(intent, FILTER_CODE);
    }
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == RESULT_OK && requestCode == FILTER_CODE) {
      did = data.getStringExtra(Constants.KEY_TEXT);

      setDesignationTitle();
    }
  }

  private void setDesignationTitle() {
    DesignationDbModel model = DesignationDbModel.getDesignation(did);
    tvDesignationValue.setText(model.getTitle());
  }

  @Override public void setPersonalData(ProfileData mData) {
    edtEmailValue.setText(mData.getUserModel().getU_email());
    edtFirstNameValue.setText(mData.getUserModel().getfName());
    edtSurNameValue.setText(mData.getUserModel().getlName());

    edtPhoneValue.setText(mData.getUserModel().getU_phone());
    edtDescription.setText(mData.getUserProfileData().getDescription());
    gender = Integer.parseInt(mData.getUserProfileData().getGender());
    if (gender == 1) {
      tvMan.performClick();
    } else if (gender == 2) {
      tvFemale.performClick();
    } else if (gender == 3) {
      tvOther.performClick();
    }
    sbSearchSwitch.setChecked(mData.getUserProfileData().getActiveStatus()==2);
    if (mData.getUserProfileData().getBirthdate().length() > 0) {
      tvDateOfBirthValue.setText(
          TimeUtils.getTimeInGMT(Long.parseLong(mData.getUserProfileData().getBirthdate())));
    }
    tvDesignationValue.setText(mData.getUserProfileData().getTitle());
    did = String.valueOf(mData.getUserProfileData().getDesignationId());
  }

  @Override public int getGender() {
    return gender;
  }

  @Override public void setLengthView(String currentString, String totalString) {
    tvCharacter.setText(String.format("%s %s", currentString, totalString));
  }

  public void ShowDatePicker() {
    myDatePicker.cancel();
    myDatePicker.show();
    myDatePicker.setDateListener(new MyDatePicker.onDateSet() {

      @Override public void onDate(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
        UTCTimeStamp = TimeUtils.getTimeInUTC(year, monthOfYear, dayOfMonth);

        tvDateOfBirthValue.setText(
            TimeUtils.getGMTString(view.getYear(), view.getMonth() + 1, view.getDayOfMonth()));
      }
    });
  }

  @Override protected void onDestroy() {
    presenter.detachView();
    super.onDestroy();
  }

  @Override public String getEmail() {
    return Utils.getText(edtEmailValue);
  }

  @Override public String getBirthDate() {
    return Utils.getText(tvDateOfBirthValue);
  }

  @Override public String getDescription() {
    return Utils.getText(edtDescription);
  }

  @Override public String getDesignationId() {
    return did;
  }

  @Override public String getBirthDateTimeStamp() {
    return String.valueOf(UTCTimeStamp);
  }

  @Override public String getFirstName() {
    return Utils.getText(edtFirstNameValue);
  }

  @Override public String getLastName() {
    return Utils.getText(edtSurNameValue);
  }

  @Override public String getPhoneNumber() {
    return Utils.getText(edtPhoneValue);
  }

  @Override public String getDesignation() {
    return Utils.getText(tvDesignationValue);
  }

  @Override public String getChangePassword() {
    return Utils.getText(edtChangePwd);
  }

  @Override public String getActiveSearch() {
    return sbSearchSwitch.isChecked() ? "2" : "1";
  }

  @Override public void onUpdated(ProfileData mData) {
    EventBus.getDefault().post(mData);
    finish();
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }
}
