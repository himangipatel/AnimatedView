/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

/**
 * @author Harsh
 * @version 1.0
 */
public class NotificationEvent {

  public boolean showNotification;
  public String offerId;

  public NotificationEvent(boolean showNotification, String offerId) {
    this.showNotification = showNotification;
    this.offerId = offerId;
  }

  @Override public String toString() {
    return String.format("%s - %s", showNotification, offerId);
  }
}
