/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import com.bnbjobs.R;
import com.bnbjobs.model.CandidateContainer;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.DashboardCandidateView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.components.support.RxFragment;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class DashboardCandidatePresenter extends BasePresenter
    implements Presenter<DashboardCandidateView> {

  private static final int SIZE = 10;
  private static final String TAG = makeLogTag(DashboardCandidatePresenter.class);
  private DashboardCandidateView mCandidateView;
  private int limit = 0;
  private RxFragment fragment;
  private boolean loadMore;

  @Override public void attachView(DashboardCandidateView view) {
    mCandidateView = view;
  }

  @Override public void detachView() {
    mCandidateView = null;
  }

  public void getCandidate(int type) {
    if (!loadMore) {
      mCandidateView.showProgress();
    }
    HashMap<String, String> params = new HashMap<>(9);
    params.put("apiName", "recruiterDashboardCandidateLoadMore");
    params.put("loadMoreTab", Integer.toString(type));
    params.put("page", mCandidateView.getOffset());
    limit += 10;
    params.put("perPage", Integer.toString(limit));
    params.putAll(addDefaultParamsWitLat(params));
    RestClient.getInstance(params)
        .compose(fragment.<String>bindUntilEvent(FragmentEvent.DESTROY_VIEW))
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            mCandidateView.hideProgress();
            mCandidateView.setRetryView();
          }

          @Override public void onNext(String s) {
            mCandidateView.hideProgress();
            CandidateContainer candidateContainer =
                new Gson().fromJson(s, CandidateContainer.class);
            loadMore = candidateContainer.getCandidateModelList().size() == SIZE;
            mCandidateView.setLoadMore(loadMore);
            if (candidateContainer.isSuccess()) {
              mCandidateView.setAdapter(candidateContainer.getCandidateModelList());
            } else {
              showDialogMessage(candidateContainer.getMessage());
            }
          }
        });
  }

  public void applyJob(final HashMap<String, String> data) {
    mCandidateView.showParentProcess();
    final HashMap<String, String> params = new HashMap<>(12);
    params.put("apiName", "jobApplyAction");
    params.putAll(data);
    params.putAll(addDefaultParamsWitLat(params));
    RestClient.getInstance(params)
        .compose(fragment.<String>bindUntilEvent(FragmentEvent.DESTROY_VIEW))
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            mCandidateView.hideParentProgress();
            String error;
            if (e instanceof SocketTimeoutException) {
              error = getBaseContext().getString(R.string.error_timeout);
            } else {
              error = getBaseContext().getString(R.string.error_other);
            }
            showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
                getBaseContext().getString(R.string.retry),
                new DialogInterface.OnClickListener() {
                  @Override public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    applyJob(data);
                  }
                }).show();
          }

          @Override public void onNext(String s) {
            mCandidateView.hideParentProgress();
            JSONObject object = null;
            try {
              object = new JSONObject(s);
              if (isResponseSuccess(s)) {
                mCandidateView.applyStatus(params.get("action"));
              } else {
                showDialog(getBaseContext(), getBaseContext().getString(R.string.alert),
                    object.optString("message"), getBaseContext().getString(R.string.retry),
                    new DialogInterface.OnClickListener() {
                      @Override public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                      }
                    }).show();
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  public void setFragment(RxFragment fragment) {
    this.fragment = fragment;
  }

  @Override protected Context getBaseContext() {
    return mCandidateView.getContext();
  }
}
