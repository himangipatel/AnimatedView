/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.bnbjobs.model.FbFriends;
import com.bnbjobs.model.InviteModel;
import com.jakewharton.rxbinding.widget.TextViewTextChangeEvent;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public interface InviteView extends MainView {

  void checkPermission();

  void setAdapter(List<InviteModel> mInviteModelList);

  void onContactSearch(TextViewTextChangeEvent textViewTextChangeEvent);

  void showFbFriends(List<FbFriends.FbFriendsList> fbFriendsLists);
}
