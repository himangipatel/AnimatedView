/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.model.Experience;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.EditExperienceView;
import com.trello.rxlifecycle.ActivityEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;

/**
 * @author Harsh
 * @version 1.0
 */

public class EditExperiencePresenter extends BasePresenter
    implements Presenter<EditExperienceView> {

  private EditExperienceView mEditExperienceView;
  private static final String TAG = makeLogTag(EditExperiencePresenter.class);

  @Override public void attachView(EditExperienceView view) {
    mEditExperienceView = view;
  }

  @Override public void detachView() {
    mEditExperienceView = null;
  }

  /**
   * add candidate experience
   *
   * @param experience experience model
   */
  public void onAddExperience(final Experience experience) {
    mEditExperienceView.showProgress();
    HashMap<String, String> params = new HashMap<>();
    if (experience.geteId() != 0) {
      params.put("apiName", "editCandidateExperience");
      params.put("experienceId", Integer.toString(experience.geteId()));
    } else {
      params.put("apiName", "addCandidateExperience");
    }
    params.put("designationId", Integer.toString(experience.getD_id()));
    params.put("month", Integer.toString(experience.getProgressInMonths()));
    params.putAll(addParams(params));

    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mEditExperienceView.hideProgress();
        mEditExperienceView.onAddError(e);
      }

      @Override public void onNext(String s) {
        mEditExperienceView.hideProgress();
        try {
          JSONObject object = new JSONObject(s);
          if (experience.geteId() == 0) {
            experience.seteId(object.optInt("insertId"));
          }
          experience.setProfilePercent(object.optInt("profilePercentage"));
          mEditExperienceView.onAddSuccess(experience);
        } catch (JSONException e) {
          e.printStackTrace();
        }
      }
    });
  }

  public void onDeleteExperience(String experienceId) {
    mEditExperienceView.showProgress();
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "deleteCandidateExperience");
    params.put("experienceId", experienceId);
    params.putAll(addParams(params));

    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mEditExperienceView.hideProgress();
        mEditExperienceView.onDeleteError(e);
      }

      @Override public void onNext(String s) {
        mEditExperienceView.hideProgress();
        try {
          JSONObject object = new JSONObject(s);
          if (isResponseSuccess(s)) {
            mEditExperienceView.onDeleteSuccess(object.optInt("profilePercentage"));
          } else {
            Utils.showMessage(getBaseContext(), object.optString("message"));
          }
        } catch (JSONException e) {
          e.printStackTrace();
        }
      }
    });
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseActivity) getBaseContext()).bindUntilEvent(ActivityEvent.DESTROY);
  }

  @Override protected Context getBaseContext() {
    return mEditExperienceView.getContext();
  }
}
