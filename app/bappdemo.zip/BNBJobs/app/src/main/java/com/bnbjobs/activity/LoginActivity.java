/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.GradientView;
import com.bnbjobs.presenter.LoginPresenter;
import com.bnbjobs.services.DesignationService;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.view.LoginView;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.ActivityUtils.launchActivity;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class LoginActivity extends BaseActivity implements LoginView {

  private static final String TAG = makeLogTag(LoginActivity.class);
  @BindView(R.id.fbImage) ImageView fbImage;
  @BindView(R.id.etUserName) EditText etUserName;
  @BindView(R.id.etPassword) EditText etPassword;
  @BindView(R.id.tvLogin) GradientView tvLogin;
  @BindView(R.id.tvRegister) TextView tvRegister;
  @BindView(R.id.tvForgotPassword) TextView tvForgotPassword;
  @BindView(R.id.relativeProgress) RelativeLayout relativeProgress;
  private LoginPresenter presenter;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_login);
    ButterKnife.bind(this);
    presenter = new LoginPresenter();
    presenter.attachView(this);
  }

  @OnClick(R.id.tvForgotPassword) void onForgot() {
    launchActivity(this, ForgotActivity.class, false);
  }

  @OnClick(R.id.imageBack) void onBack() {
    onBackPressed();
  }

  @OnClick(R.id.tvRegister) void onRegister() {
    launchActivity(this, RegisterActivity.class, true);
  }

  @OnClick(R.id.tvLogin) void onLoginClick() {
    presenter.doLogin(etUserName, etPassword);
  }

  @OnClick(R.id.fbImage) void onFb() {
    presenter.onFbLogin();
  }

  @Override public void showProgress() {
    relativeProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    relativeProgress.setVisibility(View.GONE);
  }

  @Override public void onLogin() {
    startService(new Intent(this, DesignationService.class));
    int status = getPrefs(getBaseContext()).getInt(QuickstartPreferences.USER_PHONE_VERIFIED, 0);
    if (status == 1) {
      launchActivity(this, InviteActivity.class, true);
    } else {
      Intent intent = new Intent(LoginActivity.this, PhoneNumberActivity.class);
      intent.putExtra(Constants.KEY_VISIBLE_TYPE,"Register");
      startActivity(intent);
      finish();
    }
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    presenter.setResult(requestCode, resultCode, data);
  }

  @Override public Context getContext() {
    return this;
  }

  @Override protected void onDestroy() {
    presenter.detachView();
    super.onDestroy();
  }
}
