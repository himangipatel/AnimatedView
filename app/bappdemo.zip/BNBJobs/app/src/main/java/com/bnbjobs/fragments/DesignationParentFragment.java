/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.activity.DesignationSelectActivity;
import com.bnbjobs.adapter.DesignationDbAdapter;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.DesignationDbModel;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.SimpleDividerItemDecoration;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class DesignationParentFragment extends BaseFragment
    implements ClickImpl<DesignationDbModel> {

  @BindView(R.id.imgCancel) ImageView mImgCancel;
  @BindView(R.id.recyclerDesignation) RecyclerView mRecyclerDesignation;
  @BindView(R.id.tvDesignationTitle) TextView mTvDesignationTitle;
  @BindView(R.id.tvParentDesignation) TextView mTvParentDesignation;

  private List<DesignationDbModel> mList = new ArrayList<>();
  private DesignationDbAdapter mAdapter;

  private Unbinder unbinder;

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_designation_list, container, false);
    unbinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    mRecyclerDesignation.setLayoutManager(new LinearLayoutManager(getActivity()));
    mRecyclerDesignation.addItemDecoration(new SimpleDividerItemDecoration(getActivity()));

    if (!((DesignationSelectActivity) getActivity()).showCancel()) {
      mImgCancel.setVisibility(View.GONE);
    }
    getData();
  }

  /**
   * show data as for parent id
   * which has parent_id 0
   */
  private void getData() {
    mTvParentDesignation.setVisibility(View.GONE);
    mList = DesignationDbModel.getDesignationList(0); // 0 is parent id
    mAdapter = new DesignationDbAdapter(getActivity(), mList, this);
    mRecyclerDesignation.setAdapter(mAdapter);
  }

  /**
   * @param view click view
   * @param object click object
   * @param position click position
   */
  @Override public void onClick(View view, DesignationDbModel object, int position) {
    Fragment fragment = new DesignationChildFragment();
    Bundle bundle = new Bundle();
    bundle.putInt(Constants.KEY_ID, object.getD_id());
    bundle.putString(Constants.KEY_TEXT, object.getTitle());
    fragment.setArguments(bundle);
    ((DesignationSelectActivity) getActivity()).switchFragment(fragment, true);
  }

  @OnClick(R.id.imgCancel) void onCancel() {
    getActivity().finish();
  }

  @Override public void onDestroyView() {
    super.onDestroyView();
    unbinder.unbind();
  }
}
