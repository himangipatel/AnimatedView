/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.activity.CardDetailActivity;
import com.bnbjobs.adapter.ChooseOfferAdapter;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.ChooseOfferItem;
import com.bnbjobs.model.PremiumDataModel;
import com.bnbjobs.presenter.ChooseOfferPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.ChooseOfferView;
import com.trello.rxlifecycle.components.support.RxFragment;
import java.util.ArrayList;

/**
 * @author Harsh
 * @version 1.0
 */
public class ChooseOfferFragment extends RxFragment implements ChooseOfferView, ClickImpl<Object> {

  @BindView(R.id.recycler_offer_list) RecyclerView recyclerOfferList;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  private Unbinder unbinder;
  private ArrayList<ChooseOfferItem> chooseOfferItems = new ArrayList<>();
  private ChooseOfferAdapter chooseOfferAdapter;
  private ChooseOfferPresenter chooseOfferPresenter;
  private PremiumDataModel premiumDataModel;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    createOfferItems();
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_chooseoffer, container, false);
    unbinder = ButterKnife.bind(this, view);
    chooseOfferPresenter = new ChooseOfferPresenter();
    chooseOfferPresenter.attachView(this);
    chooseOfferPresenter.setFragment(this);
    setRecyclerViewData();
    chooseOfferPresenter.getPremiumPlanData();
    return view;
  }

  private void createOfferItems() {
    String[] offer_types = getContext().getResources().getStringArray(R.array.offer_types);
    String[] offer_description =
        getContext().getResources().getStringArray(R.array.offer_description);
    String[] offer_discount_desc =
        getContext().getResources().getStringArray(R.array.offer_discount_desc);
    String[] offer_discount_rates =
        getContext().getResources().getStringArray(R.array.offer_discount_rates);
    String[] offer_discount_colors =
        getContext().getResources().getStringArray(R.array.offer_discount_colors);
    for (int i = 0; i < offer_types.length; i++) {
      ChooseOfferItem chooseOfferItem = new ChooseOfferItem();
      chooseOfferItem.setOfferType(offer_types[i]);
      chooseOfferItem.setDiscountLabel(offer_discount_desc[i]);
      chooseOfferItem.setOfferDescription(offer_description[i]);
      chooseOfferItem.setDiscount(offer_discount_rates[i]);
      chooseOfferItem.setColor(offer_discount_colors[i]);
      chooseOfferItems.add(chooseOfferItem);
    }
  }

  private void setRecyclerViewData() {
    recyclerOfferList.setLayoutManager(new LinearLayoutManager(getContext()));
    chooseOfferAdapter = new ChooseOfferAdapter(getContext(), chooseOfferItems, this);
    recyclerOfferList.setAdapter(chooseOfferAdapter);
  }

  @Override public void onDestroyView() {
    chooseOfferPresenter.detachView();
    unbinder.unbind();
    super.onDestroyView();
  }

  @Override public void onResume() {
    super.onResume();
  }

  @Override public void setPremiumData(PremiumDataModel planData) {
    this.premiumDataModel = planData;
    chooseOfferItems.get(0).setPrice(String.valueOf(planData.getPriceOneWeek()));
    chooseOfferItems.get(1).setPrice(String.valueOf(planData.getPriceTwoWeek()));
    chooseOfferItems.get(2).setPrice(String.valueOf(planData.getPriceMonthly()));
    chooseOfferAdapter.notifyDataSetChanged();
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void onClick(View view, Object object, int position) {
    if (premiumDataModel != null) {
      ChooseOfferItem planData = chooseOfferItems.get(position);
      Intent cardDetail = new Intent(getContext(), CardDetailActivity.class);
      cardDetail.putExtra(Constants.KEY_TEXT, planData.getPrice());
      cardDetail.putExtra(Constants.KEY_PLAN_TYPE, String.valueOf(premiumDataModel.getPlanType()));
      startActivity(cardDetail);
    } else {
      Utils.showMessage(getContext(), getString(R.string.plan_amount));
    }
  }
}
