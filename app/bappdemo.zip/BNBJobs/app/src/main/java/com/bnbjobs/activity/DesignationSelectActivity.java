/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.fragments.DesignationParentFragment;
import com.bnbjobs.utils.Constants;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class DesignationSelectActivity extends BaseActivity {

  @BindView(R.id.containerLayout) FrameLayout containerLayout;
  @BindView(R.id.tvApplyFilter) TextView tvApplyFilter;
  private List<String> selectedIds = new ArrayList<>();
  private static final String TAG = makeLogTag(DesignationSelectActivity.class);
  private boolean isSingleSelect;
  private static final int SINGLE_SELECT = 1;
  private int keyEditPosition;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_designation_db);
    ButterKnife.bind(this);
    if (getIntent() != null && getIntent().hasExtra(Constants.KEY_TYPE)) {
      isSingleSelect = getIntent().getIntExtra(Constants.KEY_TYPE, 0) == SINGLE_SELECT;
      keyEditPosition = getIntent().getIntExtra(Constants.KEY_EDIT_POSITION, -1);
    }
    if (savedInstanceState == null) {
      setSelectedIds();
      switchFragment(new DesignationParentFragment(), false);
    }
    if (isSingleSelect) {
      tvApplyFilter.setVisibility(View.GONE);
    }
  }

  private void setSelectedIds() {
    String ids = getIntent().getStringExtra(Constants.KEY_TEXT);
    if (!isEmpty(ids)) {
      selectedIds.addAll(Arrays.asList(ids.split(",")));
    }
  }

  /**
   * @param fragment fragment object
   * @param addToBackStack want to add fragment in back stack or not
   */
  public void switchFragment(Fragment fragment, boolean addToBackStack) {
    FragmentManager fragmentManager = getSupportFragmentManager();
    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
    fragmentTransaction.replace(R.id.containerLayout, fragment);
    if (addToBackStack) {
      fragmentTransaction.addToBackStack(fragment.getClass().getSimpleName());
    }
    fragmentTransaction.commit();
  }

  @OnClick(R.id.tvApplyFilter) public void onFilter() {
    String ids = TextUtils.join(",", selectedIds);
    Intent intent = new Intent();
    intent.putExtra(Constants.KEY_TEXT, ids);
    intent.putExtra(Constants.KEY_EDIT_POSITION, keyEditPosition);
    setResult(RESULT_OK, intent);
    finish();
  }

  public boolean isSingleChoice() {
    return isSingleSelect;
  }

  public List<String> getArrayList() {
    return selectedIds;
  }

  @Override public void onBackPressed() {
    if (!getIntent().hasExtra(Constants.KEY_USER_TYPE)) {
      super.onBackPressed();
    }
  }

  public boolean showCancel() {
    return !getIntent().hasExtra(Constants.KEY_USER_TYPE);
  }
}
