/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import io.realm.RealmObject;
import io.realm.annotations.Required;

/**
 * @author Harsh
 * @version 1.0
 */
public class CountryModel extends RealmObject implements Parcelable {

  @Required private String name;
  @Required @SerializedName("dial_code") private String dialCode;
  @Required @SerializedName("code") private String code;

  public static final Creator<CountryModel> CREATOR = new Creator<CountryModel>() {
    @Override public CountryModel createFromParcel(Parcel in) {
      CountryModel model = new CountryModel();
      model.readIn(in);
      return model;
    }

    @Override public CountryModel[] newArray(int size) {
      return new CountryModel[size];
    }
  };

  private void readIn(Parcel in) {
    name = in.readString();
    dialCode = in.readString();
    code = in.readString();
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDialCode() {
    return dialCode;
  }

  public void setDialCode(String dialCode) {
    this.dialCode = dialCode;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  @Override public int describeContents() {
    return 0;
  }

  @Override public void writeToParcel(Parcel dest, int flags) {
    dest.writeString(name);
    dest.writeString(dialCode);
    dest.writeString(code);
  }
}

