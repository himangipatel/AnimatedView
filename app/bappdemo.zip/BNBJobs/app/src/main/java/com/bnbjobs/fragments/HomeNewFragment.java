/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnTouch;
import butterknife.Unbinder;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.AddGroupActivity;
import com.bnbjobs.activity.CountryJobFragment;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.activity.InviteFriendsActivity;
import com.bnbjobs.adapter.BaseRecyclerAdapter;
import com.bnbjobs.adapter.CityAdapter;
import com.bnbjobs.adapter.GroupListAdapter;
import com.bnbjobs.adapter.HomeAdapter;
import com.bnbjobs.customui.looppager.RecyclerViewPager;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.CountryListModel;
import com.bnbjobs.model.GroupModel;
import com.bnbjobs.model.JobModel;
import com.bnbjobs.model.UpdateEvent;
import com.bnbjobs.presenter.HomeNewFragmentPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.CustomItemDecoration;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.HomeNewFragmentView;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections4.IterableUtils;
import org.apache.commons.collections4.Predicate;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.showMessage;

public class HomeNewFragment extends BaseFragment
    implements HomeNewFragmentView, ClickImpl<Object> {

  private static final String TAG = makeLogTag(HomeNewFragment.class);
  @BindView(R.id.imgSearch) TinTableImageView imgSearch;
  @BindView(R.id.etSearch) EditText etSearch;
  @BindView(R.id.tvCurrentLocation) TextView tvCurrentLocation;

  @BindView(R.id.searchRecyclerView) RecyclerViewPager rvRecentJobs;
  @BindView(R.id.jobRecyclerView) RecyclerViewPager rvSelectionJobs;
  @BindView(R.id.jobKmRecyclerView) RecyclerView rvKmSelectionJobs;
  @BindView(R.id.todayRecyclerView) RecyclerViewPager rvTodayDeal;
  @BindView(R.id.cityRecyclerView) RecyclerView rvCities;
  @BindView(R.id.rvGroupRecyclerView) RecyclerView rvGroupRecyclerView;

  @BindView(R.id.relativeProgress) View relativeProgress;
  @BindView(R.id.scrollView) ScrollView scrollView;

  @BindView(R.id.tvJobSelection) TextView tvJobSelection;
  @BindView(R.id.tvCity) TextView tvCity;
  @BindView(R.id.tvRecentSearch) TextView tvRecentSearch;

  @BindView(R.id.swipeRefresh) SwipeRefreshLayout mSwipeRefreshLayout;
  @BindView(R.id.pbSearch) View pbSearch;

  @BindView(R.id.tvJobSelectionError) TextView tvJobSelectionError;
  @BindView(R.id.tvJobKmSelectionError) TextView tvJobKmSelectionError;
  @BindView(R.id.tvTodayError) TextView tvTodayDealError;
  @BindView(R.id.tvCityError) TextView tvCityError;
  @BindView(R.id.tvGroupError) TextView tvGroupError;

  @BindView(R.id.tvRecentSearchError) TextView tvRecentSearchError;
  @BindView(R.id.tvUpdateTitle) TextView tvUpdateTitle;

  @BindView(R.id.ivInviteFriend) View ivInviteFriend;
  @BindView(R.id.tvMapRadius) TextView tvMapRadius;
  @BindView(R.id.tvFilters) TextView tvFilters;

  private Unbinder mUnbind;
  private HomeNewFragmentPresenter presenter;
  private List<JobModel> recentJobSearchList, selectionJobList, kmJobList, todayDealList;
  private List<CountryListModel> cityList;
  private List<GroupModel> mGroupModelList;
  private int PLACE_AUTOCOMPLETE_REQUEST_CODE = 1111;

  @Override public void

  onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    init();
  }

  private void init() {
    recentJobSearchList = new ArrayList<>();
    cityList = new ArrayList<>();
    selectionJobList = new ArrayList<>();
    kmJobList = new ArrayList<>();
    todayDealList = new ArrayList<>();
    mGroupModelList = new ArrayList<>();
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
    return inflater.inflate(R.layout.fragment_home_new, container, false);
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    EventBus.getDefault().register(this);
    if (presenter == null) {
      presenter = new HomeNewFragmentPresenter();
    }
    mUnbind = ButterKnife.bind(this, view);

    presenter.setFragment(this);
    presenter.attachView(this);
    presenter.onSearch(etSearch);
    presenter.onSwipeRefresh(mSwipeRefreshLayout);

    String placeName = getPrefs(getActivity()).getString(QuickstartPreferences.PLACE_NAME, "");
    tvMapRadius.setText(getString(R.string.map_radius, placeName));

    String name = getPrefs(getActivity()).getString(QuickstartPreferences.USER_FNAME, "");
    tvUpdateTitle.setText(getString(R.string.are_you_looking_for_ben, name));
    int height = getResources().getDimensionPixelOffset(R.dimen._200sdp) * 2;

    HomeAdapter mSearchAdapter = new HomeAdapter(getActivity(), height, recentJobSearchList, this);
    rvRecentJobs.setAdapter(mSearchAdapter);

    HomeAdapter mJobListAdapter = new HomeAdapter(getActivity(), height, selectionJobList, this);
    rvSelectionJobs.setAdapter(mJobListAdapter);

    HomeAdapter mKmListAdapter = new HomeAdapter(getActivity(), height, kmJobList, this);
    rvKmSelectionJobs.addItemDecoration(new CustomItemDecoration(getResources().getDimensionPixelSize(R.dimen._10sdp)));
    mKmListAdapter.setIsFavorite(true);
    rvKmSelectionJobs.setAdapter(mKmListAdapter);

    HomeAdapter mTodayAdapter = new HomeAdapter(getActivity(), height, todayDealList, this);
    rvTodayDeal.setAdapter(mTodayAdapter);

    GroupListAdapter groupListAdapter = new GroupListAdapter(getActivity(),mGroupModelList);
    groupListAdapter.setIsUserGroup(true);
    groupListAdapter.setRecycleOnItemClickListner(new BaseRecyclerAdapter.RecycleOnItemClickListener() {
      @Override public void onItemClick(View view, int position) {
        if (view.getId() == R.id.tvJoin) {
          //delete group
          if (mGroupModelList.get(position).getuId() == getUserId(getActivity())) {
            presenter.deleteGroup(String.valueOf(mGroupModelList.get(position).getgId()));
          }
        }else{
          Intent intent = new Intent(getActivity(), AddGroupActivity.class);
          if (!mGroupModelList.get(position).isShowAdd()) {
            intent.putExtra(Constants.KEY_GROUP_ID, mGroupModelList.get(position).getgId());
            intent.putExtra(Constants.KEY_EDIT, true);
          }
          startActivity(intent);
        }

      }
    });
    rvGroupRecyclerView.setAdapter(groupListAdapter);
    CityAdapter mCityAdapter = new CityAdapter(getActivity(), cityList);
    mCityAdapter.setRecycleOnItemClickListner(mRecycleOnItemClickListener);
    rvCities.addItemDecoration(new CustomItemDecoration(getResources().getDimensionPixelSize(R.dimen._10sdp)));
    rvCities.setAdapter(mCityAdapter);

    hideSearchProgress();

    showRecentJob(!recentJobSearchList.isEmpty());
    showCityList(!cityList.isEmpty());
    showJobOfferList(!selectionJobList.isEmpty());
    showKmJobOfferList(!kmJobList.isEmpty());
    showTodayOfferList(!todayDealList.isEmpty());
    showGroupList();
  }

  private void showTodayOfferList(boolean show) {
    if (show) {
      tvTodayDealError.setVisibility(View.INVISIBLE);
      rvTodayDeal.setVisibility(View.VISIBLE);
    } else {
      tvTodayDealError.setVisibility(View.VISIBLE);
      rvTodayDeal.setVisibility(View.INVISIBLE);
    }
  }

  private void showGroupList() {
    if(mGroupModelList.isEmpty())
      mGroupModelList.add(new GroupModel(true));

    if (!mGroupModelList.isEmpty()) {
      tvGroupError.setVisibility(View.INVISIBLE);
      rvGroupRecyclerView.setVisibility(View.VISIBLE);
    } else {
      tvGroupError.setVisibility(View.VISIBLE);
      rvGroupRecyclerView.setVisibility(View.INVISIBLE);
    }
  }

  @Override public void onResume() {
    super.onResume();
    showToolbar(false);
  }

  @Override public void onClick(View view, Object object, int position) {
    if (object instanceof JobModel) {
      JobModel model = (JobModel) object;
      Bundle bundle = new Bundle();
      bundle.putString(Constants.KEY_ID, model.getRpId());
      bundle.putInt(Constants.KEY_POSITION, position);
      JobDetailFragment fragment = new JobDetailFragment();
      fragment.setTargetFragment(this, 1111);
      fragment.setArguments(bundle);
      ((HomeActivity) getActivity()).switchFragment(fragment, true);
    }
  }

  private BaseRecyclerAdapter.RecycleOnItemClickListener mRecycleOnItemClickListener = new BaseRecyclerAdapter.RecycleOnItemClickListener() {
        @Override public void onItemClick(View view, int position) {
          CountryListModel mCity = cityList.get(position);
          SearchDetailFragment mSearchDetailFragment = new SearchDetailFragment();
          Bundle bundle = new Bundle();
          bundle.putString(Constants.KEY_TEXT, mCity.getName());
          bundle.putString(Constants.KEY_DIALOG_TYPE, "Country");
          bundle.putString(Constants.KEY_TYPE, mCity.getName());
          mSearchDetailFragment.setArguments(bundle);
          addFragment(mSearchDetailFragment, true);
        }
      };

  @Override public void updateList(final String offerId) {
    JobModel jobModel = IterableUtils.find(recentJobSearchList, new Predicate<JobModel>() {
      @Override public boolean evaluate(JobModel object) {
        return offerId.equalsIgnoreCase(object.getRpId());
      }
    });
    if (jobModel != null) {
      jobModel.setApplyJobBtnFlag(2); // applied
    }
    JobModel jobModel2 = IterableUtils.find(selectionJobList, new Predicate<JobModel>() {
      @Override public boolean evaluate(JobModel object) {
        return offerId.equalsIgnoreCase(object.getRpId());
      }
    });
    if (jobModel2 != null) {
      jobModel2.setApplyJobBtnFlag(2); // applied
    }

    JobModel jobModel3 = IterableUtils.find(kmJobList, new Predicate<JobModel>() {
      @Override public boolean evaluate(JobModel object) {
        return offerId.equalsIgnoreCase(object.getRpId());
      }
    });
    if (jobModel3 != null) {
      jobModel3.setApplyJobBtnFlag(2); // applied
    }

    JobModel jobModel4 = IterableUtils.find(todayDealList, new Predicate<JobModel>() {
      @Override public boolean evaluate(JobModel object) {
        return offerId.equalsIgnoreCase(object.getRpId());
      }
    });
    if (jobModel4 != null) {
      jobModel4.setApplyJobBtnFlag(2); // applied
    }
  }

  @Subscribe public void onEvent(UpdateEvent event){
    if (event != null && event.getGroupModel() != null) {
      final GroupModel groupModel = event.getGroupModel();
      final GroupModel model = IterableUtils.find(mGroupModelList, new Predicate<GroupModel>() {
        @Override public boolean evaluate(GroupModel object) {
          return groupModel.getgId() == object.getgId();
        }
      });
      if (model != null) {
        int pos = mGroupModelList.indexOf(model);
        mGroupModelList.set(pos, event.getGroupModel());
        rvGroupRecyclerView.getAdapter().notifyItemChanged(pos);
      } else {
        mGroupModelList.add(event.getGroupModel());
        rvGroupRecyclerView.getAdapter().notifyDataSetChanged();
      }
    }
  }

  @Override public void onError() {
  }

  @Override public void clearData() {
  }

  @Override public void showProgress() {
    relativeProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    relativeProgress.setVisibility(View.GONE);
    if (mSwipeRefreshLayout.isRefreshing()) {
      mSwipeRefreshLayout.setRefreshing(false);
    }
    if (pbSearch.getVisibility() == View.VISIBLE) {
      pbSearch.setVisibility(View.VISIBLE);
    }
  }

  @Override public void showSearchProgress() {
    pbSearch.setVisibility(View.VISIBLE);
  }

  @Override public void hideSearchProgress() {
    pbSearch.setVisibility(View.INVISIBLE);
  }

  public RecyclerViewPager getRvRecentJobs() {
    return rvRecentJobs;
  }

  public RecyclerViewPager getRvSelectionJobs() {
    return rvSelectionJobs;
  }

  @Override public RecyclerViewPager getTodayDeal() {
    return rvTodayDeal;
  }

  public RecyclerView getRvCities() {
    return rvCities;
  }

  @Override public RecyclerView getKmJob() {
    return rvKmSelectionJobs;
  }

  @Override public RecyclerView getGroupRecycle() {
    return rvGroupRecyclerView;
  }

  private void scrollSetup(){

      rvRecentJobs.scrollToPosition(1);
      rvSelectionJobs.scrollToPosition(1);
      rvKmSelectionJobs.scrollToPosition(1);
      rvTodayDeal.scrollToPosition(1);

  }

  @Override public void setRecentJobAdapter(BaseContainer<JobModel> baseContainer) {
    boolean success = baseContainer.isSuccess();
    List<JobModel> dataList = baseContainer.getDataList();
    if (success) {
      if (dataList != null && !dataList.isEmpty()) {
        showRecentJob(true);
        recentJobSearchList.clear();
        recentJobSearchList.addAll(dataList);
        rvRecentJobs.getAdapter().notifyDataSetChanged();
      } else if (recentJobSearchList.isEmpty()) {
        showRecentJob(false);
      }
    } else {
      showRecentJob(false);
    }
    scrollSetup();
  }

  @Override public void setSelectionJobAdapter(BaseContainer<JobModel> baseContainer) {
    boolean success = baseContainer.isSuccess();
    List<JobModel> dataList = baseContainer.getDataList();
    boolean clearAll = baseContainer.getCurrentPage() == 1;
    if (success) {
      if (dataList != null && !dataList.isEmpty()) {
        showJobOfferList(true);
        if (clearAll) {
          selectionJobList.clear();
        }
        selectionJobList.addAll(dataList);
        rvSelectionJobs.getAdapter().notifyDataSetChanged();
      } else if (selectionJobList.isEmpty()) {
        showJobOfferList(false);
      }
    } else {
      showJobOfferList(false);
    }
  }

  @Override public void setTodayDealList(BaseContainer<JobModel> baseContainer) {
    boolean success = baseContainer.isSuccess();
    List<JobModel> dataList = baseContainer.getDataList();
    boolean clearAll = baseContainer.getCurrentPage() == 1;
    if (success) {
      if (dataList != null && !dataList.isEmpty()) {
        showTodayOfferList(true);
        if (clearAll) {
          todayDealList.clear();
        }
        todayDealList.addAll(dataList);
        rvTodayDeal.getAdapter().notifyDataSetChanged();
      } else if (todayDealList.isEmpty()) {
        showTodayOfferList(false);
      }
    } else {
      showTodayOfferList(false);
    }
  }

  @Override public void setKmJobAdapter(BaseContainer<JobModel> baseContainer) {
    boolean success = baseContainer.isSuccess();
    List<JobModel> dataList = baseContainer.getDataList();
    boolean clearAll = baseContainer.getCurrentPage() == 1;
    if (success) {
      if (dataList != null && !dataList.isEmpty()) {
        showKmJobOfferList(true);
        if (clearAll) {
          kmJobList.clear();
        }
        kmJobList.addAll(dataList);
        rvKmSelectionJobs.getAdapter().notifyDataSetChanged();
      } else if (kmJobList.isEmpty()) {
        showKmJobOfferList(false);
      }
    } else {
      showKmJobOfferList(false);
    }
  }

  @Override public void onGroupSuccess(List<GroupModel> dataList, boolean b) {
    if(b){
      mGroupModelList.clear();
      showGroupList();
    }
    mGroupModelList.addAll(dataList);
    rvGroupRecyclerView.getAdapter().notifyDataSetChanged();
  }

  @Override public void onDeleteSuccess(final String groupId) {
    if (groupId != null) {
      final GroupModel model = IterableUtils.find(mGroupModelList, new Predicate<GroupModel>() {
        @Override public boolean evaluate(GroupModel object) {
          return Integer.parseInt(groupId) == object.getgId();
        }
      });
      if (model != null) {
        int pos = mGroupModelList.indexOf(model);
        mGroupModelList.remove(pos);
        rvGroupRecyclerView.getAdapter().notifyItemRemoved(pos);
      }
    }
  }

  @Override public void onError(String message) {
    showMessage(getActivity(),message);
  }

  @Override public void setMyCityAdapter(BaseContainer<CountryListModel> baseContainer) {
    boolean success = baseContainer.isSuccess();
    List<CountryListModel> dataList = baseContainer.getDataList();
    boolean clearAll = baseContainer.getCurrentPage() == 1;
    if (success) {
      if (dataList != null && !dataList.isEmpty()) {
        showCityList(true);
        if (clearAll) {
          cityList.clear();
        }
        cityList.addAll(dataList);
        rvCities.getAdapter().notifyDataSetChanged();
      } else if (cityList.isEmpty()) {
        showCityList(false);
      }
    } else {
      showCityList(false);
    }
  }

  private void showRecentJob(boolean show) {
    if (show) {
      tvRecentSearchError.setVisibility(View.INVISIBLE);
      rvRecentJobs.setVisibility(View.VISIBLE);
    } else {
      tvRecentSearchError.setVisibility(View.VISIBLE);
      rvRecentJobs.setVisibility(View.INVISIBLE);
    }
  }

  private void showJobOfferList(boolean show) {
    if (show) {
      tvJobSelectionError.setVisibility(View.INVISIBLE);
      rvSelectionJobs.setVisibility(View.VISIBLE);
    } else {
      tvJobSelectionError.setVisibility(View.VISIBLE);
      rvSelectionJobs.setVisibility(View.GONE);
    }
  }

  private void showKmJobOfferList(boolean show) {
    if (show) {
      tvJobKmSelectionError.setVisibility(View.INVISIBLE);
      rvKmSelectionJobs.setVisibility(View.VISIBLE);
    } else {
      tvJobKmSelectionError.setVisibility(View.VISIBLE);
      rvKmSelectionJobs.setVisibility(View.GONE);
    }
  }

  private void showCityList(boolean show) {
    if (show) {
      tvCityError.setVisibility(View.INVISIBLE);
      rvCities.setVisibility(View.VISIBLE);
    } else {
      tvCityError.setVisibility(View.VISIBLE);
      rvCities.setVisibility(View.GONE);
    }
  }

  @Override public void onDestroyView() {
    EventBus.getDefault().unregister(this);
    super.onDestroyView();

    if (mUnbind != null) {
      mUnbind.unbind();
    }
  }

  @OnTouch(R.id.scrollView) public boolean onTouch() {
    etSearch.clearFocus();
    Utils.hideKeyboard(getActivity());
    return false;
  }

  private void findPlace() {
    try {
      Intent intent =
          new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY).build(getActivity());
      startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
    } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
      LOGE(TAG, e.getMessage(), e);
    }
  }

  @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
      if (resultCode == Activity.RESULT_OK) {
        Place place = PlaceAutocomplete.getPlace(getActivity(), data);
        getPrefs(getActivity()).save(QuickstartPreferences.PLACE_NAME,
            String.valueOf(place.getName()));
        getPrefs(getActivity()).save(QuickstartPreferences.LAT,
            String.valueOf(place.getLatLng().latitude));
        getPrefs(getActivity()).save(QuickstartPreferences.LNG,
            String.valueOf(place.getLatLng().longitude));
        presenter.updateUserLocation(place);
      } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
        Status status = PlaceAutocomplete.getStatus(getActivity(), data);
        LOGI(TAG, status.getStatusMessage());
      } else if (resultCode == Activity.RESULT_CANCELED) {
        LOGI(TAG, "User cancel");
      }
    }
  }

  @OnClick({ R.id.tvCurrentLocation, R.id.ivInviteFriend, R.id.tvFilters, R.id.tvMapRadius })
  public void onClick(View view) {
    switch (view.getId()) {
      case R.id.tvFilters:
        SearchFragment fragment = new SearchFragment();
        fragment.setTargetFragment(this, 1000);
        addFragment(fragment, true);
        break;
      case R.id.tvMapRadius:
        addFragment(new CountryJobFragment(), true);
        break;
      case R.id.ivInviteFriend:
        Intent inviteFriend = new Intent(getActivity(), InviteFriendsActivity.class);
        startActivity(inviteFriend);
        break;
      case R.id.tvCurrentLocation:
        findPlace();
        break;
    }
  }

  @Override public void onLocationSet(String location) {
    //tvCurrentLocation.setText(location);
  }
}

