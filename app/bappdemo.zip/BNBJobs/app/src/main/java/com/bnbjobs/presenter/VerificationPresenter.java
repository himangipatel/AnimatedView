/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.activity.VerifyPhoneActivity;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.VerificationView;
import com.trello.rxlifecycle.ActivityEvent;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;

/**
 * @author Harsh
 * @version 1.0
 */
public class VerificationPresenter extends BasePresenter implements Presenter<VerificationView> {

  private VerificationView verificationView;

  @Override protected Context getBaseContext() {
    return verificationView.getContext();
  }

  @Override public void attachView(VerificationView view) {
    this.verificationView = view;
  }

  @Override public void detachView() {
    this.verificationView = null;
  }

  public void verifyPhoneNumber(String verificationCode) {
    verificationView.showProgress();
    HashMap<String, String> params = new HashMap<>(3);
    params.put("apiName", "verifyPhoneToken");
    params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
    params.put("phoneToken", verificationCode);
    RestClient.getInstance(params)
        .compose(getContext().<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            verificationView.hideProgress();
          }

          @Override public void onNext(String s) {
            verificationView.hideProgress();
            try {
              JSONObject jsonObject = new JSONObject(s);
              boolean success = jsonObject.optBoolean("success");
              String message = jsonObject.optString("message", "");
              if (success) {
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_PHONE_VERIFIED, 1);
              }
              verificationView.onVerificationComplete(success, message);
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  public void callVerificationCodeApi(String currentPhoneNumber) {
    verificationView.showProgress();
    String pnE164 = Utils.getConvertedNumber(getContext(), currentPhoneNumber);
    HashMap<String, String> params = new HashMap<>(3);
    params.put("apiName", "resendOTP");
    params.put("number", pnE164);
    RestClient.getInstance(params)
        .compose(getContext().<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            verificationView.hideProgress();
          }

          @Override public void onNext(String s) {
            verificationView.hideProgress();
            try {
              JSONObject jsonObject = new JSONObject(s);
              boolean success = jsonObject.optBoolean("success");
              String message = jsonObject.optString("message", "");
              verificationView.onCodeResend(success, message);
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  private VerifyPhoneActivity getContext() {
    return (VerifyPhoneActivity) verificationView.getContext();
  }
}
