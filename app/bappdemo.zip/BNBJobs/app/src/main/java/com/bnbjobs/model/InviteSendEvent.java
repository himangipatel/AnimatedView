/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class InviteSendEvent {

  private List<InviteSelectModel> mInviteSelectModel;
  private String uIds;

  public List<InviteSelectModel> getmInviteSelectModel() {
    return mInviteSelectModel;
  }

  public void setmInviteSelectModel(List<InviteSelectModel> mInviteSelectModel) {
    this.mInviteSelectModel = mInviteSelectModel;
  }

  public String getuIds() {
    return uIds;
  }

  public void setuIds(String uIds) {
    this.uIds = uIds;
  }
}
