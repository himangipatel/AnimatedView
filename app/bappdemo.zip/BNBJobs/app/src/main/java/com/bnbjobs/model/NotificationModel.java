/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import android.content.Context;
import com.bnbjobs.R;
import com.google.gson.annotations.SerializedName;

/**
 * @author Harsh
 * @version 1.0
 */
public class NotificationModel {

  @SerializedName("u_id") private String uId;
  @SerializedName("u_fname") private String fName;
  @SerializedName("u_lname") private String lName;
  @SerializedName("u_image") private String image;
  @SerializedName("n_notification_type") private int notification;
  @SerializedName("n_rp_id") private int offerId;
  @SerializedName("n_created_at") private String createdAt;
  @SerializedName("u_image_url") private String imageUrl;
  @SerializedName("u_image_thumb_url") private String imageThumbUrl;
  @SerializedName("n_title") private String title;
  @SerializedName("n_text") private String text;

  public int getOfferId() {
    return offerId;
  }

  public void setOfferId(int offerId) {
    this.offerId = offerId;
  }

  public String getuId() {
    return uId;
  }

  public void setuId(String uId) {
    this.uId = uId;
  }

  public String getfName() {
    return fName;
  }

  public void setfName(String fName) {
    this.fName = fName;
  }

  public String getlName() {
    return lName;
  }

  public void setlName(String lName) {
    this.lName = lName;
  }

  public String getImage() {
    return image;
  }

  public void setImage(String image) {
    this.image = image;
  }

  public int getNotification() {
    return notification;
  }

  public void setNotification(int notification) {
    this.notification = notification;
  }

  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  public String getImageUrl() {
    return imageUrl;
  }

  public void setImageUrl(String imageUrl) {
    this.imageUrl = imageUrl;
  }

  public String getImageThumbUrl() {
    return imageThumbUrl;
  }

  public void setImageThumbUrl(String imageThumbUrl) {
    this.imageThumbUrl = imageThumbUrl;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getText() {
    return text;
  }

  public void setText(String text) {
    this.text = text;
  }

  public String getTitileNotification(Context context) {

    if (getNotification() == 1) {
      return context.getString(R.string.notification_accept);
    } else if (getNotification() == 2) {
      return context.getString(R.string.notification_reject);
    } else if (getNotification() == 3) {
      return context.getString(R.string.notification_new_candidate);
    } else if (getNotification() == 4) {
      return context.getString(R.string.notification_expire);
    } else if (getNotification() == 5) {
      return context.getString(R.string.notification_approve);
    } else if (getNotification() == 6) {
      return context.getString(R.string.notification_denial);
    }

    return "";
  }
}




