/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;

/**
 * @author Harsh
 * @version 1.0
 */
public class JobImages {
  @SerializedName("rpi_image") private String rpiImage;
  @SerializedName("rp_image_url") private String rpImageUrl;
  @SerializedName("rp_image_thumb_url") private String rpImageThumbUrl;

  public String getRpiImage() {
    return rpiImage;
  }

  public void setRpiImage(String rpiImage) {
    this.rpiImage = rpiImage;
  }

  public String getRpImageUrl() {
    return rpImageUrl;
  }

  public void setRpImageUrl(String rpImageUrl) {
    this.rpImageUrl = rpImageUrl;
  }

  public String getRpImageThumbUrl() {
    return rpImageThumbUrl;
  }

  public void setRpImageThumbUrl(String rpImageThumbUrl) {
    this.rpImageThumbUrl = rpImageThumbUrl;
  }
}

