/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.DesignationSelectActivity;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.adapter.OfferImagesAdapter;
import com.bnbjobs.customui.views.GradientView;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.keyboard.KeyboardVisibilityEvent;
import com.bnbjobs.keyboard.KeyboardVisibilityEventListener;
import com.bnbjobs.model.DesignationDbModel;
import com.bnbjobs.model.EditImageModel;
import com.bnbjobs.model.ImageModel;
import com.bnbjobs.model.JobOfferData;
import com.bnbjobs.model.PhotoModel;
import com.bnbjobs.presenter.OfferPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.SpacesItemDecoration;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.OfferFragmentView;
import com.bumptech.glide.Glide;
import com.google.android.gms.location.places.Place;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.json.JSONException;
import org.json.JSONObject;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnNeverAskAgain;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.presenter.BasePresenter.toRequestBody;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.showMessage;

@RuntimePermissions public class OfferFragment extends BaseFragment implements OfferFragmentView, ClickImpl<Object> {
  public static final String ARG_IMAGE_MODEL = "imageModel";
  public static final String ARG_JOBOFFER_MODEL = "jobofferModel";
  private static final String TAG = makeLogTag(OfferFragment.class);
  @BindView(R.id.rlDelete) RelativeLayout rlDelete;
  @BindView(R.id.ivDelete) ImageView ivDelete;
  @BindView(R.id.ivPhoto4) ImageView ivPhoto4;
  @BindView(R.id.tlPhotoVideo) LinearLayout tlPhotoVideo;
  @BindView(R.id.rbCDI) RadioButton rbCDI;
  @BindView(R.id.rbCDD) RadioButton rbCDD;
  @BindView(R.id.rbINDTERIN) RadioButton rbINDTERIN;
  @BindView(R.id.rbStage) RadioButton rbStage;
  @BindView(R.id.rbOne) RadioButton rbOne;
  @BindView(R.id.rbTwo) RadioButton rbTwo;
  @BindView(R.id.rbThree) RadioButton rbThree;
  @BindView(R.id.rbFive) RadioButton rbFive;
  @BindView(R.id.rbFifty) RadioButton rbProfileFifty;
  @BindView(R.id.rbSixty) RadioButton rbProfileSixty;
  @BindView(R.id.rbEighty) RadioButton rbProfileEighty;
  @BindView(R.id.ivIcnMap) ImageView ivIcnMap;
  @BindView(R.id.rlLocation) RelativeLayout rlLocation;
  @BindView(R.id.ivIcnRef) ImageView ivIcnRef;
  @BindView(R.id.edtReferance) EditText edtReferance;
  @BindView(R.id.rlReferance) RelativeLayout rlReferance;
  @BindView(R.id.edtDesc) EditText edtDesc;
  @BindView(R.id.llDesc) LinearLayout llDesc;
  @BindView(R.id.ivDesc) ImageView ivDesc;
  @BindView(R.id.rlDesc) RelativeLayout rlDesc;
  @BindView(R.id.ivSalary) ImageView ivSalary;
  @BindView(R.id.edtSalary) EditText edtSalary;
  @BindView(R.id.rlSalary) RelativeLayout rlSalary;
  @BindView(R.id.ivTransCom) ImageView ivTransCom;
  @BindView(R.id.btnDone) GradientView btnDone;
  @BindView(R.id.tvStartMonth) TextView tvStartMonth;
  @BindView(R.id.tvEndMonth) TextView tvEndMonth;
  @BindView(R.id.tvCharacter) TextView tvCharacter;
  @BindView(R.id.tvCharacterDescription) TextView tvCharacterDescription;
  @BindView(R.id.etRequiredQuality) EditText etRequiredQuality;
  @BindView(R.id.tvLocation) TextView tvLocation;
  @BindView(R.id.etOtherBenefits) TextView etOtherBenefits;
  @BindView(R.id.recyclerViewPhoto) RecyclerView recyclerViewPhoto;
  @BindView(R.id.nestedScrollView) NestedScrollView nestedScrollView;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.linestart) View linestart;
  @BindView(R.id.lineend) View lineend;
  @BindView(R.id.relRoot) RelativeLayout relRoot;
  @BindView(R.id.tvDesignationSelect) TextView tvDesignationSelect;
  private OfferPresenter offerPresenter;
  private Place locPlace;
  private String displayDate = "";
  private ImageModel selMedia;
  private OfferImagesAdapter offerImagesAdapter;
  private List<ImageModel> mPhotoList = new ArrayList<ImageModel>();
  //For maintaining server side image updating in edit job offer mode.
  private List<Integer> serverPhotoIds = new ArrayList<>();
  private HashMap<Integer, EditImageModel> editImageIds = new HashMap<>();
  private ImageModel mVideoModel = null;
  private int radioStatus = 0;
  private Unbinder unbinder;
  private JobOfferData editJobData;
  private boolean isVideoEdited;
  private boolean isVideoDeleted;
  private boolean isEditMode;
  private int imageEdiPos = -1;
  private boolean isStopCalled = false;
  private String endDate = "";
  private int contentType;
  private String location;
  private String latitude;
  private String longitude;
  private String reference;
  private String startDate;
  private String desc;
  private String salary;
  private String requiredQuality;
  private String otherBenefits;
  private static final int FILTER_CODE = 7777;
  private String dId;
  private boolean showRightImage;
  private String countryCode;
  private int expId;
  private int profilePercentage;

  public OfferFragment() {
    // Required empty public constructor
  }

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    if (getArguments() != null) {
      selMedia = (ImageModel) getArguments().getSerializable(ARG_IMAGE_MODEL);
      editJobData = (JobOfferData) getArguments().getSerializable(ARG_JOBOFFER_MODEL);
    }
    if (editJobData != null) {
      setHasOptionsMenu(true);
      showRightImage = false;
    } else {
      showRightImage = true;
    }
    setRetainInstance(true);
  }

  @Override public View onCreateView(LayoutInflater inflater, ViewGroup container,
      Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_offer, container, false);
    unbinder = ButterKnife.bind(this, view);
    offerPresenter = new OfferPresenter();
    offerPresenter.attachView(this);
    offerPresenter.setFragment(this);
    setRbCDISelected();
    setExperience(R.id.rbOne);
    setProfilePercentage(R.id.rbFifty);
    registerKeyboardListener(true);
    changeSoftInputMode(true);

    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    //setEditTouchListener();
    if (offerImagesAdapter == null) {
      offerImagesAdapter = new OfferImagesAdapter(getActivity(), mPhotoList, this);
    }
    recyclerViewPhoto.setNestedScrollingEnabled(false);
    recyclerViewPhoto.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
    recyclerViewPhoto.setAdapter(offerImagesAdapter);
    if (mVideoModel == null) {
      rlDelete.setVisibility(View.GONE);
    }
    setInitialData();
    int spacingInPixels = getResources().getDimensionPixelSize(R.dimen._5sdp);
    recyclerViewPhoto.addItemDecoration(new SpacesItemDecoration(spacingInPixels));
    offerImagesAdapter.setEdit(!isEditMode);
    if (isEditMode) {
      disableEnableControls(false, nestedScrollView);
    }
    setupUI(nestedScrollView);
    etRequiredQuality.addTextChangedListener(qualityWatcher);
    edtDesc.addTextChangedListener(descriptionWatcher);
  }

  @OnClick({ R.id.rbFifty, R.id.rbSixty, R.id.rbEighty }) void onProfileChoose(View view) {
    int id = view.getId();
    setProfilePercentage(id);
  }

  @OnClick({ R.id.rbOne, R.id.rbTwo, R.id.rbThree, R.id.rbFive }) void onExperienceChoose(View view) {
    int id = view.getId();
    setExperience(id);
  }

  @Override public void onResume() {
    super.onResume();
    showToolbar(true);
    showRightImage(showRightImage);
    setRightImage(R.drawable.top_check);
    if (!isEditMode) {
      setTitle(getString(R.string.add_job_offer));
    } else {
      setTitle(getString(R.string.edit_job_offer));
    }
  }

  private static final int descriptionLimit = 150;
  private static final int qualityLimit = 100;

  public TextWatcher descriptionWatcher = new TextWatcher() {
    @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override public void afterTextChanged(Editable s) {
      if (s.toString().length() <= descriptionLimit) {
        tvCharacterDescription.setText(
            String.format(Locale.getDefault(), "%s/%d", s.toString().length(), descriptionLimit));
      }
    }
  };

  public TextWatcher qualityWatcher = new TextWatcher() {
    @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override public void afterTextChanged(Editable s) {
      if (s.toString().length() <= qualityLimit) {
        tvCharacter.setText(
            String.format(Locale.getDefault(), "%s/%d", s.toString().length(), qualityLimit));
      }
    }
  };

  private void visibleRightImage() {
    showRightImage(showRightImage);
  }

  private void setInitialData() {
    if (selMedia != null) {
      if (selMedia.isVideo()) {
        addVideo(selMedia);
      } else {
        addImage(selMedia, 0);
      }
    } else {
      if (editJobData != null) {
        isEditMode = true;
        setEditOfferModeData();
      }
    }
  }

  private void setEditOfferModeData() {
    mPhotoList.clear();
    editImageIds.clear();
    serverPhotoIds.clear();
    if (!editJobData.getmPhotoList().isEmpty()) {
      for (int i = 0; i < editJobData.getmPhotoList().size(); i++) {
        PhotoModel photoModel = editJobData.getmPhotoList().get(i);
        ImageModel imageModel = new ImageModel();
        imageModel.setVideo(false);
        imageModel.setImageId(Integer.parseInt(photoModel.getImageId()));
        imageModel.setEdit(true);
        imageModel.setImageUrl(photoModel.getImageUrl());
        imageModel.setImage(photoModel.getImage());
        imageModel.setImageThumbUrl(photoModel.getImageThumbUrl());
        mPhotoList.add(imageModel);
        EditImageModel editImageModel = new EditImageModel();
        editImageModel.setAdded(false);
        editImageModel.setEdited(false);
        editImageModel.setDeleted(false);
        editImageModel.setUpdatedImageModel(imageModel);
        editImageIds.put(Integer.parseInt(photoModel.getImageId()), editImageModel);
        serverPhotoIds.add(Integer.parseInt(photoModel.getImageId()));
      }
    }
    offerImagesAdapter.notifyDataSetChanged();
    if (!isEmpty(editJobData.getVideo())) {
      rlDelete.setVisibility(View.VISIBLE);
      ImageModel mVideoModel = new ImageModel();
      mVideoModel.setVideo(true);
      mVideoModel.setImageUrl(editJobData.getVideoUrl());
      mVideoModel.setEdit(true);
      mVideoModel.setImage(editJobData.getVideo());
      addVideoOperation(mVideoModel);
    }
    if (!isEmpty(editJobData.getStartDate())) {
      startDate = String.valueOf(Long.parseLong(editJobData.getStartDate()) * 1000);
      tvStartMonth.setText(Utils.getDisplayDate(startDate));
    }
    if (!isEmpty(editJobData.getEndDate())) {
      endDate = String.valueOf(Long.parseLong(editJobData.getEndDate()) * 1000);
      tvEndMonth.setText(Utils.getDisplayDate(endDate));
      tvEndMonth.setVisibility(View.VISIBLE);
    }
    dId = Integer.toString(editJobData.getDesignationId());
    tvDesignationSelect.setText(editJobData.getdTitle());
    contentType = editJobData.getContractType();
    setDefaultRadioButton(editJobData.getContractType());
    location = editJobData.getLocation();
    latitude = editJobData.getLatitude();
    longitude = editJobData.getLongitude();
    tvLocation.setText(location);
    reference = editJobData.getReferences();
    edtReferance.setText(reference);
    salary = editJobData.getSalary();
    edtSalary.setText(salary);
    desc = editJobData.getDescription();
    edtDesc.setText(desc);
    setProfile(Integer.parseInt(editJobData.getProfilePer()));
    setExpLvl(editJobData.getExpRequired());
    //experience = editJobData.getExperience();
    //etExperience.setText(experience);
    otherBenefits = editJobData.getOtherBenefits();
    etOtherBenefits.setText(otherBenefits);
    requiredQuality = editJobData.getQuality();
    etRequiredQuality.setText(requiredQuality);
    countryCode = isEmpty(editJobData.getCountryName()) ? "" : editJobData.getCountryName();
  }

  private void setDefaultRadioButton(int contractType) {
    if (contractType == 1) {
      setRbCDISelected();
    } else if (contractType == 2) {
      setRbCDDSelected();
    } else if(contractType == 3){
      setRbINDTERINSelected();
    }else{
      setRbStageSelected();
    }
  }

  private void setEditTouchListener() {
    edtDesc.setOnTouchListener(new View.OnTouchListener() {

      public boolean onTouch(View v, MotionEvent event) {
        nestedScrollView.requestDisallowInterceptTouchEvent(true);
        switch (event.getAction() & MotionEvent.ACTION_MASK) {
          case MotionEvent.ACTION_UP:
            nestedScrollView.requestDisallowInterceptTouchEvent(false);
            break;
        }
        return false;
      }
    });
  }

  @Override public void setPlaceInView(Place place, int click) {
    String placeAddress = place.getAddress().toString();
    if (click == 1) {
      locPlace = place;
      rlLocation.setClickable(true);
      tvLocation.setText(placeAddress);
    } else if (click == 2) {
      rlLocation.setClickable(true);
    }
  }

  @Override public void setCancelSearchPlace(String message) {
    rlLocation.setClickable(true);
    LOGE(OfferFragment.class.getName(), message);
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    nestedScrollView.setVisibility(View.VISIBLE);
    linearProgress.setVisibility(View.GONE);
  }

  @Override public String getLocation() {
    return null;
  }

  @Override public void onError() {
  }

  @Override public void addCountry(String countryCode) {
    this.countryCode = countryCode;
  }

  @Override public void onDelete(String message) {
    Utils.showMessage(getActivity(), getString(R.string.delete_job_success));
    ((HomeActivity) getActivity()).setLastPosition();
    getFragmentManager().popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
  }

  @Override public void onDestroyView() {
    showRightImage(false);
    setRightImage(R.drawable.edit_gray);
    unbinder.unbind();
    super.onDestroyView();
  }

  private void focusHandling() {
    edtReferance.clearFocus();
    edtDesc.clearFocus();
    edtSalary.clearFocus();
    Utils.hideKeyboard(getActivity());
    relRoot.requestFocus();
  }

  @Override public void navigateToBack() {
    ((HomeActivity) getActivity()).setLastPosition();
    if (isEditMode) {
      showRightImage = false;
      visibleRightImage();
      disableEnableControls(false, nestedScrollView);
      setHasOptionsMenu(true);
      getFragmentManager().popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
    } else {
      getFragmentManager().popBackStack();
    }
  }

  @Override public void openCamera() {
    OfferFragmentPermissionsDispatcher.showCameraWithCheck(this, true, false);
  }

  @Override public void openGallery() {
    OfferFragmentPermissionsDispatcher.showCameraWithCheck(this, false, false);
  }

  @Override public void opeVideoCamera() {
    OfferFragmentPermissionsDispatcher.showCameraWithCheck(this, true, true);
  }

  @Override public void openVideoGallery() {
    OfferFragmentPermissionsDispatcher.showCameraWithCheck(this, false, true);
  }

  @Override public void setDefault() {
  }

  @Override public boolean isImageSet() {
    return false;
  }

  @Override public void addImage(ImageModel imageModel, int posSel) {
    if (imageEdiPos > -1) {
      int prevId = mPhotoList.get(imageEdiPos).getImageId();
      if (prevId > -1) {
        imageModel.setImageId(prevId);
      } else {
        imageModel.setImageId(imageEdiPos);
      }
      mPhotoList.set(imageEdiPos, imageModel);
      imageEdiPos = -1;
    } else {
      mPhotoList.add(imageModel);
      imageModel.setImageId(mPhotoList.size());
    }
    if (isEditMode) {
      EditImageModel editImageModel = new EditImageModel();
      editImageModel.setDeleted(false);
      if (editImageIds.get(imageModel.getImageId()) != null) {
        if (!serverPhotoIds.contains(imageModel.getImageId())) {
          editImageModel.setAdded(true);
          editImageModel.setEdited(false);
        } else {
          editImageModel.setAdded(false);
          editImageModel.setEdited(true);
        }
      } else {
        editImageModel.setAdded(true);
        editImageModel.setEdited(false);
      }
      editImageModel.setUpdatedImageModel(imageModel);
      editImageIds.put(imageModel.getImageId(), editImageModel);
    }
    offerImagesAdapter.notifyDataSetChanged();
  }

  @Override public void addVideo(ImageModel imgModelVideo) {
    addVideoOperation(imgModelVideo);
    if (editJobData != null) {
      isVideoEdited = true;
      isVideoDeleted = false;
    }
  }

  private void addVideoOperation(ImageModel imgModelVideo) {
    mVideoModel = imgModelVideo;
    File file = new File(mVideoModel.getImage());
    rlDelete.setVisibility(View.VISIBLE);
    Uri imageUri = Uri.fromFile(file);
    Glide.with(getActivity())
        .load(imageUri)
        .error(R.drawable.add_video)
        .placeholder(R.drawable.add_video)
        .dontAnimate()
        .fitCenter()
        .into(ivPhoto4);
  }

  @Override public void onClick(View view, Object object, int position) {
    if (view.getId() == R.id.imageRemove) {
      showDeleteAlertPhoto(position);
    } else {
      offerPresenter.showChangePhotoDialog(position);
      try {
        if (!isEmpty(mPhotoList.get(position).getImageUrl())) {
          imageEdiPos = position;
        }
      } catch (IndexOutOfBoundsException e) {
        e.printStackTrace();
        //here image is place holder so new image is being added so no need to set flag
        imageEdiPos = -1;
      }
    }
  }

  private void setExpLvl(int experience) {
    switch (experience) {
      case 1:
        setExperience(R.id.rbOne);
        break;
      case 2:
        setExperience(R.id.rbTwo);
        break;
      case 3:
        setExperience(R.id.rbThree);
        break;
      case 4:
        setExperience(R.id.rbFive);
        break;
    }
  }

  private void setProfile(int profile) {
    switch (profile) {
      case 50:
        setProfilePercentage(R.id.rbFifty);
        break;
      case 65:
        setProfilePercentage(R.id.rbSixty);
        break;
      case 80:
        setProfilePercentage(R.id.rbEighty);
        break;
    }
  }

  private void showDeleteAlertPhoto(final int position) {
    Utils.showDialog(getActivity(), getString(R.string.delete), getString(R.string.delete_message),
        getString(R.string.yes), getString(R.string.no), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            int deleteImageId = mPhotoList.get(position).getImageId();
            if (serverPhotoIds.contains(deleteImageId)) {
              ImageModel updatedModel = new ImageModel();
              updatedModel.setImageId(deleteImageId);
              EditImageModel updatedImageModel = new EditImageModel();
              updatedImageModel.setAdded(false);
              updatedImageModel.setEdited(false);
              updatedImageModel.setDeleted(true);
              updatedImageModel.setUpdatedImageModel(updatedModel);
              editImageIds.put(deleteImageId, updatedImageModel);
            } else {
              editImageIds.remove(deleteImageId);
            }
            mPhotoList.remove(position);
            imageEdiPos = -1;
            offerImagesAdapter.notifyDataSetChanged();
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }

  private void showDeleteAlertVideo() {
    Utils.showDialog(getActivity(), getString(R.string.delete), getString(R.string.delete_message),
        getString(R.string.yes), getString(R.string.no), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            resetVideoView();
            if (editJobData != null) {
              isVideoEdited = true;
              isVideoDeleted = true;
            }
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }

  private void resetVideoView() {
    mVideoModel = null;
    rlDelete.setVisibility(View.GONE);
    ivPhoto4.setImageResource(R.drawable.add_video);
  }

  //CDI==1
  //CDD=2
  //INTERIM=3
  //Stage=4
  @OnClick({
      R.id.rbCDI, R.id.rbCDD, R.id.rbINDTERIN, R.id.rbStage, R.id.tvStartMonth, R.id.tvEndMonth, R.id.rlLocation,
      R.id.rlNearStop, R.id.ivPhoto4, R.id.ivDelete, R.id.btnDone, R.id.tvDesignationSelect
  }) void onClick(View view) {
    setImageDrawable(view);
  }

  public void setImageDrawable(View view) {
    switch (view.getId()) {
      case R.id.rbCDI:
        setRbCDISelected();
        break;
      case R.id.rbCDD:
        setRbCDDSelected();
        break;
      case R.id.rbINDTERIN:
        setRbINDTERINSelected();
        break;
      case R.id.rbStage:
        setRbStageSelected();
        break;
      case R.id.tvStartMonth:
        showDatePicker(true);
        break;
      case R.id.tvEndMonth:
        showDatePicker(false);
        break;
      case R.id.rlLocation:
        rlLocation.setClickable(false);
        offerPresenter.setStarAndEndAddressClick(1);
        offerPresenter.openPlaceApiIntent();
        break;
      case R.id.ivPhoto4:
        offerPresenter.ShowVideoCaptureDialog();
        break;
      case R.id.ivDelete:
        showDeleteAlertVideo();
        break;
      case R.id.btnDone:
        callOfferPresenterApiCall();
        break;
      case R.id.tvDesignationSelect:
        Intent intent = new Intent(getActivity(), DesignationSelectActivity.class);
        intent.putExtra(Constants.KEY_TYPE, 1); // 1 for single select
        startActivityForResult(intent, FILTER_CODE);
        break;
      default:
        break;
    }
  }

  private void setRbCDISelected() {
    radioStatus = 1;
    rbCDI.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_select, 0);
    rbCDD.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
    rbINDTERIN.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
    rbStage.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
    tvStartMonth.setVisibility(View.VISIBLE);
    tvEndMonth.setVisibility(View.INVISIBLE);
  }

  private void setRbCDDSelected() {
    radioStatus = 2;
    rbCDI.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
    rbCDD.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_select, 0);
    rbINDTERIN.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
    rbStage.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
    tvStartMonth.setVisibility(View.VISIBLE);
    tvEndMonth.setVisibility(View.VISIBLE);
    lineend.setVisibility(View.VISIBLE);
  }

  private void setRbINDTERINSelected() {
    radioStatus = 3;
    rbCDI.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
    rbCDD.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
    rbStage.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
    rbINDTERIN.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_select, 0);
    tvStartMonth.setVisibility(View.VISIBLE);
    tvEndMonth.setVisibility(View.VISIBLE);
    lineend.setVisibility(View.VISIBLE);
  }

  private void setRbStageSelected() {
    radioStatus = 4;
    rbCDI.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
    rbCDD.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
    rbINDTERIN.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
    rbStage.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_select, 0);
    tvStartMonth.setVisibility(View.VISIBLE);
    tvEndMonth.setVisibility(View.VISIBLE);
    lineend.setVisibility(View.VISIBLE);
  }

  private void setExperience(int selectExp) {

    switch (selectExp) {
      case R.id.rbOne:
        expId = 1;
        rbOne.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_select, 0);
        rbTwo.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbThree.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbFive.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        break;
      case R.id.rbTwo:
        expId = 2;
        rbOne.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbTwo.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_select, 0);
        rbThree.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbFive.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        break;
      case R.id.rbThree:
        expId = 3;
        rbOne.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbTwo.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbThree.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_select, 0);
        rbFive.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        break;
      case R.id.rbFive:
        expId = 4;
        rbOne.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbTwo.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbThree.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbFive.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_select, 0);
        break;
    }
  }

  private void setProfilePercentage(int profile) {
    switch (profile) {
      case R.id.rbFifty:
        profilePercentage = 50;
        rbProfileFifty.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_select, 0);
        rbProfileSixty.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbProfileEighty.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        break;
      case R.id.rbSixty:
        profilePercentage = 65;
        rbProfileFifty.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbProfileSixty.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_select, 0);
        rbProfileEighty.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        break;
      case R.id.rbEighty:
        profilePercentage = 80;
        rbProfileFifty.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbProfileSixty.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_unselect, 0);
        rbProfileEighty.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.radio_select, 0);
        break;
    }
  }

  public void callOfferPresenterApiCall() {
    focusHandling();
    //jobPos = String.valueOf(listJobPos.get(spJobPos.getSelectedItemPosition()).getD_id());
    contentType = radioStatus;
    if (locPlace != null) {
      location = locPlace.getAddress().toString();
      latitude = String.valueOf(locPlace.getLatLng().latitude);
      longitude = String.valueOf(locPlace.getLatLng().longitude);
    }
    reference = Utils.getText(edtReferance);
    desc = Utils.getText(edtDesc);
    salary = Utils.getText(edtSalary);
    //experience = Utils.getText(etExperience);
    requiredQuality = Utils.getText(etRequiredQuality);
    otherBenefits = Utils.getText(etOtherBenefits);
    if (checkValidation()) {
      offerPresenter.callAddOff(_requestHashMap());
    }
  }
  //CDI==1
  //CDD=2
  //INTERIM=3
  //Stage=4

  private HashMap<String, RequestBody> _requestHashMap() {
    HashMap<String, RequestBody> addOfferMap = new HashMap<>();
    if (!isEditMode) {
      addOfferMap.put("apiName", toRequestBody("addJobOffer"));
    } else {
      addOfferMap.put("apiName", toRequestBody("editJobOffer"));
    }
    addOfferMap.put("userId",
        toRequestBody(getPrefs(getContext()).getString(QuickstartPreferences.USER_ID, "")));
    addOfferMap.put("accessToken",
        toRequestBody(getPrefs(getContext()).getString(QuickstartPreferences.ACCESS_TOKEN, "")));
    addOfferMap.put("designationId", toRequestBody(dId));
    addOfferMap.put("country", toRequestBody(countryCode));
    addOfferMap.put("experience_required", toRequestBody(Integer.toString(expId)));
    addOfferMap.put("profile_per_required", toRequestBody(Integer.toString(profilePercentage)));
    int cnt = 0;
    if (mPhotoList != null && !isEditMode) {
      for (ImageModel imageModel : mPhotoList) {
        cnt++;
        if (!imageModel.getImage().isEmpty()) {
          addOfferMap.put("image" + cnt + "\"; filename=\"pp.png\"",
              RequestBody.create(MediaType.parse("image/*"), new File(imageModel.getImage())));
        }
      }
    }
    if (isEditMode) {
      if (editImageIds.size() > 0) {
        HashMap<String, Object> editFlagData = new HashMap<>();
        for (Map.Entry<Integer, EditImageModel> entry : editImageIds.entrySet()) {
          cnt++;
          EditImageModel editModel = entry.getValue();
          JSONObject editedObject = new JSONObject();
          try {
            if (!editModel.isAdded()) {
              editedObject.put("id", editModel.getUpdatedImageModel().getImageId());
            }
            editedObject.put("add", editModel.isAdded());
            editedObject.put("edit", editModel.isEdited());
            editedObject.put("delete", editModel.isDeleted());
          } catch (JSONException jsonException) {
            jsonException.printStackTrace();
          }
          if (editModel.isEdited() || editModel.isAdded()) {
            addOfferMap.put("image" + cnt + "\"; filename=\"pp.png\"",
                RequestBody.create(MediaType.parse("image/*"),
                    new File(editModel.getUpdatedImageModel().getImage())));
          }
          if (editModel.isEdited() || editModel.isAdded() || editModel.isDeleted()) {
            editFlagData.put(String.valueOf(cnt), editedObject);
          }
        }
        JSONObject imageEditFlag = new JSONObject(editFlagData);
        addOfferMap.put("imageEditDeleteFlg", toRequestBody(imageEditFlag.toString()));
      }
      if (isVideoEdited && isVideoDeleted) {
        try {
          JSONObject videoEditFlag = new JSONObject();
          videoEditFlag.put("add", false);
          videoEditFlag.put("edit", false);
          videoEditFlag.put("delete", true);
          addOfferMap.put("videoEditDeleteFlg", toRequestBody(videoEditFlag.toString()));
        } catch (JSONException e) {
          LOGE(TAG, e.getMessage(), e);
        }
      } else if (isVideoEdited) {
        try {
          JSONObject videoEditFlag = new JSONObject();
          videoEditFlag.put("add", false);
          videoEditFlag.put("edit", true);
          videoEditFlag.put("delete", false);
          addOfferMap.put("videoEditDeleteFlg", toRequestBody(videoEditFlag.toString()));
          if (mVideoModel != null) {
            addOfferMap.put("video\"; filename=\"pp.mp4\"",
                RequestBody.create(MediaType.parse("video/*"), new File(mVideoModel.getImage())));
          }
        } catch (JSONException e) {
          LOGE(TAG, e.getMessage(), e);
        }
      }
      addOfferMap.put("jobOfferId", toRequestBody(String.valueOf(editJobData.getOfferId())));
    }
    if (mVideoModel != null && !isEditMode) {
      addOfferMap.put("video\"; filename=\"pp.mp4\"",
          RequestBody.create(MediaType.parse("video/*"), new File(mVideoModel.getImage())));
    }
    addOfferMap.put("contractType", toRequestBody(String.valueOf(contentType)));
    addOfferMap.put("location", toRequestBody(location));
    addOfferMap.put("latitude", toRequestBody(latitude));
    addOfferMap.put("longitude", toRequestBody(longitude));
    addOfferMap.put("reference", toRequestBody(reference));
    addOfferMap.put("startDate", toRequestBody(String.valueOf(Long.parseLong(startDate) / 1000)));
    if (contentType > 1) {
      addOfferMap.put("endDate", toRequestBody(String.valueOf(Long.parseLong(endDate) / 1000)));
    }
    addOfferMap.put("description", toRequestBody(desc));
    addOfferMap.put("salary", toRequestBody(salary));
    addOfferMap.put("quality", toRequestBody(requiredQuality));
    addOfferMap.put("otherBenefits", toRequestBody(otherBenefits));
    addOfferMap.put("language", toRequestBody("en"));
    return addOfferMap;
  }

  private boolean checkValidation() {

    if (isEmpty(dId)) {
      showMessage(getContext(), getString(R.string.enter_designation));
      return false;
    }

    if (isEmpty(location)) {
      showMessage(getContext(), getString(R.string.sel_location));
      return false;
    }
    if (isEmpty(startDate)) {
      showMessage(getContext(), getString(R.string.select_start_date));
      return false;
    }
    if ((contentType > 1) && isEmpty(endDate)) {
      showMessage(getContext(), getString(R.string.select_end_date));
      return false;
    }

    if (isEditMode && !isEmpty(startDate)) {
      if (!Utils.getValidityOfDate(startDate, 1, getContext())) {
        return false;
      }
    }
    if (isEditMode && !isEmpty(endDate)) {
      if (!Utils.getValidityOfDate(endDate, 2, getContext())) {
        return false;
      }
    }
    if (!isEmpty(startDate) && !isEmpty(endDate)) {
      if (Utils.isStartGreaterEnd(startDate, endDate, getContext())) {
        return false;
      }
    }
    return true;
  }

  private void showDatePicker(final boolean start) {
    Utils.hideKeyboard(getActivity());
    CustomDatePickerFragment datePickerFragment = new CustomDatePickerFragment();
    String currentText;
    if (start) {
      currentText = Utils.getText(tvStartMonth);
    } else {
      currentText = Utils.getText(tvEndMonth);
    }
    Calendar calender = Calendar.getInstance();
    Bundle args = new Bundle();
    final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH);
    Date showDate = null;
    try {
      showDate = simpleDateFormat.parse(currentText);
    } catch (ParseException e) {
      e.printStackTrace();
      showDate = new Date();
    }
    calender.setTime(showDate);
    args.putInt("year", calender.get(Calendar.YEAR));
    args.putInt("month", calender.get(Calendar.MONTH));
    args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
    datePickerFragment.setListener(new DatePickerDialog.OnDateSetListener() {
      @Override public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
        if (offerPresenter._isValidDate(year, monthOfYear, dayOfMonth)) {
          Calendar displayCal = Calendar.getInstance();
          displayCal.set(Calendar.DAY_OF_MONTH, dayOfMonth);
          displayCal.set(Calendar.MONTH, monthOfYear);
          displayCal.set(Calendar.YEAR, year);
          displayCal.set(Calendar.HOUR_OF_DAY, 0);
          displayCal.set(Calendar.MINUTE, 0);
          displayCal.set(Calendar.SECOND, 0);
          displayCal.set(Calendar.MILLISECOND, 0);
          displayDate = simpleDateFormat.format(displayCal.getTime());
          if (start) {
            tvStartMonth.setText(displayDate);
            startDate = String.valueOf(displayCal.getTimeInMillis());
          } else {
            tvEndMonth.setText(displayDate);
            endDate = String.valueOf(displayCal.getTimeInMillis());
          }
        } else {
          if (start) {
            Utils.showMessage(getContext(), getString(R.string.startdate_val));
          } else {
            Utils.showMessage(getContext(), getString(R.string.enddate_val));
          }
        }
      }
    });
    datePickerFragment.setArguments(args);
    datePickerFragment.show(getFragmentManager(), datePickerFragment.getClass().getSimpleName());
  }

  @Override public void onStart() {
    super.onStart();
    isStopCalled = false;
  }

  @Override public void onStop() {
    super.onStop();
    isStopCalled = true;
  }

  @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == Activity.RESULT_OK && requestCode == FILTER_CODE) {
      dId = data.getStringExtra(Constants.KEY_TEXT);
      DesignationDbModel model = DesignationDbModel.getDesignation(dId);
      tvDesignationSelect.setText(model.getTitle());
    }
    if (resultCode == Activity.RESULT_OK) {
      offerPresenter.onActivityResult(requestCode, resultCode, data);
    } else {
      rlLocation.setClickable(true);
    }
  }

  @NeedsPermission({ Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE })
  void showCamera(boolean isCamera, boolean isVideo) {
    if (isVideo) {
      if (isCamera) {
        offerPresenter.openVideoCamera();
      } else {
        offerPresenter.openVideoGallery();
      }
    } else {
      if (isCamera) {
        offerPresenter.openCamera();
      } else {
        offerPresenter.openGallery();
      }
    }
  }

  @Override public void onBack(View view) {
    if (isEditMode) {
      getFragmentManager().popBackStack();
    } else {
      getActivity().onBackPressed();
    }
  }

  @Override public void onRight(View view) {
    callOfferPresenterApiCall();
  }

  @OnShowRationale({ Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE })
  void showRationaleForCamera(final PermissionRequest request) {
    LOGI(OfferFragment.class.getName(), "OnShowRationale");
    Utils.showDialog(getActivity(), getString(R.string.alert),
        getString(R.string.permission_camera_rationale), getString(R.string.button_allow),
        getString(R.string.button_deny), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.proceed();
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.cancel();
          }
        }).show();
  }

  @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
      @NonNull int[] grantResults) {
    OfferFragmentPermissionsDispatcher.onRequestPermissionsResult(this, requestCode, grantResults);
  }

  @OnPermissionDenied({ Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE })
  void showDeniedForCamera() {
    LOGI(OfferFragment.class.getName(), "OnPermissionDenied");
    showPermissionDialog();
  }

  @OnNeverAskAgain({ Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE })
  void showNeverAskForCamera() {
    LOGI(OfferFragment.class.getName(), "OnNeverAskAgain");
    showPermissionDialog();
  }

  private void showPermissionDialog() {
    Utils.showDialog(getActivity(), getString(R.string.alert),
        getString(R.string.permission_camera_never_askagain), getString(android.R.string.ok),
        new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }

  private void changeSoftInputMode(boolean toggle) {
    if (toggle) {
      getActivity().getWindow()
          .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
              | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    } else {
      getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
    }
  }

  private void registerKeyboardListener(boolean register) {
    if (register) {
      KeyboardVisibilityEvent.setEventListener(getActivity(),
          new KeyboardVisibilityEventListener() {
            @Override public void onVisibilityChanged(boolean isOpen, int height) {
              try {
                if (isOpen && getActivity() != null) {
                  ((HomeActivity) getActivity()).changeTabVisibility(false);
                } else {
                  if (!isStopCalled) {
                    ((HomeActivity) getActivity()).changeTabVisibility(true);
                  }
                }
              } catch (Exception e) {
                e.printStackTrace();
              }
            }
          });
    } else {
      KeyboardVisibilityEvent.setEventListener(getActivity(), null);
    }
  }

  @Override public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
    inflater.inflate(R.menu.offer_fragment, menu);
    super.onCreateOptionsMenu(menu, inflater);
  }

  @Override public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.edit:
        showRightImage = true;
        visibleRightImage();
        if (isEditMode) {
          disableEnableControls(true, nestedScrollView);
          offerImagesAdapter.setEdit(true);
        }
        setHasOptionsMenu(false);
        break;

      case R.id.delete:
        showDelete(getActivity(), editJobData.getOfferId());
        break;
    }
    return true;
  }

  private void showDelete(Context context, final int getOfferId) {
    Utils.showDialog(context, context.getString(R.string.delete),
        context.getString(R.string.delete_job), context.getString(R.string.yes),
        context.getString(R.string.no), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            offerPresenter.onDeleteOffer(Integer.toString(getOfferId));
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }
}
