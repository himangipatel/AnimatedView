/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.GradientView;
import com.bnbjobs.customui.views.OtpView;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.fragments.InviteFragment;
import com.bnbjobs.presenter.PhoneNumberPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.PhoneNumberView;

import static android.text.TextUtils.isEmpty;

/**
 * @author Harsh
 * @version 1.0
 */
public class PhoneVerifyActivity extends BaseActivity implements PhoneNumberView {

  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.tvDetailText) TextView tvDetailText;
  @BindView(R.id.otpView) OtpView otpView;
  @BindView(R.id.tvSendCode) GradientView tvSendCode;
  @BindView(R.id.relativeProgress) RelativeLayout relativeProgress;
  private PhoneNumberPresenter presenter;
  private String phoneNumber;
  private String currentOtp;

  @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_phone_verification);
    ButterKnife.bind(this);
    currentOtp = getIntent().getStringExtra(Constants.KEY_TEXT);
    phoneNumber = getIntent().getStringExtra(Constants.KEY_NUMBER);
    presenter = new PhoneNumberPresenter();
    presenter.attachView(this);
    tvTitle.setVisibility(View.VISIBLE);
    tvTitle.setText("Verify phone number");
  }

  @OnClick({ R.id.tvResendOtp, R.id.tvNewOtp }) void onResendOTP() {
    presenter.getOtp(phoneNumber);
  }

  @OnClick(R.id.tvSendCode) void onVerify() {

    if (isEmpty(otpView.getText())) {
      Utils.showMessage(this, "Please enter proper otp");
    } else {
      if (otpView.getText().equalsIgnoreCase(currentOtp)) {
        Utils.hideKeyboard(this);
        presenter.verifyPhoneNumber(currentOtp);
      } else {
        Utils.showMessage(this, "Otp is not valid. please try again!");
      }
    }
  }

  @Override public void showMessage(String msg) {
    currentOtp = msg;
  }

  @Override public void showVerified() {
    InviteFragment fragment = new InviteFragment();
    Bundle bundle = new Bundle();
    bundle.putInt(Constants.KEY_DIALOG_TYPE, Constants.PHONE_VERIFIED);
    fragment.setArguments(bundle);
    fragment.show(getSupportFragmentManager(), fragment.getClass().getSimpleName());
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    relativeProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    relativeProgress.setVisibility(View.GONE);
  }

  @Override protected void onDestroy() {
    super.onDestroy();
    presenter.detachView();
  }
}
