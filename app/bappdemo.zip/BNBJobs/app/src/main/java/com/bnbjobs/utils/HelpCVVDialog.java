/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.bnbjobs.R;

public class HelpCVVDialog extends Dialog {

  public Activity activity;
  public TextView tv_ok, tv_title;
  private ImageView iv_image, ivCVV;
  private int height;
  private int width;
  private String msg;
  private Context context;

  public HelpCVVDialog(Activity a) {
    super(a);
    this.activity = a;
  }

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    requestWindowFeature(Window.FEATURE_NO_TITLE);
    Window window = getWindow();
    window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

    setContentView(R.layout.help_dialog);

    RelativeLayout layout = (RelativeLayout) findViewById(R.id.rl_dialog);

    iv_image = (ImageView) findViewById(R.id.iv_image);
    ivCVV = (ImageView) findViewById(R.id.ivCVV);

    iv_image.measure(RelativeLayout.LayoutParams.WRAP_CONTENT,
        RelativeLayout.LayoutParams.WRAP_CONTENT);
    int width = iv_image.getMeasuredWidth();
    int height = iv_image.getMeasuredHeight();

    RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) layout.getLayoutParams();
    params.setMargins(0, height / 2, 0, 0);
    layout.setLayoutParams(params);

    tv_ok = (TextView) findViewById(R.id.tv_ok);
    tv_ok.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View view) {
        dismiss();
      }
    });
    tv_title = (TextView) findViewById(R.id.tv_title);
  }

  public void setTitle(String title) {
    tv_title.setText(title);
  }
}
