/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;

import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.model.ProfileContainer;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.EditProfileView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.ActivityEvent;
import com.trello.rxlifecycle.LifecycleTransformer;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */
public class EditProfilePresenter extends BasePresenter implements Presenter<EditProfileView> {

    private final static String TAG = makeLogTag(EditProfilePresenter.class);
    private EditProfileView mEditProfileView;

    @Override
    public void attachView(EditProfileView view) {
        mEditProfileView = view;
    }

    @Override
    public void detachView() {
        mEditProfileView = null;
    }

    @Override
    protected Context getBaseContext() {
        return mEditProfileView.getContext();
    }

    public void getCandidateProfile() {
        mEditProfileView.showProgress();
        HashMap<String, String> params = new HashMap<>(4);
        params.put("apiName", "getPersonalProfile");
        addParams(params);
        RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
                mEditProfileView.hideProgress();
                LOGE(TAG, e.getMessage(), e);
            }

            @Override
            public void onNext(String s) {
                mEditProfileView.hideProgress();
                ProfileContainer container = new Gson().fromJson(s, ProfileContainer.class);
                if (container.isSuccess()) {
                    mEditProfileView.setPersonalData(container.getData());
                }
            }
        });
    }

    private LifecycleTransformer<String> getBindEvent() {
        return ((BaseActivity) getBaseContext()).bindUntilEvent(ActivityEvent.DESTROY);
    }

    /**
     * showChangePhotoDialog
     * Show the dialog for photo selection options
     */
    public void showChangePhotoDialog() {
        imagePicker(new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    mEditProfileView.openCamera();
                } else if (which == 1) {
                    mEditProfileView.openGallery();
                } else {
                    mEditProfileView.setDefault();
                }
            }
        }, mEditProfileView.isImageSet()).show();
    }

    public void openCamera() {
        requestImageFromCamera();
    }

    public void openGallery() {
        requestImageFromGallery();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            Uri uri = null;
            String path = "";
            if (requestCode == REQUEST_CODE_CAMERA) {
                path = mCameraOutputPath;
            } else if (requestCode == REQUEST_CODE_GALLERY) {
                uri = data.getData();
                path = getRealPathFromURI(uri);
            }
            if (!isEmpty(path)) {
                mEditProfileView.showPhoto(path);
            }
        }
    }

    public void updatePersonalProfile() {
        if (!isValid()) {
            return;
        }
        mEditProfileView.showProgress();
        HashMap<String, RequestBody> params = new HashMap<>(15);
        params.put("apiName", toRequestBody("updatePersonalProfile"));
        params.put("firstname", toRequestBody(mEditProfileView.getFirstName()));
        params.put("lastname", toRequestBody(mEditProfileView.getLastName()));
        params.put("email", toRequestBody(mEditProfileView.getEmail()));
        params.put("phone", toRequestBody(mEditProfileView.getPhoneNumber()));
        if (!isEmpty(mEditProfileView.getPassword())) {
            params.put("password", toRequestBody(mEditProfileView.getPassword()));
        }
        params.put("designationId", toRequestBody("1"));
        if (mEditProfileView.isFbLinkShow()) {
            params.put("fbLink", toRequestBody(mEditProfileView.getFirstName()));
        }
        if (mEditProfileView.isTwLinkShow()) {
            params.put("twitterLink", toRequestBody(mEditProfileView.getTwLink()));
        }
        if (mEditProfileView.getProfile() != null) {
            params.put("image\"; filename=\"pp.png\"",
                    RequestBody.create(MediaType.parse("image/*"), mEditProfileView.getProfile()));
        }
        params.putAll(addParamsBody(params));
        RestClient.getInstance()
                .apiCallImage(params)
                .compose(getBindEvent())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<String>() {
                    @Override
                    public void onCompleted() {
                    }

                    @Override
                    public void onError(Throwable e) {
                        LOGE(TAG, e.getMessage(), e);
                        mEditProfileView.hideProgress();
                    }

                    @Override
                    public void onNext(String s) {
                        mEditProfileView.hideProgress();
                        try {
                            JSONObject object = new JSONObject(s);
                            ProfileContainer container = new Gson().fromJson(s, ProfileContainer.class);
                            if (container.isSuccess()) {
                                JSONObject dataObject = object.getJSONObject("data");
                                JSONObject userObject = dataObject.getJSONObject("userData");
                                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_PHONENUMBER,
                                        userObject.optString("u_phone", ""));
                                mEditProfileView.onUpdated(container.getData());
                            }
                        } catch (JSONException e) {
                            LOGE(TAG, e.getMessage(), e);
                        }
                    }
                });
    }

    public void callVerificationCodeApi(String newPhoneNumber) {
        mEditProfileView.showProgress();
        HashMap<String, String> params = new HashMap<>(3);
        params.put("apiName", "resendOTP");
        params.put("number", newPhoneNumber);
        params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
        RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
                LOGE(TAG, e.getMessage(), e);
                mEditProfileView.hideProgress();
            }

            @Override
            public void onNext(String s) {
                mEditProfileView.hideProgress();
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    boolean success = jsonObject.optBoolean("success");
                    String message = jsonObject.optString("message", "");
                    mEditProfileView.onCodeResend(success, message);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private boolean isValid() {
        if (!Utils.isValidEmail(mEditProfileView.getEmail())) {
            showMessage(getBaseContext(), getString(R.string.enter_valid_email_address));
            return false;
        } else if (isEmpty(mEditProfileView.getFirstName())) {
            showMessage(getBaseContext(), getString(R.string.enter_valid_first_name));
            return false;
        } else if (isEmpty(mEditProfileView.getLastName())) {
            showMessage(getBaseContext(), getString(R.string.enter_valid_last_name));
            return false;
        } else if (!isEmpty(mEditProfileView.getPassword())
                && mEditProfileView.getPassword().length() < 8) {
            showMessage(getBaseContext(),
                    getBaseContext().getString(R.string.enter_valid_password_length));
            return false;
        } else if (isEmpty(mEditProfileView.getPhoneNumber())) {
            showMessage(getBaseContext(), getString(R.string.enter_your_phone_number));
            return false;
        } else if (mEditProfileView.isFbLinkShow() && isEmpty(mEditProfileView.getFbLink())) {
            showMessage(getBaseContext(), getString(R.string.enter_valid_fb_link));
            return false;
        } else if (mEditProfileView.isTwLinkShow() && isEmpty(mEditProfileView.getTwLink())) {
            showMessage(getBaseContext(), getString(R.string.enter_valid_tw_link));
            return false;
        }
        return true;
    }

    public void updateDesignation(String designationId) {
        mEditProfileView.showProgress();
        HashMap<String, String> params = new HashMap<>(5);
        params.put("apiName", "updateCandidateDesignation");
        params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
        params.put("accessToken",
                getPrefs(getBaseContext()).getString(QuickstartPreferences.ACCESS_TOKEN, ""));
        params.put("language", getLanguage());
        params.put("designationId", designationId);

        RestClient.getInstance(params)
                .compose(((BaseActivity) getBaseContext()).<String>bindUntilEvent(ActivityEvent.DESTROY))
                .subscribe(new Subscriber<String>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        LOGE(TAG, e.getMessage(), e);
                        mEditProfileView.hideProgress();
                        if (e.getMessage() != null) {
                            Utils.showMessage(getBaseContext(), e.getMessage());
                        }
                    }

                    @Override
                    public void onNext(String s) {
                        mEditProfileView.hideProgress();
                        JSONObject object;
                        try {
                            object = new JSONObject(s);
                            if (isResponseSuccess(s)) {
                                getPrefs(getBaseContext()).save(QuickstartPreferences.SHOW_DESIGNATION, false);
                                Utils.showMessage(getBaseContext(), getBaseContext().getString(R.string.designation_update));
                            } else {
                                showDialog(getBaseContext(), getBaseContext().getString(R.string.alert),
                                        object.getString("message"), getBaseContext().getString(android.R.string.ok),
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                dialog.dismiss();
                                            }
                                        }).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
    }
}
