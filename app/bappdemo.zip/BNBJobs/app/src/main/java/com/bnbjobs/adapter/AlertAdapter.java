/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.CircleImageView;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.CandidateModel;
import com.bumptech.glide.Glide;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class AlertAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

  private final int VIEW_TYPE_ITEM = 0;
  private final int VIEW_TYPE_LOADING = 1;
  private Context mContext;
  private List<CandidateModel> mUserModelList;
  private ClickImpl listnere;

  public AlertAdapter(Context context, List<CandidateModel> userModelList, Fragment fragment) {
    mContext = context;
    mUserModelList = userModelList;
    listnere = (ClickImpl) fragment;
  }

  @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    if (viewType == VIEW_TYPE_ITEM) {
      return new MyViewHolder(LayoutInflater.from(parent.getContext())
          .inflate(R.layout.adapter_recruiter_home, parent, false));
    } else if (viewType == VIEW_TYPE_LOADING) {
      View view =
          LayoutInflater.from(parent.getContext()).inflate(R.layout.progress, parent, false);
      return new LoadingViewHolder(view);
    }
    return null;
  }

  @Override public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
    if (holder instanceof MyViewHolder) {
      MyViewHolder mHolder = (MyViewHolder) holder;
      Glide.with(mContext)
          .load(mUserModelList.get(position).getuThumbImage())
          .placeholder(R.drawable.user_placeholder)
          .dontAnimate()
          .into(mHolder.mImgAvatar);
      mHolder.mTvUserName.setText(
          mUserModelList.get(position).getfName() + " " + mUserModelList.get(position).getlName());
      mHolder.mTvUserAddress.setText(mUserModelList.get(position).getTitle());
      mHolder.mTvDistance.setText(mUserModelList.get(position).getDistance());
    } else {
      LoadingViewHolder loadingViewHolder = (LoadingViewHolder) holder;
      loadingViewHolder.progressBar.setIndeterminate(true);
    }
  }

  @Override public int getItemViewType(int position) {
    return mUserModelList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
  }

  @Override public int getItemCount() {
    return mUserModelList == null ? 0 : mUserModelList.size();
  }

  private static class LoadingViewHolder extends RecyclerView.ViewHolder {

    public ProgressBar progressBar;

    LoadingViewHolder(View itemView) {
      super(itemView);
      progressBar = (ProgressBar) itemView.findViewById(R.id.progressBar);
    }
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.imgAvatar) CircleImageView mImgAvatar;
    @BindView(R.id.tvUserName) TextView mTvUserName;
    @BindView(R.id.tvUserAddress) TextView mTvUserAddress;
    @BindView(R.id.tvDistance) TextView mTvDistance;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
      itemView.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          listnere.onClick(v, mUserModelList.get(getLayoutPosition()), getLayoutPosition());
        }
      });
    }
  }
}
