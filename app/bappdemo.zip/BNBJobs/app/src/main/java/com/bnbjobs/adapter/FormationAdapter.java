/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.FormationModel;
import com.bnbjobs.utils.Utils;
import java.util.List;

import static com.bnbjobs.R.id.ratingbar;

/**
 * @author Harsh
 * @version 1.0
 */
public class FormationAdapter extends RecyclerView.Adapter<FormationAdapter.MyViewHolder> {

  private int ratingBarHeight;
  private Context mContext;
  private List<FormationModel> formationModelList;
  private boolean isEdit;
  private ClickImpl mClick;

  public FormationAdapter(Context mContext, List<FormationModel> formationModelList,
      Fragment fragment) {
    this.mContext = mContext;
    this.formationModelList = formationModelList;
    Drawable ratingBar = ContextCompat.getDrawable(this.mContext, R.drawable.select_star);
    ratingBarHeight = ratingBar.getIntrinsicHeight();
    mClick = (ClickImpl) fragment;
  }

  public void setEdit(boolean isEdit) {
    this.isEdit = isEdit;
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view =
        LayoutInflater.from(parent.getContext()).inflate(R.layout.rating_inflater, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {
    holder.tvCategoryName.setText(Utils.capitalize(formationModelList.get(position).getTitle()));
    if (formationModelList.get(position).getRate() == 5) {
      holder.ratingBarGreen.setRating(formationModelList.get(position).getRate());
      holder.ratingBarGreen.setVisibility(View.VISIBLE);
      holder.ratingBar.setVisibility(View.GONE);
    } else {
      holder.ratingBar.setRating(formationModelList.get(position).getRate());
      holder.ratingBarGreen.setVisibility(View.GONE);
      holder.ratingBar.setVisibility(View.VISIBLE);
    }
  }

  @Override public int getItemCount() {
    return formationModelList.size();
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.tv_category_name) TextView tvCategoryName;
    @BindView(R.id.ratingBarGreen) RatingBar ratingBarGreen;
    @BindView(ratingbar) RatingBar ratingBar;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
      ratingBarGreen.setVisibility(View.VISIBLE);
      ratingBarGreen.getLayoutParams().height = ratingBarHeight;
      ratingBar.getLayoutParams().height = ratingBarHeight;
      itemView.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          if (isEdit) {
            mClick.onClick(v, formationModelList.get(getLayoutPosition()), getLayoutPosition());
          }
        }
      });
    }
  }
}
