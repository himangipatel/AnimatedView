/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.keyboard;

/**
 * Created by yshrsmz on 15/03/17.
 */
public interface KeyboardVisibilityEventListener {

  void onVisibilityChanged(boolean isOpen, int height);
}
