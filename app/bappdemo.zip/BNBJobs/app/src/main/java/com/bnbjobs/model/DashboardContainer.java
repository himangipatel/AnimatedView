/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;

/**
 * @author Harsh
 * @version 1.0
 */
public class DashboardContainer {

  private boolean success;
  private String message;

  @SerializedName("data") private DashboardData dashboardData;

  public DashboardData getDashboardData() {
    return dashboardData;
  }

  public void setDashboardData(DashboardData dashboardData) {
    this.dashboardData = dashboardData;
  }

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }
}
