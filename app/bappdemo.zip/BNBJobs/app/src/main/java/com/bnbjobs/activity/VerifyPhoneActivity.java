/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.presenter.VerificationPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.VerificationView;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.ActivityUtils.launchActivity;

/**
 * @author Harsh
 * @version 1.0
 */
public class VerifyPhoneActivity extends BaseActivity implements VerificationView {

  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.toolbar) Toolbar toolbar;
  @BindView(R.id.tvSkip) TextView tvSkip;
  @BindView(R.id.editPhoneCode) EditText editPhoneCode;
  private VerificationPresenter verificationPresenter;
  private boolean isCallbackReturn;
  private boolean isFromRegistration;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_verification);
    ButterKnife.bind(this);
    init();
  }

  private void init() {

    isCallbackReturn = getIntent().getBooleanExtra("isCallbackReturn", false);
    isFromRegistration = getIntent().getBooleanExtra("isFromRegistration", false);

    toolbar.setBackgroundColor(ContextCompat.getColor(getContext(), android.R.color.white));
    imageBack.setImageResource(R.drawable.back_arrow);
    tvTitle.setTextColor(ContextCompat.getColor(getContext(), R.color.color_black));

    tvTitle.setText(getString(R.string.verify_phone));
    tvSkip.setVisibility(View.VISIBLE);
    tvTitle.setVisibility(View.VISIBLE);

    verificationPresenter = new VerificationPresenter();
    verificationPresenter.attachView(this);

    setEditActionLister();
  }

  private void setEditActionLister() {
    editPhoneCode.setOnEditorActionListener(new TextView.OnEditorActionListener() {
      @Override public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
        if (actionId == EditorInfo.IME_ACTION_DONE) {
          Utils.hideKeyboard(VerifyPhoneActivity.this);
          onVerifyCode();
          return true;
        }
        return false;
      }
    });
  }

  @Override public void onVerificationComplete(boolean result, String message) {
    Utils.showMessage(getContext(), message);
    if (result) {
      getPrefs(getBaseContext()).save(QuickstartPreferences.USER_PHONE_VERIFIED, 1);
      if (isCallbackReturn) {
        Intent intent = new Intent(VerifyPhoneActivity.this, EditPersonalActivity.class);
        setResult(RESULT_OK, intent);
        finish();
      } else {
        editPhoneCode.setText("");
        if (isFromRegistration) {
          launchActivity(this, InviteActivity.class, true);
        } else {
          finish();
        }
      }
    }
  }

  @Override public void onCodeResend(boolean result, String message) {
    Utils.showMessage(getContext(), message);
  }

  @OnClick(R.id.imageBack) void onBack() {
    onBackPressed();
  }

  @OnClick(R.id.tvSkip) void onSkip() {
    if (isFromRegistration) {
      launchActivity(this, InviteActivity.class, true);
    } else {
      finish();
    }
  }

  @OnClick(R.id.btnVerify) void onVerifyCode() {
    String phoneCode = Utils.getText(editPhoneCode);
    if (!TextUtils.isEmpty(phoneCode)) {
      verificationPresenter.verifyPhoneNumber(phoneCode);
    } else {
      Utils.showMessage(getContext(), getString(R.string.verification_code));
    }
  }

  @OnClick(R.id.tvSendCode) void sendVerificationCode() {
    verificationPresenter.callVerificationCodeApi(getIntent().getStringExtra(Constants.KEY_NUMBER));
  }

  @Override public Context getContext() {
    return VerifyPhoneActivity.this;
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override protected void onDestroy() {
    verificationPresenter.detachView();
    super.onDestroy();
  }
}
