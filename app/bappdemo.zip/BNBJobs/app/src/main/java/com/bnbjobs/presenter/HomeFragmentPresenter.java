/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.app.Fragment;
import android.widget.EditText;
import com.bnbjobs.R;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.JobContainer;
import com.bnbjobs.model.JobModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.HomeFragmentView;
import com.google.gson.Gson;
import com.jakewharton.rxbinding.widget.RxTextView;
import com.jakewharton.rxbinding.widget.TextViewTextChangeEvent;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class HomeFragmentPresenter extends BasePresenter implements Presenter<HomeFragmentView> {
  private static final String TAG = makeLogTag(HomeFragmentPresenter.class);
  private final static int REGULAR_TYPE = 1;
  private final static int PULL_TYPE = 2;
  private final static int SEARCH_TYPE = 3;
  boolean loadMore;
  private HomeFragmentView mHomeFragmentView;
  private Fragment fragment;
  private int page = 1;
  private int PER_PAGE = 5;
  private Subscription subscription;
  private String searchText;
  private int requestType;
  private boolean showProgress = true;
  private String filter = "";

  @Override public void attachView(HomeFragmentView view) {
    mHomeFragmentView = view;
  }

  @Override public void detachView() {
    if (subscription != null && !subscription.isUnsubscribed()) subscription.unsubscribe();
    mHomeFragmentView = null;
  }

  public void resetRequest(int requestType) {
    this.requestType = requestType;
    page = 1;
    loadMore = false;
    showProgress = false;
    getAllCandidates(requestType);
  }

  public void getAllCandidates(int requestType) {
    this.requestType = requestType;
    if (showProgress) mHomeFragmentView.showProgress();
    HashMap<String, String> params = new HashMap<>(10);
    params.put("apiName", "getAllJobOffers");
    params.put("perPage", String.valueOf(PER_PAGE));
    params.put("contractType", filter);
    params.putAll(addDefaultParamsWitLat(params));
    if (loadMore) params.put("page", String.valueOf(page));
    if (requestType == SEARCH_TYPE || !isEmpty(searchText)) params.put("title", searchText);

    mHomeFragmentView.loadMore(false);

    if (subscription != null && !subscription.isUnsubscribed()) subscription.unsubscribe();
    subscription =
        RestClient.getInstance(params).compose(getBindEvent()).subscribe(getSubscriber());
  }

  private Subscriber<String> getSubscriber() {
    if (requestType == REGULAR_TYPE) {
      return regularRequest();
    } else if (requestType == PULL_TYPE) {
      return pullToSubscribe();
    } else {
      return searchSubscriber();
    }
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).<String>bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  private Subscriber<String> regularRequest() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mHomeFragmentView.hideProgress();
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        mHomeFragmentView.hideProgress();
        showProgress = false;
        JobContainer container = new Gson().fromJson(s, JobContainer.class);
        setData(container);
      }
    };
  }

  private Subscriber<String> searchSubscriber() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mHomeFragmentView.hideProgress();
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        mHomeFragmentView.hideProgress();
        JobContainer container = new Gson().fromJson(s, JobContainer.class);
        setData(container);
      }
    };
  }

  private Subscriber<String> pullToSubscribe() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mHomeFragmentView.hideProgress();
        mHomeFragmentView.onError();
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        mHomeFragmentView.hideProgress();
        JobContainer container = new Gson().fromJson(s, JobContainer.class);
        setData(container);
      }
    };
  }

  private void setData(JobContainer container) {

    if (container.isSuccess()) {
      page = container.getCurrentPage() + 1;
      loadMore = container.getTotalPage() != container.getCurrentPage();
      mHomeFragmentView.loadMore(loadMore);
      mHomeFragmentView.setAdapter(container.getmJobModel());
    } else {
      loadMore = false;
      mHomeFragmentView.loadMore(false);
      mHomeFragmentView.setAdapter(new ArrayList<JobModel>());
            /*if (requestType != SEARCH_TYPE)
                showMessage(container);*/
    }
  }

  public void onSearch(final EditText editText) {

    RxTextView.textChangeEvents(editText)
        .debounce(400, TimeUnit.MILLISECONDS)
        .observeOn(AndroidSchedulers.mainThread())
        .compose(((BaseFragment) fragment).<TextViewTextChangeEvent>bindUntilEvent(
            FragmentEvent.DESTROY_VIEW))
        .subscribe(new Subscriber<TextViewTextChangeEvent>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
          }

          @Override public void onNext(TextViewTextChangeEvent textViewTextChangeEvent) {
            searchText = String.valueOf(textViewTextChangeEvent.text());
            LOGI(TAG, "search: " + searchText);
            if (!editText.hasFocus()) return;
            page = 1;
            loadMore = false;
            showProgress = true;
            mHomeFragmentView.clearData();
            if (isEmpty(searchText)) {
              getAllCandidates(REGULAR_TYPE);
            } else {
              getAllCandidates(SEARCH_TYPE);
            }
          }
        });
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(final Throwable e) {
    String error = "";
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            getAllCandidates(requestType);
          }
        }).show();
  }

  public void updateUserLocation() {
    HashMap<String, String> params = new HashMap<>(6);
    params.put("apiName", "updateUserLocation");
    params.putAll(addDefaultParamsWitLat(params));

    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
      }

      @Override public void onNext(String s) {
        if (isResponseSuccess(s)) {
          page = 1;
          mHomeFragmentView.clearData();
          showProgress = true;
          loadMore = false;
          getAllCandidates(requestType);
        }
      }
    });
  }

  @Override public Context getBaseContext() {
    return mHomeFragmentView.getContext();
  }

  public Context getContext() {
    return mHomeFragmentView.getContext();
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }

  public void setFilterString(String filter) {
    this.filter = filter;
  }
}
