/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.keyboard;

import android.app.Activity;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

/**
 * Created by yshrsmz on 15/03/17.
 */
public class KeyboardVisibilityEvent {

  private final static int KEYBOARD_VISIBLE_THRESHOLD_DP = 100;

  /**
   * Set keyboard visibility change event listener.
   *
   * @param activity Activity
   * @param listener KeyboardVisibilityEventListener
   */
  public static void setEventListener(final Activity activity,
      final KeyboardVisibilityEventListener listener) {

    if (activity == null) {
      throw new NullPointerException("Parameter:activity must not be null");
    }

    final View activityRoot = getActivityRoot(activity);

    activityRoot.getViewTreeObserver()
        .addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

          private final Rect r = new Rect();

          private final int visibleThreshold =
              Math.round(UIUtil.convertDpToPx(activity, KEYBOARD_VISIBLE_THRESHOLD_DP));

          private boolean wasOpened = false;

          @Override public void onGlobalLayout() {
            activityRoot.getWindowVisibleDisplayFrame(r);

            int heightDiff = activityRoot.getRootView().getHeight() - r.height();

            boolean isOpen = heightDiff > visibleThreshold;

            if (isOpen == wasOpened) {
              // keyboard state has not changed
              return;
            }

            wasOpened = isOpen;

            if (listener != null) listener.onVisibilityChanged(isOpen, heightDiff);
          }
        });
  }

  private static View getActivityRoot(Activity activity) {
    return ((ViewGroup) activity.findViewById(android.R.id.content)).getChildAt(0);
  }
}
