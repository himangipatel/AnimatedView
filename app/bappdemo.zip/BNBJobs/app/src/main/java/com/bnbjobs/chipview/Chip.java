/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.chipview;

/**
 * Created by Plumillon Forge on 17/09/15.
 */
public interface Chip {
    /**
     * Return the Chip text
     *
     * @return String
     */
    String getText();

    int getPosition();
}
