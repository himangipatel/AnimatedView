/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.fragments.CustomDatePickerFragment;
import com.bnbjobs.model.Experience;
import com.bnbjobs.presenter.ExperiencePresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.ExperienceView;
import com.bumptech.glide.Glide;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import org.greenrobot.eventbus.EventBus;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnNeverAskAgain;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.hideKeyboard;

/**
 * @author Harsh
 * @version 1.0
 */
@RuntimePermissions public class ExperienceActivity extends BaseActivity implements ExperienceView {

  private static final String TAG = makeLogTag(ExperienceActivity.class);
  Bundle bundle;
  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.rightImage) TinTableImageView rightImage;
  @BindView(R.id.toolbar) Toolbar toolbar;
  @BindView(R.id.imageExperience) ImageView imageExperience;
  @BindView(R.id.etCompanyName) EditText etCompanyName;
  @BindView(R.id.etDTitle) EditText etDTitle;
  @BindView(R.id.tvStartMonth) TextView tvStartMonth;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.tvEndMonth) TextView tvEndMonth;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.relativeContainer) RelativeLayout relativeContainer;
  @BindView(R.id.linearDate) LinearLayout linearDate;
  private Experience mExperience;
  private ExperiencePresenter presenter;
  private boolean isImageSet;
  private String path = null;
  private boolean isEdit;
  private String eId;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_add_experience);
    ButterKnife.bind(this);
    presenter = new ExperiencePresenter();
    tvTitle.setVisibility(View.VISIBLE);
    tvTitle.setText(getString(R.string.experience));
    rightImage.setVisibility(View.VISIBLE);
    rightImage.setImageResource(R.drawable.top_check);
    if (getIntent() != null) {
      bundle = getIntent().getExtras();
      if (bundle != null) {
        mExperience = bundle.getParcelable(Constants.KEY_OBJECT);
        if (mExperience != null) setData();
      }
    }
    presenter.attachView(this);
  }

  @OnClick(R.id.imageBack) void onBack() {
    onBackPressed();
  }

  private void setData() {
   /* isEdit = true;
    eId = mExperience.getId();
    tvStartMonth.setText(mExperience.getStartMonth() + ", " + mExperience.getStartYear());
    if (mExperience.getEndMonth().equalsIgnoreCase("0")) {
      tvEndMonth.setText("");
    } else {
      tvEndMonth.setText(mExperience.getEndMonth() + ", " + mExperience.getEndYear());
    }
    etCompanyName.setText(mExperience.getCompany());
    etDTitle.setText(mExperience.getTitle());
    isImageSet = false;
    Glide.with(this)
        .load(mExperience.getImageThumb())
        .placeholder(R.drawable.add_photo_placeholder)
        .dontAnimate()
        .into(imageExperience);*/
  }

  @OnClick({ R.id.tvStartMonth, R.id.tvEndMonth }) void onDateSelect(View view) {
    int id = view.getId();
    hideKeyboard(this);
    if (id == R.id.tvStartMonth) {
      showDatePicker(true);
    } else {
      if (!isEmpty(Utils.getText(tvStartMonth))) {
        showDatePicker(false);
      } else {
        Utils.showDialog(this, getString(R.string.alert), getString(R.string.error_start_date),
            getString(R.string.ok), new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
              }
            }).show();
      }
    }
  }

  @OnClick({ R.id.imageExperience, R.id.rightImage, R.id.linearProgress }) void onImageClick(
      View view) {
    if (view.getId() == R.id.imageExperience) {
      presenter.showChangePhotoDialog();
    } else if (view.getId() == R.id.linearProgress) {
      // do nothing
      LOGI(TAG, "onImageClick");
    } else {
      hideKeyboard(this);
      presenter.callService();
    }
  }

  private void showDatePicker(final boolean start) {
    CustomDatePickerFragment datePickerFragment = new CustomDatePickerFragment();
    String currentText;
    if (start) {
      currentText = Utils.getText(tvStartMonth);
    } else {
      currentText = Utils.getText(tvEndMonth);
    }

    Calendar calender = Calendar.getInstance();
    Bundle args = new Bundle();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM, yyyy", Locale.ENGLISH);
    Date showDate = null;
    try {
      showDate = simpleDateFormat.parse(currentText);
    } catch (ParseException e) {
      showDate = new Date();
    }
    calender.setTime(showDate);
    args.putInt("year", calender.get(Calendar.YEAR));
    args.putInt("month", calender.get(Calendar.MONTH));
    args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
    datePickerFragment.setListener(new DatePickerDialog.OnDateSetListener() {
      @Override public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
        if (start) {
          tvStartMonth.setText(String.format(Locale.getDefault(), "%d, %d", monthOfYear + 1, year));
          tvEndMonth.setText("");
        } else {
          tvEndMonth.setText(String.format(Locale.getDefault(), "%d, %d", monthOfYear + 1, year));
        }
        presenter.dateValidate(start);
      }
    });
    datePickerFragment.setArguments(args);
    datePickerFragment.show(getSupportFragmentManager(),
        datePickerFragment.getClass().getSimpleName());
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    presenter.onActivityResult(requestCode, resultCode, data);
  }

  @Override protected void onDestroy() {
    presenter.detachView();
    super.onDestroy();
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public String getCompanyName() {
    return Utils.getText(etCompanyName);
  }

  @Override public String getDTitle() {
    return Utils.getText(etDTitle);
  }

  @Override public String getStartYear() {
    return Utils.getText(tvStartMonth);
  }

  @Override public String getEndYear() {
    return Utils.getText(tvEndMonth);
  }

  @Override public File getProfile() {
    return path != null ? new File(path) : null;
  }

  @Override public void openCamera() {
    ExperienceActivityPermissionsDispatcher.showCameraWithCheck(this, true);
  }

  @Override public void openGallery() {
    ExperienceActivityPermissionsDispatcher.showCameraWithCheck(this, false);
  }

  @Override public void showPhoto(String path) {
    this.path = path;
    isImageSet = true;
    Glide.with(this).load(new File(path)).into(imageExperience);
  }

  @Override public void setDefault() {
    path = null;
    isImageSet = false;
    imageExperience.setImageResource(R.drawable.add_photo_placeholder);
  }

  @Override public boolean isImageSet() {
    return isImageSet;
  }

  @Override public int getSMonth() {
    return getDate(Utils.getText(tvStartMonth), Calendar.MONTH) + 1;
  }

  @Override public int getSYear() {
    return getDate(Utils.getText(tvStartMonth), Calendar.YEAR);
  }

  @Override public int getEMonth() {
    return getDate(Utils.getText(tvEndMonth), Calendar.MONTH) + 1;
  }

  @Override public int getEYear() {
    return getDate(Utils.getText(tvEndMonth), Calendar.YEAR);
  }

  @Override public boolean isEdit() {
    return isEdit;
  }

  @Override public String getId() {
    return eId;
  }

  @Override public void onDone(Experience experience) {

    EventBus.getDefault().post(experience);
    finish();
  }

  @Override public void setStartDate(String text) {
    tvStartMonth.setText(text);
  }

  @Override public void setEndDate(String text) {
    tvEndMonth.setText(text);
  }

  @NeedsPermission({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showCamera(boolean isCamera) {
    if (isCamera) {
      presenter.openCamera();
    } else {
      presenter.openGallery();
    }
  }

  @OnShowRationale({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showRationaleForCamera(final PermissionRequest request) {
    LOGI(TAG, "OnShowRationale");
    Utils.showDialog(this, getString(R.string.alert),
        getString(R.string.permission_camera_rationale), getString(R.string.button_allow),
        getString(R.string.button_deny), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.proceed();
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.cancel();
          }
        }).show();
  }

  @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
      @NonNull int[] grantResults) {
    ExperienceActivityPermissionsDispatcher.onRequestPermissionsResult(this, requestCode,
        grantResults);
  }

  @OnPermissionDenied({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showDeniedForCamera() {
    LOGI(TAG, "OnPermissionDenied");
    showPermissionDialog();
  }

  @OnNeverAskAgain({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showNeverAskForCamera() {
    LOGI(TAG, "OnNeverAskAgain");
    showPermissionDialog();
  }

  private void showPermissionDialog() {
    Utils.showDialog(this, getString(R.string.alert),
        getString(R.string.permission_camera_never_askagain), getString(android.R.string.ok),
        new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }
}
