/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import com.bnbjobs.R;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.GroupModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.EndlessRecyclerViewScrollListener;
import com.bnbjobs.utils.RxUtil;
import com.bnbjobs.view.GroupListView;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.lang.reflect.Type;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Action1;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class GroupListPresenter extends BasePresenter implements Presenter<GroupListView> {

  private GroupListView view;
  private Fragment fragment;
  private int groupListCurrentPage;
  private int groupListTotalPages;
  private Subscription subscription;
  private boolean groupListLoading;
  private EndlessRecyclerViewScrollListener mEndlessRecyclerViewScrollListener;
  private final int LOAD_MORE_START_INDEX = 3;
  private final int PER_PAGE = 10;
  private static final String TAG = makeLogTag(GroupListPresenter.class);
  private boolean loadMore;

  @Override public void attachView(GroupListView view) {
    this.view = view;
    final RecyclerView recyclerView = view.getRecyclerView();
    mEndlessRecyclerViewScrollListener = new EndlessRecyclerViewScrollListener(
        (GridLayoutManager) recyclerView.getLayoutManager()) {

      @Override public void onLoadMore(int page, int totalItemsCount) {
        GroupListPresenter.this.onLoadMore();
      }
    }.setVisibleThreshold(LOAD_MORE_START_INDEX);
    recyclerView.addOnScrollListener(mEndlessRecyclerViewScrollListener);

  }

  @Override public void detachView() {
      RxUtil.unsubscribe(subscription);
  }

  public void getGroupList(final int page) {
    if (hasNetworkConnectivity()) {
      groupListLoading = true;
      HashMap<String, String> params = new HashMap<>(10);
      params.put("apiName", "list_all_group");
      String search = view.getSearchString();
      boolean isSearch = !TextUtils.isEmpty(search);
      if (isSearch) {
        params.put("title", search);
      }
      if(view.isUserGroups())
      params.put("my_groups", "1");
      params.putAll(addDefaultParamsWitLat(params));
      params.put("page", String.valueOf(page));
      params.put("perPage", String.valueOf(PER_PAGE));
      if(page==1 && !view.isSwipeToRefresh())
        view.showProgress();
      RxUtil.unsubscribe(subscription);
      subscription = RestClient.getInstance(params).compose(getBindEvent()).doOnError(new Action1<Throwable>() {
        @Override public void call(Throwable e) {
            onError(page,e);
        }
      }).subscribe(getAllGroupSubscriber());
    }
  }

  public void deleteGroup(final String groupId) {
    view.showProgress();
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "delete_group");
    params.put("group_id", groupId);
    params.putAll(addParams(params));
    RxUtil.unsubscribe(subscription);
    subscription = RestClient.getInstance(params).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        view.hideProgress();
        LOGE(TAG, Log.getStackTraceString(e));
        String error;
        if (e instanceof SocketTimeoutException) {
          error = getBaseContext().getString(R.string.error_timeout);
        } else {
          error = getBaseContext().getString(R.string.error_other);
        }
        showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error, getBaseContext().getString(R.string.retry),
            new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                deleteGroup(groupId);
              }
            }).show();
      }

      @Override public void onNext(String s) {
        view.hideProgress();
        try {
          JSONObject object = new JSONObject(s);
          if (object.getBoolean("success")) {
            view.onDeleteSuccess(groupId);
          } else {
            view.onError(object.getString("message"));
          }
        } catch (JSONException e) {
          e.printStackTrace();
        }

      }
    });
  }

  private void hideProgress() {
    if (mEndlessRecyclerViewScrollListener != null) {
      mEndlessRecyclerViewScrollListener.setLoading(false);
    }
   view.hideProgress();
  }

  private void onError(final int page,Throwable e){
    LOGE(TAG, e.getMessage(), e);
    hideProgress();
    groupListLoading = false;
    String error;
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            getGroupList(page);
          }
        }).show();
  }


  private Subscriber<String> getAllGroupSubscriber() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {
        groupListLoading = false;
      }

      @Override public void onError(Throwable e) {

      }

      @Override public void onNext(String s) {
        hideProgress();
        groupListLoading = false;
        GsonBuilder builder = new GsonBuilder();
        Type collectionType = new TypeToken<BaseContainer<GroupModel>>() {}.getType();
        BaseContainer<GroupModel> jobSearchBaseContainer =  builder.create().fromJson(s, collectionType);
        groupListCurrentPage = jobSearchBaseContainer.getCurrentPage();
        groupListTotalPages = jobSearchBaseContainer.getTotalPages();
        loadMore = groupListTotalPages > groupListCurrentPage;
        view.onSuccess(jobSearchBaseContainer.getDataList(),jobSearchBaseContainer.getCurrentPage()==1);
      }
    };
  }

  private void onLoadMore() {
    if (loadMore && !groupListLoading) {
      LOGI(TAG,"Calling loadmore");
      getGroupList(++groupListCurrentPage);
    }
  }
  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }

  @Override protected Context getBaseContext() {
    return view.getContext();
  }
}
