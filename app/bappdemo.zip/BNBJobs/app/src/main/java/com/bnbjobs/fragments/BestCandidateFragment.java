/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.adapter.HomeRecruiterAdapter;
import com.bnbjobs.customui.views.BackImageView;
import com.bnbjobs.customui.views.GradientView;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.CandidateModel;
import com.bnbjobs.presenter.BestCandidatePresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.view.BestCandidateView;
import java.util.ArrayList;
import java.util.List;

import static com.bnbjobs.R.id.linearSearch;

/**
 * @author Harsh
 * @version 1.0
 */
public class BestCandidateFragment extends BaseFragment
    implements BestCandidateView, ClickImpl<CandidateModel> {

  @BindView(R.id.linearLocation) LinearLayout mLinearLocation;
  @BindView(R.id.recyclerView) RecyclerView mRecyclerView;
  @BindView(R.id.swipeRefresh) SwipeRefreshLayout mSwipeRefresh;
  @BindView(R.id.linearProgress) LinearLayout mLinearProgress;
  @BindView(R.id.tvNoRecord) TextView mTvNoRecord;
  @BindView(R.id.etSearch) EditText mEtSearch;
  @BindView(linearSearch) LinearLayout mLinearSearch;
  @BindView(R.id.filterRecycler) RecyclerView mFilterRecycler;
  @BindView(R.id.tvDone) GradientView mTvDone;
  @BindView(R.id.linearFilter) LinearLayout mLinearFilter;
  @BindView(R.id.imageFilter) BackImageView mImageFilter;
  @BindView(R.id.relativeTop) RelativeLayout mRelativeTop;
  @BindView(R.id.imageBack) TinTableImageView mImageBack;
  @BindView(R.id.tvInformation) TextView tvInformation;
  private BestCandidatePresenter presenter;
  private HomeRecruiterAdapter adapter;
  private List<CandidateModel> mCandidateModels = new ArrayList<>();

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_list, container, false);
    ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    init();

    if (presenter == null) {
      presenter = new BestCandidatePresenter();
      presenter.attachView(this);
      presenter.setFragment(this);
    }
    mSwipeRefresh.setEnabled(false);
    mSwipeRefresh.setRefreshing(false);
    mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
    if (adapter == null) {
      adapter = new HomeRecruiterAdapter(getActivity(), mCandidateModels, this);
    }
    if (mCandidateModels.size() < 1) {
      presenter.getBestCandidate();
    }
    mRecyclerView.setAdapter(adapter);
  }

  /**
   * initialize view
   */
  private void init() {
    mLinearLocation.setVisibility(View.GONE);
    mLinearSearch.setVisibility(View.GONE);
    mRelativeTop.setVisibility(View.GONE);
    mImageBack.setVisibility(View.VISIBLE);
    tvInformation.setVisibility(View.VISIBLE);
  }

  @Override public void getBestCandidates(List<CandidateModel> mCandidateModel) {
    mCandidateModels.addAll(mCandidateModel);
    adapter.notifyDataSetChanged();
  }

  @OnClick(R.id.imageBack) void onClick() {
    getFragmentManager().popBackStack();
  }

  @Override public String getOfferId() {
    return getArguments().getString(Constants.KEY_ID);
  }

  @Override public void showProgress() {
    mLinearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    mLinearProgress.setVisibility(View.GONE);
  }

  @Override public void onDestroyView() {
    presenter.detachView();
    super.onDestroyView();
  }

  @Override public void onClick(View view, CandidateModel object, int position) {
    ProfileFragment fragment = new ProfileFragment();
    Bundle bundle = new Bundle();
    bundle.putString(Constants.KEY_ID, object.getuId());
    fragment.setArguments(bundle);
    addFragment(fragment, true);
  }
}
