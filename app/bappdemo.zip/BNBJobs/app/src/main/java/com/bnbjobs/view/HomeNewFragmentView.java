/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import android.support.v7.widget.RecyclerView;
import com.bnbjobs.customui.looppager.RecyclerViewPager;
import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.CountryListModel;
import com.bnbjobs.model.GroupModel;
import com.bnbjobs.model.JobModel;
import java.util.List;

/**
 * Created by krupal on 1/8/16.
 */

public interface HomeNewFragmentView extends MainView {

  void setRecentJobAdapter(BaseContainer<JobModel> jobModelBaseContainer);

  void setSelectionJobAdapter(BaseContainer<JobModel> jobModelBaseContainer);

  void setTodayDealList(BaseContainer<JobModel> jobModelBaseContainer);

  void setMyCityAdapter(BaseContainer<CountryListModel> cityBaseContainer);

  void onLocationSet(String location);

  void onError();

  void clearData();

  RecyclerViewPager getRvRecentJobs();

  RecyclerViewPager getRvSelectionJobs();

  RecyclerViewPager getTodayDeal();

  RecyclerView getRvCities();

  RecyclerView getKmJob();
  RecyclerView getGroupRecycle();

  void showProgress();

  void hideProgress();

  void showSearchProgress();

  void hideSearchProgress();

  void setKmJobAdapter(BaseContainer<JobModel> jobSearchBaseContainer);

  void onGroupSuccess(List<GroupModel> dataList, boolean b);

  void onDeleteSuccess(String groupId);

  void onError(String message);
}
