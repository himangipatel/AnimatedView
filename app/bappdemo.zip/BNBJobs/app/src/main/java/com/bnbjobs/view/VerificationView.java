/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

/**
 * Created by jay shah on 5/8/16.
 */
public interface VerificationView extends MainView {

  void onVerificationComplete(boolean result, String message);

  void onCodeResend(boolean result, String message);
}
