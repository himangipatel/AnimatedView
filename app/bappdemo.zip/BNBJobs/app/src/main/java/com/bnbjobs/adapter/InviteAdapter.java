/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.activity.InviteActivity;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.InviteModel;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class InviteAdapter extends RecyclerView.Adapter<InviteAdapter.MyViewHolder>
    implements Filterable {

  private static final String TAG = makeLogTag(InviteAdapter.class);
  private Context mContext;
  private List<InviteModel> mInviteModelList;
  private List<InviteModel> mOriginalList;
  private ClickImpl<InviteModel> mClickImpl;

  public InviteAdapter(Context mContext) {
    this.mContext = mContext;
    mClickImpl = (ClickImpl<InviteModel>) mContext;
  }

  public void setAdapter(List<InviteModel> mInviteModelList) {
    this.mInviteModelList = mInviteModelList;
    notifyDataSetChanged();
  }

  public void setOriginalList(List<InviteModel> mOriginalList) {
    this.mOriginalList = mOriginalList;
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_invite, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(final MyViewHolder holder, final int position) {
    if (mInviteModelList.get(position).isInvited()) {
      holder.tvInvite.setTextColor(Color.WHITE);
      holder.tvInvite.setText(mContext.getString(R.string.invited));
      holder.tvInvite.setBackgroundResource(R.drawable.round_fill_pink_invite);
    } else {
      holder.tvInvite.setText(mContext.getString(R.string.invite));
      holder.tvInvite.setTextColor(ActivityCompat.getColor(mContext, R.color.theme_pink));
      holder.tvInvite.setBackgroundResource(R.drawable.round_pink_invite);
    }
    holder.tvUserName.setText(mInviteModelList.get(position).getName());
    holder.tvUserAddress.setText(mInviteModelList.get(position).getAddress());
    if (mInviteModelList.get(position).getPhotoId() != null) {
      Glide.with(mContext)
          .load(Uri.parse(mInviteModelList.get(position).getPhotoId()))
          .into(holder.imgAvatar);
    } else {
      Glide.with(mContext).load(R.drawable.user_placeholder).into(holder.imgAvatar);
    }

    holder.tvInvite.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        if (mInviteModelList.get(holder.getLayoutPosition()).isInvited()){
          return;
        }
        mClickImpl.onClick(v, mInviteModelList.get(holder.getLayoutPosition()),holder.getLayoutPosition());
        mInviteModelList.get(holder.getLayoutPosition()).setInvited(true);
        notifyDataSetChanged();
      }
    });
  }

  @Override public int getItemCount() {
    return mInviteModelList.size();
  }

  @Override public Filter getFilter() {
    return new UserFilter(this, mOriginalList);
  }

  private static class UserFilter extends Filter {
    private final InviteAdapter adapter;
    private final List<InviteModel> originalList;
    private final List<InviteModel> filteredList;
    private List<InviteModel> mFilterInviteModelList;

    private UserFilter(InviteAdapter adapter, List<InviteModel> originalList) {
      super();
      this.adapter = adapter;
      this.originalList = new LinkedList<>(originalList);
      filteredList = new ArrayList<>();
      mFilterInviteModelList = new ArrayList<>();
    }

    @Override protected FilterResults performFiltering(CharSequence constraint) {
      filteredList.clear();
      final FilterResults results = new FilterResults();

      if (constraint.length() == 0) {
        filteredList.addAll(originalList);
      } else {
        String filterPattern = constraint.toString().toLowerCase().trim();
        for (InviteModel user : originalList) {
          if (user.getName().toLowerCase().contains(filterPattern)) {
            filteredList.add(user);
          }
        }
      }
      results.values = filteredList;
      results.count = filteredList.size();
      return results;
    }

    @Override protected void publishResults(CharSequence constraint, FilterResults results) {
      mFilterInviteModelList.clear();
      mFilterInviteModelList.addAll(((ArrayList<InviteModel>) results.values));
      adapter.setAdapter(mFilterInviteModelList);
      ((InviteActivity) adapter.mContext).scrollToFirst();
    }
  }

  static class MyViewHolder extends RecyclerView.ViewHolder {
    @BindView(R.id.imgAvatar) ImageView imgAvatar;
    @BindView(R.id.tvUserName) TextView tvUserName;
    @BindView(R.id.tvUserAddress) TextView tvUserAddress;
    @BindView(R.id.tvInvite) TextView tvInvite;

    MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
    }
  }
}
