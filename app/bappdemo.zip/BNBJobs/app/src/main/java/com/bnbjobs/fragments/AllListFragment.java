/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.adapter.CandidateRequestAdapter;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.CandidateModel;
import com.bnbjobs.presenter.DashboardCandidatePresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.EndlessRecyclerViewScrollListener;
import com.bnbjobs.utils.SpacesItemDecoration;
import com.bnbjobs.view.DashboardCandidateView;
import com.trello.rxlifecycle.components.support.RxFragment;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.collections4.IterableUtils;
import org.apache.commons.collections4.Predicate;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class AllListFragment extends RxFragment implements DashboardCandidateView, ClickImpl<CandidateModel> {

  private static final String TAG = makeLogTag(AllListFragment.class);
  @BindView(R.id.recyclerView) RecyclerView recyclerView;
  @BindView(R.id.tvNoRecord) TextView tvNoRecord;
  @BindView(R.id.linearSmallProgress) LinearLayout linearSmallProgress;
  private Unbinder unbinder;
  private CandidateRequestAdapter adapter;
  private ArrayList<CandidateModel> candidateRequestArrayList = new ArrayList<>();
  private int type;
  private DashboardCandidatePresenter presenter;
  private boolean loadMore;
  private boolean isFooterAdd;
  private int position;
  private boolean resumeCall;
  private CandidateModel tempCandidate;

  public static AllListFragment getInstance(int type) {
    Bundle bundle = new Bundle();
    bundle.putInt(Constants.KEY_TYPE, type);
    AllListFragment fragment = new AllListFragment();
    fragment.setArguments(bundle);
    return fragment;
  }

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    type = getArguments().getInt(Constants.KEY_TYPE, 0);
    EventBus.getDefault().register(this);
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_all_list, container, false);
    unbinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    if (presenter == null) {
      presenter = new DashboardCandidatePresenter();
    }
    presenter.attachView(this);
    presenter.setFragment(this);
    LinearLayoutManager layout1 =  new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
    recyclerView.setLayoutManager(layout1);
    recyclerView.setHasFixedSize(true);
    if (adapter == null) {
      adapter = new CandidateRequestAdapter(getActivity(), candidateRequestArrayList, this);
    }
    adapter.setType(type);
    recyclerView.setAdapter(adapter);
    int spacingInPixels = getResources().getDimensionPixelSize(R.dimen._5sdp);
    recyclerView.addItemDecoration(new SpacesItemDecoration(spacingInPixels));
    if (candidateRequestArrayList.size() == 0) {
      presenter.getCandidate(type);
    }
    recyclerView.addOnScrollListener(new EndlessRecyclerViewScrollListener(layout1) {
      @Override public void onLoadMore(int page, int totalItemsCount) {
        if (loadMore) {
          loadMore = false;
          isFooterAdd = true;
          candidateRequestArrayList.add(null);
          adapter.notifyItemInserted(candidateRequestArrayList.size() - 1);
          presenter.getCandidate(type);
        }
      }
    });
  }

  @Override public void onDestroyView() {
    presenter.detachView();
    unbinder.unbind();
    super.onDestroyView();
  }

  @Override public void onDestroy() {
    super.onDestroy();
    LOGI(TAG, "onDestroy");
    EventBus.getDefault().unregister(this);
  }

  private void updateCount(boolean add) {
    ((DashboardFragment) getParentFragment()).totalCandidate(type, add);
  }

  @Override public void setRetryView() {
  }

  @Override public void setAdapter(List<CandidateModel> mUserModelList) {
    if (isFooterAdd) {
      isFooterAdd = false;
      this.candidateRequestArrayList.remove(this.candidateRequestArrayList.size() - 1);
      adapter.notifyItemRemoved(this.candidateRequestArrayList.size());
    }
    candidateRequestArrayList.addAll(mUserModelList);
    //setCount();
    adapter.notifyDataSetChanged();
    checkData();
  }

  @Override public void applyStatus(String action) {
    Bundle bundle = new Bundle();
    if (action.equalsIgnoreCase("1")) {
      //accept
      bundle.putInt(Constants.KEY_DIALOG_TYPE, Constants.CANDIDATE_ACCEPT);
      CandidateModel model = candidateRequestArrayList.get(position);
      model.setAccept(true);
      ((DashboardFragment) getParentFragment()).candidateUpdate(model);
    } else {
      //reject
      candidateRequestArrayList.get(position).setApplyJobBtnFlag(4);
      bundle.putInt(Constants.KEY_DIALOG_TYPE, Constants.CANDIDATE_REJECT);
      CandidateModel model = candidateRequestArrayList.get(position);
      model.setAccept(false);
      ((DashboardFragment) getParentFragment()).candidateUpdate(model);
    }
    adapter.notifyItemChanged(position);
    InviteFragment inviteFragment = new InviteFragment();
    inviteFragment.setArguments(bundle);
    inviteFragment.show(getFragmentManager(), inviteFragment.getClass().getName());
  }

  @Override public void showParentProcess() {
    ((DashboardFragment) getParentFragment()).showProgress();
  }

  @Override public void hideParentProgress() {
    ((DashboardFragment) getParentFragment()).hideProgress();
  }

  @Override public String getOffset() {
    return Integer.toString(candidateRequestArrayList.size());
  }

  @Override public void setLoadMore(boolean loadMore) {
    this.loadMore = loadMore;
  }

  @Override public void showProgress() {
    linearSmallProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearSmallProgress.setVisibility(View.GONE);
  }

  @Override public void onClick(View view, CandidateModel object, int position) {
    if (view.getId() == R.id.tvAccept || view.getId() == R.id.tvReject) {
      this.position = position;
      HashMap<String, String> params = new HashMap<>(3);
      params.put("offerId", Integer.toString(object.getOfferId()));
      if (view.getId() == R.id.tvAccept) {
        params.put("action", "1");
      } else {
        params.put("action", "2");
      }
      params.put("candidateId", object.getuId());
      presenter.applyJob(params);
    } else {
      ProfileFragment fragment = new ProfileFragment();
      Bundle bundle = new Bundle();
      bundle.putString(Constants.KEY_ID, object.getuId());
      bundle.putParcelable(Constants.KEY_OBJECT, object);
      fragment.setArguments(bundle);
      fragment.setTargetFragment(this, 1111);
      addFragment(fragment, true);
    }
  }

  @Subscribe public void onEvent(@NonNull final CandidateModel data) {
    LOGI(TAG, "here onEvent: " + data.toString());
    final CandidateModel model =
        IterableUtils.find(candidateRequestArrayList, new Predicate<CandidateModel>() {
          @Override public boolean evaluate(CandidateModel object) {
            return data.getuId().equalsIgnoreCase(object.getuId())
                && data.getOfferId() == object.getOfferId();
          }
        });
    if (type == 3 && data.isAccept()) {
      updateCount(true);
      data.setApplyJobBtnFlag(3);
      candidateRequestArrayList.add(data);
      adapter.notifyDataSetChanged();
    }
    if (model == null) {
      return;
    }
    switch (type) {
      case 1:
        if (model.isAccept()) {
          model.setApplyJobBtnFlag(3);
        } else {
          candidateRequestArrayList.remove(model);
          updateCount(false);
        }
        adapter.notifyDataSetChanged();
        break;
      case 2:
        candidateRequestArrayList.remove(model);
        adapter.notifyDataSetChanged();
        updateCount(false);
        break;
      case 3:
        if (model.isAccept()) {
          model.setApplyJobBtnFlag(3);
          candidateRequestArrayList.add(model);
          adapter.notifyDataSetChanged();
        }
        break;
    }
    checkData();
  }

  private void checkData() {
    if (adapter.getItemCount() > 0) {
      tvNoRecord.setVisibility(View.GONE);
    } else {
      tvNoRecord.setVisibility(View.VISIBLE);
    }
  }

  private void addFragment(Fragment fragment, boolean addToBackStack) {
    ((HomeActivity) getActivity()).switchFragment(fragment, addToBackStack);
  }

  public void onResumeCall(CandidateModel candidateModel) {
    resumeCall = true;
    tempCandidate = candidateModel;
  }

  @Override public void onResume() {
    super.onResume();
    LOGI(TAG, "onResume: " + type);
    if (resumeCall) {
      resumeCall = false;
      if (tempCandidate != null) {
        ((DashboardFragment) getParentFragment()).candidateUpdate(tempCandidate);
        tempCandidate = null;
      }
    }
  }
}
