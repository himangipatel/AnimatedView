/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.bnbjobs.model.JobModel;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public interface HomeFragmentView extends MainView {

  void setAdapter(List<JobModel> mJobModelList);

  void loadMore(boolean loadMore);

  void onError();

  void clearData();
}
