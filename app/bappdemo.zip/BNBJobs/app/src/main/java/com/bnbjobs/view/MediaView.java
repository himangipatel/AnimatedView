/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.bnbjobs.model.ImageModel;

/**
 * Created by jay shah on 25/7/16.
 */
public interface MediaView extends MainView {

  void openCamera();

  void openGallery();

  void opeVideoCamera();

  void openVideoGallery();

  void addImage(ImageModel imageModel, int posSel);

  void addVideo(ImageModel imgVideo);

  void setDefault();

  boolean isImageSet();
}
