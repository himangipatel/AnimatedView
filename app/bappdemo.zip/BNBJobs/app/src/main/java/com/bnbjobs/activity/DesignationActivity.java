/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.adapter.DesignationAdapter;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.DesignationModel;
import com.bnbjobs.presenter.DesignationPresenter;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.DesignationView;
import com.jakewharton.rxbinding.widget.TextViewTextChangeEvent;
import java.util.ArrayList;
import java.util.List;

import static android.text.TextUtils.isEmpty;

/**
 * @author Harsh
 * @version 1.0
 */
public class DesignationActivity extends BaseActivity implements DesignationView {

  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.imageCenterLogo) ImageView imageCenterLogo;
  @BindView(R.id.etSearch) EditText etSearch;
  @BindView(R.id.recyclerView) RecyclerView recyclerView;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;

  private List<DesignationModel> mDesignationModel = new ArrayList<>();
  private DesignationAdapter adapter;
  private DesignationPresenter presenter;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_designation);
    ButterKnife.bind(this);
    tvTitle.setVisibility(View.VISIBLE);
    tvTitle.setText(R.string.Designation);
    imageBack.setVisibility(View.GONE);
    recyclerView.setLayoutManager(new LinearLayoutManager(this));
    adapter = new DesignationAdapter(this);
    adapter.setAdapter(mDesignationModel);
    recyclerView.setAdapter(adapter);
    presenter = new DesignationPresenter();
    presenter.attachView(this);
    presenter.getDesignation();
    presenter.onSearchText(etSearch);

  }

  @Override public void setAdapter(List<DesignationModel> mDesignationModel) {
    this.mDesignationModel.addAll(mDesignationModel);
    adapter.setOriginalList(mDesignationModel);
    adapter.setAdapter(mDesignationModel);
  }

  @Override public void onSearch(TextViewTextChangeEvent textViewTextChangeEvent) {
    if (isEmpty(textViewTextChangeEvent.text())) {
      adapter.setAdapter(mDesignationModel);
    } else {
      adapter.getFilter().filter(Utils.getText(etSearch));
    }
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void onBackPressed() {
  }

  public void scrollToFirst() {
    recyclerView.smoothScrollToPosition(0);
  }

  public void onUpdate(String dId) {
    presenter.updateDesignation(dId);
  }
}
