/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.widget.Toast;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.view.MediaView;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;

/**
 * @author Harsh
 * @version 1.0
 */
public class MediaPresenter extends BasePresenter implements Presenter<MediaView> {

  /**
   * Create a File for saving an image or video
   */
  protected static final int MEDIA_TYPE_VIDEO = 10;
  Fragment fragment;
  String filePath;
  private MediaView mediaView;

  @Override protected Context getBaseContext() {
    return mediaView.getContext();
  }

  @Override public void attachView(MediaView view) {
    this.mediaView = view;
  }

  @Override public void detachView() {
    this.mediaView = null;
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }

  public void openCamera() {
    requestImageFromCamera();
  }

  public void openGallery() {
    requestImageFromGallery();
  }

  public void openVideoCamera() {
    requestVideoFromCamera();
  }

  public void openVideoGallery() {
    requestVideoFromGallery();
  }

  protected void requestImageFromCamera() {
    try {
      File outputDir =
          new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
              "temp");
      if (!outputDir.exists()) {
        if (!outputDir.mkdir()) {
          LOGI("TAG", "Error creating image file for camera output.");
          return;
        }
      }
      File outputFile =
          File.createTempFile(String.valueOf(System.currentTimeMillis()), ".jpg", outputDir);
      mCameraOutputPath = outputFile.getAbsolutePath();
      Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
      intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(outputFile));
      if (this.fragment != null) {
        fragment.startActivityForResult(intent, REQUEST_CODE_CAMERA);
      } else {
        ((BaseActivity) getBaseContext()).startActivityForResult(intent, REQUEST_CODE_CAMERA);
      }
    } catch (Exception e) {
      LOGI("TAG", "Error requesting photo from camera. " + e.getMessage());
    }
  }

  public void requestVideoFromCamera() {
    // create new Intentwith with Standard Intent action that can be
    // sent to have the camera application capture an video and return it.
    Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);

    Uri fileUri = getOutputMediaFileUri(MEDIA_TYPE_VIDEO);
    // set the image file name
    intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
    // set the video image quality to high
    intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
    if (this.fragment != null) {
      fragment.startActivityForResult(intent, REQUEST_CODE_VIDEO_CAMERA);
    } else {
      ((BaseActivity) getBaseContext()).startActivityForResult(intent, REQUEST_CODE_VIDEO_CAMERA);
    }
  }

  protected File getOutputMediaFile(int type) {
    // Check that the SDCard is mounted
    File mediaStorageDir =
        new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            "MyCameraVideo");
    // Create the storage directory(MyCameraVideo) if it does not exist
    if (!mediaStorageDir.exists()) {
      if (!mediaStorageDir.mkdirs()) {
        LOGE("Capture ", "Failed to create directory MyCameraVideo.");
        Toast.makeText(getBaseContext(), "Failed to create directory MyCameraVideo.",
            Toast.LENGTH_LONG).show();
        Log.d("MyCameraVideo", "Failed to create directory MyCameraVideo.");
        return null;
      }
    }
    // Create a media file name
    // For unique file name appending current timeStamp with file name
    Date date = new Date();
    String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(date.getTime());
    File mediaFile;
    if (type == MEDIA_TYPE_VIDEO) {
      // For unique video file name appending current timeStamp with file name
      mediaFile = new File(mediaStorageDir.getPath() + File.separator +
          "VID_" + timeStamp + ".mp4");
      filePath = mediaFile.getAbsolutePath();
    } else {
      return null;
    }
    return mediaFile;
  }

  /**
   * Create a file Uri for saving an image or video
   */
  private Uri getOutputMediaFileUri(int type) {
    return Uri.fromFile(getOutputMediaFile(type));
  }

  /**
   * requestImageFromGallery
   * Open photo gallery to choose a photo
   */
  public void requestVideoFromGallery() {
    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
    intent.setType("video/*");
    if (this.fragment != null) {
      fragment.startActivityForResult(
          Intent.createChooser(intent, getBaseContext().getString(R.string.change_photo_gallery)),
          REQUEST_CODE_VIDEO);
    } else {
      ((BaseActivity) getBaseContext()).startActivityForResult(
          Intent.createChooser(intent, getBaseContext().getString(R.string.change_photo_gallery)),
          REQUEST_CODE_VIDEO);
    }
  }


    /*requestImageFromGallery
    Open photo gallery to choose a photo*/

  protected void requestImageFromGallery() {
    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
    intent.setType("image/*");
    if (this.fragment != null) {
      fragment.startActivityForResult(
          Intent.createChooser(intent, getBaseContext().getString(R.string.change_photo_gallery)),
          REQUEST_CODE_GALLERY);
    } else {
      ((BaseActivity) getBaseContext()).startActivityForResult(
          Intent.createChooser(intent, getBaseContext().getString(R.string.change_photo_gallery)),
          REQUEST_CODE_GALLERY);
    }
  }
}
