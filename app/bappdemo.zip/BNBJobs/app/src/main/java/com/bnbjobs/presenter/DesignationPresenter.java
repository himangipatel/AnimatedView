/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.widget.EditText;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.activity.DesignationActivity;
import com.bnbjobs.model.DesignationContainer;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.DesignationView;
import com.google.gson.Gson;
import com.jakewharton.rxbinding.widget.RxTextView;
import com.jakewharton.rxbinding.widget.TextViewTextChangeEvent;
import com.trello.rxlifecycle.ActivityEvent;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class DesignationPresenter extends BasePresenter implements Presenter<DesignationView> {

  private final static String TAG = makeLogTag(DesignationPresenter.class);
  private DesignationView mDesignationView;

  @Override public void attachView(DesignationView view) {
    mDesignationView = view;
  }

  @Override public void detachView() {
    mDesignationView = null;
  }

  @Override protected Context getBaseContext() {
    return mDesignationView.getContext();
  }

  public void getDesignation() {
    mDesignationView.showProgress();
    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "getAllDesignations");
    params.put("language", getLanguage());
    params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
    params.put("accessToken",
        getPrefs(getBaseContext()).getString(QuickstartPreferences.ACCESS_TOKEN, ""));
    RestClient.getInstance(params)
        .compose(((BaseActivity) getBaseContext()).<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            mDesignationView.hideProgress();
            retryMethod(e, false, "");
          }

          @Override public void onNext(String s) {
            mDesignationView.hideProgress();
            DesignationContainer container = new Gson().fromJson(s, DesignationContainer.class);
            if (container.isSuccess()) {
              mDesignationView.setAdapter(container.getDesignationModelsList());
            }
          }
        });
  }

  public void onSearchText(EditText editText) {
    RxTextView.textChangeEvents(editText)
        .debounce(250, TimeUnit.MILLISECONDS)
        .observeOn(AndroidSchedulers.mainThread())
        .compose(((BaseActivity) getBaseContext()).<TextViewTextChangeEvent>bindUntilEvent(
            ActivityEvent.DESTROY))
        .subscribe(new Subscriber<TextViewTextChangeEvent>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
          }

          @Override public void onNext(TextViewTextChangeEvent textViewTextChangeEvent) {
            mDesignationView.onSearch(textViewTextChangeEvent);
          }
        });
  }

  public void updateDesignation(final String designationId) {
    mDesignationView.showProgress();
    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "updateCandidateDesignation");
    params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
    params.put("accessToken",
        getPrefs(getBaseContext()).getString(QuickstartPreferences.ACCESS_TOKEN, ""));
    params.put("language", getLanguage());
    params.put("designationId", designationId);

    RestClient.getInstance(params)
        .compose(((BaseActivity) getBaseContext()).<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            mDesignationView.hideProgress();
            retryMethod(e, true, designationId);
          }

          @Override public void onNext(String s) {
            mDesignationView.hideProgress();
            JSONObject object;
            try {
              object = new JSONObject(s);
              if (isResponseSuccess(s)) {
                getPrefs(getBaseContext()).save(QuickstartPreferences.SHOW_DESIGNATION, false);
                ((DesignationActivity) getBaseContext()).finish();
              } else {
                showDialog(getBaseContext(), getBaseContext().getString(R.string.alert),
                    object.getString("message"), getBaseContext().getString(android.R.string.ok),
                    new DialogInterface.OnClickListener() {
                      @Override public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                      }
                    }).show();
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  /**
   * retry
   *
   * @param e error
   */
  private void retryMethod(final Throwable e, final boolean update, final String id) {
    String error = "";
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            if (update) {
              updateDesignation(id);
            } else {
              getDesignation();
            }
          }
        }).show();
  }
}
