/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.adapter.EditExperienceAdapter;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.DesignationDbModel;
import com.bnbjobs.model.Experience;
import com.bnbjobs.model.ProfileUpdate;
import com.bnbjobs.presenter.EditExperiencePresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.ExperienceTypes;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.EditExperienceView;
import io.realm.Realm;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import org.apache.commons.collections4.IterableUtils;
import org.apache.commons.collections4.Predicate;
import org.greenrobot.eventbus.EventBus;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class EditExperienceActivity extends BaseActivity
    implements EditExperienceAdapter.DesignationSelection, EditExperienceView {

  @BindView(R.id.recyclerViewExperience) RecyclerView recyclerViewExperience;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.toolbar) Toolbar toolbar;
  @BindView(R.id.linearProgress) LinearLayout mLinearProgress;

  private ArrayList<Experience> editExperienceArrayList = new ArrayList<>();
  private EditExperienceAdapter editExperienceAdapter;

  private Experience currentEditExpRef;
  private EditExperiencePresenter presenter;
  private boolean isEditMode;
  private boolean isNewAdded;
  private static final String TAG = makeLogTag(EditExperienceActivity.class);
  private Experience tempExperience;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_edit_experience);
    ButterKnife.bind(this);
    presenter = new EditExperiencePresenter();
    presenter.attachView(this);
    init();
  }

  @OnClick(R.id.imageBack) void onImageBack() {
    onBackPressed();
  }

  @Override public void onBackPressed() {
    if (!mLinearProgress.isShown()) super.onBackPressed();
  }

  private void init() {
    tvTitle.setText(getString(R.string.edit_experience));
    tvTitle.setVisibility(View.VISIBLE);

    if (getIntent().hasExtra(Constants.KEY_LIST)) {
      editExperienceArrayList = getIntent().getParcelableArrayListExtra(Constants.KEY_LIST);
    }
    //necessary to add this dummy model at last to show all designations in last row of recyclerview
    editExperienceArrayList.add(getChipViewExpModel());

    editExperienceAdapter =
        new EditExperienceAdapter(EditExperienceActivity.this, editExperienceArrayList);
    editExperienceAdapter.setDesignationClickListener(this);
    recyclerViewExperience.setLayoutManager(new LinearLayoutManager(this));
    recyclerViewExperience.setAdapter(editExperienceAdapter);
  }

  /**
   * onAddDesignation click
   * if new designation is already in progress then user
   * can not add another designation
   */
  @Override public void onDesignationClick() {
    if (isEditMode || isNewAdded) {
      Utils.showMessage(this, getString(R.string.cant_edit));
      return;
    } else if (editExperienceArrayList.size() - 1 >= 5) {
      Utils.showMessage(this, getString(R.string.error_experience));
      return;
    }
    Intent intent = new Intent(this, DesignationSelectActivity.class);
    intent.putExtra(Constants.KEY_TYPE, 1);
    startActivityForResult(intent, Constants.REQUEST_CODE_EDIT_EXP);
  }

  /**
   * on designation edit
   *
   * @param position edit position
   * @param experience experience model
   */
  @Override public void singleDesignationEdit(int position, Experience experience) {

    if (isEditMode || isNewAdded) {
      Utils.showMessage(this, getString(R.string.cant_edit));
      return;
    }

    resetToDefaultType();
    try {
      currentEditExpRef = (Experience) experience.clone();
      currentEditExpRef.setType(ExperienceTypes.TYPE_EXP_EDIT_LISTING);
    } catch (CloneNotSupportedException e) {
      LOGE(TAG, e.getMessage(), e);
    }
    editExperienceArrayList.get(position).setType(ExperienceTypes.TYPE_EXP_EDIT_LISTING);
    editExperienceAdapter.setModifyingData(position, editExperienceArrayList.get(position));
    editExperienceAdapter.notifyItemChanged(position);
    isEditMode = true;
  }

  /**
   * on Keep
   *
   * @param position current editing position
   * @param experience experience model
   */
  @Override public void onKeepSettings(int position, Experience experience) {
    if (experience.getProgressInMonths() == 0) {
      Utils.showMessage(this, getString(R.string.experience_duration));
    } else {
      experience.setType(ExperienceTypes.TYPE_EXP_COMMON_LISTING);
      editExperienceArrayList.set(position, experience);
      editExperienceAdapter.notifyItemChanged(position);
      resetBooleans();
      this.tempExperience = experience;
      presenter.onAddExperience(experience);
    }
  }

  /**
   * on remove edited part
   *
   * @param position edit position
   */

  @Override public void onRemoveSettings(int position) {
    if (currentEditExpRef != null) {
      editExperienceArrayList.set(position, currentEditExpRef);
      editExperienceAdapter.notifyItemChanged(position);
    }
  }

  /**
   * on delete experience
   *
   * @param position delete position
   */
  @Override public void onDeleteExperience(int position) {
    tempExperience = editExperienceArrayList.get(position);
    if (tempExperience.geteId() != 0) {
      showDeleteAlert(tempExperience);
    } else {
      editExperienceArrayList.remove(position);
      editExperienceAdapter.notifyItemRemoved(position);
      editExperienceAdapter.notifyItemChanged(editExperienceArrayList.size() - 1);
      resetBooleans();
      tempExperience = null;
    }
  }

  private void showDeleteAlert(final Experience experience) {
    Utils.showDialog(this, getString(R.string.delete), getString(R.string.delete_message),
        getString(R.string.yes), getString(R.string.no), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            presenter.onDeleteExperience(Integer.toString(experience.geteId()));
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }

  /**
   * on edit experience title
   *
   * @param position edit position
   */
  @Override public void onEditExperienceTitle(int position) {
    Intent intent = new Intent(this, DesignationSelectActivity.class);
    intent.putExtra(Constants.KEY_TYPE, 1);
    intent.putExtra(Constants.KEY_EDIT_POSITION, position);
    startActivityForResult(intent, Constants.REQUEST_CODE_EDIT_EXP_TITLE);
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == RESULT_OK) {
      if (requestCode == Constants.REQUEST_CODE_EDIT_EXP) {
        String selectedId = data.getStringExtra(Constants.KEY_TEXT);
        Realm mRealm = Realm.getDefaultInstance();
        DesignationDbModel designationDbModel = mRealm.where(DesignationDbModel.class)
            .equalTo("d_id", Integer.parseInt(selectedId))
            .findFirst();
        if (designationDbModel != null) {
          int addPosition = editExperienceArrayList.size() - 1;
          editExperienceArrayList.add(addPosition, getNewModel(designationDbModel));
          isNewAdded = true;
          editExperienceAdapter.setModifyingData(addPosition,
              editExperienceArrayList.get(addPosition));
          editExperienceAdapter.notifyItemChanged(addPosition);
          recyclerViewExperience.scrollToPosition(addPosition);
        }
      } else if (requestCode == Constants.REQUEST_CODE_EDIT_EXP_TITLE) {
        int editPosition = data.getIntExtra(Constants.KEY_EDIT_POSITION, -1);
        if (editPosition > -1) {
          String selectedId = data.getStringExtra(Constants.KEY_TEXT);
          Realm mRealm = Realm.getDefaultInstance();
          DesignationDbModel designationDbModel = mRealm.where(DesignationDbModel.class)
              .equalTo("d_id", Integer.parseInt(selectedId))
              .findFirst();
          if (designationDbModel != null) {
            editExperienceArrayList.get(editPosition).setD_id(designationDbModel.getD_id());
            editExperienceArrayList.get(editPosition)
                .setD_title_1(designationDbModel.getD_title_1());
            editExperienceArrayList.get(editPosition)
                .setD_title_2(designationDbModel.getD_title_2());
            editExperienceArrayList.get(editPosition)
                .setD_title_3(designationDbModel.getD_title_3());
            editExperienceAdapter.notifyItemChanged(editPosition);
          }
        }
      }
    }
  }

  /**
   * create new model on Add
   *
   * @param designationDbModel set title
   * @return experience
   */
  private Experience getNewModel(DesignationDbModel designationDbModel) {
    Experience editExperience = new Experience();
    editExperience.setD_id(designationDbModel.getD_id());
    editExperience.setD_title_1(designationDbModel.getD_title_1());
    editExperience.setD_title_2(designationDbModel.getD_title_2());
    editExperience.setD_title_3(designationDbModel.getD_title_3());
    editExperience.setType(ExperienceTypes.TYPE_EXP_EDIT_LISTING);
    editExperience.setProgress_title("");
    editExperience.setProgressInMonths("0");
    editExperience.setProgress_subtitle("");
    return editExperience;
  }

  /**
   * set default type as list
   */
  private void resetToDefaultType() {
    for (int i = 0; i < editExperienceArrayList.size(); i++) {
      if (editExperienceArrayList.get(i).getType() != ExperienceTypes.TYPE_EXP_CHIP_VIEWS_LISTING) {
        editExperienceArrayList.get(i).setType(ExperienceTypes.TYPE_EXP_COMMON_LISTING);
      }
    }
  }

  /**
   * resetting flag
   */
  private void resetBooleans() {
    isNewAdded = false;
    isEditMode = false;
  }

  /**
   * adding last chipView model
   *
   * @return chipViewModel
   */
  private Experience getChipViewExpModel() {
    Experience editExperience = new Experience();
    editExperience.setType(ExperienceTypes.TYPE_EXP_CHIP_VIEWS_LISTING);
    return editExperience;
  }

  @Override protected void onDestroy() {
    presenter.detachView();
    super.onDestroy();
  }

  @OnClick(R.id.linearProgress) void onProgressClick() {
    //do nothing
  }

  @Override public void onDeleteSuccess(int profilePercentage) {
    if (tempExperience != null) {
      EventBus.getDefault().post(new ProfileUpdate(profilePercentage, tempExperience.geteId()));
      int index = editExperienceArrayList.indexOf(tempExperience);
      editExperienceArrayList.remove(index);
      editExperienceAdapter.notifyDataSetChanged();
    }
    Utils.showMessage(EditExperienceActivity.this, getString(R.string.experience_delete));
    resetBooleans();
    tempExperience = null;
  }

  @Override public void onDeleteError(Throwable e) {
    handleError(e, new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        dialog.dismiss();
        if (tempExperience != null) {
          presenter.onDeleteExperience(Integer.toString(tempExperience.geteId()));
        } else {
          Utils.showMessage(EditExperienceActivity.this, getString(R.string.please_try_again));
        }
      }
    });
  }

  @Override public void onAddSuccess(Experience experience) {
    if (tempExperience != null && tempExperience.geteId() != 0) {
      Utils.showMessage(EditExperienceActivity.this, getString(R.string.experience_update));
    } else {
      Utils.showMessage(EditExperienceActivity.this, getString(R.string.new_experience_add));
    }
    updateData(experience);
  }

  private void updateData(final Experience experience) {
    Experience model = IterableUtils.find(editExperienceArrayList, new Predicate<Experience>() {
      @Override public boolean evaluate(Experience object) {
        if (tempExperience.geteId() != 0) {
          return experience.geteId() == object.geteId();
        } else {
          return object.geteId() == 0;
        }
      }
    });
    if (model != null) {
      int index = editExperienceArrayList.indexOf(experience);
      editExperienceArrayList.remove(experience);
      editExperienceArrayList.add(index, experience);
      editExperienceAdapter.notifyItemChanged(index);
    }
    tempExperience = null;
    EventBus.getDefault().post(experience);
    resetBooleans();
  }

  private void handleError(Throwable e, DialogInterface.OnClickListener listener) {
    String error;
    if (e instanceof SocketTimeoutException) {
      error = getString(R.string.error_timeout);
    } else {
      error = getString(R.string.error_other);
    }
    AlertDialog dialog =
        Utils.showDialog(this, getString(R.string.alert), error, getString(R.string.retry),
            listener);
    dialog.show();
  }

  @Override public void onAddError(Throwable e) {
    String error;
    if (e instanceof SocketTimeoutException) {
      error = getString(R.string.error_timeout);
    } else {
      error = getString(R.string.error_other);
    }
    AlertDialog dialog =
        Utils.showDialog(this, getString(R.string.alert), error, getString(R.string.retry),
            new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                if (tempExperience != null) {
                  presenter.onAddExperience(tempExperience);
                } else {
                  Utils.showMessage(EditExperienceActivity.this,
                      getString(R.string.please_try_again));
                }
              }
            });
    dialog.show();
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    mLinearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    mLinearProgress.setVisibility(View.GONE);
  }
}
