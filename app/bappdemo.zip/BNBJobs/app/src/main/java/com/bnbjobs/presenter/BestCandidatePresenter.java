/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.app.Fragment;
import com.bnbjobs.R;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.CandidateContainer;
import com.bnbjobs.model.CandidateModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.BestCandidateView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class BestCandidatePresenter extends BasePresenter implements Presenter<BestCandidateView> {

  private static final String TAG = makeLogTag(BestCandidatePresenter.class);
  private BestCandidateView mBestCandidateView;
  private Fragment fragment;

  @Override public void attachView(BestCandidateView view) {
    mBestCandidateView = view;
  }

  @Override public void detachView() {
    mBestCandidateView = null;
  }

  /**
   * get best candidate for particular job
   */
  public void getBestCandidate() {
    mBestCandidateView.showProgress();
    HashMap<String, String> params = new HashMap<>(7);
    params.put("apiName", "getAllCandidates");
    params.put("offerId", mBestCandidateView.getOfferId());
    params.putAll(addDefaultParamsWitLat(params));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mBestCandidateView.hideProgress();
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        CandidateContainer candidateContainer = new Gson().fromJson(s, CandidateContainer.class);
        setUpData(candidateContainer.getCandidateModelList());
      }
    });
  }

  private void setUpData(List<CandidateModel> models) {
    Observable.just(models)
        .map(new Func1<List<CandidateModel>, List<CandidateModel>>() {
          @Override public List<CandidateModel> call(List<CandidateModel> candidateModels) {
            List<CandidateModel> mList = new ArrayList<>();
            for (CandidateModel model : candidateModels) {
              model.setAddress(getAddress(model.getuLat(), model.getuLng()));
              model.setDistance(getKm(Double.parseDouble(model.getDistance())));
              mList.add(model);
            }
            return mList;
          }
        })
        .subscribeOn(Schedulers.io())
        .compose(((BaseFragment) fragment).<List<CandidateModel>>bindUntilEvent(
            FragmentEvent.DESTROY_VIEW))
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<List<CandidateModel>>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            if (!isNotNull()) {
              return;
            }
            mBestCandidateView.hideProgress();
            LOGE(TAG, e.getMessage(), e);
          }

          @Override public void onNext(List<CandidateModel> candidateModels) {
            if (!isNotNull()) {
              return;
            }
            mBestCandidateView.hideProgress();
            mBestCandidateView.getBestCandidates(candidateModels);
          }
        });
  }

  private boolean isNotNull() {
    return mBestCandidateView != null;
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(final Throwable e) {
    String error = "";
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            getBestCandidate();
          }
        }).show();
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }

  @Override protected Context getBaseContext() {
    return mBestCandidateView.getContext();
  }
}
