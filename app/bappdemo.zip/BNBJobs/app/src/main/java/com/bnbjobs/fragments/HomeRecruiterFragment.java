/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import atownsend.swipeopenhelper.SwipeOpenItemTouchHelper;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnEditorAction;
import butterknife.OnTouch;
import butterknife.Unbinder;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.DesignationSelectActivity;
import com.bnbjobs.adapter.HomeFavAdapter;
import com.bnbjobs.adapter.HomeRecruiterAdapter;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.CandidateModel;
import com.bnbjobs.presenter.HomeRecruiterPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.EndlessRecyclerViewScrollListener;
import com.bnbjobs.utils.SpacesItemDecoration;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.HomeRecruiterView;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections4.IterableUtils;
import org.apache.commons.collections4.Predicate;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */
public class HomeRecruiterFragment extends BaseFragment implements HomeRecruiterView, ClickImpl<CandidateModel> {

  private static final String TAG = makeLogTag(HomeRecruiterFragment.class);
  private static final int REGULAR_TYPE = 1;
  private static final int PULL_TYPE = 2;
  private static final int SEARCH_TYPE = 3;
  @BindView(R.id.recyclerView) RecyclerView recyclerView;

  @BindView(R.id.swipeRefresh) SwipeRefreshLayout mSwipeRefresh;
  @BindView(R.id.linearFilter) LinearLayout linearFilter;
  @BindView(R.id.tvCurrentLocation) TextView tvCurrentLocation;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.etSearch) EditText etSearch;
  @BindView(R.id.tvNoRecord) TextView tvNoRecord;
  @BindView(R.id.progressBarFav) ProgressBar progressBarFav;
  @BindView(R.id.favRecyclerView) RecyclerView favRecyclerView;
  @BindView(R.id.tvTodayError) TextView tvTodayError;

  private HomeRecruiterAdapter adapter;
  private HomeFavAdapter homeFavAdapter;
  private HomeRecruiterPresenter presenter;
  private List<CandidateModel> mCandidateList = new ArrayList<>();
  private EndlessRecyclerViewScrollListener listener;
  private Unbinder unbinder;

  private boolean loadMore;
  private boolean isFooterAdd;
  private static final int FILTER_CODE = 7777;
  private String filterText;
  private ArrayList<CandidateModel> favArrayList = new ArrayList<>();
  private boolean isFavFooterAdd;
  private boolean favLoadMore;
  private SwipeOpenItemTouchHelper helper;
  @Nullable @Override public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_recuriter_home, container, false);
    unbinder = ButterKnife.bind(this, view);
    if (presenter == null) {
      presenter = new HomeRecruiterPresenter();
    }
    presenter.attachView(this);
    presenter.setFragment(this);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    tvCurrentLocation.setText(getPrefs(getActivity()).getString(QuickstartPreferences.PLACE_NAME, ""));
    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
    recyclerView.setLayoutManager(linearLayoutManager);
    presenter.onSearch(etSearch);
    if (adapter == null) {
      adapter = new HomeRecruiterAdapter(getActivity(), mCandidateList, this);
    }

    if (mCandidateList.isEmpty()) {
      showProgress();
      presenter.getCandidates(REGULAR_TYPE);
    }
    recyclerView.setAdapter(adapter);

    initFavList();

    mSwipeRefresh.setColorSchemeResources(R.color.colorPrimary, R.color.theme_blue, R.color.theme_pink, android.R.color.holo_orange_dark);
    mSwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
      @Override public void onRefresh() {
        onRefreshCall();
      }
    });

    recyclerView.setOnTouchListener(new View.OnTouchListener() {
      @Override public boolean onTouch(View v, MotionEvent event) {
        if (etSearch.hasFocus()) {
          clearFocus();
        }
        if (linearFilter.isShown()) {
          onFilter();
        }
        return false;
      }
    });
    if(helper == null){
      helper = new SwipeOpenItemTouchHelper(new SwipeOpenItemTouchHelper.SimpleCallback(SwipeOpenItemTouchHelper.START));
    }
    helper.attachToRecyclerView(recyclerView);

    etSearch.setOnFocusChangeListener(new View.OnFocusChangeListener() {
      @Override public void onFocusChange(View v, boolean hasFocus) {
        if (hasFocus && linearFilter.isShown()) {
          onFilter();
        }
      }
    });

    recyclerView.addOnScrollListener(new EndlessRecyclerViewScrollListener(linearLayoutManager) {
      @Override public void onLoadMore(int page, int totalItemsCount) {
        listener = this;
        if (loadMore) {
          if (isFooterAdd) {
            return;
          }
          adapter.notifyItemInserted(mCandidateList.size() - 1);
          isFooterAdd = true;
          mCandidateList.add(null);
          presenter.getCandidates(isEmpty(Utils.getText(etSearch)) ? REGULAR_TYPE : SEARCH_TYPE);
        }
      }
    });
  }

  private void initFavList() {
    LinearLayoutManager layout1 = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
    favRecyclerView.setLayoutManager(layout1);
    favRecyclerView.setHasFixedSize(true);
    if (homeFavAdapter == null) {
      homeFavAdapter = new HomeFavAdapter(getActivity(), favArrayList);
    }
    favRecyclerView.setAdapter(homeFavAdapter);
    int spacingInPixels = getResources().getDimensionPixelSize(R.dimen._5sdp);
    favRecyclerView.addItemDecoration(new SpacesItemDecoration(spacingInPixels));
    if (favArrayList.size() == 0) {
      presenter.getFavoriteList(false);
    }
    favRecyclerView.addOnScrollListener(new EndlessRecyclerViewScrollListener(layout1) {

      @Override public void onLoadMore(int page, int totalItemsCount) {
        if (favLoadMore) {
          favLoadMore = false;
          isFavFooterAdd = true;
          favArrayList.add(null);
          homeFavAdapter.notifyItemInserted(favArrayList.size() - 1);
          presenter.getFavoriteList(false);
        }
      }
    });
  }

  @Override public void onResume() {
    super.onResume();
    showToolbar(false);
  }

  @Override public void onPause() {
    super.onPause();
    if(helper!=null)
      helper.closeAllOpenPositions();
    if (linearFilter.isShown()) {
      onFilter();
    }
  }

  private void onRefreshCall() {
    if (listener != null) {
      listener.setLoading(false);
    }
    presenter.resetRequest(PULL_TYPE);
    presenter.getFavoriteList(true);
  }

  private void clearFocus() {
    etSearch.clearFocus();
    InputMethodManager imm = (InputMethodManager) getActivity().getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.hideSoftInputFromWindow(etSearch.getWindowToken(), 0);
  }

  @OnClick(R.id.imageFilter) void onFilter() {
    Intent intent = new Intent(getActivity(), DesignationSelectActivity.class);
    intent.putExtra(Constants.KEY_TEXT, filterText);
    startActivityForResult(intent, FILTER_CODE);
  }

  @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == Activity.RESULT_OK && requestCode == FILTER_CODE) {
      filterText = data.getStringExtra(Constants.KEY_TEXT);
      presenter.setFilterString(filterText);
      mSwipeRefresh.setRefreshing(true);
      onRefreshCall();
    }
  }

  @OnTouch(R.id.linearFilter) boolean relativeFilter() {
    return true;
  }

  @Override public Context getContext() {
    return getActivity();
  }

  @Override public void onDestroyView() {
    presenter.detachView();
    unbinder.unbind();
    super.onDestroyView();
  }

  @Override public void onStop() {
    super.onStop();
    if (isFooterAdd) {
      loadMore = true;
    }
    removeFooter();
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void setAdapter(List<CandidateModel> candidateModels, boolean clear) {
    removeFooter();
    if (clear || mCandidateList.isEmpty()) {
      this.mCandidateList.clear();
      mSwipeRefresh.setRefreshing(false);
    }
    this.mCandidateList.addAll(candidateModels);
    adapter.notifyDataSetChanged();
    if (adapter.getItemCount() > 0) {
      tvNoRecord.setVisibility(View.GONE);
    } else {
      tvNoRecord.setVisibility(View.VISIBLE);
    }
  }

  private void removeFooter() {
    if (isFooterAdd) {
      isFooterAdd = false;
      this.mCandidateList.remove(this.mCandidateList.size() - 1);
      adapter.notifyItemRemoved(this.mCandidateList.size());
    }
  }

  @OnEditorAction(R.id.etSearch) boolean onSearchPress(TextView v, int actionId, KeyEvent event) {
    if (actionId == EditorInfo.IME_ACTION_SEARCH) {
      clearFocus();
      return true;
    }
    return false;
  }

  @Override public void loadMore(boolean loadMore) {
    this.loadMore = loadMore;
  }

  @Override public void onError(String msg) {
    if (mSwipeRefresh.isRefreshing()) {
      mSwipeRefresh.setRefreshing(false);
    }
    showMessage(getActivity(),msg);
  }

  @Override public void clearData() {
    mCandidateList.clear();
  }

  @Override public void setFavAdapter(List<CandidateModel> candidateModelList, boolean clear) {
    if (isFavFooterAdd) {
      isFavFooterAdd = false;
      this.favArrayList.remove(this.favArrayList.size() - 1);
      homeFavAdapter.notifyItemRemoved(this.favArrayList.size());
    }
    if (clear) this.favArrayList.clear();
    favArrayList.addAll(candidateModelList);
    homeFavAdapter.notifyDataSetChanged();
    checkEmptyStatus();
  }

  @Override public void setLoadMore(boolean loadMore) {
    favLoadMore = loadMore;
  }

  @Override public String getOffset() {
    return Integer.toString(favArrayList.size());
  }

  @Override public void showSmallProgress(boolean show) {
    if (show) {
      progressBarFav.setVisibility(View.VISIBLE);
    } else {
      progressBarFav.setVisibility(View.GONE);
    }
  }

  @Override public void changeFavoriteStatus(final CandidateModel object) {
    final CandidateModel model = IterableUtils.find(favArrayList, new Predicate<CandidateModel>() {
      @Override public boolean evaluate(CandidateModel candidateModel) {
        return object.getuId().equalsIgnoreCase(candidateModel.getuId());
      }
    });
    if (model != null) {
      int pos = favArrayList.indexOf(model);
      favArrayList.remove(pos);
      homeFavAdapter.notifyItemRemoved(pos);
    } else {
      favArrayList.add(object);
      homeFavAdapter.notifyItemInserted(favArrayList.size());
    }
    checkEmptyStatus();
    int pos = mCandidateList.indexOf(object);
    helper.closeOpenPosition(pos);
    adapter.notifyItemChanged(pos);

  }

  /**
   * check favorite list
   */
  private void checkEmptyStatus(){
    if(tvTodayError==null)
      return;
    if (favArrayList.isEmpty()) {
      tvTodayError.setVisibility(View.VISIBLE);
    } else {
      tvTodayError.setVisibility(View.GONE);
    }
  }

  @Override public void onClick(View view, final CandidateModel object, int position) {
    if (view.getId() == R.id.relativeSwipe || view.getId() == R.id.ivProfileWhite) {
      ProfileFragment fragment = new ProfileFragment();
      Bundle bundle = new Bundle();
      bundle.putString(Constants.KEY_ID, object.getuId());
      bundle.putParcelable(Constants.KEY_MODEL,object);
      fragment.setArguments(bundle);
      fragment.setTargetFragment(this,1001);
      addFragment(fragment, true);
    } else if (view.getId() == R.id.ivStar) {
      if (hasNetworkConnectivity()) {
        presenter.favoriteCandidate(object);
      } else {
        showMessage(getActivity(), getString(R.string.check_internet));
      }
    }
  }
}
