/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.bnbjobs.utils.Utils;

/**
 * @author Harsh
 * @version 1.0
 */
public class DesignationModel {

  private String d_id;
  private String d_status;
  private String d_created_at;
  private String d_updated_at;
  private String d_title;

  private boolean isSelect = true;

  public boolean isSelect() {
    return isSelect;
  }

  public void setSelect(boolean select) {
    isSelect = select;
  }

  public String getD_id() {
    return d_id;
  }

  public void setD_id(String d_id) {
    this.d_id = d_id;
  }

  public String getD_status() {
    return d_status;
  }

  public void setD_status(String d_status) {
    this.d_status = d_status;
  }

  public String getD_created_at() {
    return d_created_at;
  }

  public void setD_created_at(String d_created_at) {
    this.d_created_at = d_created_at;
  }

  public String getD_updated_at() {
    return d_updated_at;
  }

  public void setD_updated_at(String d_updated_at) {
    this.d_updated_at = d_updated_at;
  }

  public String getD_title() {
    return Utils.capitalize(d_title);
  }

  public void setD_title(String d_title) {
    this.d_title = d_title;
  }
}


