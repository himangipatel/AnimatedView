/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.Toast;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.FormationModel;
import com.bnbjobs.model.ImageModel;
import com.bnbjobs.model.JobModel;
import com.bnbjobs.model.LanguageModel;
import com.bnbjobs.model.ProfileContainer;
import com.bnbjobs.model.SkillModel;
import com.bnbjobs.model.UserModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.EndlessRecyclerViewScrollListener;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.ProfileView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.io.File;
import java.lang.reflect.Type;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */
public class ProfilePresenter extends BasePresenter implements Presenter<ProfileView> {

  private static final int MEDIA_TYPE_VIDEO = 10;
  private static final String TAG = makeLogTag(ProfilePresenter.class);
  private static final int FILE_TYPE_GALLARY = 1;
  private static final int FILE_TYPE_VIDEO = 2;
  private ProfileView mProfileView;
  private Fragment fragment;
  private String videoUrl = "";
  private String candidateId = "";
  private REQUEST_TYPE currentType;
  private String filePath;
  private int descriptionLimit = 100;
  private String appendCharText;
  private boolean isProfileImage;
  private float scaleFactor = 0.95f;
  private final int LOAD_MORE_START_INDEX = 3;
  private int jobListCurrentPage = -1, jobListTotalPages = -1;
  private boolean jobListLoading;
  private EndlessRecyclerViewScrollListener mEndlessRecyclerViewScrollListener;

  @Override public void attachView(ProfileView view) {
    mProfileView = view;
  }

  @Override public void detachView() {
    mProfileView = null;
  }

  public TextWatcher descriptionWatcher = new TextWatcher() {
    @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override public void afterTextChanged(Editable s) {
      if (s.toString().length() <= descriptionLimit) {
        mProfileView.setLengthView(String.valueOf(s.toString().length()), appendCharText);
      }
    }
  };

  public void getProfile() {
    mProfileView.showProgress();
    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "getCandidateProfile");
    if (isCandidate()) {
      params.putAll(addParams(params));
    } else {
      params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
      params.put("accessToken",
          getPrefs(getBaseContext()).getString(QuickstartPreferences.ACCESS_TOKEN, ""));
      params.put("candidateId", candidateId);
      params.put("language", getLanguage());
    }
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {

      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mProfileView.hideProgress();
        currentType = REQUEST_TYPE.GET_PROFILE;
        retryMethod(e, "");
      }

      @Override public void onNext(String s) {
        if (!isNotNull()) {
          return;
        }
        mProfileView.hideProgress();
        ProfileContainer container = new Gson().fromJson(s, ProfileContainer.class);
        if (container.isSuccess()) {
          mProfileView.setFavorite(container.isFavoriteFlag());
          mProfileView.setExperienceAdapter(container.getData().getExperienceList());
          mProfileView.setFormationAdapter(container.getData().getFormationModelList());
          mProfileView.setSkillAdapter(container.getData().getSkillModelList());
          mProfileView.setPhotoAdapter(container.getData().getImageModelList());
          mProfileView.setUserData(container.getData().getUserModel(),
              container.getProfilePercentage());
          mProfileView.setUserDescription(container.getData().getUserProfileData());
          mProfileView.setVideoId(container.getData().getVideoId());
          mProfileView.setPlanPurchased(container.isPlanPurchaseFlg());
          mProfileView.setLanguageData(container.getData().getLanguageModelList());
          if (!isCandidate()) {
            mProfileView.setJobApply(container.getJobApplyModels());
          }
          findAddress(container.getData().getUserModel());
          if (!isEmpty(container.getData().getVideoUrl())) {
            loadVideoThumb(container.getData().getVideoUrl());
          }
          videoUrl = container.getData().getVideoUrl();
        } else {
          showDialog(getBaseContext(), getBaseContext().getString(R.string.alert),
              container.getMessage(), getBaseContext().getString(android.R.string.ok),
              new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                  dialog.dismiss();
                }
              }).show();
        }
      }
    });
  }

  public void setCandidateId(String candidateId) {
    this.candidateId = candidateId;
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(final Throwable e, final String params) {
    String error;
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            if (currentType != REQUEST_TYPE.ADD_SKILL) {
              retryRequest(params);
            }
          }
        }).show();
  }

  public void callVerificationCodeApi() {
    mProfileView.showProgress();
    HashMap<String, String> params = new HashMap<>();
    String pnE164 = Utils.getConvertedNumber(getBaseContext(),
        getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_PHONENUMBER, ""));
    params.put("apiName", "resendOTP");
    params.put("number", pnE164);
    params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mProfileView.hideProgress();
      }

      @Override public void onNext(String s) {
        mProfileView.hideProgress();
        try {
          JSONObject jsonObject = new JSONObject(s);
          boolean success = jsonObject.optBoolean("success");
          String message = jsonObject.optString("message", "");
          mProfileView.onCodeResend(success, message);
        } catch (JSONException e) {
          e.printStackTrace();
        }
      }
    });
  }

  private void retryRequest(String param) {
    if (currentType == REQUEST_TYPE.GET_PROFILE) {
      getProfile();
    } else if (currentType == REQUEST_TYPE.DELETE_EXP) {
      deleteExperience(param);
    } else if (currentType == REQUEST_TYPE.REMOVE_IMAGE) {
      removeImage(Integer.parseInt(param));
    } else if (currentType == REQUEST_TYPE.REMOVE_VIDEO) {
      removeVideo(Integer.parseInt(param));
    } else if (currentType == REQUEST_TYPE.UPLOAD_VIDEO) {
      uploadVideo(param);
    } else if (currentType == REQUEST_TYPE.UPLOAD_IMAGE) {
      uploadImage(param);
    } else if (currentType == REQUEST_TYPE.UPLOAD_IMAGE_PROFILE) {
      uploadProfileImage(param);
    } else {
      retryMethod(new Throwable(new SocketTimeoutException()), "");
    }
  }

  private void loadVideoThumb(String videoUrl) {
    if (isNotNull()) {
      mProfileView.setVideoThumb(videoUrl);
    }
  }

  private boolean isNotNull() {
    return mProfileView != null;
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  private void findAddress(UserModel model) {
    Observable.just(model)
        .map(new Func1<UserModel, String>() {
          @Override public String call(UserModel userModel) {
            return getAddress(userModel.getLat(), userModel.getLng());
          }
        })
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .compose(getBindEvent())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            mProfileView.setAddress("");
          }

          @Override public void onNext(String s) {
            if (isNotNull()) {
              mProfileView.setAddress(s);
            }
          }
        });
  }

  public void deleteExperience(final String id) {
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "deleteCandidateExperience");
    params.put("experienceId", id);
    params.putAll(addParams(params));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        currentType = REQUEST_TYPE.DELETE_EXP;
        retryMethod(e, id);
      }

      @Override public void onNext(String s) {
      }
    });
  }

  @Override protected Context getBaseContext() {
    return mProfileView.getContext();
  }

  public void setFragment(Fragment fragment) {
    appendCharText = " /" + descriptionLimit;
    this.fragment = fragment;
  }
  // image chooser

  public void playVideo() {
    if (isEmpty(videoUrl)) {
      return;
    }
    Intent intent = new Intent(Intent.ACTION_VIEW);
    intent.setDataAndType(Uri.parse(videoUrl), "video/*");
    getBaseContext().startActivity(Intent.createChooser(intent, "Complete action using"));
  }

  public void addSkill(final String text, String rate, final int type, final boolean isUpdate,
      Object object) {
    HashMap<String, String> params = new HashMap<>();
    if (type == 1111) {
      if (isUpdate) {
        SkillModel model = (SkillModel) object;
        params.put("apiName", "editCandidateSkill");
        params.put("skillId", model.getId());
      } else {
        params.put("apiName", "addCandidateSkill");
      }
    } else if (type == 1112) {
      if (isUpdate) {
        FormationModel formationModel = (FormationModel) object;
        params.put("apiName", "editCandidateFormations");
        params.put("formationId", formationModel.getId());
      } else {
        params.put("apiName", "addCandidateFormations");
      }
    } else if (type == 1113) {
      if (isUpdate) {
        LanguageModel model = (LanguageModel) object;
        params.put("languageId", Integer.toString(model.getlId()));
        params.put("apiName", "editCandidateLanguages");
      } else {
        params.put("apiName", "addCandidateLanguages");
      }
    }
    params.put("title", text);
    params.put("rate", rate);
    params.putAll(addParams(params));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        currentType = REQUEST_TYPE.ADD_SKILL;
        retryMethod(e, "");
      }

      @Override public void onNext(String s) {
        try {
          JSONObject jsonObject = new JSONObject(s);
          if (isResponseSuccess(s)) {
            JSONObject object = jsonObject.getJSONObject("data");
            if (type == 1111) {
              SkillModel skillModel = new Gson().fromJson(object.toString(), SkillModel.class);
              skillModel.setProfileStatus(jsonObject.optInt("profilePercentage"));
              if (isUpdate) {
                mProfileView.editData(skillModel);
              } else {
                mProfileView.addData(skillModel);
              }
            } else if (type == 1112) {
              FormationModel formationModel =
                  new Gson().fromJson(object.toString(), FormationModel.class);
              formationModel.setProfileStatus(jsonObject.optInt("profilePercentage"));
              if (isUpdate) {
                mProfileView.editData(formationModel);
              } else {
                mProfileView.addData(formationModel);
              }
            } else if (type == 1113) {
              LanguageModel mLanguage = new Gson().fromJson(object.toString(), LanguageModel.class);
              mLanguage.setProfileStatus(jsonObject.optInt("profilePercentage"));
              if (isUpdate) {
                mProfileView.editData(mLanguage);
              } else {
                mProfileView.addData(mLanguage);
              }
            }
          }
        } catch (JSONException e) {
          e.printStackTrace();
        }
      }
    });
  }

  public void removeImage(final int imageId) {
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "deleteCandidateImage");
    params.put("imageId", String.valueOf(imageId));
    params.putAll(addParams(params));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        currentType = REQUEST_TYPE.REMOVE_IMAGE;
        retryMethod(e, String.valueOf(imageId));
      }

      @Override public void onNext(String s) {
        if (isResponseSuccess(s)) {
          try {
            JSONObject object1 = new JSONObject(s);
            mProfileView.updateProfileProgress(object1.optInt("profilePercentage"));
          } catch (JSONException e) {
            e.printStackTrace();
          }
        }
      }
    });
  }

  /**
   * showChangePhotoDialog
   * Show the dialog for photo selection options
   */
  public void showChangePhotoDialog() {
    imagePicker(new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        if (which == 0) {
          mProfileView.openCamera();
        } else if (which == 1) {
          mProfileView.openGallery();
        } else {
          mProfileView.setDefault();
        }
      }
    }, mProfileView.isImageSet()).show();
  }

  public void openVideoCamera() {
    requestVideoFromCamera();
  }

  public void openVideoGallery() {
    requestVideoFromGallery();
  }

  protected void requestVideoFromCamera() {
    // create new Intentwith with Standard Intent action that can be
    // sent to have the camera application capture an video and return it.
    Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
    Uri fileUri = getOutputMediaFileUri(MEDIA_TYPE_VIDEO);
    // set the image file name
    intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
    // set the video image quality to high
    intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
    if (this.fragment != null) {
      fragment.startActivityForResult(intent, REQUEST_CODE_VIDEO_CAMERA);
    } else {
      ((BaseActivity) getBaseContext()).startActivityForResult(intent, REQUEST_CODE_VIDEO_CAMERA);
    }
  }

  /**
   * Create a file Uri for saving an image or video
   */
  private Uri getOutputMediaFileUri(int type) {
    return Uri.fromFile(getOutputMediaFile(type));
  }

  private File getOutputMediaFile(int type) {
    // Check that the SDCard is mounted
    File mediaStorageDir =
        new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            "MyCameraVideo");
    // Create the storage directory(MyCameraVideo) if it does not exist
    if (!mediaStorageDir.exists()) {
      if (!mediaStorageDir.mkdirs()) {
        LOGE("Capture ", "Failed to create directory MyCameraVideo.");
        Toast.makeText(getBaseContext(), "Failed to create directory MyCameraVideo.",
            Toast.LENGTH_LONG).show();
        Log.d("MyCameraVideo", "Failed to create directory MyCameraVideo.");
        return null;
      }
    }
    // Create a media file name
    // For unique file name appending current timeStamp with file name
    Date date = new Date();
    String timeStamp =
        new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(date.getTime());
    File mediaFile;
    if (type == MEDIA_TYPE_VIDEO) {
      // For unique video file name appending current timeStamp with file name
      mediaFile = new File(mediaStorageDir.getPath() + File.separator +
          "VID_" + timeStamp + ".mp4");
      filePath = mediaFile.getAbsolutePath();
    } else {
      return null;
    }
    return mediaFile;
  }

  public void ShowVideoCaptureDialog() {
    videoPicker(new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        if (which == 0) {
          mProfileView.opeVideoCamera();
        } else if (which == 1) {
          mProfileView.openVideoGallery();
        }
      }
    }).show();
  }

  public void openCamera() {
    requestImageFromCamera();
  }

  public void openGallery() {
    requestImageFromGallery();
  }

  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    String path = null;
    if (resultCode == Activity.RESULT_OK) {
      Uri uri;
      if (requestCode == REQUEST_CODE_CAMERA) {
        path = mCameraOutputPath;
        if (Utils.isFileSizeValid(getBaseContext(), path, FILE_TYPE_GALLARY)) {
          setPath(path);
        }
      } else if (requestCode == REQUEST_CODE_GALLERY) {
        uri = data.getData();
        path = getRealPathFromURI(uri);
        if (Utils.isFileSizeValid(getBaseContext(), path, FILE_TYPE_GALLARY)) {
          setPath(path);
        }
      } else if (requestCode == REQUEST_CODE_VIDEO || requestCode == REQUEST_CODE_VIDEO_CAMERA) {
        if (requestCode == REQUEST_CODE_VIDEO_CAMERA) {
          if (filePath != null) {
            path = filePath;
          }
        } else if (data != null) {
          uri = data.getData();
          path = getRealPathFromURIVideo(uri);
        }
        if (path != null) {
          LOGI(TAG, "Video Path: " + path);
          if (Utils.isFileSizeValid(getBaseContext(), path, FILE_TYPE_VIDEO)) {
            uploadVideo(path);
          }
        }
      }
    }
  }

  public void getProfileImage(boolean isProfileImage) {
    this.isProfileImage = isProfileImage;
  }

  private void setPath(String path) {
    if (!TextUtils.isEmpty(path)) {
      if (isProfileImage) {
        uploadProfileImage(path);
      } else {
        uploadImage(path);
      }
    } else {
      showMessage(getBaseContext(), getString(R.string.file_not_found));
    }
  }


  private void uploadProfileImage(final String path){
    mProfileView.showProgress();
    HashMap<String, RequestBody> params = new HashMap<>();
    params.put("apiName", toRequestBody("update_user_image"));
    params.put("image\"; filename=\"pp.png\"", RequestBody.create(MediaType.parse("image/*"), new File(path)));
    params.putAll(addParamsBody(params));
    RestClient.getInstance()
        .apiCallImage(params)
        .compose(getBindEvent())
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            mProfileView.hideProgress();
            currentType = REQUEST_TYPE.UPLOAD_IMAGE_PROFILE;
            retryMethod(e, path);
          }

          @Override public void onNext(String s) {
            mProfileView.hideProgress();
            LOGI(TAG,"Response: "+s);
            try {
              JSONObject object = new JSONObject(s);
              if (isResponseSuccess(s)) {
                  JSONObject jsonObject = object.getJSONObject("data");
                JSONObject dataObject = jsonObject.getJSONObject("userData");
                mProfileView.setProfileImage(dataObject.getString("u_image_url"));
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  private void uploadImage(final String path) {
    mProfileView.showProgress();
    HashMap<String, RequestBody> params = new HashMap<>();
    params.put("apiName", toRequestBody("addCandidateImage"));
    params.put("image\"; filename=\"pp.png\"",
        RequestBody.create(MediaType.parse("image/*"), new File(path)));
    params.putAll(addParamsBody(params));
    RestClient.getInstance()
        .apiCallImage(params)
        .compose(getBindEvent())
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            mProfileView.hideProgress();
            currentType = REQUEST_TYPE.UPLOAD_IMAGE;
            retryMethod(e, path);
          }

          @Override public void onNext(String s) {
            mProfileView.hideProgress();
            try {
              JSONObject object = new JSONObject(s);
              if (isResponseSuccess(s)) {
                JSONObject jsonObject = object.getJSONObject("data");
                ImageModel imageModel =
                    new Gson().fromJson(jsonObject.toString(), ImageModel.class);
                mProfileView.addImage(imageModel);
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  protected void requestImageFromCamera() {
    try {
      File outputDir =
          new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
              "temp");
      if (!outputDir.exists()) {
        if (!outputDir.mkdir()) {
          LOGI(TAG, "Error creating image file for camera output.");
          return;
        }
      }
      File outputFile =
          File.createTempFile(String.valueOf(System.currentTimeMillis()), ".jpg", outputDir);
      mCameraOutputPath = outputFile.getAbsolutePath();
      Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
      intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(outputFile));
      fragment.startActivityForResult(intent, REQUEST_CODE_CAMERA);
    } catch (Exception e) {
      LOGI(TAG, "Error requesting photo from camera. " + e.getMessage());
    }
  }

  /**
   * requestImageFromGallery
   * Open photo gallery to choose a photo
   */
  protected void requestImageFromGallery() {
    Intent intent = new Intent(Intent.ACTION_PICK,
        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
    intent.setType("image/*");
    fragment.startActivityForResult(
        Intent.createChooser(intent, getBaseContext().getString(R.string.change_photo_gallery)),
        REQUEST_CODE_GALLERY);
  }

  /**
   * requestImageFromGallery
   * Open photo gallery to choose a photo
   */
  public void requestVideoFromGallery() {
    Intent intent = new Intent(Intent.ACTION_PICK,
        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
    intent.setType("video/*");
    fragment.startActivityForResult(
        Intent.createChooser(intent, getBaseContext().getString(R.string.change_photo_gallery)),
        REQUEST_CODE_VIDEO);
  }

  public void removeVideo(final int videoId) {
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "deleteCandidateVideo");
    params.put("videoId", String.valueOf(videoId));
    params.putAll(addParams(params));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        currentType = REQUEST_TYPE.REMOVE_VIDEO;
        retryMethod(e, String.valueOf(videoId));
      }

      @Override public void onNext(String s) {
        try {
          JSONObject object = new JSONObject(s);
          if (isResponseSuccess(s)) {
            mProfileView.onRemoveVideo();
            mProfileView.updateProfileProgress(object.optInt("profilePercentage"));
          }
        } catch (JSONException e) {
          e.printStackTrace();
        }
      }
    });
  }

  private void uploadVideo(final String path) {
    mProfileView.showProgress();
    HashMap<String, RequestBody> params = new HashMap<>();
    params.put("apiName", toRequestBody("addCandidateVideo"));
    params.put("video\"; filename=\"pp.mp4\"",
        RequestBody.create(MediaType.parse("video/*"), new File(path)));
    params.putAll(addParamsBody(params));
    RestClient.getInstance()
        .apiCallImage(params)
        .compose(getBindEvent())
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            mProfileView.hideProgress();
            currentType = REQUEST_TYPE.UPLOAD_VIDEO;
            retryMethod(e, path);
          }

          @Override public void onNext(String s) {
            mProfileView.hideProgress();
            try {
              JSONObject object = new JSONObject(s);
              if (isResponseSuccess(s)) {
                JSONObject jsonObject = object.getJSONObject("data");
                mProfileView.setVideoId(jsonObject.optInt("upv_id"));
                mProfileView.updateProfileProgress(object.optInt("profilePercentage"));
                loadVideoThumb(jsonObject.optString("upv_video_url"));
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  public void onViewStateRestored(Bundle savedInstanceState) {
    if (savedInstanceState != null) {
      if (savedInstanceState.containsKey("photopath")) {
        mCameraOutputPath = savedInstanceState.getString("photopath");
      }
    }
  }

  public void onSaveInstanceState(Bundle outState) {
    outState.putString("photopath", mCameraOutputPath);
  }

  public void applyJob(final HashMap<String, String> data) {
    mProfileView.showProgress();
    final HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "jobApplyAction");
    params.putAll(data);
    params.putAll(addDefaultParamsWitLat(params));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        mProfileView.hideProgress();
        LOGE(TAG, e.getMessage(), e);
        String error;
        if (e instanceof SocketTimeoutException) {
          error = getBaseContext().getString(R.string.error_timeout);
        } else {
          error = getBaseContext().getString(R.string.error_other);
        }
        showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
            getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                applyJob(data);
              }
            }).show();
      }

      @Override public void onNext(String s) {
        mProfileView.hideProgress();
        if (isResponseSuccess(s)) {
          mProfileView.applyStatus(params.get("action"));
        }
      }
    });
  }


  public void setRecyclerViewLayoutManagers(final RecyclerView cityRecyclerView) {
    cityRecyclerView.setLayoutManager(
        new LinearLayoutManager(getBaseContext(), LinearLayoutManager.HORIZONTAL,
            false));
    mEndlessRecyclerViewScrollListener = new EndlessRecyclerViewScrollListener(
        (LinearLayoutManager) cityRecyclerView.getLayoutManager()) {

      @Override public void onLoadMore(int page, int totalItemsCount) {
        ProfilePresenter.this.onLoadMore(cityRecyclerView);
      }
    }.setVisibleThreshold(LOAD_MORE_START_INDEX);
    cityRecyclerView.addOnScrollListener(mEndlessRecyclerViewScrollListener);
  }
  public void getFavoriteJobOffer(int page){
    HashMap<String,String> params = new HashMap<>();
    params.put("apiName","get_favorite_job_offers");
    params.put("page",Integer.toString(page));
    params.put("perPage","10");
    addParams(params);
    RestClient
        .getInstance(params)
        .compose(getBindEvent())
        .subscribe(getFavJobOffer());

  }

  private Subscriber<String> getFavJobOffer() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        jobListLoading = false;

      }

      @Override public void onNext(String s) {
        jobListLoading = false;
        LOGI(TAG,"Response: "+s);
        GsonBuilder builder = new GsonBuilder();
        Type collectionType = new TypeToken<BaseContainer<JobModel>>() {
        }.getType();
        BaseContainer<JobModel> jobSearchBaseContainer =
            builder.create().fromJson(s, collectionType);
        mProfileView.setFavoriteList(jobSearchBaseContainer);
      }
    };
  }
  private void onLoadMore(RecyclerView mRecyclerViewPager) {
    switch (mRecyclerViewPager.getId()) {
      case R.id.jobRecyclerView:
        if (jobListCurrentPage < jobListTotalPages && !jobListLoading) {
          getFavoriteJobOffer(jobListCurrentPage+1);
        }
        break;
    }
  }

  public void removeItem(final int type, final Object object) {
    HashMap<String, String> params = new HashMap<>();
    if (type == 1111) {
      SkillModel model = (SkillModel) object;
      params.put("apiName", "deleteCandidateSkill");
      params.put("skillId", model.getId());
    } else if (type == 1112) {
      FormationModel formationModel = (FormationModel) object;
      params.put("apiName", "deleteCandidateFormations");
      params.put("formationId", formationModel.getId());
    } else if (type == 1113) {
      LanguageModel model = (LanguageModel) object;
      params.put("apiName", "deleteCandidateLanguages");
      params.put("languageId", Integer.toString(model.getlId()));
    }
    params.putAll(addParams(params));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
      }

      @Override public void onNext(String s) {
        mProfileView.removeObject(type);
        if (isResponseSuccess(s)) {
          try {
            JSONObject object1 = new JSONObject(s);
            mProfileView.updateProfileProgress(object1.optInt("profilePercentage"));
          } catch (JSONException e) {
            e.printStackTrace();
          }
        }
      }
    });
  }

  public void favoriteCandidate(final boolean favoriteFlag) {
    mProfileView.showProgress();
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "favoriteCandidate");
    params.putAll(addParams(params));
    params.put("candidateId", candidateId);
    RestClient.getInstance(params).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        mProfileView.hideProgress();
        LOGE(TAG, e.getMessage(), e);
        String error;
        if (e instanceof SocketTimeoutException) {
          error = getBaseContext().getString(R.string.error_timeout);
        } else {
          error = getBaseContext().getString(R.string.error_other);
        }
        showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
            getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                favoriteCandidate(favoriteFlag);
              }
            }).show();
      }

      @Override public void onNext(String s) {
        mProfileView.hideProgress();
        if (isResponseSuccess(s)) {
          mProfileView.updateFavorite(!favoriteFlag);
        }
        //EventBus.getDefault().post(new UpdateFavorite(favoriteFlag));
      }
    });
  }

  public void updateDescription(final String text) {
    HashMap<String,String> params = new HashMap<>();
    params.put("apiName","editCandidateDescription");
    params.put("description",text);
    addParams(params);
    mProfileView.showProgress();
    RestClient.getInstance(params).compose(getBindEvent())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            mProfileView.hideProgress();
            String error;
            if (e instanceof SocketTimeoutException) {
              error = getBaseContext().getString(R.string.error_timeout);
            } else {
              error = getBaseContext().getString(R.string.error_other);
            }
            showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
                getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
                  @Override public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    updateDescription(text);
                  }
                }).show();
          }

          @Override public void onNext(String s) {
            mProfileView.hideProgress();
          }
        });

  }

  private enum REQUEST_TYPE {
    GET_PROFILE, DELETE_EXP, REMOVE_IMAGE, UPLOAD_IMAGE, UPLOAD_VIDEO, REMOVE_VIDEO, UPLOAD_IMAGE_PROFILE, ADD_SKILL
  }
}

