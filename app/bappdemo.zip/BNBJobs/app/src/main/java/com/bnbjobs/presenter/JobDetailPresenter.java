/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import com.bnbjobs.R;
import com.bnbjobs.customui.looppager.RecyclerViewPager;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.JobDetail;
import com.bnbjobs.model.JobDetailContainer;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.JobDetailView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class JobDetailPresenter extends BasePresenter implements Presenter<JobDetailView> {
  private static final String TAG = makeLogTag(JobDetailPresenter.class);
  private RecyclerViewPager mRecyclerViewPager;
  private JobDetailView mJobDetailView;
  private Fragment fragment;
  // alpha factor for job vacancies
  private float scaleFactor = 0.94f;
  private float alphaFactor = 0.6f;
  private int favoriteOffer;

  @Override public void attachView(JobDetailView view) {
    mJobDetailView = view;
    mRecyclerViewPager = mJobDetailView.getRecyclerPager();
  }

  @Override public void detachView() {
    mJobDetailView = null;
  }

  public void getJobDetail() {
    mJobDetailView.showProgress();
    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "getJobDetails");
    params.putAll(addParams(params));
    params.put("offerId", mJobDetailView.getJobId());

    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mJobDetailView.hideProgress();
        retryMethod(e, false);
      }

      @Override public void onNext(String s) {
        mJobDetailView.hideProgress();
        JobDetailContainer container = new Gson().fromJson(s, JobDetailContainer.class);
        if (container.isSuccess()) {
          mJobDetailView.setJobDetail(container.getJobDetail());
          setAddress(container.getJobDetail());
        }else{
          mJobDetailView.showError(getBaseContext().getString(R.string.no_job));
        }
      }
    });
  }

  private void setAddress(JobDetail models) {
    Observable.just(models)
        .map(new Func1<JobDetail, String>() {
          @Override public String call(JobDetail jobDetail) {
            return getAddress(jobDetail.getuLat(), jobDetail.getuLng());
          }
        })
        .subscribeOn(Schedulers.io())
        .compose(getBindEvent())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
          }

          @Override public void onNext(String s) {
            if (mJobDetailView != null) mJobDetailView.setAddress(s);
          }
        });
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(final Throwable e, final boolean isApplied) {
    String error;
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            if (isApplied) {
              applyJob();
            } else {
              getJobDetail();
            }
          }
        }).show();
  }

  /**
   * set recyclerview settings
   */
  public void setRecyclerViewSettings() {
    mRecyclerViewPager.addOnScrollListener(new RecyclerView.OnScrollListener() {
      @Override public void onScrollStateChanged(RecyclerView recyclerView, int scrollState) {

      }

      @Override public void onScrolled(RecyclerView recyclerView, int i, int i2) {
        int childCount = mRecyclerViewPager.getChildCount();
        int width = mRecyclerViewPager.getChildAt(0).getWidth();
        //int padding = getResources().getDisplayMetrics().densityDpi;
        int padding = (mRecyclerViewPager.getWidth() - width) / 2;

        for (int j = 0; j < childCount; j++) {
          View v = recyclerView.getChildAt(j);
          float rate = 0;
          if (v.getLeft() <= padding) {
            if (v.getLeft() >= padding - v.getWidth()) {
              rate = (padding - v.getLeft()) * 1f / v.getWidth();
            } else {
              rate = 1;
            }
            v.setAlpha(1 - rate * (1 - alphaFactor));
            v.setScaleX(1 - rate * (1 - scaleFactor));
          } else {
            if (v.getLeft() <= recyclerView.getWidth() - padding) {
              rate = (recyclerView.getWidth() - padding - v.getLeft()) * 1f / v.getWidth();
            }
            v.setAlpha(alphaFactor + rate * (1 - alphaFactor));
            v.setScaleX(scaleFactor + rate * (1 - scaleFactor));
          }
        }
      }
    });

    // add on layout change listener
    mRecyclerViewPager.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
      @Override
      public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft,
          int oldTop, int oldRight, int oldBottom) {
        if (mRecyclerViewPager.getChildCount() < 3) {
          if (mRecyclerViewPager.getChildAt(1) != null) {
            if (mRecyclerViewPager.getCurrentPosition() == 0) {
              View v1 = mRecyclerViewPager.getChildAt(1);
              v1.setAlpha(alphaFactor);
              v1.setScaleX(scaleFactor);
            } else {
              View v1 = mRecyclerViewPager.getChildAt(0);
              v1.setAlpha(alphaFactor);
              v1.setScaleX(scaleFactor);
            }
          }
        } else {
          if (mRecyclerViewPager.getChildAt(0) != null) {
            View v0 = mRecyclerViewPager.getChildAt(0);
            v0.setAlpha(alphaFactor);
            v0.setScaleX(scaleFactor);
          }
          if (mRecyclerViewPager.getChildAt(2) != null) {
            View v2 = mRecyclerViewPager.getChildAt(2);
            v2.setAlpha(alphaFactor);
            v2.setScaleX(scaleFactor);
          }
        }
      }
    });
  }

  @Override protected Context getBaseContext() {
    return mJobDetailView.getContext();
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }

  /**
   * apply job
   */
  public void applyJob() {
    if (mJobDetailView.getProfilePercentage() < 50) {
      mJobDetailView.showProfileCompleteDialog();
      return;
    }

    mJobDetailView.showProgress();
    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "applyForJob");
    params.put("offerId", mJobDetailView.getJobId());
    params.putAll(addParams(params));

    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mJobDetailView.hideProgress();
        retryMethod(e, true);
      }

      @Override public void onNext(String s) {
        mJobDetailView.hideProgress();
        try {
          JSONObject object = new JSONObject(s);
          if (isResponseSuccess(s)) {
            mJobDetailView.showAppliedDialog();
          } else {
            mJobDetailView.showError(object.optString("message"));
          }
        } catch (JSONException e) {
          e.printStackTrace();
        }
      }
    });
  }

  public void report() {
    mJobDetailView.showProgress();
    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "reportJobOffer");
    params.put("offerId", mJobDetailView.getJobId());
    params.putAll(addParams(params));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mJobDetailView.hideProgress();
      }

      @Override public void onNext(String s) {
        mJobDetailView.hideProgress();
        try {
          JSONObject object = new JSONObject(s);
          showDialog(getBaseContext(), getString(R.string.alert), object.getString("message"),
              getString(R.string.ok), new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                  dialog.dismiss();
                }
              }).show();
        } catch (JSONException e) {
          e.printStackTrace();
        }
      }
    });
  }

  public void callFavoriteOffer(final int favoriteOffer) {
    mJobDetailView.showProgress();
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "favorite_job_offer");
    params.put("offer_id", String.valueOf(favoriteOffer));
    params.putAll(addParams(params));

    RestClient.getInstance(params)
        .compose(getBindEvent())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            mJobDetailView.hideProgress();
            LOGE(TAG, Log.getStackTraceString(e));
            String error;
            if (e instanceof SocketTimeoutException) {
              error = getBaseContext().getString(R.string.error_timeout);
            } else {
              error = getBaseContext().getString(R.string.error_other);
            }
            showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
                getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
                  @Override public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                  callFavoriteOffer(favoriteOffer);
                  }
                }).show();
          }

          @Override public void onNext(String s) {
            mJobDetailView.hideProgress();
            LOGI(TAG,s);
            mJobDetailView.changeFavorite();
          }
        });
  }
}

