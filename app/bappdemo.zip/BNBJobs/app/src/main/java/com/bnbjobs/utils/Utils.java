/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.utils;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Point;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGD;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class Utils {

  private static final String TAG = makeLogTag(Utils.class);
  private static final int FILE_TYPE_GALLARY = 1;
  private static final int FILE_TYPE_VIDEO = 2;
  private static final String DINERS_PATTERN = "^3(?:0[0-5]|[68])(.*)"; //14
  private static final String MASTERCARD_PATTERN = "^5[1-5](.*)"; //16-19
  private static final String VISA_PATTERN = "^4(.*)";//13-16
  private static final String MAESTRO_PATTERN = "^((?:5(?:0|[6789])|6[0-9]))(.*)";//12-19
  private static SimpleDateFormat timeFormat = new SimpleDateFormat("MM,yyyy", Locale.ENGLISH);

  public static AlertDialog showDialog(Context ctx, String title, String msg, String btn1,
      String btn2, OnClickListener listener1, OnClickListener listener2) {
    AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
    builder.setTitle(title);
    builder.setMessage(msg).setCancelable(true).setPositiveButton(btn1, listener1);
    if (btn2 != null) {
      builder.setNegativeButton(btn2, listener2);
    }
    return builder.create();
  }

  public static AlertDialog showDialog(Context ctx, String title, String msg, String buttonName,
      OnClickListener listener) {
    return showDialog(ctx, title, msg, buttonName, null, listener, null);
  }

  /**
   * Checks if the device has network connectivity
   *
   * @return true if network is connected
   */
  public static boolean hasNetworkConnectivity(Context context) {
    ConnectivityManager connectivityManager = (ConnectivityManager) context.getApplicationContext()
        .getSystemService(Context.CONNECTIVITY_SERVICE);
    NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
    return networkInfo != null && networkInfo.isConnectedOrConnecting();
  }

  public static int getToolbarHeight(Context context) {
    final TypedArray styledAttributes =
        context.getTheme().obtainStyledAttributes(new int[] { R.attr.actionBarSize });
    int toolbarHeight = (int) styledAttributes.getDimension(0, 0);
    styledAttributes.recycle();
    return toolbarHeight;
  }

  public static boolean isFileSizeValid(Context context, String filePath, int fileType) {
    boolean isSizeValid = false;
    File file = new File(filePath);
    if (file.exists()) {
      // Get length of file in bytes
      long fileSizeInBytes = file.length();
      // Convert the bytes to Kilobytes (1 KB = 1024 Bytes)
      long fileSizeInKB = fileSizeInBytes / 1024;
      // Convert the KB to MegaBytes (1 MB = 1024 KBytes)
      long fileSizeInMB = fileSizeInKB / 1024;
      if (fileType == FILE_TYPE_GALLARY) {
        if (fileSizeInMB <= 2) {
          isSizeValid = true;
        } else {
          Utils.showMessage(context, context.getString(R.string.large_image));
        }
      } else if (fileType == FILE_TYPE_VIDEO) {
        if (fileSizeInMB <= 6) {
          isSizeValid = true;
        } else {
          Utils.showMessage(context, context.getString(R.string.large_video));
        }
      }
    }
    return isSizeValid;
  }

  public static String capitalize(final String str) {
    int strLen;
    if (str == null || (strLen = str.length()) == 0) {
      return str;
    }
    final char firstChar = str.charAt(0);
    final char newChar = Character.toTitleCase(firstChar);
    if (firstChar == newChar) {
      // already capitalized
      return str;
    }
    char[] newChars = new char[strLen];
    newChars[0] = newChar;
    str.getChars(1, strLen, newChars, 1);
    return String.valueOf(newChars);
  }

  public static int getScreenWidth(Context c) {
    WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
    Display display = wm.getDefaultDisplay();
    Point size = new Point();
    display.getSize(size);
    return size.x;
  }

  public static long getTimeStamp(String strDate) throws ParseException {
    DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault());
    Date date = formatter.parse(strDate);
    return date.getTime()/1000;
  }

  public static String getDate(long millis) {
    Timestamp timestamp = new Timestamp(millis * 1000);
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
    return dateFormat.format(timestamp);
  }

  public static String getTime(long millis) {
    Timestamp timestamp = new Timestamp(millis * 1000);
    SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm", Locale.ENGLISH);
    return dateFormat.format(timestamp);
  }

  public static String getDateSlash(long millis) {
    Timestamp timestamp = new Timestamp(millis * 1000);
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM", Locale.ENGLISH);
    return dateFormat.format(timestamp);
  }

  /**
   * Uses static final constants to detect if the device's platform version is Honeycomb or
   * later.
   */
  public static boolean hasHoneycomb() {
    return true;
  }

  public static boolean hasMarshmallow() {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;
  }

  public static AlertDialog showNetworkDialog(Context ctx, OnClickListener listener) {
    return showDialog(ctx, ctx.getString(R.string.alert), ctx.getString(R.string.check_internet),
        ctx.getString(android.R.string.ok), null, listener, null);
  }

  public static int dpToPx(int dp) {
    return (int) (dp * Resources.getSystem().getDisplayMetrics().density);
  }

  public static void showMessage(Context context, String message) {
    Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
  }

  public static boolean isValidEmail(String email) {
    return !isEmpty(email) && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
  }

  public static void hideKeyboard(Activity ctx) {
    if (ctx.getCurrentFocus() != null) {
      InputMethodManager imm =
          (InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
      imm.hideSoftInputFromWindow(ctx.getCurrentFocus().getWindowToken(), 0);
    }
  }

  public static void hideKeyboard(EditText editText, Context context) {
    InputMethodManager imm =
        (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
  }

  public static String decimalFormat(double value) {
    return new DecimalFormat("#.##").format(value);
  }

  public static String getEuro() {
    return "€";
  }

  public static void makeCall(final Context act, String number) {
    String num = number.replace(" ", "").replace("-", "");
    String digits = "0123456789";
    String phNum = "";
    for (int i = 0; i < num.length(); i++) {
      if (digits.contains(num.charAt(i) + "")) {
        phNum += num.charAt(i);
      }
    }
    Log.d("phone", number + "=" + phNum);
    Intent call = new Intent(Intent.ACTION_DIAL);
    call.setData(Uri.parse("tel:" + phNum));
    act.startActivity(call);
  }

  public static boolean isVisaCard(String text) {
    Pattern pattern = Pattern.compile(VISA_PATTERN);
    Matcher matcher = pattern.matcher(text);
    return matcher.matches();
  }

  public static boolean isMasterCard(String text) {
    Pattern pattern = Pattern.compile(MASTERCARD_PATTERN);
    Matcher matcher = pattern.matcher(text);
    return matcher.matches();
  }

  public static boolean isDinersCard(String text) {
    Pattern pattern = Pattern.compile(DINERS_PATTERN);
    Matcher matcher = pattern.matcher(text);
    return matcher.matches();
  }

  public static boolean isMaestroCard(String text) {
    Pattern pattern = Pattern.compile(MAESTRO_PATTERN);
    Matcher matcher = pattern.matcher(text);
    return matcher.find();
  }

  public static String getContractValue(int id) {
    if (id == 1) {
      return "CDI";
    } else if (id == 2) {
      return "CDD";
    } else {
      return "Interim";
    }
  }

  public static String getNumber(String text) {
    double d1 = Double.parseDouble(text);
    NumberFormat formatter = NumberFormat.getInstance(Locale.getDefault());
    formatter.setMaximumFractionDigits(2);
    formatter.setMinimumFractionDigits(2);
    LOGI("NUMBER", formatter.format(d1));
    return formatter.format(d1);
  }

  public static void openUrl(Context context, String url) {
    Intent intent = new Intent(Intent.ACTION_VIEW);
    intent.setDataAndType(Uri.parse(url), "video/*");
    context.startActivity(Intent.createChooser(intent, "Complete action using"));
  }

  public static boolean isResponseSuccess(String s) {
    try {
      boolean result = new JSONObject(s).optString("success").equalsIgnoreCase("true");
      return new JSONObject(s).optString("success").equalsIgnoreCase("true");
    } catch (JSONException e) {
      e.printStackTrace();
    }
    return false;
  }

  private static void showError(Context context, String msg) {
    showDialog(context, context.getString(R.string.alert), msg,
        context.getString(android.R.string.ok), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }

  public static String getDeviceId(Context context) {
    String android_id =
        Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    LOGD(TAG, "here device id is " + android_id);
    return android_id;
  }

  public static String getText(TextView editText) {
    return editText.getText().toString().trim();
  }

  public static String SHA1(String text)
      throws NoSuchAlgorithmException, UnsupportedEncodingException {
    MessageDigest md = MessageDigest.getInstance("SHA-1");
    md.update(text.getBytes("iso-8859-1"), 0, text.length());
    byte[] sha1hash = md.digest();
    return convertToHex(sha1hash);
  }

  private static String convertToHex(byte[] data) {
    StringBuilder buf = new StringBuilder();
    for (byte b : data) {
      int halfbyte = (b >>> 4) & 0x0F;
      int two_halfs = 0;
      do {
        buf.append((0 <= halfbyte) && (halfbyte <= 9) ? (char) ('0' + halfbyte)
            : (char) ('a' + (halfbyte - 10)));
        halfbyte = b & 0x0F;
      } while (two_halfs++ < 1);
    }
    return buf.toString();
  }

  public static String getUtcDate(String stardate) {
    //        timeFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
    String utcTime = "";
    try {
      Date date = timeFormat.parse(stardate);
      utcTime = String.valueOf(date.getTime());
    } catch (Exception e) {
      Log.w("Error conver date ", e);
    }
    return utcTime;
  }

  public static String getDisplayDate(String date) {
    Calendar calendar = Calendar.getInstance();
    calendar.setTimeInMillis(Long.parseLong(date));
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
    return dateFormat.format(calendar.getTime());
  }

  public static boolean isStartGreaterEnd(String startDate, String endDate, Context context) {
    boolean isgreater = false;
    Calendar startCalendar = Calendar.getInstance();
    startCalendar.setTimeInMillis(Long.parseLong(startDate));
    Calendar endCalendar = Calendar.getInstance();
    endCalendar.setTimeInMillis(Long.parseLong(endDate));
    if (startCalendar.getTimeInMillis() > endCalendar.getTimeInMillis()) {
      isgreater = true;
      Utils.showMessage(context, context.getString(R.string.start_date_small));
    }
    return isgreater;
  }

  public static boolean getValidityOfDate(String date, int type, Context context) {
    boolean isValid = false;
    long selDate = Long.parseLong(date);
    Calendar calendar = Calendar.getInstance();
    calendar.setTimeInMillis(selDate);
    calendar.set(Calendar.HOUR_OF_DAY, 0);
    calendar.set(Calendar.MINUTE, 0);
    calendar.set(Calendar.SECOND, 0);
    calendar.set(Calendar.MILLISECOND, 0);
    Calendar toDayCalender = Calendar.getInstance();
    toDayCalender.set(Calendar.HOUR_OF_DAY, 0);
    toDayCalender.set(Calendar.MINUTE, 0);
    toDayCalender.set(Calendar.SECOND, 0);
    toDayCalender.set(Calendar.MILLISECOND, 0);
    if (calendar.getTimeInMillis() >= toDayCalender.getTimeInMillis()) {
      isValid = true;
    } else {
      if (type == 1) {
        showMessage(context, context.getString(R.string.startdate_val));
      } else {
        showMessage(context, context.getString(R.string.enddate_val));
      }
    }
    return isValid;
  }

  public static String getConvertedNumber(Context context, String currentPhoneNumber) {
    String lat = getPrefs(context).getString(QuickstartPreferences.LAT, "");
    String lon = getPrefs(context).getString(QuickstartPreferences.LNG, "");
    String countryCode = "";
    if (!TextUtils.isEmpty(lat) && !TextUtils.isEmpty(lon)) {
      double latitude = Double.parseDouble(lat);
      double longitude = Double.parseDouble(lon);
      countryCode = getCurrentCountry(context, latitude, longitude);
    } else {
      countryCode = getCountryCodeFromOthrDetails(context);
    }
    String pnE164 = getFormattedPhoneNumber(currentPhoneNumber, countryCode);
    return pnE164;
  }

  private static String getCurrentCountry(Context context, double latitude, double longitude) {
    String countryCode = "";
    if (TextUtils.isEmpty(countryCode)) {
      List<Address> addresses;
      try {
        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        addresses = geocoder.getFromLocation(latitude, longitude, 1);
        if (addresses != null && addresses.isEmpty()) {
          countryCode = addresses.get(0).getCountryCode();
        }
      } catch (Exception e) {
        Log.e("your app name here", "Log your error here");
      }
    }
    if (TextUtils.isEmpty(countryCode)) {
      countryCode = getCountryCodeFromOthrDetails(context);
    }
    return countryCode.toUpperCase();
  }

  private static String getCountryCodeFromOthrDetails(Context context) {
    String countryCode = "";
    try {
      TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
      String simCountry = tm.getSimCountryIso();
      if (tm.getPhoneType()
          != TelephonyManager.PHONE_TYPE_CDMA) { // device is not 3G (would be unreliable)
        String networkCountry = tm.getNetworkCountryIso();
        if (networkCountry != null
            && networkCountry.length() == 2) { // network country code is available
          countryCode = networkCountry;
        }
      } else if (simCountry != null && simCountry.length() == 2) { // SIM country code is available
        countryCode = simCountry;
      }
    } catch (Exception e) {
      LOGE(TAG, e.getMessage(), e);
    }
    if (TextUtils.isEmpty(countryCode)) {
      countryCode = context.getResources().getConfiguration().locale.getCountry();
    }
    return countryCode;
  }

  private static String getFormattedPhoneNumber(String unFormattedNumber, String countryCode) {
    PhoneNumberUtil pnu = PhoneNumberUtil.getInstance();
    Phonenumber.PhoneNumber pn;
    String convertedNumber = "";
    try {
      pn = pnu.parse(unFormattedNumber, countryCode);
      String formatted = pnu.format(pn, PhoneNumberUtil.PhoneNumberFormat.E164);
      String countryCodeNumber = formatted.replace(unFormattedNumber, "").trim();
      convertedNumber = countryCodeNumber + "-" + unFormattedNumber;
    } catch (NumberParseException e) {
      LOGE(TAG, e.getMessage(), e);
    }
    if (TextUtils.isEmpty(convertedNumber)) {
      return unFormattedNumber;
    } else {
      return convertedNumber;
    }
  }

  public static String loadJSONFromAsset(Context context) {
    String json = null;
    try {
      InputStream is = context.getAssets().open("countrylist.json");
      int size = is.available();
      byte[] buffer = new byte[size];
      is.read(buffer);
      is.close();
      json = new String(buffer, "UTF-8");
    } catch (IOException ex) {
      ex.printStackTrace();
      return null;
    }
    return json;
  }
}
