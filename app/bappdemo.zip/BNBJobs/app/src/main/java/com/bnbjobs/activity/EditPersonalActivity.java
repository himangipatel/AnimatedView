/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.SwitchCompat;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnCheckedChanged;
import butterknife.OnClick;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.CircleImageView;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.DesignationDbModel;
import com.bnbjobs.model.PhoneNumberEvent;
import com.bnbjobs.model.ProfileData;
import com.bnbjobs.presenter.EditProfilePresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.EditProfileView;
import com.bumptech.glide.Glide;
import java.io.File;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnNeverAskAgain;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
@RuntimePermissions public class EditPersonalActivity extends BaseActivity
    implements EditProfileView {

  private static final String TAG = makeLogTag(EditPersonalActivity.class);
  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.imageCenterLogo) ImageView imageCenterLogo;
  @BindView(R.id.rightImage) TinTableImageView rightImage;
  @BindView(R.id.toolbar) Toolbar toolbar;
  @BindView(R.id.ivCircle) CircleImageView ivCircle;
  @BindView(R.id.etEmailAddress) EditText etEmailAddress;
  @BindView(R.id.etPassword) EditText etPassword;
  @BindView(R.id.switchRemember) SwitchCompat switchRemember;
  @BindView(R.id.etFirstName) EditText etFirstName;
  @BindView(R.id.etLastName) EditText etLastName;
  @BindView(R.id.etPhoneNumber) EditText etPhoneNumber;
  @BindView(R.id.tvDesignationTitle) TextView tvDesignationTitle;
  @BindView(R.id.tvFormation) TextView tvFormation;
  @BindView(R.id.tvSkill) TextView tvSkill;
  @BindView(R.id.tvPersonalExperience) TextView tvPersonalExperience;
  @BindView(R.id.tvLocation) TextView tvLocation;
  @BindView(R.id.switchFb) SwitchCompat switchFb;
  @BindView(R.id.switchTw) SwitchCompat switchTw;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.scrollProfile) ScrollView scrollProfile;
  @BindView(R.id.tvUploadProfile) TextView tvUploadProfile;
  @BindView(R.id.linearFb) LinearLayout linearFb;
  @BindView(R.id.linearTwLink) LinearLayout linearTwLink;
  @BindView(R.id.etFbLink) EditText etFbLink;
  @BindView(R.id.etTwLink) EditText etTwLink;
  @BindView(R.id.linearLogout) LinearLayout linearLogout;
  private EditProfilePresenter presenter;
  private boolean isImageSet;
  private String path = null;
  private static final int FILTER_CODE = 7777;
  private static final int SINGLE_SELECT = 1;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_edit_personal_profile);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    presenter = new EditProfilePresenter();
    presenter.attachView(this);
    setupUI(scrollProfile);
    disableEnableControls(false, scrollProfile);
    linearLogout.setEnabled(true);
    findViewById(R.id.linearDescription).setEnabled(true);
    tvTitle.setText(R.string.profile);
    tvTitle.setVisibility(View.VISIBLE);
    rightImage.setVisibility(View.VISIBLE);
    rightImage.setImageResource(R.drawable.edit_gray);
    presenter.getCandidateProfile();
  }

  @OnClick({
      R.id.imageBack, R.id.ivCircle, R.id.rightImage, R.id.linearProgress, R.id.linearDescription
  }) void onClick(View view) {
    if (view.getId() == R.id.rightImage) {
      if (etLastName.isEnabled()) {
        Utils.hideKeyboard(etLastName, this);
        presenter.updatePersonalProfile();
      }
      if (!etLastName.isEnabled()) {
        disableEnableControls(true, scrollProfile);
        rightImage.setImageResource(R.drawable.top_check);
      }
    } else if (view.getId() == R.id.ivCircle) {
      presenter.showChangePhotoDialog();
    } else if (view.getId() == R.id.linearProgress) {
      // do nothing..
    } else if (view.getId() == R.id.linearDescription) {
      Intent intent = new Intent(this, DescriptionActivity.class);
      intent.putExtra(Constants.KEY_TEXT, getIntent().getStringExtra(Constants.KEY_TEXT));
      startActivity(intent);
    } else {
      onBackPressed();
    }
  }

  @OnClick(R.id.etPhoneNumber) void onPhone() {
    Intent intent = new Intent(this, PhoneNumberActivity.class);
    intent.putExtra(Constants.KEY_SHOW_BACK, true);
    startActivity(intent);
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void setPersonalData(ProfileData mData) {
    etEmailAddress.setText(mData.getUserModel().getU_email());
    etFirstName.setText(mData.getUserModel().getfName());
    etLastName.setText(mData.getUserModel().getlName());
    String phoneNumber = mData.getUserModel().getU_phone();
    etPhoneNumber.setText(phoneNumber);
    isImageSet = false;
    if (!isEmpty(mData.getUserModel().getImageThumb())) {
      tvUploadProfile.setVisibility(View.GONE);
    }
    Glide.with(EditPersonalActivity.this)
        .load(mData.getUserModel().getImageThumb())
        .placeholder(R.drawable.upload_pic_placeholder)
        .dontAnimate()
        .into(ivCircle);
    tvFormation.setText(String.valueOf(mData.getTotalFormations()));
    tvPersonalExperience.setText(String.valueOf(mData.getTotalExperiences()));
    tvDesignationTitle.setText(mData.getUserProfileData().getTitle());
    tvLocation.setText(getPrefs(this).getString(QuickstartPreferences.PLACE_NAME, ""));
  }

  @OnCheckedChanged({ R.id.switchFb }) void onCheckChange(CompoundButton buttonView) {
    if (switchFb.isChecked()) {
      linearFb.setVisibility(View.VISIBLE);
    } else {
      linearFb.setVisibility(View.GONE);
    }
  }

  @OnClick(R.id.tvDesignationTitle) void onChangeTitle() {
    Intent intent = new Intent(this, DesignationSelectActivity.class);
    intent.putExtra(Constants.KEY_TYPE, SINGLE_SELECT);
    startActivityForResult(intent, FILTER_CODE);
  }

  @OnCheckedChanged({ R.id.switchTw }) void onCheckChangeTwitter(CompoundButton buttonView) {
    if (switchTw.isChecked()) {
      linearTwLink.setVisibility(View.VISIBLE);
    } else {
      linearTwLink.setVisibility(View.GONE);
    }
  }

  @OnClick(R.id.linearLogout) void onLogout() {
    getPrefs(this).save(QuickstartPreferences.IS_LOGIN, false);
    getPrefs(this).save(QuickstartPreferences.KEY_SEARCH_ADDRESS, "");
    Intent intent = new Intent(this, LandingScreen.class);
    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
    startActivity(intent);
    finish();
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == RESULT_OK && requestCode == FILTER_CODE) {
      String did = data.getStringExtra(Constants.KEY_TEXT);
      presenter.updateDesignation(did);
      DesignationDbModel model = DesignationDbModel.getDesignation(did);
      tvDesignationTitle.setText(model.getTitle());
    } else {
      if (resultCode == RESULT_OK && requestCode == Constants.REQUEST_CODE_PERSONAL_INFO) {
        presenter.updatePersonalProfile();
      } else {
        presenter.onActivityResult(requestCode, resultCode, data);
      }
    }
  }

  @Override protected void onDestroy() {
    presenter.detachView();
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Override public File getProfile() {
    return path != null ? new File(path) : null;
  }

  @Override public void openCamera() {
    EditPersonalActivityPermissionsDispatcher.showCameraWithCheck(this, true);
  }

  @Override public void openGallery() {
    EditPersonalActivityPermissionsDispatcher.showCameraWithCheck(this, false);
  }

  @Override public void showPhoto(String path) {
    this.path = path;
    isImageSet = true;
    tvUploadProfile.setVisibility(View.GONE);
    Glide.with(this).load(new File(path)).into(ivCircle);
  }

  @Override public void setDefault() {
    path = null;
    isImageSet = false;
    tvUploadProfile.setVisibility(View.VISIBLE);
    ivCircle.setImageResource(R.drawable.upload_pic_placeholder);
  }

  @Override public boolean isImageSet() {
    return isImageSet;
  }

  @Override public String getEmail() {
    return Utils.getText(etEmailAddress);
  }

  @Override public String getPassword() {
    return Utils.getText(etPassword);
  }

  @Override public boolean isRemember() {
    return switchRemember.isChecked();
  }

  @Override public String getFirstName() {
    return Utils.getText(etFirstName);
  }

  @Override public String getLastName() {
    return Utils.getText(etLastName);
  }

  @Override public String getPhoneNumber() {
    return Utils.getText(etPhoneNumber);
  }

  @Override public String getFbLink() {
    return Utils.getText(etFbLink);
  }

  @Override public String getTwLink() {
    return Utils.getText(etTwLink);
  }

  @Override public boolean isFbLinkShow() {
    return switchFb.isChecked();
  }

  @Override public boolean isTwLinkShow() {
    return switchTw.isChecked();
  }

  @Override public void onUpdated(ProfileData mData) {
    EventBus.getDefault().post(mData);
    finish();
  }

  @Subscribe public void onEvent(PhoneNumberEvent event) {
    if (event.isCloseCurrentActivity()) {
      presenter.getCandidateProfile();
    }
  }

  @Override public void onCodeResend(boolean result, String message) {
    Utils.showMessage(getContext(), message);
    if (result) {
      Intent intent = new Intent(EditPersonalActivity.this, VerifyPhoneActivity.class);
      intent.putExtra("isCallbackReturn", true);
      intent.putExtra(Constants.KEY_NUMBER, Utils.getText(etPhoneNumber));
      startActivityForResult(intent, Constants.REQUEST_CODE_PERSONAL_INFO);
    }
  }

  @NeedsPermission({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showCamera(boolean isCamera) {
    if (isCamera) {
      presenter.openCamera();
    } else {
      presenter.openGallery();
    }
  }

  @OnShowRationale({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showRationaleForCamera(final PermissionRequest request) {
    Utils.showDialog(this, getString(R.string.alert),
        getString(R.string.permission_camera_rationale), getString(R.string.button_allow),
        getString(R.string.button_deny), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.proceed();
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.cancel();
          }
        }).show();
  }

  @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
      @NonNull int[] grantResults) {
    EditPersonalActivityPermissionsDispatcher.onRequestPermissionsResult(this, requestCode,
        grantResults);
  }

  @OnPermissionDenied({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showDeniedForCamera() {
    showPermissionDialog();
  }

  @OnNeverAskAgain({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showNeverAskForCamera() {
    showPermissionDialog();
  }

  private void showPermissionDialog() {
    Utils.showDialog(this, getString(R.string.alert),
        getString(R.string.permission_camera_never_askagain), getString(android.R.string.ok),
        new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }
}
