/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.GradientView;
import com.bnbjobs.presenter.ForgotPasswordPresenter;
import com.bnbjobs.view.ForgotPasswordView;

/**
 * @author Harsh
 * @version 1.0
 */
public class ForgotActivity extends BaseActivity implements ForgotPasswordView {

  @BindView(R.id.etEmailAddress) EditText etEmailAddress;
  @BindView(R.id.tvForgotPassword) GradientView tvForgotPassword;
  @BindView(R.id.relativeProgress) RelativeLayout relativeProgress;
  @BindView(R.id.tvTitle) TextView tvTitle;

  private ForgotPasswordPresenter presenter;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_forgot_password);
    ButterKnife.bind(this);
    tvTitle.setVisibility(View.VISIBLE);
    tvTitle.setText(getString(R.string.restore_the_password));
    presenter = new ForgotPasswordPresenter();
    presenter.attachView(this);
  }

  @OnClick(R.id.tvForgotPassword) void onForgot() {
    presenter.onSubmit(etEmailAddress);
  }

  @OnClick(R.id.imageBack) void onBack() {
    onBackPressed();
  }

  @Override public void onDone() {
    finish();
  }

  @Override protected void onDestroy() {
    presenter.detachView();
    super.onDestroy();
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    relativeProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    relativeProgress.setVisibility(View.GONE);
  }
}
