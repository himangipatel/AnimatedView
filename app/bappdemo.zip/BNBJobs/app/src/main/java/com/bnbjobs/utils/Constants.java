/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.utils;

/**
 * @author imobdev
 * @version 1.0
 */
public class Constants {

  public static final int SUCCESS_RESULT = 0;

  public static final int FAILURE_RESULT = 1;

  public static final String PACKAGE_NAME = "com.bnbjobs";

  public static final String RECEIVER = PACKAGE_NAME + ".RECEIVER";

  public static final String RESULT_DATA_KEY = PACKAGE_NAME + ".RESULT_DATA_KEY";

  public static final String LOCATION_DATA_EXTRA = PACKAGE_NAME + ".LOCATION_DATA_EXTRA";
  public static final String COUNTRY_CODE = "country_code";
  public static final String CANDIDATE = "1";
  public static final String RECRUITER = "2";
  public static final String KEY_USER_TYPE = "key_user_type";
  public static final String REG_NORMAL = "1";
  public static final String REG_FB = "2";

  public static final int INVITE_IMAGE_TICK = 1;
  public static final int INVITE_IMAGE_CROSS = 2;

  public static final int PROFILE_VISIBLE_TYPE1 = 3;
  public static final int PROFILE_VISIBLE_TYPE2 = 4;
  public static final String KEY_OBJECT = "key_object";
  public static final String KEY_POSITION = "key_position";
  public static final String KEY_LIST = "key_list";
  public static final String KEY_ID = "key_id";

  public static final String KEY_VISIBLE_TYPE = "key_visible_type";
  public static final String KEY_DIALOG_TYPE = "key_dialog_type";
  public static final int INVITE_FRIENDS = 1;
  public static final int JOB_APPLIED_TYPE = 2;
  public static final int CANDIDATE_ACCEPT = 3;
  public static final int CANDIDATE_REJECT = 4;
  public static final String KEY_TYPE = "key_type";
  public static final String KEY_TEXT = "key_text";
  public static final String KEY_PLAN_TYPE = "key_plan_type";
  public static final String KEY_EDIT_POSITION = "key_edit_position";
  public static final int REQUEST_CODE_PERSONAL_INFO = 5;

  public static final String INVITE_FRIENDS_FROM = "inviteFriendsFrom";
  public static final int PER_PAGE = 5;
  public static final int INVITE_FRIENDS_FROM_FB = 1;
  public static final int INVITE_FRIENDS_FROM_CONTACT = 2;
  public static final String KEY_NUMBER = "key_number";
  public static final int PHONE_VERIFIED = 6;
  public static final String KEY_SHOW_BACK = "key_show_back";

  public static final int REQUEST_CODE_EDIT_EXP = 6;
  public static final int REQUEST_CODE_EDIT_EXP_TITLE = 7;
  public static final String KEY_SHOW = "key_show";
  public static final String KEY_COUNT = "key_count";
  public static final String KEY_EDIT = "key_edit";
  public static final String KEY_GROUP_ID = "key_group_id";
  public static final String KEY_MODEL = "key_model";
  public static final String FOR_ALL_CONTRACT = "1,2,3,4";
}
