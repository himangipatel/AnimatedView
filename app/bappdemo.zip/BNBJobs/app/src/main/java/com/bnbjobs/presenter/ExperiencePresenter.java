/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.model.Experience;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.ExperienceView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.ActivityEvent;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.joda.time.DateTime;
import org.joda.time.Months;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class ExperiencePresenter extends BasePresenter implements Presenter<ExperienceView> {

  private final static String TAG = makeLogTag(ExperiencePresenter.class);
  private ExperienceView mExperienceView;

  @Override public void attachView(ExperienceView view) {
    mExperienceView = view;
  }

  @Override public void detachView() {
    mExperienceView = null;
  }

  public void callService() {
    if (!checkValidation()) return;
    mExperienceView.showProgress();
    HashMap<String, RequestBody> params = new HashMap<>(15);
    if (mExperienceView.isEdit()) {
      params.put("apiName", toRequestBody("editCandidateExperience"));
      params.put("experienceId", toRequestBody(mExperienceView.getId()));
    } else {
      params.put("apiName", toRequestBody("addCandidateExperience"));
    }

    params.put("title", toRequestBody(mExperienceView.getDTitle()));
    params.put("company", toRequestBody(mExperienceView.getCompanyName()));
    params.put("userId",
        toRequestBody(getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, "")));
    params.put("accessToken", toRequestBody(
        getPrefs(getBaseContext()).getString(QuickstartPreferences.ACCESS_TOKEN, "")));
    params.put("language", toRequestBody(getLanguage()));
    params.put("start_month", toRequestBody(String.valueOf(mExperienceView.getSMonth())));
    params.put("start_year", toRequestBody(String.valueOf(mExperienceView.getSYear())));
    if (mExperienceView.getEMonth() != -1) {
      params.put("end_month", toRequestBody(String.valueOf(mExperienceView.getEMonth())));
      params.put("end_year", toRequestBody(String.valueOf(mExperienceView.getEYear())));
    }

    if (mExperienceView.getProfile() != null) {
      params.put("image\"; filename=\"pp.png\"",
          RequestBody.create(MediaType.parse("image/*"), mExperienceView.getProfile()));
    }

    RestClient.getInstance()
        .apiCallImage(params)
        .compose(((BaseActivity) getBaseContext()).<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(mExperienceView.isEdit() ? getEditSubscriber() : getAddSubscriber());
  }

  private Subscriber<String> getEditSubscriber() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        mExperienceView.hideProgress();
        LOGE(TAG, e.getMessage(), e);
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        mExperienceView.hideProgress();
        JSONObject object = null;
        try {
          object = new JSONObject(s);

          if (isResponseSuccess(s)) {
            Experience experience =
                new Gson().fromJson(object.getJSONObject("data").toString(), Experience.class);

            mExperienceView.onDone(experience);
          } else {
            showDialog(getBaseContext(), getBaseContext().getString(R.string.alert),
                object.getString("message"), getBaseContext().getString(android.R.string.ok),
                new DialogInterface.OnClickListener() {
                  @Override public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                  }
                }).show();
          }
        } catch (JSONException e) {
          e.printStackTrace();
        }
      }
    };
  }

  private Subscriber<String> getAddSubscriber() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mExperienceView.hideProgress();
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        mExperienceView.hideProgress();
        JSONObject object = null;
        try {
          object = new JSONObject(s);

          if (isResponseSuccess(s)) {
            Experience experience =
                new Gson().fromJson(object.getJSONObject("data").toString(), Experience.class);

            mExperienceView.onDone(experience);
          } else {
            showDialog(getBaseContext(), getBaseContext().getString(R.string.alert),
                object.getString("message"), getBaseContext().getString(android.R.string.ok),
                new DialogInterface.OnClickListener() {
                  @Override public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                  }
                }).show();
          }
        } catch (JSONException e) {
          e.printStackTrace();
        }
      }
    };
  }

  private boolean checkValidation() {
    if (TextUtils.isEmpty(mExperienceView.getCompanyName())) {
      Utils.showMessage(getBaseContext(), "Please enter company name.");
      return false;
    } else if (TextUtils.isEmpty(mExperienceView.getDTitle())) {
      Utils.showMessage(getBaseContext(), "Please enter designation title.");
      return false;
    } else if (TextUtils.isEmpty(mExperienceView.getStartYear())) {
      Utils.showMessage(getBaseContext(), "Please enter start date.");
      return false;
    }
    return true;
  }

  public void dateValidate(boolean start) {
    DateTimeFormatter formatter = DateTimeFormat.forPattern("MM, yyyy");
    DateTime dateTime = formatter.parseDateTime(mExperienceView.getStartYear());
    DateTime endDateTime = isEmpty(mExperienceView.getEndYear()) ? new DateTime()
        : formatter.parseDateTime(mExperienceView.getEndYear());
    int month = Months.monthsBetween(dateTime, new DateTime()).getMonths();
    int eMonth = Months.monthsBetween(endDateTime, new DateTime()).getMonths();

    if (!start) {
      if (eMonth < 1) {
        Utils.showDialog(getBaseContext(), getString(R.string.alert),
            getString(R.string.error_date), getString(R.string.ok),
            new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                mExperienceView.setEndDate("");
                dialog.dismiss();
              }
            }).show();
        return;
      }
    }

    if (month > 0) {
      int monthDiff = Months.monthsBetween(dateTime, endDateTime).getMonths();
      if (monthDiff > 0) {
        LOGI(TAG, "Good");
      } else {
        Utils.showDialog(getBaseContext(), getString(R.string.alert),
            getString(R.string.error_date), getString(R.string.ok),
            new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                mExperienceView.setEndDate("");
                dialog.dismiss();
              }
            }).show();
      }
    } else {
      Utils.showDialog(getBaseContext(), getString(R.string.alert), getString(R.string.error_start),
          getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
              mExperienceView.setStartDate("");
              dialog.dismiss();
            }
          }).show();
    }
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(final Throwable e) {
    String error = "";
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            callService();
          }
        }).show();
  }

  @Override protected Context getBaseContext() {
    return mExperienceView.getContext();
  }

  /**
   * showChangePhotoDialog
   * Show the dialog for photo selection options
   */
  public void showChangePhotoDialog() {

    imagePicker(new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        if (which == 0) {
          mExperienceView.openCamera();
        } else if (which == 1) {
          mExperienceView.openGallery();
        } else {
          mExperienceView.setDefault();
        }
      }
    }, mExperienceView.isImageSet()).show();
  }

  public void openCamera() {
    requestImageFromCamera();
  }

  public void openGallery() {
    requestImageFromGallery();
  }

  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (resultCode == Activity.RESULT_OK) {
      Uri uri = null;
      String path = "";
      if (requestCode == REQUEST_CODE_CAMERA) {
        path = mCameraOutputPath;
      } else if (requestCode == REQUEST_CODE_GALLERY) {
        uri = data.getData();
        path = getRealPathFromURI(uri);
      }
      if (!TextUtils.isEmpty(path)) mExperienceView.showPhoto(path);
    }
  }
}
