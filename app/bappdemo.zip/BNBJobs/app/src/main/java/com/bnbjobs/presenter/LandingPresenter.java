/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.activity.SplashActivity;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.services.FetchAddressIntentService;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.view.LandingScreenView;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.trello.rxlifecycle.ActivityEvent;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Observer;

import static com.bnbjobs.R.string.location;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class LandingPresenter extends BasePresenter
    implements Presenter<LandingScreenView>, GoogleApiClient.ConnectionCallbacks,
    GoogleApiClient.OnConnectionFailedListener, LocationListener,
    ResultCallback<LocationSettingsResult> {

  private static final int REQUEST_CHECK_SETTINGS = 0x1;
  /**
   * The desired interval for location updates. Inexact. Updates may be more or less frequent.
   */
  private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 10000;
  /**
   * The fastest rate for active location updates. Exact. Updates will never be more frequent
   * than this value.
   */
  private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS =
      UPDATE_INTERVAL_IN_MILLISECONDS / 2;
  private LandingScreenView mLandingScreenView;
  private LocationRequest mLocationRequest;
  private Location mCurrentLocation;
  private GoogleApiClient mGoogleApiClient;
  private Boolean mRequestingLocationUpdates;
  private String TAG = makeLogTag(LandingPresenter.class);
  private AddressResultReceiver mResultReceiver;

  @Override public void attachView(LandingScreenView view) {
    mLandingScreenView = view;
    mResultReceiver = new AddressResultReceiver(new Handler());
  }

  @Override public void detachView() {
    mLandingScreenView = null;
  }

  /**
   * setup location
   */
  public void setUpLocationClient() {
    mRequestingLocationUpdates = false;
    buildGoogleApiClient();
    createLocationRequest();
    buildLocationSettingsRequest();
  }

  /**
   * Setup google client
   */

  private synchronized void buildGoogleApiClient() {
    mGoogleApiClient = new GoogleApiClient.Builder(getContext()).addConnectionCallbacks(this)
        .addOnConnectionFailedListener(this)
        .addApi(LocationServices.API)
        .build();
  }

  private void createLocationRequest() {
    mLocationRequest = new LocationRequest();
    mLocationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);
    mLocationRequest.setFastestInterval(FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS);
    mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
  }

  public void onResume() {
    LOGI(TAG,
        "onResume  " + !mRequestingLocationUpdates + " client " + mGoogleApiClient.isConnected());
    checkPermission();
  }

  private void checkPermission() {
    if (mGoogleApiClient.isConnected() && !mRequestingLocationUpdates) {
      LOGI(TAG, "onResume check Permission");
      mLandingScreenView.checkLocationPermission();
    }
  }

  public void onPause() {
    LOGI(TAG, "onPause");
    if (mGoogleApiClient.isConnected()) {
      stopLocationUpdate();
    }

    mRequestingLocationUpdates = false;
  }

  private void stopLocationUpdate() {
    if (mGoogleApiClient.isConnected()) {
      LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this)
          .setResultCallback(new ResultCallback<Status>() {
            @Override public void onResult(@NonNull Status status) {
              mRequestingLocationUpdates = false;
            }
          });
    }
  }

  public void onStart() {
    LOGI(TAG, "onStart");
    mGoogleApiClient.connect();
  }

  public void onStop() {
    LOGI(TAG, "onStop");
    mGoogleApiClient.disconnect();
  }

  private void buildLocationSettingsRequest() {
    LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
    builder.addLocationRequest(mLocationRequest);
    builder.setAlwaysShow(true);
    LocationSettingsRequest mLocationSettingsRequest = builder.build();
    PendingResult<LocationSettingsResult> result =
        LocationServices.SettingsApi.checkLocationSettings(mGoogleApiClient,
            mLocationSettingsRequest);
    result.setResultCallback(this);
  }

  public void startLocationUpdate() {
    mLandingScreenView.showProgress();

    LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this).setResultCallback(new ResultCallback<Status>() {
      @Override public void onResult(@NonNull Status status) {
        LOGI(TAG,status.getStatusMessage());
        mRequestingLocationUpdates = true;
      }
    });
  }

  @Override public void onConnected(@Nullable Bundle bundle) {
    LOGI(TAG, "onConnected");
  }

  @Override public void onConnectionSuspended(int i) {
    LOGI(TAG, "Connection suspended");
    mGoogleApiClient.connect();
  }

  @Override public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

  }

  @Override public void onResult(@NonNull LocationSettingsResult locationSettingsResult) {
    final Status status = locationSettingsResult.getStatus();
    switch (status.getStatusCode()) {
      case LocationSettingsStatusCodes.SUCCESS:
        LOGI(TAG, "All location settings are satisfied.");
        mLandingScreenView.checkLocationPermission();
        break;
      case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
        LOGI(TAG, "Location settings are not satisfied. Show the user a dialog to"
            + "upgrade location settings ");
        try {
          status.startResolutionForResult(getContext(), REQUEST_CHECK_SETTINGS);
        } catch (IntentSender.SendIntentException e) {
          LOGI(TAG, "PendingIntent unable to execute request.");
        }
        break;
      case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
        LOGI(TAG,
            "Location settings are inadequate, and cannot be fixed here. Dialog " + "not created.");
        break;
    }
  }

  @Override public void onLocationChanged(Location location) {

    if (location != null) {
      mCurrentLocation = location;
      setUpLocation(mCurrentLocation);
    }else{
      mCurrentLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
      if(mCurrentLocation!=null){
        setUpLocation(mCurrentLocation);
      }else{
        mLandingScreenView.hideProgress();
        mLandingScreenView.showCurrentAddress("FR"); // when not getting location set defaults to france
      }
    }
  }

  private void setUpLocation(Location location){
    getPrefs(getBaseContext()).save(QuickstartPreferences.LAT,
        String.valueOf(location.getLatitude()));
    getPrefs(getBaseContext()).save(QuickstartPreferences.LNG,
        String.valueOf(location.getLongitude()));
    startService(mCurrentLocation);
    if (!(getContext() instanceof SplashActivity)) getNearByJobCount();
    stopLocationUpdate();
  }

  private void startService(Location location) {
    Intent intent = new Intent(getContext(), FetchAddressIntentService.class);

    // Pass the result receiver as an extra to the service.
    intent.putExtra(Constants.RECEIVER, mResultReceiver);

    // Pass the location data as an extra to the service.
    intent.putExtra(Constants.LOCATION_DATA_EXTRA, location);

    // Start the service. If the service isn't already running, it is instantiated and started
    // (creating a process for it if needed); if it is running then it remains running. The
    // service kills itself automatically once all intents are processed.
    getContext().startService(intent);
  }

  /**
   * get near by job
   */
  private void getNearByJobCount() {
    HashMap<String, String> params = new HashMap<>(4);
    params.put("apiName", "landingScreen");
    params.put("latitude", String.valueOf(mCurrentLocation.getLatitude()));
    params.put("longitude", String.valueOf(mCurrentLocation.getLongitude()));
    params.put("type", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_TYPE, "1"));

    RestClient.getInstance(params)
        .compose(getContext().<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Observer<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, Log.getStackTraceString(e));
            retryMethod(e);
          }

          @Override public void onNext(final String s) {
            LOGI(TAG, "response is " + s);
            try {
              if (isResponseSuccess(s)) {
                final JSONObject object = new JSONObject(s);
                mLandingScreenView.hideProgress();
                mLandingScreenView.showCurrentJob(object.optString("count"));
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(Throwable e) {
    String error = "";
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            getNearByJobCount();
          }
        }).show();
  }

  private BaseActivity getContext() {
    return (BaseActivity) mLandingScreenView.getContext();
  }

  @Override protected Context getBaseContext() {
    return getContext();
  }

  /**
   * get the address from location
   */
  private class AddressResultReceiver extends ResultReceiver {

    AddressResultReceiver(Handler handler) {
      super(handler);
    }

    /**
     * Receives data sent from FetchAddressIntentService and updates the UI in MainActivity.
     */
    @Override protected void onReceiveResult(int resultCode, Bundle resultData) {

      if (mLandingScreenView == null) {
        return;
      }
      // Display the address string or an error message sent from the intent service.
      String mAddressOutput = resultData.getString(Constants.RESULT_DATA_KEY);
      String mCountryCode = resultData.getString(Constants.COUNTRY_CODE);

      if (getContext() instanceof SplashActivity) {
        mLandingScreenView.hideProgress();
        mLandingScreenView.showCurrentAddress(mCountryCode);
      } else {
        mLandingScreenView.showCurrentAddress(mAddressOutput);
      }

      // Show a toast message if an address was found.
      if (resultCode == Constants.SUCCESS_RESULT) {
        //showToast(getString(R.string.address_found));
      }
    }
  }
}
