/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.adapter.BaseRecyclerAdapter;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.InviteSelectModel;
import com.bnbjobs.model.InviteSendEvent;
import com.bnbjobs.model.UserModel;
import com.bnbjobs.presenter.InviteGroupPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.InviteGroupView;
import com.bumptech.glide.Glide;
import com.kyleduo.switchbutton.SwitchButton;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import org.greenrobot.eventbus.EventBus;

import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class InviteGroupActivity extends BaseActivity implements InviteGroupView {

  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.ivAddGroup) ImageView ivDone;
  @BindView(R.id.etSearch) EditText etSearch;
  @BindView(R.id.linearSearch) LinearLayout linearSearch;
  @BindView(R.id.sb_default) SwitchButton sbDefault;
  @BindView(R.id.tvRadius) TextView tvRadius;
  @BindView(R.id.seekBar) SeekBar seekBar;
  @BindView(R.id.groupRecyclerView) RecyclerView groupRecyclerView;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.tvTodayError) TextView tvTodayError;
  @BindView(R.id.tvInvitation) TextView tvInvitation;

  private List<UserModel> mUserModelList = new ArrayList<>();
  private InviteGroupPresenter presenter;
  private ArrayList<InviteSelectModel> mInviteSelectList = new ArrayList<>();
  private List<String> userIdList = new ArrayList<>();
  private int maxNumber;
  private static final String TAG = makeLogTag(InviteGroupActivity.class);
  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_invite_group);
    ButterKnife.bind(this);
    tvRadius.setText(Html.fromHtml(getString(R.string.view_profile_radius, "30")));
    seekBar.setOnSeekBarChangeListener(seekBarChangeListener);
    groupRecyclerView.setNestedScrollingEnabled(false);
    maxNumber = getIntent().getIntExtra(Constants.KEY_NUMBER, 0);
    tvInvitation.setText(Html.fromHtml(getString(R.string.you_have_2_invitation_out_of_12,getIntent().getIntExtra(Constants.KEY_COUNT, 0),maxNumber)));
    groupRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
    String ids = getIntent().getStringExtra(Constants.KEY_LIST);
    ArrayList<InviteSelectModel> abc = getIntent().getParcelableArrayListExtra(Constants.KEY_OBJECT);
    mInviteSelectList.addAll(abc);
    userIdList.addAll(Arrays.asList(ids.split(",")));
    InviteAdapter adapter = new InviteAdapter(this,mUserModelList,userIdList);
    groupRecyclerView.setAdapter(adapter);
    presenter = new InviteGroupPresenter();
    presenter.attachView(this);
    etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
      @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_SEARCH) {
          Utils.hideKeyboard(etSearch, InviteGroupActivity.this);
          resetApiCall();
        }
        return false;
      }
    });
    adapter.setRecycleOnItemClickListner(new BaseRecyclerAdapter.RecycleOnItemClickListener() {
      @Override public void onItemClick(View view, int position) {
        if (view.getId() == R.id.tvInvite) {
            synchronized (this){
              addOperation(position);
            }
        }
      }
    });
    resetApiCall();
    sbDefault.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
      @Override public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        resetApiCall();
      }
    });
  }

  private void addOperation(int position){
    String id = mUserModelList.get(position).getId();
    if (userIdList.contains(id)) {
      userIdList.remove(id);
      Iterator<InviteSelectModel> mList = mInviteSelectList.iterator();
      while (mList.hasNext()){
        InviteSelectModel model = mList.next();
        if (model.getuId().equalsIgnoreCase(id)) {
          mList.remove();
        }
      }
    } else {
      if (mInviteSelectList.size() == maxNumber) {
        Utils.showMessage(InviteGroupActivity.this,"Max limit reached!");
        return;
      }
      userIdList.add(id);
      InviteSelectModel model = new InviteSelectModel();
      model.setImageUrl(mUserModelList.get(position).getImageUrl());
      model.setuId(mUserModelList.get(position).getId());
      mInviteSelectList.add(model);
    }
    LOGI(TAG,"this is just ");
    mUserModelList.get(position).setSeletected(!mUserModelList.get(position).isSeletected());
    groupRecyclerView.getAdapter().notifyItemChanged(position);
  }
  @OnClick(R.id.ivAddGroup) void onDone(){
    String uIds = TextUtils.join(",",userIdList);
    InviteSendEvent event = new InviteSendEvent();
    event.setmInviteSelectModel(mInviteSelectList);
    event.setuIds(uIds);
    EventBus.getDefault().post(event);
    finish();
  }

  private void resetApiCall() {
    presenter.getCandidates(1);
  }

  private SeekBar.OnSeekBarChangeListener seekBarChangeListener =
      new SeekBar.OnSeekBarChangeListener() {
        @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
          tvRadius.setText(
              Html.fromHtml(getString(R.string.view_profile_radius, String.valueOf(progress))));
        }

        @Override public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override public void onStopTrackingTouch(SeekBar seekBar) {
          resetApiCall();
        }
      };

  @OnClick(R.id.imageBack) void onBack() {
    onBackPressed();
  }

  @Override public String getSearchString() {
    return Utils.getText(etSearch);
  }

  @Override public String getRadius() {
    return String.valueOf(seekBar.getProgress());
  }

  @Override public String getActiveFlag() {
    return sbDefault.isChecked() ? "1" : "0";
  }

  @Override public void onSuccess(List<UserModel> userModels, boolean clear) {
    if (clear) this.mUserModelList.clear();
    mUserModelList.addAll(userModels);
    groupRecyclerView.getAdapter().notifyDataSetChanged();
    if (groupRecyclerView.getAdapter().getItemCount() < 1) {
      tvTodayError.setVisibility(View.VISIBLE);
    } else {
      tvTodayError.setVisibility(View.GONE);
    }
  }

  @Override public void onError(String msg) {
    Utils.showMessage(this, msg);
  }

  @Override public RecyclerView getRecyclerView() {
    return groupRecyclerView;
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override protected void onDestroy() {
    presenter.detachView();
    super.onDestroy();
  }

  static class InviteAdapter extends BaseRecyclerAdapter<InviteAdapter.MyViewHolder> {

    private List<UserModel> mUserModelList;
    private Context context;
    private List<String> uids;

    InviteAdapter(Context context, List<UserModel> mUserModelList,List<String> uids) {
      this.context = context;
      this.mUserModelList = mUserModelList;
      this.uids = uids;
    }

    @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
      View view = LayoutInflater.from(parent.getContext())
          .inflate(R.layout.adapter_invite_item, parent, false);
      return new MyViewHolder(view);
    }

    @Override public void onBindViewHolder(MyViewHolder holder, int position) {
      Glide.with(context)
          .load(mUserModelList.get(position).getImageUrl())
          .placeholder(R.drawable.placeholder)
          .dontAnimate()
          .into(holder.ivUserImage);
      holder.tvDesignationTitle.setText(mUserModelList.get(position).getTitle());
      holder.tvUserName.setText(String.format("%s %s", mUserModelList.get(position).getfName(),mUserModelList.get(position).getlName()));
      holder.tvLocation.setText(context.getString(R.string.location_km, mUserModelList.get(position).getU_location(),mUserModelList.get(position).getDistance()));
      if(uids.contains(mUserModelList.get(position).getId())){
        holder.tvInvite.setTextColor(Color.WHITE);
        holder.tvInvite.setBackgroundResource(R.drawable.round_fill_pink_invite);
      }else{
        holder.tvInvite.setTextColor(ActivityCompat.getColor(context,R.color.color_pink));
        holder.tvInvite.setBackgroundResource(R.drawable.round_pink_invite);
      }

    }

    @Override public int getItemCount() {
      return mUserModelList.size();
    }

    class MyViewHolder extends BaseRecyclerAdapter.ViewHolder {
      @BindView(R.id.ivUserImage) ImageView ivUserImage;
      @BindView(R.id.tvUserName) TextView tvUserName;
      @BindView(R.id.tvDesignationTitle) TextView tvDesignationTitle;
      @BindView(R.id.tvInvite) TextView tvInvite;
      @BindView(R.id.tvLocation) TextView tvLocation;

      public MyViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
        clickableViews(tvInvite);
      }
    }
  }
}
