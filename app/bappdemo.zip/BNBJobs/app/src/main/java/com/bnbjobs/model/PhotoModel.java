/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

/**
 * @author Harsh
 * @version 1.0
 */
public class PhotoModel implements Serializable,Parcelable {

  @SerializedName("rpi_image") private String image;
  @SerializedName("rp_image_url") private String imageUrl;
  @SerializedName("rp_image_thumb_url") private String imageThumbUrl;
  @SerializedName("rpi_id") private String imageId;

  private void readIn(Parcel in) {
    image = in.readString();
    imageUrl = in.readString();
    imageThumbUrl = in.readString();
    imageId = in.readString();
  }

  public static final Creator<PhotoModel> CREATOR = new Creator<PhotoModel>() {
    @Override public PhotoModel createFromParcel(Parcel in) {
      PhotoModel model = new PhotoModel();
      model.readIn(in);
      return model;
    }

    @Override public PhotoModel[] newArray(int size) {
      return new PhotoModel[size];
    }
  };

  public String getImage() {
    return image;
  }

  public void setImage(String image) {
    this.image = image;
  }

  public String getImageUrl() {
    return imageUrl;
  }

  public void setImageUrl(String imageUrl) {
    this.imageUrl = imageUrl;
  }

  public String getImageThumbUrl() {
    return imageThumbUrl;
  }

  public void setImageThumbUrl(String imageThumbUrl) {
    this.imageThumbUrl = imageThumbUrl;
  }

  public String getImageId() {
    return imageId;
  }

  public void setImageId(String imageId) {
    this.imageId = imageId;
  }

  @Override public int describeContents() {
    return 0;
  }

  @Override public void writeToParcel(Parcel dest, int flags) {
    dest.writeString(image);
    dest.writeString(imageUrl);
    dest.writeString(imageThumbUrl);
    dest.writeString(imageId);
  }
}

