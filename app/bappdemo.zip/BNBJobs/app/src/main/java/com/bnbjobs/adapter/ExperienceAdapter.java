/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.model.Experience;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class ExperienceAdapter
    extends RecyclerView.Adapter<ExperienceAdapter.CustomViewHolderExperience> {

  private Context context;
  private List<Experience> experienceArrayList;

  public ExperienceAdapter(Context context, List<Experience> mExperienceList,
      Fragment profileFragment) {
    this.experienceArrayList = mExperienceList;
    this.context = context;
  }

  @Override public CustomViewHolderExperience onCreateViewHolder(ViewGroup parent, int viewType) {
    View rowView = LayoutInflater.from(context).inflate(R.layout.experince_inlfater, parent, false);
    return new CustomViewHolderExperience(rowView);
  }

  @Override public void onBindViewHolder(CustomViewHolderExperience holder, int position) {
    Experience experience = experienceArrayList.get(position);
    holder.tv_company_designation.setText(experience.getTitle());
    String experienceTemp = experience.getExperience();
    if (experience.getProgressInMonths() > 12) {
      experienceTemp += context.getResources().getQuantityString(R.plurals.year, 2);
    } else {
      experienceTemp += context.getResources()
          .getQuantityString(R.plurals.month, experience.getProgressInMonths());
    }
    holder.tv_company_name.setText(experienceTemp);
    holder.linearEditOptions.setVisibility(View.INVISIBLE);
  }

  @Override public int getItemCount() {
    return experienceArrayList.size();
  }

  static class CustomViewHolderExperience extends RecyclerView.ViewHolder {
    @BindView(R.id.tv_company_name) TextView tv_company_name;
    @BindView(R.id.tv_job_duration) TextView tv_company_jobduration;
    @BindView(R.id.tv_designation) TextView tv_company_designation;
    @BindView(R.id.iv_company_logo) ImageView iv_company_logo;
    @BindView(R.id.imageDelete) ImageView imageDelete;
    @BindView(R.id.imageEdit) ImageView imageEdit;
    @BindView(R.id.linearEditOptions) LinearLayout linearEditOptions;

     CustomViewHolderExperience(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
    }
  }
}



