/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.DesignationDbModel;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class DesignationChildAdapter
    extends RecyclerView.Adapter<DesignationChildAdapter.MyViewHolder> {

  private Context mContext;
  private List<DesignationDbModel> mList;
  private ClickImpl mClick;
  private List<String> selectedIds;

  public DesignationChildAdapter(Context mContext, List<DesignationDbModel> mList,
      ClickImpl mClick) {
    this.mContext = mContext;
    this.mList = mList;
    this.mClick = mClick;
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.inflater_designation_child, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {
    holder.bindData(mList.get(position));
  }

  @Override public int getItemCount() {
    return mList.size();
  }

  public void setSelectedIds(List<String> selectedIds) {
    this.selectedIds = selectedIds;
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {
    @BindView(R.id.imgSelect) ImageView imgSelect;
    @BindView(R.id.tvName) TextView tvName;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
    }

    void bindData(DesignationDbModel dbModel) {
      if (selectedIds.contains(Integer.toString(dbModel.getD_id()))) {
        imgSelect.setImageResource(R.drawable.round_select);
      } else {
        imgSelect.setImageResource(R.drawable.round);
      }
      tvName.setText(dbModel.getTitle());
    }

    @OnClick(R.id.item) void onItemClick(View v) {
      mClick.onClick(v, mList.get(getLayoutPosition()), getLayoutPosition());
    }
  }
}
