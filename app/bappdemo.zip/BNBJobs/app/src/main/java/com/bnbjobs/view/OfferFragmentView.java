/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.google.android.gms.location.places.Place;

/**
 * @author Harsh
 * @version 1.0
 */

public interface OfferFragmentView extends MediaView {

  void setPlaceInView(Place place, int click);

  void setCancelSearchPlace(String message);

  String getLocation();

  void onError();

  void addCountry(String countryCode);

  void onDelete(String message);

  void navigateToBack();
}
