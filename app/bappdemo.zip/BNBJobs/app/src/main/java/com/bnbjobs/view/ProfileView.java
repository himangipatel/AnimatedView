/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.Experience;
import com.bnbjobs.model.FormationModel;
import com.bnbjobs.model.ImageModel;
import com.bnbjobs.model.JobApplyModel;
import com.bnbjobs.model.JobModel;
import com.bnbjobs.model.LanguageModel;
import com.bnbjobs.model.SkillModel;
import com.bnbjobs.model.UserModel;
import com.bnbjobs.model.UserProfileData;

import java.io.File;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public interface ProfileView extends MainView {
    void setLengthView(String currentString, String totalString);

    void setExperienceAdapter(List<Experience> experienceList);

    void setFormationAdapter(List<FormationModel> categoryLists);

    void setSkillAdapter(List<SkillModel> skillList);

    void setPhotoAdapter(List<ImageModel> photoUrls);

    void updateProfileProgress(int percent);

    void setUserData(UserModel userData, int profilePercent);

    void setVideoThumb(String url);

    void setUserDescription(UserProfileData profileData);

    void setLanguageData(List<LanguageModel> modelList);

    void setAddress(String address);

    void addData(Object obj);

    File getProfile();

    void openCamera();

    void openGallery();

    void setVideoId(int videoId);

    void showPhoto(String path);

    void setDefault();

    boolean isImageSet();

    void onRemoveVideo();

    void addImage(ImageModel imageModel);

    void setPlanPurchased(boolean planPurchaseFlg);

    void setJobApply(List<JobApplyModel> jobApplyModelList);

    void applyStatus(String action);

    void onCodeResend(boolean result, String message);

    void editData(Object o);

    void removeObject(int type);

    void setFavorite(boolean favoriteFlag);

    void updateFavorite(boolean favoriteFlag);

    void opeVideoCamera();

    void openVideoGallery();

    void setProfileImage(String path);

    void setFavoriteList(BaseContainer<JobModel> jobSearchBaseContainer);
}

