/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.LanguageModel;
import com.bnbjobs.utils.Utils;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class LanguageAdapter extends RecyclerView.Adapter<LanguageAdapter.MyViewHolder> {

  private final int ratingBarHeight;
  private Context mContext;
  private List<LanguageModel> mLanguageModels;
  private ClickImpl mClick;
  private boolean mEdit;

  public LanguageAdapter(Context context, List<LanguageModel> languageModels, Fragment fragment) {
    mContext = context;
    mLanguageModels = languageModels;
    mClick = (ClickImpl) fragment;
    Drawable ratingBar = ContextCompat.getDrawable(this.mContext, R.drawable.green_star);
    ratingBarHeight = ratingBar.getIntrinsicHeight();
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view =
        LayoutInflater.from(parent.getContext()).inflate(R.layout.rating_inflater, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {
    holder.tvCategoryName.setText(Utils.capitalize(mLanguageModels.get(position).getTitle()));
    if (mLanguageModels.get(position).getRate() == 5) {
      holder.ratingBarGreen.setRating(mLanguageModels.get(position).getRate());
      holder.ratingBarGreen.setVisibility(View.VISIBLE);
      holder.ratingBar.setVisibility(View.GONE);
    } else {
      holder.ratingBar.setRating(mLanguageModels.get(position).getRate());
      holder.ratingBarGreen.setVisibility(View.GONE);
      holder.ratingBar.setVisibility(View.VISIBLE);
    }
  }

  @Override public int getItemCount() {
    return mLanguageModels.size();
  }

  public void setEdit(boolean edit) {
    mEdit = edit;
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.tv_category_name) TextView tvCategoryName;
    @BindView(R.id.ratingBarGreen) RatingBar ratingBarGreen;
    @BindView(R.id.ratingbar) RatingBar ratingBar;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);

      ratingBarGreen.setVisibility(View.VISIBLE);
      ratingBarGreen.getLayoutParams().height = ratingBarHeight;
      ratingBar.getLayoutParams().height = ratingBarHeight;
      itemView.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          if (mEdit) {
            mClick.onClick(v, mLanguageModels.get(getLayoutPosition()), getLayoutPosition());
          }
        }
      });
    }
  }
}
