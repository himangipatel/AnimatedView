/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.model.ImageModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.HomeView;
import com.bnbjobs.view.MediaView;
import com.trello.rxlifecycle.ActivityEvent;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;

import static android.app.Activity.RESULT_OK;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * Created by jay shah on 25/7/16.
 */
public class HomePresenter extends MediaPresenter {

  private static final int FILE_TYPE_GALLARY = 1;
  private static final int FILE_TYPE_VIDEO = 2;
  private HomeView mHomeView;
  private PopupWindow popupWindow;
  private View.OnClickListener takepicture;
  private View.OnClickListener takevideo = new View.OnClickListener() {
    @Override public void onClick(View view) {
      showVideoCaptureDialog();
    }
  };
  private PopupWindow.OnDismissListener dismissListener = new PopupWindow.OnDismissListener() {
    @Override public void onDismiss() {
      ((HomeActivity) mHomeView).isMediaSel = false;
    }
  };
  private String dId;

  public HomePresenter() {
    takepicture = new View.OnClickListener() {
      @Override public void onClick(View view) {
        showChangePhotoDialog();
      }
    };
  }

  @Override public void attachView(MediaView view) {
    super.attachView(view);
    this.mHomeView = (HomeView) view;
  }

  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    handleCameraResult(requestCode, resultCode, data);
  }

  private void handleCameraResult(int requestCode, int resultCode, Intent data) {
    Uri uri;
    String path = "";
    if (resultCode == RESULT_OK) {
      if (requestCode == REQUEST_CODE_CAMERA) {
        path = mCameraOutputPath;
        if (Utils.isFileSizeValid(getBaseContext(), path, FILE_TYPE_GALLARY)) {
          addImageInList(path);
        }
      } else if (requestCode == REQUEST_CODE_GALLERY && data != null) {
        uri = data.getData();
        path = getRealPathFromURI(uri);
        if (Utils.isFileSizeValid(getBaseContext(), path, FILE_TYPE_GALLARY)) {
          addImageInList(path);
        }
      } else if (requestCode == REQUEST_CODE_VIDEO || requestCode == REQUEST_CODE_VIDEO_CAMERA) {
        if (requestCode == REQUEST_CODE_VIDEO_CAMERA) {
          if (filePath != null) {
            path = filePath;
          }
        } else if (data != null) {
          uri = data.getData();
          path = getRealPathFromURIVideo(uri);
        }
        if (path != null) {
          LOGI(TAG, "Video Path: " + path);
          if (Utils.isFileSizeValid(getBaseContext(), path, FILE_TYPE_VIDEO)) {
            uploadVideo(path);
          }
        }
      }
    }
  }

  private void addImageInList(String path) {
    ImageModel imageModel = new ImageModel();
    imageModel.setImageId(0);
    imageModel.setImageUrl(path);
    imageModel.setImageThumbUrl(path);
    imageModel.setImage(path);
    imageModel.setEdit(true);
    mHomeView.addImage(imageModel, 0);
  }

  private void uploadVideo(String path) {
    ImageModel imageModel = new ImageModel();
    imageModel.setImageId(0);
    imageModel.setImageUrl(path);
    imageModel.setImageThumbUrl(path);
    imageModel.setImage(path);
    imageModel.setEdit(true);
    mHomeView.addVideo(imageModel);
  }

  public void showMediaDialog() {
    int[] loc = new int[2];
    ((HomeActivity) mHomeView).mLinearTab.getLocationOnScreen(loc);
    popupWindow = new PopupWindow(getBaseContext());
    popupWindow.setAnimationStyle(R.style.animationPopup);
    View popupView = LayoutInflater.from(getBaseContext()).inflate(R.layout.popup_media, null);
    LinearLayout llTakePic = (LinearLayout) popupView.findViewById(R.id.llTakePic);
    LinearLayout llTakeVideo = (LinearLayout) popupView.findViewById(R.id.llTakeVideo);
    llTakePic.setOnClickListener(takepicture);
    llTakeVideo.setOnClickListener(takevideo);
    popupWindow.setOnDismissListener(dismissListener);
    popupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    popupWindow.setOutsideTouchable(true);
    popupWindow.setWindowLayoutMode(ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT);
    popupWindow.setHeight(1);
    popupWindow.setWidth(1);
    popupView.measure(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    int measuredHeight = popupView.getMeasuredHeight();
    popupWindow.setContentView(popupView);
    popupWindow.setFocusable(true);
    popupWindow.showAtLocation(((HomeActivity) mHomeView).llHome, Gravity.START | Gravity.TOP, 0,
        loc[1] - measuredHeight + Utils.dpToPx(10));
    popupWindow.update();
  }

  private void dismissPopupDialog() {
    if (popupWindow != null && popupWindow.isShowing()) {
      try {
        popupWindow.dismiss();
      } catch (Exception e) {
        LOGE(TAG, e.getMessage(), e);
      }
    }
  }

  public void showChangePhotoDialog() {
    imagePicker(new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        if (which == 0) {
          mHomeView.openCamera();
        } else if (which == 1) {
          mHomeView.openGallery();
        } else {
          mHomeView.setDefault();
        }
        dismissPopupDialog();
      }
    }, mHomeView.isImageSet()).show();
  }

  public void showVideoCaptureDialog() {
    videoPicker(new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        if (which == 0) {
          mHomeView.opeVideoCamera();
        } else if (which == 1) {
          mHomeView.openVideoGallery();
        }
        dismissPopupDialog();
      }
    }).show();
  }

  private HomeActivity getContext() {
    return (HomeActivity) mHomeView.getContext();
  }

  public void updateDesignation(final String designationId) {
    //mHomeView.showProgress();
    this.dId = designationId;
    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "updateCandidateDesignation");
    params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
    params.put("accessToken",
        getPrefs(getBaseContext()).getString(QuickstartPreferences.ACCESS_TOKEN, ""));
    params.put("language", getLanguage());
    params.put("designationId", designationId);

    RestClient.getInstance(params)
        .compose(((BaseActivity) getBaseContext()).<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            mHomeView.hideProgress();
            if (e.getMessage() != null) {
              Utils.showMessage(getContext(), e.getMessage());
            }
          }

          @Override public void onNext(String s) {
            mHomeView.hideProgress();
            JSONObject object;
            try {
              object = new JSONObject(s);
              if (isResponseSuccess(s)) {
                getPrefs(getBaseContext()).save(QuickstartPreferences.SHOW_DESIGNATION, false);
                Utils.showMessage(getContext(),
                    getBaseContext().getString(R.string.designation_update));
              } else {
                showDialog(getBaseContext(), getBaseContext().getString(R.string.alert),
                    object.getString("message"), getBaseContext().getString(android.R.string.ok),
                    new DialogInterface.OnClickListener() {
                      @Override public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                      }
                    }).show();
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(final Throwable e) {
    String error;
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    AlertDialog dialog =
        showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
            getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                updateDesignation(dId);
              }
            });
    dialog.setCancelable(false);
    dialog.show();
  }
}
