/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.os.Handler;
import com.bnbjobs.view.TestView;

/**
 * @author Harsh
 * @version 1.0
 */
public class TestPresenter implements Presenter<TestView> {

  private TestView testView;

  @Override public void attachView(TestView view) {
    testView = view;
  }

  @Override public void detachView() {
    testView = null;
  }

  public void doSomeThing() {
    // do your stuff here
    testView.showProgress();

    new Handler().postDelayed(new Runnable() {
      @Override public void run() {
        testView.hideProgress();
        testView.showMessage("Hi this is MVP Test");
      }
    }, 2000);
  }
}
