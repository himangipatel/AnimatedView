/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.model.PurchaseModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.PurchaseView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.ActivityEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class PurchasePresenter extends BasePresenter implements Presenter<PurchaseView> {

  private static final String TAG = makeLogTag(PurchasePresenter.class);
  private PurchaseView mPurchaseView;

  @Override public void attachView(PurchaseView view) {
    mPurchaseView = view;
  }

  @Override public void detachView() {
    mPurchaseView = null;
  }

  public void getPurchasePlan() {
    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "getPremiumPlans");
    params.put("type", "1");
    params.putAll(addParams(params));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        if (isResponseSuccess(s)) {
          JSONObject object = null;
          try {
            object = new JSONObject(s);
            PurchaseModel model =
                new Gson().fromJson(object.optString("data"), PurchaseModel.class);
            mPurchaseView.setData(model);
          } catch (JSONException e) {
            e.printStackTrace();
          }
        }
      }
    });
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(final Throwable e) {
    String error = "";
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            getPurchasePlan();
          }
        }).show();
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseActivity) getBaseContext()).<String>bindUntilEvent(ActivityEvent.DESTROY);
  }

  @Override protected Context getBaseContext() {
    return mPurchaseView.getContext();
  }
}
