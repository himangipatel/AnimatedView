/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.adapter.HomeAdapter;
import com.bnbjobs.customui.views.BackImageView;
import com.bnbjobs.customui.views.GradientView;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.JobModel;
import com.bnbjobs.presenter.SearchDetailPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.EndlessRecyclerViewScrollListener;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.SearchDetailView;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.maps.model.LatLng;
import java.util.ArrayList;
import java.util.List;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class SearchDetailFragment extends BaseFragment
    implements SearchDetailView, ClickImpl<JobModel> {

  private static final int REGULAR_TYPE = 1;
  private static final int PULL_TYPE = 2;
  private static final int SEARCH_TYPE = 3;
  private static final String TAG = makeLogTag(SearchDetailFragment.class);
  @BindView(R.id.tvCurrentLocation) TextView tvCurrentLocation;
  @BindView(R.id.linearLocation) LinearLayout linearLocation;
  @BindView(R.id.recyclerView) RecyclerView recyclerView;
  @BindView(R.id.swipeRefresh) SwipeRefreshLayout mSwipeRefresh;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.tvNoRecord) TextView tvNoRecord;
  @BindView(R.id.cddCheck) CheckBox cddCheck;
  @BindView(R.id.cdiCheck) CheckBox cdiCheck;
  @BindView(R.id.interimCheck) CheckBox interimCheck;
  @BindView(R.id.tvDone) GradientView tvDone;
  @BindView(R.id.linearFilter) LinearLayout linearFilter;
  @BindView(R.id.imgSearch) ImageView imgSearch;
  @BindView(R.id.etSearch) EditText etSearch;
  @BindView(R.id.relativeSearch) RelativeLayout relativeSearch;
  @BindView(R.id.imageFilter) BackImageView imageFilter;
  @BindView(R.id.linearSearch) LinearLayout linearSearch;
  private SearchDetailPresenter presenter;
  private Unbinder unbinder;
  private String designationTitle;
  private LatLng location;
  private String locationName;
  private HomeAdapter adapter;
  private EndlessRecyclerViewScrollListener listener;
  private boolean isFooterAdd;
  private boolean loadMore;
  private int height = -1;
  private List<JobModel> mJobModelList = new ArrayList<>();
  private int PLACE_AUTOCOMPLETE_REQUEST_CODE = 1111;

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_home, container, false);
    unbinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    presenter = new SearchDetailPresenter();
    presenter.attachView(this);
    presenter.setFragment(this);
    linearSearch.setVisibility(View.GONE);
    designationTitle = getArguments().getString(Constants.KEY_TEXT);
    location = getArguments().getParcelable(Constants.KEY_POSITION);
    locationName = getArguments().getString(Constants.KEY_TYPE);
    presenter.setIsFromCountry(getArguments().containsKey(Constants.KEY_DIALOG_TYPE), designationTitle);
    tvCurrentLocation.setText(locationName);
    showToolbar(true);
    setTitle(designationTitle);
    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
    recyclerView.setLayoutManager(linearLayoutManager);
    if (height == -1) {
      recyclerView.post(new Runnable() {
        @Override public void run() {
          if (recyclerView != null) {
            height = recyclerView.getHeight();
            adapter = new HomeAdapter(getActivity(), height, mJobModelList, SearchDetailFragment.this);
            recyclerView.setAdapter(adapter);
          }
        }
      });
    } else {
      if (adapter != null) {
        recyclerView.setAdapter(adapter);
      }
    }
    if (adapter == null || mJobModelList.isEmpty()) {
      showProgress();
      presenter.getSearchResults(REGULAR_TYPE);
    }

    mSwipeRefresh.setColorSchemeResources(R.color.colorPrimary, R.color.theme_blue,R.color.theme_pink, android.R.color.holo_orange_dark);

    mSwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
      @Override public void onRefresh() {
        onRefreshCall();
      }
    });

    recyclerView.addOnScrollListener(new EndlessRecyclerViewScrollListener(linearLayoutManager) {
      @Override public void onLoadMore(int page, int totalItemsCount) {
        listener = this;
        if (loadMore) {
          isFooterAdd = true;
          mJobModelList.add(null);
          adapter.notifyItemInserted(mJobModelList.size() - 1);
          presenter.getSearchResults(isEmpty(Utils.getText(etSearch)) ? REGULAR_TYPE : SEARCH_TYPE);
        }
      }
    });
  }
  @OnClick(R.id.tvCurrentLocation) void onCurrentLocation() {
    findPlace();
  }

  private void findPlace() {
    try {
      Intent intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY).build(getActivity());
      startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
    } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
      LOGE(TAG, e.getMessage(), e);
    }
  }
  @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
      if (resultCode == Activity.RESULT_OK) {
        Place place = PlaceAutocomplete.getPlace(getActivity(), data);
        location = place.getLatLng();
        LOGI(TAG,"Address: "+place.getAddress());
        presenter.getAddress(location);

      } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
        Status status = PlaceAutocomplete.getStatus(getActivity(), data);
        LOGI(TAG, status.getStatusMessage());
      } else if (resultCode == Activity.RESULT_CANCELED) {
        LOGI(TAG, "User cancel");
      }
    }
  }




  @Override public void onResume() {
    super.onResume();
    setWhiteToolbar();
  }

  private void onRefreshCall() {
    if (listener != null) listener.setLoading(false);
    presenter.resetRequest(PULL_TYPE);
  }

  @Override public String getDesignation() {
    return designationTitle;
  }

  @Override public void setAdapter(List<JobModel> mJobModelList) {
    if (isFooterAdd) {
      isFooterAdd = false;
      this.mJobModelList.remove(this.mJobModelList.size() - 1);
      adapter.notifyItemRemoved(this.mJobModelList.size());
    }

    if (mSwipeRefresh.isRefreshing() || mJobModelList.isEmpty()) {
      this.mJobModelList.clear();
      mSwipeRefresh.setRefreshing(false);
    }
    this.mJobModelList.addAll(mJobModelList);
    adapter.notifyDataSetChanged();

    if (adapter.getItemCount() > 0) {
      tvNoRecord.setVisibility(View.GONE);
    } else {
      tvNoRecord.setVisibility(View.VISIBLE);
    }
  }

  @Override public void loadMore(boolean loadMore) {
    this.loadMore = loadMore;
  }

  @Override public void onError() {
    if (mSwipeRefresh.isRefreshing()) {
      mSwipeRefresh.setRefreshing(false);
    }
  }

  @Override public void clearData() {
    mJobModelList.clear();
  }

  @Override public LatLng getLatLng() {
    return location;
  }

  @Override public void onErrorCountry() {
    Utils.showMessage(getActivity(),"Couldn't get country. please try again.");
  }

  @Override public void setCountry(String country) {
    setTitle(country);
    tvCurrentLocation.setText(country);
    presenter.setIsFromCountry(true, country);
    mSwipeRefresh.setRefreshing(true);
    onRefreshCall();

  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void onDestroyView() {
    unbinder.unbind();
    super.onDestroyView();
  }

  @Override public void onBack(View view) {
    getFragmentManager().popBackStack();
  }

  @Override public boolean onBackPressed() {
    getFragmentManager().popBackStack();
    return true;
  }

  @Override public void onClick(View view, JobModel model, int position) {
    Bundle bundle = new Bundle();
    bundle.putString(Constants.KEY_ID, model.getRpId());
    JobDetailFragment fragment = new JobDetailFragment();
    fragment.setArguments(bundle);
    addFragment(fragment, true);
  }
}

