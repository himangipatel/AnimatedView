/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.utils;

import android.app.Activity;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;

/**
 * Created by imobdev on 6/2/16.
 */
public class SearchNotAvailableDialog {

  private String msg;
  private Activity activity;
  private AlertDialog alert;
  private OnDismiss onDismiss;

  public SearchNotAvailableDialog(Activity activity, String msg) {
    this.msg = msg;
    this.activity = activity;
  }

  public SearchNotAvailableDialog(Activity activity, String msg, OnDismiss mOnDismiss) {
    this.msg = msg;
    this.activity = activity;
    this.onDismiss = mOnDismiss;
  }

  public void showDailog() {
    AlertDialog.Builder builder = new AlertDialog.Builder(activity);
    builder.setMessage(msg);
    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialogInterface, int i) {
        alert.dismiss();
      }
    });
    alert = builder.create();
    alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
      @Override public void onDismiss(DialogInterface dialog) {
        if (onDismiss != null) {
          onDismiss.onDismiss();
        }
      }
    });
    alert.show();
  }

  public interface OnDismiss {
    public void onDismiss();
  }
}
