/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

/**
 * Created by jay shah on 29/7/16.
 */
public class EditImageModel {

  private boolean isEdited;
  private ImageModel updatedImageModel;
  private boolean isAdded;
  private boolean isDeleted;

  public boolean isEdited() {
    return isEdited;
  }

  public void setEdited(boolean edited) {
    isEdited = edited;
  }

  public ImageModel getUpdatedImageModel() {
    return updatedImageModel;
  }

  public void setUpdatedImageModel(ImageModel updatedImageModel) {
    this.updatedImageModel = updatedImageModel;
  }

  public boolean isAdded() {
    return isAdded;
  }

  public void setAdded(boolean added) {
    isAdded = added;
  }

  public boolean isDeleted() {
    return isDeleted;
  }

  public void setDeleted(boolean deleted) {
    isDeleted = deleted;
  }
}
