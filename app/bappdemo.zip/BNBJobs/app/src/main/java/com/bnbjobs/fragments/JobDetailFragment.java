/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.activity.ShareActivity;
import com.bnbjobs.adapter.JobDetailPagerAdapter;
import com.bnbjobs.customui.looppager.LoopRecyclerViewPager;
import com.bnbjobs.customui.looppager.RecyclerViewPager;
import com.bnbjobs.customui.views.CircleImageView;
import com.bnbjobs.model.JobDetail;
import com.bnbjobs.model.PhotoModel;
import com.bnbjobs.presenter.JobDetailPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.JobDetailView;
import com.bumptech.glide.Glide;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.widget.ShareDialog;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.joda.time.DateTime;
import org.joda.time.Months;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.Utils.getContractValue;
import static com.bnbjobs.utils.Utils.getEuro;
import static com.bnbjobs.utils.Utils.openUrl;

/**
 * @author Harsh
 * @version 1.0
 */
public class JobDetailFragment extends BaseFragment implements JobDetailView {

  @BindView(R.id.viewpager) LoopRecyclerViewPager mRecyclerViewPager;
  @BindView(R.id.tvNoRecord) TextView tvNoRecord;
  @BindView(R.id.linearLoop) LinearLayout linearLoop;
  @BindView(R.id.tvAmount) TextView tvAmount;
  @BindView(R.id.imgAmount) ImageView imgAmount;
  @BindView(R.id.tvContractType) TextView tvContractType;
  @BindView(R.id.tvContractLength) TextView tvContractLength;
  @BindView(R.id.tvStartDate) TextView tvStartDate;
  @BindView(R.id.tvEndDate) TextView tvEndDate;
  @BindView(R.id.tvRef) TextView tvRef;
  @BindView(R.id.tvCreateTime) TextView tvCreateTime;
  @BindView(R.id.tvLocation) TextView tvLocation;
  @BindView(R.id.tvCar) TextView tvCar;
  @BindView(R.id.tvDescription) TextView tvDescription;
  @BindView(R.id.imageVideo) ImageView imageVideo;
  @BindView(R.id.videoFrame) FrameLayout videoFrame;
  @BindView(R.id.imagePlay) ImageView imagePlay;
  @BindView(R.id.tvSalary) TextView tvSalary;
  @BindView(R.id.tvJobLocation) TextView tvJobLocation;
  @BindView(R.id.tvExperience) TextView tvExperience;
  @BindView(R.id.tvRequiredQuality) TextView tvRequiredQuality;
  @BindView(R.id.tvOtherBenefit) TextView tvOtherBenefits;
  @BindView(R.id.tvNeedPercentage) TextView tvNeedPercentage;

  @BindView(R.id.userImage) CircleImageView userImage;
  @BindView(R.id.tvCompanyName) TextView tvCompanyName;
  @BindView(R.id.tvUserAddress) TextView tvUserAddress;
  @BindView(R.id.imageMap) ImageView imageMap;
  @BindView(R.id.tvReport) TextView tvReport;
  @BindView(R.id.tvDTitle) TextView tvDTitle;
  @BindView(R.id.tvPostedDate) TextView tvPostedDate;
  @BindView(R.id.tvMapAddress) TextView tvMapAddress;
  @BindView(R.id.tvMapCreatedTime) TextView tvMapCreatedTime;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.tvApplyJob) TextView tvApplyJob;
  @BindView(R.id.ivFav) ImageView ivFav;
  @BindView(R.id.ivMail) ImageView ivMail;
  @BindView(R.id.ivFB) ImageView ivFB;
  @BindView(R.id.container) View container;
  @BindView(R.id.linearContainer) View linearContainer;
  private JobDetailPresenter presenter;
  private Unbinder unbinder;
  private List<PhotoModel> mPhotoList = new ArrayList<>();
  private int profilePercentage;
  private String mVideoUrl;
  private int requiredProfilePercentage;
  private CallbackManager callbackManager;
  private ShareDialog shareDialog;
  private JobDetail jobDetail;
  private boolean favoriteJob;

  private static final String TAG = JobDetailFragment.class.getSimpleName();

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    callbackManager = CallbackManager.Factory.create();
    shareDialog = new ShareDialog(this);
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_job_detail, container, false);
    unbinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    showToolbar(true);
    if (presenter == null) {
      presenter = new JobDetailPresenter();
      presenter.attachView(this);
      presenter.setFragment(this);
    }
    container.setVisibility(View.GONE);
    presenter.getJobDetail();
    LinearLayoutManager layout = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
    mRecyclerViewPager.setTriggerOffset(0.01f);
    mRecyclerViewPager.setFlingFactor(0.01f);
    mRecyclerViewPager.setLayoutManager(layout);
    mRecyclerViewPager.setHasFixedSize(true);
    mRecyclerViewPager.setLongClickable(true);
    mRecyclerViewPager.setSinglePageFling(true);
    setRightImage(R.drawable.share_icon);
    shareDialog.registerCallback(callbackManager, new FacebookCallback<Sharer.Result>() {
      @Override public void onSuccess(Sharer.Result result) {

      }

      @Override public void onCancel() {
        LOGI(TAG, "Cancel Share");
      }

      @Override public void onError(FacebookException error) {
        LOGI(TAG, Log.getStackTraceString(error));
      }
    });
  }

  @Override public String getJobId() {
    return getArguments().getString(Constants.KEY_ID);
  }

  @Override public void setJobDetail(JobDetail jobDetail) {
    this.jobDetail = jobDetail;
    favoriteJob = jobDetail.isFavorite_flag();
    container.setVisibility(View.VISIBLE);
    if (favoriteJob) {
      ivFav.setImageResource(R.drawable.new_fav_select);
    } else {
      ivFav.setImageResource(R.drawable.new_fav_unselect);
    }
    tvNeedPercentage.setText(getString(R.string.need_profile_complete, jobDetail.getProfilePercentage()));
    setTitle(jobDetail.getdTitle());
    if (jobDetail.getmImageList() != null && jobDetail.getmImageList().size() > 0) {
      mPhotoList.addAll(jobDetail.getmImageList());
      JobDetailPagerAdapter jobAdapter = new JobDetailPagerAdapter(getActivity(), mPhotoList);
      mRecyclerViewPager.setAdapter(jobAdapter);
      presenter.setRecyclerViewSettings();
    } else {
      mRecyclerViewPager.setVisibility(View.GONE);
      tvNoRecord.setVisibility(View.VISIBLE);
    }
    if (jobDetail.getApplyJobBtnFlag() == 1) {
      tvApplyJob.setBackgroundResource(R.drawable.postule_bg);
    } else if (jobDetail.getApplyJobBtnFlag() == 4) {
      tvApplyJob.setBackgroundResource(R.drawable.red_postule_bg);
    } else {
      tvApplyJob.setBackgroundResource(R.drawable.green_postule_bg);
    }
    tvContractType.setText(getContractValue(jobDetail.getContractType()));
    profilePercentage = jobDetail.getProfilePercentage();
    requiredProfilePercentage = isEmpty(jobDetail.getProfileRequired()) ? 0 : Integer.parseInt(jobDetail.getProfileRequired());
    tvAmount.setText(getSalary(jobDetail.getSalary()));
    tvDescription.setText(jobDetail.getDescription());
    tvJobLocation.setText(jobDetail.getLocation());
    tvLocation.setText(jobDetail.getLocation());
    tvRef.setText(getString(R.string.ref, jobDetail.getReference()));
    if (isEmpty(jobDetail.getU_company())) {
      tvCompanyName.setText(jobDetail.getfName() + " " + jobDetail.getlName());
    } else {
      tvCompanyName.setText(jobDetail.getU_company());
    }
    tvExperience.setText(getString(R.string.experience_label_year,
        String.valueOf(jobDetail.getExperienceRequired())));
    tvOtherBenefits.setText(jobDetail.getOtherBenefits());
    tvRequiredQuality.setText(jobDetail.getQuality());
    tvSalary.setText(String.format(Locale.ENGLISH, "%s%s", jobDetail.getSalary(), getEuro()));
    tvMapAddress.setText(jobDetail.getLocation());
    tvMapAddress.setText(jobDetail.getLocation());
    tvDTitle.setText(jobDetail.getdTitle());
    String month = getDateDifference(jobDetail.getStartDate(), jobDetail.getEndDate());
    tvContractLength.setText(month);
    if (!isEmpty(jobDetail.getStartDate())) {
      tvStartDate.setText(showDate(jobDetail.getStartDate()));
    }
    if (!isEmpty(jobDetail.getEndDate())) {
      tvEndDate.setText(showDate(jobDetail.getEndDate()));
    }
    if (!isEmpty(jobDetail.getCreatedAt())) {
      tvCreateTime.setText(showDate(jobDetail.getCreatedAt()));
      tvPostedDate.setText(showDate(jobDetail.getCreatedAt()));
      tvMapCreatedTime.setText(showDate(jobDetail.getCreatedAt()));
    }
    mVideoUrl = jobDetail.getVideoUrl();
    Glide.with(this).load(jobDetail.getuImageUrl()).placeholder(R.drawable.user_placeholder).dontAnimate().into(userImage);
    if (!isEmpty(jobDetail.getVideoUrl())) {
      Glide.with(this).load(jobDetail.getmImageList().get(0).getImageUrl()).placeholder(R.drawable.placeholder).dontAnimate().into(imageVideo);
    } else {
      videoFrame.setVisibility(View.GONE);
    }
    Glide.with(this).load(getString(R.string.map_image, jobDetail.getLat() + "," + jobDetail.getLng())).placeholder(R.drawable.placeholder).dontAnimate().into(imageMap);
  }

  @OnClick(R.id.imageVideo) void onVideo() {
    if (isEmpty(mVideoUrl)) {
      return;
    }
    openUrl(getActivity(), mVideoUrl);
  }

  @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
    LOGI(TAG, "here onActivity result fragment");
    callbackManager.onActivityResult(requestCode, resultCode, data);
    super.onActivityResult(requestCode, resultCode, data);
  }

  private String getDateDifference(String strDate, String endDate) {
    if (isEmpty(strDate) || isEmpty(endDate)) {
      return "N/A";
    }
    Long _sLong = Long.parseLong(strDate);
    Long _eLong = Long.parseLong(endDate);
    DateTime _startDate = new DateTime(_sLong * 1000L);
    DateTime _endDate = new DateTime(_eLong * 1000L);
    int month = Months.monthsBetween(_startDate.withTimeAtStartOfDay(), _endDate.withTimeAtStartOfDay()).getMonths();
    return getString(R.string.months, month);
  }

  @Override public void onBack(View view) {
    super.onBack(view);
    getActivity().onBackPressed();
  }

  @Override public void onResume() {
    super.onResume();
    setWhiteToolbar();
    showRightImage(true);
  }

  @Override public void onRight(View view) {
    super.onRight(view);
    Intent intent = new Intent(getActivity(), ShareActivity.class);
    intent.putExtra(Constants.KEY_OBJECT, jobDetail);
    startActivity(intent);
  }

  /**
   * for sup text format
   *
   * @param value text
   * @return html string
   */
  private Spanned getSalary(String value) {
    value = isEmpty(value) ? "0" : value;
    try {
      return Html.fromHtml(Utils.decimalFormat(Double.valueOf(value))
          + "<small><sup> "
          + getEuro()
          + "/M </sup></small>");
    } catch (Exception e) {
      LOGI(TAG, Log.getStackTraceString(e));
    }
    return Html.fromHtml("0");
  }

  @OnClick({R.id.linearProgress, R.id.tvApplyJob, R.id.tvReport, R.id.ivFav, R.id.ivFB, R.id.ivMail}) void onClick(View view) {
    if (view.getId() == R.id.ivFav) {
      presenter.callFavoriteOffer(jobDetail.getId());
    } else if (view.getId() == R.id.tvApplyJob) {
      if (profilePercentage >= requiredProfilePercentage) {
        presenter.applyJob();
      } else {
        Utils.showDialog(getActivity(), getString(R.string.alert),getString(R.string.complete_profile), getString(R.string.ok),
            new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
              }
            }).show();
      }
    } else if (view.getId() == R.id.tvReport) {
      presenter.report();
    } else if (view.getId() == R.id.ivFB) {
      send();
    } else if (view.getId() == R.id.ivMail) {
      sendEmail();
    }
  }

  protected void sendEmail() {
    Log.i("Send email", "");
    String[] TO = { "" };
    String[] CC = { "" };
    Intent emailIntent = new Intent(Intent.ACTION_SEND);

    emailIntent.setData(Uri.parse("mailto:"));
    emailIntent.setType("text/plain");
    emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
    emailIntent.putExtra(Intent.EXTRA_CC, CC);
    emailIntent.putExtra(Intent.EXTRA_SUBJECT, jobDetail.getTitle());
    emailIntent.putExtra(Intent.EXTRA_TEXT, getMailText());
    try {
      startActivity(Intent.createChooser(emailIntent, "Send mail..."));
    } catch (android.content.ActivityNotFoundException ex) {
      Utils.showMessage(getActivity(), "There is no email client installed.");
    }
  }

  private String getMailText() {
    return "Hi there,"
        + "\n"
        + "Check out this job "
        + jobDetail.getTitle()
        + "\n"
        + getString(R.string.description)
        + ": "
        + jobDetail.getDescription()
        + "\n"
        + getString(R.string.gross_salary)
        + ": "
        + getSalary(jobDetail.getSalary())
        + "\n"
        + getString(R.string.experience)
        + ": "
        + getString(R.string.experience_label_year,
        String.valueOf(jobDetail.getExperienceRequired()))
        + "\n"
        + getString(R.string.required_qualities_label)
        + " "
        + jobDetail.getQuality()
        + "\n"
        + getString(R.string.other_benefits_label)
        + " "
        + jobDetail.getOtherBenefits()
        + "\n"
        + "https://play.google.com/store/apps/details?id="
        + getActivity().getPackageName();
  }

  @Override public RecyclerViewPager getRecyclerPager() {
    return mRecyclerViewPager;
  }

  @Override public void setAddress(String address) {
    tvUserAddress.setText(address);
  }

  @Override public int getProfilePercentage() {
    return profilePercentage;
  }

  @Override public void showProfileCompleteDialog() {
    CreateAccFragment createAccFragment = new CreateAccFragment();
    Bundle bundle = new Bundle();
    bundle.putInt(Constants.KEY_VISIBLE_TYPE, Constants.PROFILE_VISIBLE_TYPE1);
    createAccFragment.setArguments(bundle);
    createAccFragment.show(getFragmentManager(), createAccFragment.getClass().getName());
  }

  @Override public void showAppliedDialog() {
    tvApplyJob.setBackgroundResource(R.drawable.green_postule_bg);
    BaseFragment fragment = (BaseFragment) getTargetFragment();
    if (fragment != null) {
      fragment.updateList(getArguments().getString(Constants.KEY_ID));
    }
    InviteFragment inviteFragment = new InviteFragment();
    Bundle bundle = new Bundle();
    bundle.putInt(Constants.KEY_DIALOG_TYPE, Constants.JOB_APPLIED_TYPE);
    inviteFragment.setArguments(bundle);
    inviteFragment.show(getFragmentManager(), inviteFragment.getClass().getSimpleName());
  }

  @Override public void changeFavorite() {
    favoriteJob = !favoriteJob;
    if (favoriteJob) {
      ivFav.setImageResource(R.drawable.new_fav_select);
    } else {
      ivFav.setImageResource(R.drawable.new_fav_unselect);
    }
  }

  @Override public void showError(String s) {
    Utils.showDialog(getActivity(), getString(R.string.alert), s, getString(R.string.ok),
        new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            getFragmentManager().popBackStack();
          }
        }).show();
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void onDestroyView() {
    presenter.detachView();
    unbinder.unbind();
    setTitle("");
    super.onDestroyView();
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public boolean onBackPressed() {
    getFragmentManager().popBackStack();
    return true;
  }

  private void send() {
    if (ShareDialog.canShow(SharePhotoContent.class)) {
      ShareLinkContent linkContent =
          new ShareLinkContent.Builder().setContentTitle(jobDetail.getTitle())
              .setContentDescription(getMailText())
              .setContentUrl(Uri.parse(getImageUrl()))
              .setImageUrl(Uri.parse(getImageUrl()))
              .build();
      ShareDialog.show(this, linkContent);
    }
  }

  private String getImageUrl() {
    List<PhotoModel> imageModels = jobDetail.getmImageList();
    if (!imageModels.isEmpty()) {
      LOGI(TAG, "image url is " + imageModels.get(0).getImageUrl());
      return imageModels.get(0).getImageUrl();
    }
    return "https://play.google.com/store/apps/details?id=" + getActivity().getPackageName();
  }
}
