/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import com.bnbjobs.ProHelperImpl;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.ProHelper;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.PhoneNumberView;
import com.trello.rxlifecycle.ActivityEvent;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;

/**
 * @author Harsh
 * @version 1.0
 */
public class PhoneNumberPresenter extends BasePresenter implements Presenter<PhoneNumberView> {

  private PhoneNumberView mPhoneNumberView;

  @Override public void attachView(PhoneNumberView view) {
    this.mPhoneNumberView = view;
  }

  @Override public void detachView() {
    mPhoneNumberView = null;
  }

  public void getOtp(String phoneNumber) {
    mPhoneNumberView.showProgress();
    HashMap<String, String> params = new HashMap<>();
    if (new ProHelperImpl().isPro()) {
      params.put("apiName", "verifyPhoneNumber");
      params.put("phoneNumber", phoneNumber);
      params.putAll(addParams(params));
    } else {
      params.put("apiName", "resendOTP");
      params.put("number", phoneNumber);
      params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
    }

    RestClient.getInstance(params)
        .compose(((BaseActivity) getBaseContext()).<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            mPhoneNumberView.hideProgress();
            if (e.getMessage() != null) {
              Utils.showMessage(getBaseContext(), e.getMessage());
            }
          }

          @Override public void onNext(String s) {
            mPhoneNumberView.hideProgress();
            try {
              JSONObject object;
              object = new JSONObject(s);
              if (Utils.isResponseSuccess(s)) {
                Utils.showMessage(getBaseContext(), "Otp sent successfully.");
                mPhoneNumberView.showMessage(object.optString("OTP"));
              } else {
                Utils.showMessage(getBaseContext(), object.optString("message"));
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  public void verifyPhoneNumber(String phoneNumber) {
    mPhoneNumberView.showProgress();
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "verifyPhoneToken");
    params.putAll(addParams(params));
    params.put("phoneToken", phoneNumber);

    RestClient.getInstance(params)
        .compose(((BaseActivity) getBaseContext()).<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            mPhoneNumberView.hideProgress();
            if (e.getMessage() != null) {
              Utils.showMessage(getBaseContext(), e.getMessage());
            }
          }

          @Override public void onNext(String s) {
            mPhoneNumberView.hideProgress();
            try {
              JSONObject object;
              object = new JSONObject(s);
              if (Utils.isResponseSuccess(s)) {
                JSONObject userObject = object.getJSONObject("data");
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_PHONENUMBER,
                    userObject.optString("u_phone"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_PHONE_VERIFIED, 1);
                mPhoneNumberView.showVerified();
              } else {
                Utils.showMessage(getBaseContext(), object.optString("message"));
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  @Override protected Context getBaseContext() {
    return mPhoneNumberView.getContext();
  }
}
