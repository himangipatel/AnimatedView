/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.CandidateModel;
import com.bnbjobs.utils.Utils;
import com.bumptech.glide.Glide;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class CandidateRequestAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

  private final int VIEW_TYPE_ITEM = 0;
  private final int VIEW_TYPE_LOADING = 1;
  private final List<CandidateModel> candidateRequestList;
  private final Context context;
  private ClickImpl mClick;
  private int type;

  public CandidateRequestAdapter(Context context, List<CandidateModel> candidateRequestList,
      Fragment fragment) {
    this.context = context;
    this.candidateRequestList = candidateRequestList;
    mClick = (ClickImpl) fragment;
  }

  public void setType(int type) {
    this.type = type;
  }

  @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    if (viewType == VIEW_TYPE_ITEM) {
      return new SimpleViewHolder(LayoutInflater.from(parent.getContext())
          .inflate(R.layout.candidate_request_inflater, parent, false));
    } else if (viewType == VIEW_TYPE_LOADING) {
      View view =
          LayoutInflater.from(parent.getContext()).inflate(R.layout.progress, parent, false);
      return new LoadingViewHolder(view);
    }
    return null;
  }

  @Override public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
    if (holder instanceof SimpleViewHolder) {
      SimpleViewHolder mHolder = (SimpleViewHolder) holder;
      int applyBtnFlag = candidateRequestList.get(position).getApplyJobBtnFlag();
      if (applyBtnFlag == 4) {
        //reject
        mHolder.tvAccept.setVisibility(View.GONE);
        mHolder.tvReject.setVisibility(View.VISIBLE);
        mHolder.tvReject.setText(context.getString(R.string.refused));
      } else if (applyBtnFlag == 3) {
        //accept
        mHolder.tvAccept.setVisibility(View.VISIBLE);
        mHolder.tvAccept.setText(context.getString(R.string.approve));
        mHolder.tvReject.setVisibility(View.GONE);
      } else {
        mHolder.tvAccept.setVisibility(View.VISIBLE);
        mHolder.tvAccept.setText(context.getString(R.string.accept));
        mHolder.tvReject.setText(context.getString(R.string.refuse));
        mHolder.tvReject.setVisibility(View.VISIBLE);
      }
      if (type == 4) {
        //for favorite not show accept reject button
        mHolder.linearApply.setVisibility(View.GONE);
      } else {
        mHolder.linearApply.setVisibility(View.VISIBLE);
      }
      Glide.with(context)
          .load(candidateRequestList.get(position).getuThumbImage())
          .placeholder(R.drawable.placeholder)
          .dontAnimate()
          .into(mHolder.ivCandidatePic);
      mHolder.tvCandidateName.setText(
          candidateRequestList.get(position).getfName() + " " + candidateRequestList.get(position)
              .getlName());
      mHolder.tvCandidateJobName.setText(candidateRequestList.get(position).getTitle());
    } else {
      LoadingViewHolder loadingViewHolder = (LoadingViewHolder) holder;
      loadingViewHolder.progressBar.setVisibility(View.VISIBLE);
      loadingViewHolder.progressBar.setIndeterminate(true);
    }
  }

  @Override public int getItemViewType(int position) {
    return candidateRequestList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
  }

  @Override public int getItemCount() {
    return candidateRequestList == null ? 0 : candidateRequestList.size();
  }

  private static class LoadingViewHolder extends RecyclerView.ViewHolder {

    ProgressBar progressBar;

    LoadingViewHolder(View itemView) {
      super(itemView);
      ProgressBar progressBarHor = (ProgressBar) itemView.findViewById(R.id.progressBar);
      progressBarHor.setVisibility(View.INVISIBLE);
      progressBar = (ProgressBar) itemView.findViewById(R.id.progressBarVertical);
    }
  }

  class SimpleViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.ivCandidatePic) ImageView ivCandidatePic;
    @BindView(R.id.tvCandidateName) TextView tvCandidateName;
    @BindView(R.id.tvCandidateJobName) TextView tvCandidateJobName;
    @BindView(R.id.tvAccept) TextView tvAccept;
    @BindView(R.id.tvReject) TextView tvReject;
    @BindView(R.id.tvSendMessage) TextView tvSendMessage;
    @BindView(R.id.linearRoot) LinearLayout linearRoot;
    @BindView(R.id.linearApply) LinearLayout linearApply;

    SimpleViewHolder(View view) {
      super(view);
      ButterKnife.bind(this, view);
      linearRoot.getLayoutParams().width = (int) (Utils.getScreenWidth(context) * 0.45f);
      view.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          mClick.onClick(v, candidateRequestList.get(getLayoutPosition()), getLayoutPosition());
        }
      });
    }

    @OnClick({ R.id.tvAccept, R.id.tvReject }) void onAcceptStatus(View v) {
      if (candidateRequestList.get(getLayoutPosition()).getApplyJobBtnFlag() == 3
          || candidateRequestList.get(getLayoutPosition()).getApplyJobBtnFlag() == 4) {
        return;
      }
      mClick.onClick(v, candidateRequestList.get(getLayoutPosition()), getLayoutPosition());
    }
  }
}

