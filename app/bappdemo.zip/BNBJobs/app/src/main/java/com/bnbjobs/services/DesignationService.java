/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.services;

import android.app.IntentService;
import android.content.Intent;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.model.DesignationDbModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.LocaleHelper;
import com.bnbjobs.utils.Prefs;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import io.realm.Realm;
import java.util.HashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Observer;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.Utils.isResponseSuccess;

/**
 * @author Harsh
 * @version 1.0
 */
public class DesignationService extends IntentService {

  private static final String TAG = DesignationService.class.getName();
  private Realm realm;

  /**
   * Creates an IntentService.  Invoked by your subclass's constructor.
   */
  public DesignationService() {
    super(DesignationService.class.getSimpleName());
    realm = Realm.getDefaultInstance();
  }

  @Override protected void onHandleIntent(Intent intent) {
    saveDesignation();
  }

  private void saveDesignation() {
    boolean isSaved = Prefs.with(this).getBoolean(QuickstartPreferences.KEY_ALL_SAVE, false);
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "getAllDesignations");
    params.put("language", LocaleHelper.getLanguage(this));
    params.put("userId", getPrefs(this).getString(QuickstartPreferences.USER_ID, ""));
    params.put("accessToken",
        getPrefs(this).getString(QuickstartPreferences.ACCESS_TOKEN, ""));
    if (isSaved) {
      params.put("timestamp", Long.toString(System.currentTimeMillis() / 1000));
    }
    RestClient.getInstance(params).subscribe(new Observer<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
      }

      @Override public void onNext(String s) {
        try {
          JSONObject jsonObject = new JSONObject(s);
          if (isResponseSuccess(s)) {
            JSONObject data = jsonObject.getJSONObject("data");
            JSONArray array = data.getJSONArray("inserted");
            List<DesignationDbModel> designationDbModels =
                new Gson().fromJson(array.toString(), new TypeToken<List<DesignationDbModel>>() {
                }.getType());
            realm.beginTransaction();
            realm.copyToRealmOrUpdate(designationDbModels);
            JSONArray arrayUpdated = data.getJSONArray("updated");
            List<DesignationDbModel> dbModels = new Gson().fromJson(arrayUpdated.toString(),
                new TypeToken<List<DesignationDbModel>>() {
                }.getType());
            realm.copyToRealmOrUpdate(dbModels);
            realm.commitTransaction();
            Prefs.with(DesignationService.this).save(QuickstartPreferences.KEY_ALL_SAVE, true);
            realm.close();
          }
        } catch (JSONException e) {
          e.printStackTrace();
        }
      }
    });
  }
}
