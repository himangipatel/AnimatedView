/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.StringRes;
import android.support.v4.app.Fragment;
import android.support.v4.content.CursorLoader;
import android.support.v7.app.AlertDialog;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.LocaleHelper;
import com.bnbjobs.utils.Utils;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import okhttp3.MediaType;
import okhttp3.RequestBody;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.getDeviceId;
import static com.bnbjobs.utils.Utils.showDialog;
import static com.bnbjobs.utils.Utils.showNetworkDialog;

/**
 * @author Harsh
 * @version 1.0
 */

public abstract class BasePresenter {

  /**
   * Request codes for camera, gallery and crop image operations
   */
  protected static final int REQUEST_CODE_CAMERA = 1001;
  protected static final int REQUEST_CODE_GALLERY = 1002;
  protected static final int REQUEST_CODE_VIDEO = 1003;
  protected static final int REQUEST_CODE_VIDEO_CAMERA = 1004;
  protected static final String TAG = makeLogTag(BasePresenter.class);
  /**
   * The path where Camera saves the image
   */
  protected String mCameraOutputPath;

  public static RequestBody toRequestBody(String value) {
    return RequestBody.create(MediaType.parse("text/plain"), value);
  }

  protected static String getKm(double meters) {
    double kilometers = meters * 0.001;
    return new DecimalFormat("#.##").format(kilometers) + " Km";
  }

  protected void showNetworkError() {
    showNetworkDialog(getBaseContext(), new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        dialog.dismiss();
      }
    }).show();
  }

  protected abstract Context getBaseContext();

  protected HashMap<String, String> addDefaultParams(HashMap<String, String> params) {
    params.put("language", getLanguage());
    params.put("deviceType", "2");
    params.put("deviceToken",
        getPrefs(getBaseContext()).getString(QuickstartPreferences.REGISTRATION_TOKEN, ""));
    params.put("uniqueToken", getDeviceId(getBaseContext()));
    return params;
  }

  protected HashMap<String, String> addDefaultParamsWitLat(HashMap<String, String> params) {
    params.put("language", getLanguage());
    params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
    params.put("accessToken",
        getPrefs(getBaseContext()).getString(QuickstartPreferences.ACCESS_TOKEN, ""));
    params.put("latitude", getPrefs(getBaseContext()).getString(QuickstartPreferences.LAT, ""));
    params.put("longitude", getPrefs(getBaseContext()).getString(QuickstartPreferences.LNG, ""));
    return params;
  }

  protected HashMap<String, String> addParams(HashMap<String, String> params) {
    params.put("language", getLanguage());
    params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
    params.put("accessToken",
        getPrefs(getBaseContext()).getString(QuickstartPreferences.ACCESS_TOKEN, ""));
    return params;
  }

  protected HashMap<String, RequestBody> addParamsBody(HashMap<String, RequestBody> params) {
    params.put("language", toRequestBody(getLanguage()));
    params.put("userId", toRequestBody(getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, "")));
    params.put("accessToken", toRequestBody(getPrefs(getBaseContext()).getString(QuickstartPreferences.ACCESS_TOKEN, "")));
    return params;
  }

  protected String getLanguage() {
    return LocaleHelper.getLanguage(getBaseContext());
  }

  /**
   * Checks if the device has network connectivity
   *
   * @return true if network is connected
   */
  protected boolean hasNetworkConnectivity() {
    return Utils.hasNetworkConnectivity(getBaseContext());
  }

  protected AlertDialog imagePicker(DialogInterface.OnClickListener onClickListener,
      boolean isImageSet) {
    CharSequence[] items;
    if (isImageSet) {
      items = new CharSequence[] {
          getBaseContext().getString(R.string.change_photo_camera),
          getBaseContext().getString(R.string.change_photo_gallery),
          getBaseContext().getString(R.string.set_default_image)
      };
    } else {
      items = new CharSequence[] {
          getBaseContext().getString(R.string.change_photo_camera),
          getBaseContext().getString(R.string.change_photo_gallery)
      };
    }
    return new AlertDialog.Builder(getBaseContext()).setTitle(
        getBaseContext().getString(R.string.change_photo_title))
        .setItems(items, onClickListener)
        .create();
  }

  protected void requestImageFromCamera() {
    try {
      File outputDir =
          new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
              "temp");
      if (!outputDir.exists()) {
        if (!outputDir.mkdir()) {
          LOGI(TAG, "Error creating image file for camera output.");
          return;
        }
      }
      File outputFile =
          File.createTempFile(String.valueOf(System.currentTimeMillis()), ".jpg", outputDir);
      mCameraOutputPath = outputFile.getAbsolutePath();
      Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
      intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(outputFile));
      ((BaseActivity) getBaseContext()).startActivityForResult(intent, REQUEST_CODE_CAMERA);
    } catch (Exception e) {
      LOGI(TAG, "Error requesting photo from camera. " + e.getMessage());
    }
  }

  protected void requestImageFromCamera(int reqCode) {
    try {
      File outputDir =
          new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
              "temp");
      if (!outputDir.exists()) {
        if (!outputDir.mkdir()) {
          LOGI(TAG, "Error creating image file for camera output.");
          return;
        }
      }
      File outputFile =
          File.createTempFile(String.valueOf(System.currentTimeMillis()), ".jpg", outputDir);
      mCameraOutputPath = outputFile.getAbsolutePath();
      Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
      intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(outputFile));
      ((BaseActivity) getBaseContext()).startActivityForResult(intent, reqCode);
    } catch (Exception e) {
      LOGI(TAG, "Error requesting photo from camera. " + e.getMessage());
    }
  }

  /**
   * requestImageFromGallery
   * Open photo gallery to choose a photo
   */
  protected void requestImageFromGallery() {
    Intent intent = new Intent(Intent.ACTION_PICK,
        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
    intent.setType("image/*");
    ((BaseActivity) getBaseContext()).startActivityForResult(
        Intent.createChooser(intent, getBaseContext().getString(R.string.change_photo_gallery)),
        REQUEST_CODE_GALLERY);
  }

  /**
   * requestImageFromGallery
   * Open photo gallery to choose a photo
   */
  protected void requestImageFromGallery(int reqCode) {
    Intent intent = new Intent(Intent.ACTION_PICK,
        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
    intent.setType("image/*");
    ((BaseActivity) getBaseContext()).startActivityForResult(
        Intent.createChooser(intent, getBaseContext().getString(R.string.change_photo_gallery)),
        reqCode);
  }

  protected String getRealPathFromURI(Uri contentUri) {
    String[] proj = { MediaStore.Images.Media.DATA };
    CursorLoader cursorLoader =
        new CursorLoader(getBaseContext(), contentUri, proj, null, null, null);
    Cursor cursor = cursorLoader.loadInBackground();
    int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
    cursor.moveToFirst();
    return cursor.getString(column_index);
  }

  protected String getRealPathFromURIVideo(Uri contentUri) {
    String[] proj = { MediaStore.Video.Media.DATA };
    CursorLoader cursorLoader =
        new CursorLoader(getBaseContext(), contentUri, proj, null, null, null);
    Cursor cursor = cursorLoader.loadInBackground();
    int column_index = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
    cursor.moveToFirst();
    return cursor.getString(column_index);
  }

  protected String getString(@StringRes int strRes) {
    return getBaseContext().getString(strRes);
  }

  protected String getAddress(String lat, String lng) {
    Geocoder geocoder = new Geocoder(getBaseContext(), Locale.getDefault());
    List<Address> addresses = null;
    try {
      addresses = geocoder.getFromLocation(Double.parseDouble(lat), Double.parseDouble(lng), 1);
    } catch (IOException | IllegalArgumentException ioException) {
      LOGE(TAG, ioException.getMessage(), ioException);
    }
    if (addresses == null || addresses.size() == 0) {
      return "";
    } else {
      Address address = addresses.get(0);
      return address.getLocality();
    }
  }

  protected LifecycleTransformer<String> bindEvent(Fragment fragment) {
    return ((BaseFragment) fragment).<String>bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  protected AlertDialog videoPicker(DialogInterface.OnClickListener onClickListner) {
    CharSequence[] items;

    items = new CharSequence[] {
        getBaseContext().getString(R.string.change_video_camera),
        getBaseContext().getString(R.string.change_photo_gallery),
    };

    return new AlertDialog.Builder(getBaseContext()).setTitle("Video")
        .setItems(items, onClickListner)
        .create();
  }

  protected void showDialogMessage(String message) {
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), message,
        getBaseContext().getString(R.string.ok), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }

  protected boolean isCandidate() {
    return getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_TYPE, "")
        .equalsIgnoreCase(Constants.CANDIDATE);
  }
}
