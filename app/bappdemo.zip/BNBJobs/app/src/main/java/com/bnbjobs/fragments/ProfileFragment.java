/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spanned;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.activity.EditExperienceActivity;
import com.bnbjobs.activity.EditProfileActivity;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.activity.PurchaseActivity;
import com.bnbjobs.adapter.CandidateApplyAdapter;
import com.bnbjobs.adapter.ExperienceAdapter;
import com.bnbjobs.adapter.FormationAdapter;
import com.bnbjobs.adapter.HomeAdapter;
import com.bnbjobs.adapter.LanguageAdapter;
import com.bnbjobs.adapter.ProfileImagesAdapter;
import com.bnbjobs.adapter.SkillAdapter;
import com.bnbjobs.customui.views.CircleImageView;
import com.bnbjobs.customui.views.CircularProgressBar;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.CandidateModel;
import com.bnbjobs.model.DescriptionUpdate;
import com.bnbjobs.model.Experience;
import com.bnbjobs.model.FormationModel;
import com.bnbjobs.model.ImageModel;
import com.bnbjobs.model.JobApplyModel;
import com.bnbjobs.model.JobModel;
import com.bnbjobs.model.LanguageModel;
import com.bnbjobs.model.PaymentAction;
import com.bnbjobs.model.ProfileData;
import com.bnbjobs.model.ProfileUpdate;
import com.bnbjobs.model.SkillModel;
import com.bnbjobs.model.UserModel;
import com.bnbjobs.model.UserProfileData;
import com.bnbjobs.presenter.ProfilePresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.SpacesItemDecoration;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.ProfileView;
import com.bumptech.glide.Glide;
import com.nispok.snackbar.Snackbar;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.OnClickListener;
import com.orhanobut.dialogplus.OnDismissListener;
import com.orhanobut.dialogplus.ViewHolder;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.collections4.IterableUtils;
import org.apache.commons.collections4.Predicate;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnNeverAskAgain;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.ActivityUtils.launchActivity;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
@RuntimePermissions public class ProfileFragment extends BaseFragment
    implements ProfileView, ClickImpl<Object> {

  private final static String TAG = makeLogTag(ProfileFragment.class);
  private static final int SKILL = 1111;
  private static final int TRAINING = 1112;
  private static final int LANGUAGE = 1113;
  @BindView(R.id.circularprogressbar) CircularProgressBar circularprogressbar;
  @BindView(R.id.iv_profile_pic) CircleImageView ivProfilePic;
  @BindView(R.id.tv_user_name) TextView tvUserName;
  @BindView(R.id.tv_designation) TextView tvDesignation;
  @BindView(R.id.tv_user_city) TextView tvUserCity;
  @BindView(R.id.tv_user_intro) EditText tvUserIntro;
  @BindView(R.id.recycler_experience) RecyclerView recyclerExperience;
  @BindView(R.id.recycler_formations) RecyclerView recyclerFormations;
  @BindView(R.id.recycler_compretances) RecyclerView recyclerSkill;
  @BindView(R.id.iv_video_preview) ImageView ivVideoPreview;
  @BindView(R.id.iv_video_play) ImageView ivVideoPlay;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.tvProfilePercent) TextView tvProfilePercent;
  @BindView(R.id.ivTakePicture) ImageView ivTakePicture;
  @BindView(R.id.rel_center_view) RelativeLayout relCenterView;
  @BindView(R.id.tvSkipPremium) TextView tvSkipPremium;
  @BindView(R.id.relativeTop) RelativeLayout relativeTop;
  @BindView(R.id.tv_experience_label) TextView tvExperienceLabel;
  @BindView(R.id.tvAddExp) TextView tvAddExp;
  @BindView(R.id.tv_formations_label) TextView tvFormationsLabel;
  @BindView(R.id.tvAddTraining) TextView tvAddTraining;
  @BindView(R.id.tvAddLanguage) TextView tvAddLanguage;
  @BindView(R.id.tv_compretances_label) TextView tvCompretancesLabel;
  @BindView(R.id.tvAddSkill) TextView tvAddSkill;
  @BindView(R.id.imgSkillEdit) ImageView imgSkillEdit;
  @BindView(R.id.imgEditExperience) ImageView imgEditExperience;
  @BindView(R.id.imgFormationEdit) ImageView imgFormationEdit;
  @BindView(R.id.imgEditLanguage) ImageView imgEditLanguage;
  @BindView(R.id.imgEditPhoto) ImageView imgEditPhoto;
  @BindView(R.id.imgEditVideo) ImageView imgEditVideo;
  @BindView(R.id.tv_photos_label) TextView tvPhotosLabel;
  @BindView(R.id.tv_label_video) TextView tvLabelVideo;
  @BindView(R.id.tvAddVideo) TextView tvAddVideo;
  @BindView(R.id.linearRecruiterBottom) LinearLayout linearRecruiterBottom;
  @BindView(R.id.recyclerViewPhoto) RecyclerView recyclerViewPhoto;
  @BindView(R.id.recyclerLanguage) RecyclerView recyclerLanguage;
  @BindView(R.id.nestedScrollView) NestedScrollView nestedScrollView;
  @BindView(R.id.linearRemove) LinearLayout mLinearRemove;
  @BindView(R.id.imageRemove) ImageView imageRemove;
  @BindView(R.id.linearCvPublished) LinearLayout linearCvPublished;
  @BindView(R.id.ivEdit) ImageView ivEdit;
  @BindView(R.id.imgCv) ImageView imgCv;
  @BindView(R.id.relativeVideo) RelativeLayout relativeVideo;
  @BindView(R.id.tvNoPhoto) TextView tvNoPhoto;
  @BindView(R.id.tvNoVideo) TextView tvNoVideo;
  @BindView(R.id.recyclerViewAccept) RecyclerView recyclerViewAccept;
  @BindView(R.id.favRecyclerView) RecyclerView favRecyclerView;
  @BindView(R.id.tvCharacter) TextView tvCharacter;
  @BindView(R.id.tvError) TextView tvError;
  @BindView(R.id.linearFavorite) LinearLayout linearFavorite;

  private Unbinder unbinder;
  private ProfilePresenter presenter;
  private ExperienceAdapter mExperienceAdapter;
  private SkillAdapter mSkillAdapter;
  private FormationAdapter mFormationAdapter;
  private LanguageAdapter mLanguageAdapter;
  private ProfileImagesAdapter profileImagesAdapter;
  private CandidateApplyAdapter candidateApplyAdapter;
  private ArrayList<Experience> mExperienceList = new ArrayList<>();
  private List<FormationModel> mFormationList = new ArrayList<>();
  private List<SkillModel> mSkillList = new ArrayList<>();
  private List<ImageModel> mPhotoList = new ArrayList<>();
  private List<LanguageModel> mLanguageModelList = new ArrayList<>();
  private List<JobApplyModel> jobApplyList = new ArrayList<>();
  private int ratingBarHeight;
  private boolean isImageSet;
  private String path = null;
  private int videoId = 0;
  private boolean planPurchaseFlg;
  private boolean isOtherProfile;
  private boolean isAcceptStatus;
  private CandidateModel candidateModel;
  private int tempPosition;
  private boolean isVideoEdit;
  // for temp save edit position of formation,skill and language
  private int editPosition;
  private boolean favoriteFlag;
  private boolean isProfileEdit;
  private EditText etSkill;
  private RatingBar mRatingBar;
  private DialogPlus dialog;
  private List<JobModel> mFavoriteList = new ArrayList<>();
  private CandidateModel mHomeCandidateModel;
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    Drawable ratingBar = ContextCompat.getDrawable(getActivity(), R.drawable.select_star);
    ratingBarHeight = ratingBar.getIntrinsicHeight();
    View view = inflater.inflate(R.layout.fragment_profile, container, false);
    unbinder = ButterKnife.bind(this, view);
    EventBus.getDefault().register(this);
    if (savedInstanceState == null) {
      nestedScrollView.setVisibility(View.GONE);
    }
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    if (presenter == null) {
      presenter = new ProfilePresenter();
    }
    presenter.attachView(this);
    presenter.setFragment(this);
    if (getArguments() != null) {
      presenter.setCandidateId(getArguments().getString(Constants.KEY_ID));
      isAcceptStatus = !getArguments().getBoolean(Constants.KEY_VISIBLE_TYPE);
      candidateModel = getArguments().getParcelable(Constants.KEY_OBJECT);
      mHomeCandidateModel = getArguments().getParcelable(Constants.KEY_MODEL);
      isOtherProfile = true;
    }
    presenter.setRecyclerViewLayoutManagers(favRecyclerView);
    if (mExperienceAdapter == null) {
      mExperienceAdapter = new ExperienceAdapter(getActivity(), mExperienceList, this);
    }
    if (getArguments() != null) {
      presenter.setCandidateId(getArguments().getString(Constants.KEY_ID));
    }
    if (mLanguageAdapter == null) {
      mLanguageAdapter = new LanguageAdapter(getActivity(), mLanguageModelList, this);
    }
    recyclerLanguage.setNestedScrollingEnabled(false);
    recyclerLanguage.setLayoutManager(new LinearLayoutManager(getContext()));
    recyclerLanguage.setAdapter(mLanguageAdapter);
    recyclerExperience.setNestedScrollingEnabled(false);
    recyclerExperience.setLayoutManager(new LinearLayoutManager(getContext()));
    recyclerExperience.setAdapter(mExperienceAdapter);

    if (profileImagesAdapter == null) {
      profileImagesAdapter = new ProfileImagesAdapter(getActivity(), mPhotoList, this);
    }
    if (candidateApplyAdapter == null) {
      candidateApplyAdapter = new CandidateApplyAdapter(getActivity(), jobApplyList, this);
    }
    recyclerViewAccept.setNestedScrollingEnabled(false);
    recyclerViewAccept.setLayoutManager(new LinearLayoutManager(getContext()));
    recyclerViewAccept.setAdapter(candidateApplyAdapter);

    recyclerViewPhoto.setNestedScrollingEnabled(false);
    recyclerViewPhoto.setLayoutManager(
        new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
    int spacingInPixels = getResources().getDimensionPixelSize(R.dimen._5sdp);
    recyclerViewPhoto.addItemDecoration(new SpacesItemDecoration(spacingInPixels));
    recyclerViewPhoto.setAdapter(profileImagesAdapter);

    if (mSkillAdapter == null) {
      mSkillAdapter = new SkillAdapter(getActivity(), mSkillList, this);
    }
    recyclerSkill.setLayoutManager(new LinearLayoutManager(getContext()));
    recyclerSkill.setNestedScrollingEnabled(false);
    recyclerSkill.setAdapter(mSkillAdapter);

    if (mFormationAdapter == null) {
      mFormationAdapter = new FormationAdapter(getActivity(), mFormationList, this);
    }
    recyclerFormations.setLayoutManager(new LinearLayoutManager(getContext()));
    recyclerFormations.setNestedScrollingEnabled(false);
    recyclerFormations.setAdapter(mFormationAdapter);

    int height = getResources().getDimensionPixelOffset(R.dimen._200sdp) * 2;
    HomeAdapter adapter = new HomeAdapter(getActivity(), height, mFavoriteList, this);
    adapter.setIsFavorite(true);
    favRecyclerView.setAdapter(adapter);
    showFavoriteList(!mFavoriteList.isEmpty());
    presenter.getProfile();

    if (isCandidate()) {
      tvUserIntro.setEnabled(true);
      presenter.getFavoriteJobOffer(1);
    } else {
      ivTakePicture.setVisibility(View.GONE);
      tvCharacter.setVisibility(View.GONE);
      tvUserIntro.setEnabled(false);
      linearFavorite.setVisibility(View.GONE);
    }
    tvUserIntro.addTextChangedListener(presenter.descriptionWatcher);
    setRightImage(R.drawable.top_check);
  }

  @Override public void onDestroyView() {
    presenter.detachView();
    unbinder.unbind();
    EventBus.getDefault().unregister(this);
    super.onDestroyView();
  }

  @Override public void onSaveInstanceState(Bundle outState) {
    LOGI(TAG, "onSaveInstanceState");
    presenter.onSaveInstanceState(outState);
    super.onSaveInstanceState(outState);
  }



  @Override public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
    LOGI(TAG, "onViewStateRestored");
    presenter.onViewStateRestored(savedInstanceState);
    super.onViewStateRestored(savedInstanceState);
  }

  @OnClick(R.id.ivTakePicture) void onTakePicture() {
    presenter.getProfileImage(true);
    presenter.showChangePhotoDialog();
  }

  @Subscribe public void onEvent(final Experience event) {
    Experience model = IterableUtils.find(mExperienceList, new Predicate<Experience>() {
      @Override public boolean evaluate(Experience object) {
        return event.geteId() == object.geteId();
      }
    });
    if (model != null) {
      int index = mExperienceList.indexOf(model);
      mExperienceList.set(index, event);
    } else {
      mExperienceList.add(event);
    }
    updateProfileProgress(event.getProfilePercent());
    mExperienceAdapter.notifyDataSetChanged();
  }

  @Subscribe public void onEvent(ProfileData mData) {
    tvUserName.setText(
        String.format("%s %s", mData.getUserModel().getfName(), mData.getUserModel().getlName()));
    Glide.with(this)
        .load(mData.getUserModel().getImageThumb())
        .placeholder(R.drawable.user_placeholder)
        .dontAnimate()
        .into(ivProfilePic);
  }

  @Subscribe public void onEvent(PaymentAction action) {
    planPurchaseFlg = action.finish;
    if (action.finish) {
      tvSkipPremium.setText(R.string.plan_purchased);
      tvSkipPremium.setBackgroundResource(R.drawable.green_drawable);
    }
  }

  @Subscribe public void onEvent(DescriptionUpdate action) {
    tvUserIntro.setText(action.getText());
    updateProfileProgress(action.getProfilePercentage());
  }

  @Subscribe public void onEvent(final ProfileUpdate action) {
    if (action.geteId() != 0) {
      Experience model = IterableUtils.find(mExperienceList, new Predicate<Experience>() {
        @Override public boolean evaluate(Experience object) {
          return action.geteId() == object.geteId();
        }
      });
      if (model != null) {
        int index = mExperienceList.indexOf(model);
        mExperienceList.remove(index);
        mExperienceAdapter.notifyItemRemoved(index);
      }
    }
    updateProfileProgress(action.getProfilePercent());
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    if(!nestedScrollView.isShown()){
      nestedScrollView.setVisibility(View.VISIBLE);
      nestedScrollView.smoothScrollTo(0, 0);
    }
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void setLengthView(String currentString, String totalString) {
    tvCharacter.setText(String.format("%s %s", currentString, totalString));
  }

  @Override public void setExperienceAdapter(List<Experience> experienceList) {
    mExperienceList.clear();
    mExperienceList.addAll(experienceList);
    mExperienceAdapter.notifyDataSetChanged();
  }

  @Override public void setFormationAdapter(List<FormationModel> mFormationList) {
    this.mFormationList.clear();
    this.mFormationList.addAll(mFormationList);
    mFormationAdapter.notifyDataSetChanged();
  }

  @Override public void setSkillAdapter(List<SkillModel> skillList) {
    mSkillList.clear();
    mSkillList.addAll(skillList);
    mSkillAdapter.notifyDataSetChanged();
  }

  @Override public void setPhotoAdapter(List<ImageModel> imageModelList) {
    mPhotoList.clear();
    mPhotoList.addAll(imageModelList);
    profileImagesAdapter.notifyDataSetChanged();
    photoCheck();
  }

  private void photoCheck() {
    if (isProfileEdit) {
      recyclerViewPhoto.setVisibility(View.VISIBLE);
      tvNoPhoto.setVisibility(View.GONE);
      return;
    }
    if (mPhotoList.size() > 0) {
      recyclerViewPhoto.setVisibility(View.VISIBLE);
      tvNoPhoto.setVisibility(View.GONE);
    } else {
      recyclerViewPhoto.setVisibility(View.GONE);
      tvNoPhoto.setVisibility(View.VISIBLE);
    }
  }

  private void videoCheck() {
    if (isVideoEdit) {
      if (videoId != 0) {
        relativeVideo.setVisibility(View.VISIBLE);
        tvAddVideo.setVisibility(View.GONE);
      } else {
        relativeVideo.setVisibility(View.GONE);
      }
      tvNoVideo.setVisibility(View.GONE);
      return;
    }
    if (videoId != 0) {
      relativeVideo.setVisibility(View.VISIBLE);
      tvNoVideo.setVisibility(View.GONE);
    } else {
      relativeVideo.setVisibility(View.GONE);
      tvNoVideo.setVisibility(View.VISIBLE);
    }
  }

  @Override public void updateProfileProgress(int percent) {
    Spanned spanned = Html.fromHtml(percent + "<small><sup>%</sup></small>");
    tvProfilePercent.setText(spanned);
    if (percent > 50) {
      imgCv.setImageResource(R.drawable.green_check);
    } else {
      imgCv.setImageResource(R.drawable.red_check);
    }

    if (mPhotoList.isEmpty() && percent > 65) {
      percent = 65;
    }

    if (percent >= 70) {
      circularprogressbar.setProgressColorPaint(
          ActivityCompat.getColor(getActivity(), R.color.color_green_accept));
    } else {
      circularprogressbar.setProgressColorPaint(
          ActivityCompat.getColor(getActivity(), R.color.theme_pink));
    }
    circularprogressbar.animateProgressTo(0, percent, null);
  }

  @Override public void onResume() {
    super.onResume();
    showToolbar(true);
    changeToolbarColor(ActivityCompat.getColor(getActivity(), R.color.colorPrimary));
    showLeftImage(isOtherProfile);
    showRightImage(true);
    setTitle("");
    if (isOtherProfile) {
      setBackImageColor(ActivityCompat.getColor(getActivity(), android.R.color.white));
      ivEdit.setVisibility(View.GONE);
      if (isAcceptStatus) {
        linearRecruiterBottom.setVisibility(View.VISIBLE);
      }
      imgSkillEdit.setVisibility(View.GONE);
      imgEditExperience.setVisibility(View.GONE);
      imgFormationEdit.setVisibility(View.GONE);
      imgEditLanguage.setVisibility(View.GONE);
      imgEditPhoto.setVisibility(View.GONE);
      imgEditVideo.setVisibility(View.GONE);
      tvSkipPremium.setVisibility(View.GONE);
    }
  }

  @Override public void onRight(View view) {
    Utils.hideKeyboard(tvUserIntro, getContext());
    tvUserIntro.clearFocus();
    if (isCandidate()) {
      if (!isEmpty(Utils.getText(tvUserIntro))) {
        presenter.updateDescription(Utils.getText(tvUserIntro));
      }
    } else {
      presenter.favoriteCandidate(favoriteFlag);
    }
    //EventBus.getDefault().post(new UpdateFavorite(false));
  }

  @Override public void setUserData(UserModel userData, int profilePercent) {
    tvUserName.setText(String.format("%s %s", userData.getfName(), userData.getlName()));
    updateProfileProgress(profilePercent);
    Glide.with(this)
        .load(userData.getImageUrl())
        .placeholder(R.drawable.user_placeholder)
        .dontAnimate()
        .into(ivProfilePic);
    String uName = userData.getfName() + " " + userData.getlName();
    if (candidateApplyAdapter != null) {
      candidateApplyAdapter.setMessage(Html.fromHtml(
          getString(R.string.to_apply_offer, "<font color=#FF3E8C>" + uName + "</font>")));
    }
  }

  @Override public void setVideoThumb(String url) {
    ivVideoPreview.setImageResource(R.drawable.placeholder);
    relativeVideo.setVisibility(View.VISIBLE);
    videoCheck();
  }

  @Override public void setUserDescription(UserProfileData profileData) {
    tvDesignation.setText(profileData.getTitle());
    tvUserIntro.setText(profileData.getDescription());
  }

  @Override public void setLanguageData(List<LanguageModel> modelList) {
    mLanguageModelList.addAll(modelList);
    mLanguageAdapter.notifyDataSetChanged();
    showRemainingToast();
  }

  @Override public void setAddress(String address) {
    tvUserCity.setText(address);
  }

  @Override public void addData(Object obj) {
    if (obj instanceof FormationModel) {
      FormationModel model = (FormationModel) obj;
      mFormationList.add(model);
      mFormationAdapter.notifyItemInserted(mFormationList.size() - 1);
      updateProfileProgress(model.getProfileStatus());
    } else if (obj instanceof SkillModel) {
      SkillModel model = (SkillModel) obj;
      mSkillList.add(model);
      mSkillAdapter.notifyItemInserted(mSkillList.size() - 1);
      updateProfileProgress(model.getProfileStatus());
    } else if (obj instanceof LanguageModel) {
      LanguageModel model = (LanguageModel) obj;
      mLanguageModelList.add(model);
      mLanguageAdapter.notifyItemInserted(mLanguageModelList.size() - 1);
      updateProfileProgress(model.getProfileStatus());
    }
  }

  @Override public File getProfile() {
    return path != null ? new File(path) : null;
  }

  @Override public void openCamera() {
    ProfileFragmentPermissionsDispatcher.showCameraWithCheck(this, true, false);
  }

  @Override public void openGallery() {
    ProfileFragmentPermissionsDispatcher.showCameraWithCheck(this, false, false);
  }

  @Override public void opeVideoCamera() {
    ProfileFragmentPermissionsDispatcher.showCameraWithCheck(this, true, true);
  }

  @Override public void openVideoGallery() {
    ProfileFragmentPermissionsDispatcher.showCameraWithCheck(this, false, true);
  }

  @Override public void setProfileImage(String path) {
    Glide.with(this).load(path).dontAnimate().into(ivProfilePic);
  }

  @Override public void setFavoriteList(BaseContainer<JobModel> baseContainer) {
    boolean success = baseContainer.isSuccess();
    List<JobModel> dataList = baseContainer.getDataList();
    boolean clearAll = baseContainer.getCurrentPage() == 1;
    if (success) {
      if (dataList != null && !dataList.isEmpty()) {
        showFavoriteList(true);
        if (clearAll) {
          mFavoriteList.clear();
        }
        mFavoriteList.addAll(dataList);
        favRecyclerView.getAdapter().notifyDataSetChanged();
      } else if (mFavoriteList.isEmpty()) {
        showFavoriteList(false);
      }
    } else {
      showFavoriteList(false);
    }
  }

  private void showFavoriteList(boolean show) {
    if (show) {
      tvError.setVisibility(View.INVISIBLE);
      favRecyclerView.setVisibility(View.VISIBLE);
    } else {
      tvError.setVisibility(View.VISIBLE);
      favRecyclerView.setVisibility(View.INVISIBLE);
    }
  }

  @NeedsPermission({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showCamera(boolean isCamera, boolean isVideo) {
    if (isVideo) {
      if (isCamera) {
        presenter.openVideoCamera();
      } else {
        presenter.openVideoGallery();
      }
    } else {
      if (isCamera) {
        presenter.openCamera();
      } else {
        presenter.openGallery();
      }
    }
  }

  @OnShowRationale({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showRationaleForCamera(final PermissionRequest request) {
    Utils.showDialog(getActivity(), getString(R.string.alert),
        getString(R.string.permission_camera_rationale), getString(R.string.button_allow),
        getString(R.string.button_deny), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.proceed();
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.cancel();
          }
        }).show();
  }

  @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
      @NonNull int[] grantResults) {
    LOGI(TAG, "onRequestPermissionResult");
    ProfileFragmentPermissionsDispatcher.onRequestPermissionsResult(this, requestCode,
        grantResults);
  }

  @OnPermissionDenied({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showDeniedForCamera() {
    showPermissionDialog();
  }

  @OnNeverAskAgain({
      android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
  }) void showNeverAskForCamera() {
    showPermissionDialog();
  }

  private void showPermissionDialog() {
    Utils.showDialog(getActivity(), getString(R.string.alert),
        getString(R.string.permission_camera_never_askagain), getString(android.R.string.ok),
        new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }

  @Override public void setVideoId(int videoId) {
    this.videoId = videoId;
    videoCheck();
  }

  @Override public void showPhoto(String path) {
    this.path = path;
    isImageSet = true;
  }

  @Override public void setDefault() {
    path = null;
    isImageSet = false;
  }

  @Override public boolean isImageSet() {
    return isImageSet;
  }

  @Override public void onRemoveVideo() {
    relativeVideo.setVisibility(View.GONE);
    if (isVideoEdit) {
      tvAddVideo.setVisibility(View.VISIBLE);
    }
    videoId = 0;
    videoCheck();
  }

  @Override public void addImage(ImageModel imageModel) {
    mPhotoList.add(imageModel);
    profileImagesAdapter.notifyDataSetChanged();
    photoCheck();
  }

  @Override public void setPlanPurchased(boolean planPurchaseFlg) {
    this.planPurchaseFlg = planPurchaseFlg;
    if (planPurchaseFlg) {
      tvSkipPremium.setText(R.string.plan_purchased);
      tvSkipPremium.setBackgroundResource(R.drawable.green_drawable);
    }
  }

  @Override public void setJobApply(List<JobApplyModel> jobApplyModelList) {
    jobApplyList.addAll(jobApplyModelList);
    candidateApplyAdapter.notifyDataSetChanged();
  }

  @Override public void applyStatus(String action) {
    Bundle bundle = new Bundle();
    if (action.equalsIgnoreCase("1")) {
      //accept
      bundle.putInt(Constants.KEY_DIALOG_TYPE, Constants.CANDIDATE_ACCEPT);
      if (candidateModel != null) {
        candidateModel.setAccept(true);
      }
    } else {
      //reject
      bundle.putInt(Constants.KEY_DIALOG_TYPE, Constants.CANDIDATE_REJECT);
      if (candidateModel != null) {
        candidateModel.setAccept(false);
      }
    }
    if (candidateModel != null) {
      AllListFragment fragment = (AllListFragment) getTargetFragment();
      if (fragment != null) {
        fragment.onResumeCall(candidateModel);
      }
    }
    jobApplyList.remove(tempPosition);
    candidateApplyAdapter.notifyItemRemoved(tempPosition);
    InviteFragment inviteFragment = new InviteFragment();
    inviteFragment.setArguments(bundle);
    inviteFragment.show(getFragmentManager(), inviteFragment.getClass().getName());
  }

  @Override public void onCodeResend(boolean result, String message) {
    Utils.showMessage(getContext(), message);
    if (result) {
      navigateToVerifyPhoneActivity();
    }
  }

  @Override public void editData(Object o) {
    if (o instanceof FormationModel) {
      mFormationList.remove(editPosition);
      mFormationList.add(editPosition, (FormationModel) o);
      mFormationAdapter.notifyItemChanged(editPosition);
    } else if (o instanceof SkillModel) {
      mSkillList.remove(editPosition);
      mSkillList.add(editPosition, (SkillModel) o);
      mSkillAdapter.notifyItemChanged(editPosition);
    } else if (o instanceof LanguageModel) {
      mLanguageModelList.remove(editPosition);
      mLanguageModelList.add(editPosition, (LanguageModel) o);
      mLanguageAdapter.notifyItemChanged(editPosition);
    }
  }

  @Override public void removeObject(int type) {
    if (type == TRAINING) {
      mFormationList.remove(editPosition);
      mFormationAdapter.notifyItemRemoved(editPosition);
    } else if (type == SKILL) {
      mSkillList.remove(editPosition);
      mSkillAdapter.notifyItemRemoved(editPosition);
    } else if (type == LANGUAGE) {
      mLanguageModelList.remove(editPosition);
      mLanguageAdapter.notifyItemRemoved(editPosition);
    }
  }

  @Override public void setFavorite(boolean favoriteFlag) {
    if (isOtherProfile) {
      showRightImage(true);
      this.favoriteFlag = favoriteFlag;
      if (favoriteFlag && isOtherProfile) {
        setRightImage(R.drawable.favorite_icon);
      } else {
        setRightImage(R.drawable.unfavorite_icon);
      }
    }
  }

  @Override public void updateFavorite(boolean favoriteFlag) {
    this.favoriteFlag = favoriteFlag;
    if (favoriteFlag) {
      setRightImage(R.drawable.favorite_icon);
    } else {
      setRightImage(R.drawable.unfavorite_icon);
    }
    if(mHomeCandidateModel!=null){
      mHomeCandidateModel.setFavorite(favoriteFlag?1:0);
    }
    Fragment fragment =  getTargetFragment();
    if(fragment!=null && fragment instanceof HomeRecruiterFragment){
      HomeRecruiterFragment homeFragment = (HomeRecruiterFragment) fragment;
      homeFragment.changeFavoriteStatus(mHomeCandidateModel);
    }
  }

  @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
    presenter.onActivityResult(requestCode, resultCode, data);
    super.onActivityResult(requestCode, resultCode, data);
  }

  @Override public Context getContext() {
    return getActivity();
  }

  @OnClick(R.id.iv_video_preview) void onVideo() {
    if (isVideoEdit && !checkPhoneVerified()) {
      presenter.callVerificationCodeApi();
      return;
    }
    presenter.playVideo();
  }

  @OnClick(R.id.ivEdit) void onPersonalEdit() {
    Intent intent = new Intent(getActivity(), EditProfileActivity.class);
    intent.putExtra(Constants.KEY_TEXT, Utils.getText(tvUserIntro));
    startActivity(intent);
  }

  @Override public void onBack(View view) {
    if (isOtherProfile) {
      getFragmentManager().popBackStack();
    } else {
      if (!onBackPressed()) {
        getActivity().onBackPressed();
      }
    }
  }

  @OnClick({
      R.id.imgEditExperience, R.id.tvAddSkill, R.id.tvAddTraining, R.id.tvAddVideo,
      R.id.imageRemove, R.id.linearProgress, R.id.tvSkipPremium, R.id.imgSkillEdit,
      R.id.imgFormationEdit, R.id.imgEditLanguage, R.id.imgEditPhoto, R.id.imgEditVideo,
      R.id.tvAddLanguage
  }) void addClick(View view) {
    if (!checkPhoneVerified()) {
      presenter.callVerificationCodeApi();
      return;
    }
    if (view.getId() == R.id.imgEditExperience) {
      Intent mIntent = new Intent(getActivity(), EditExperienceActivity.class);
      mIntent.putExtra(Constants.KEY_LIST, mExperienceList);
      startActivity(mIntent);
    } else if (view.getId() == R.id.tvAddTraining) {
      if (mFormationList.size() == 2) {
        Utils.showMessage(getActivity(), getString(R.string.cant_formation));
        return;
      }
      showAddInfo(TRAINING, false, null);
    } else if (view.getId() == R.id.tvAddSkill) {
      if (mSkillList.size() == 2) {
        Utils.showMessage(getActivity(), getString(R.string.cant_skill));
        return;
      }
      showAddInfo(SKILL, false, null);
    } else if (view.getId() == R.id.tvAddLanguage) {
      if (mLanguageModelList.size() == 2) {
        Utils.showMessage(getActivity(), getString(R.string.cant_language));
        return;
      }
      showAddInfo(LANGUAGE, false, null);
    } else if (view.getId() == R.id.tvAddVideo) {
      presenter.ShowVideoCaptureDialog();
    } else if (view.getId() == R.id.imgSkillEdit) {
      if (tvAddSkill.isShown()) {
        imgSkillEdit.setImageResource(R.drawable.edit_gray);
      } else {
        imgSkillEdit.setImageResource(R.drawable.top_check);
      }
      skillEdited(!tvAddSkill.isShown());
    } else if (view.getId() == R.id.imgFormationEdit) {
      if (tvAddTraining.isShown()) {
        imgFormationEdit.setImageResource(R.drawable.edit_gray);
      } else {
        imgFormationEdit.setImageResource(R.drawable.top_check);
      }
      formationEdit(!tvAddTraining.isShown());
    } else if (view.getId() == R.id.imgEditLanguage) {
      if (tvAddLanguage.isShown()) {
        imgEditLanguage.setImageResource(R.drawable.edit_gray);
      } else {
        imgEditLanguage.setImageResource(R.drawable.top_check);
      }
      languageEdit(!tvAddLanguage.isShown());
    } else if (view.getId() == R.id.imgEditPhoto) {
      isProfileEdit = !isProfileEdit;
      if (isProfileEdit) {
        imgEditPhoto.setImageResource(R.drawable.top_check);
      } else {
        imgEditPhoto.setImageResource(R.drawable.edit_gray);
      }
      photoCheck();
      profileImageEdit(isProfileEdit);
    } else if (view.getId() == R.id.imgEditVideo) {
      isVideoEdit = !isVideoEdit;
      if (isVideoEdit) {
        imgEditVideo.setImageResource(R.drawable.top_check);
      } else {
        imgEditVideo.setImageResource(R.drawable.edit_gray);
      }
      videoEdit(isVideoEdit);
    } else if (view.getId() == R.id.linearProgress) {
      // do nothing
    } else if (view.getId() == R.id.tvSkipPremium) {
      if (!planPurchaseFlg) {
        launchActivity(getActivity(), PurchaseActivity.class, false);
      }
    } else if (view.getId() == R.id.imageRemove) {
      if (videoId != 0) {
        showDeleteAlert(new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            if (hasNetworkConnectivity()) {
              presenter.removeVideo(videoId);
            } else {
              showNetworkError();
            }
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        });
      }
    }
  }

  private void showNetworkError() {
    Utils.showNetworkDialog(getActivity(), new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        dialog.dismiss();
      }
    }).show();
  }

  private void addInfo(String skill, String rate, int addTraining, boolean isUpdate,
      Object object) {
    presenter.addSkill(skill, rate, addTraining, isUpdate, object);
  }

  @Override public boolean onBackPressed() {
    if (isOtherProfile) {
      getFragmentManager().popBackStack();
      return true;
    } else {
      if (dialog != null && dialog.isShowing()) {
        dialog.dismiss();
        return true;
      }
      return super.onBackPressed();
    }
  }

  private void skillEdited(boolean isEditMode) {
    mSkillAdapter.setEdit(isEditMode);
    if (isEditMode) {
      tvAddSkill.setVisibility(View.VISIBLE);
    } else {
      tvAddSkill.setVisibility(View.GONE);
    }
  }

  private void formationEdit(boolean isEditMode) {
    mFormationAdapter.setEdit(isEditMode);
    if (isEditMode) {
      tvAddTraining.setVisibility(View.VISIBLE);
    } else {
      tvAddTraining.setVisibility(View.GONE);
    }
  }

  private void languageEdit(boolean isEditMode) {
    mLanguageAdapter.setEdit(isEditMode);
    if (isEditMode) {
      tvAddLanguage.setVisibility(View.VISIBLE);
    } else {
      tvAddLanguage.setVisibility(View.GONE);
    }
  }

  private void profileImageEdit(boolean isEditMode) {
    profileImagesAdapter.setEdit(isEditMode);
  }

  private void videoEdit(boolean isEditedMode) {
    if (!isEditedMode) {
      tvAddVideo.setVisibility(View.GONE);
      mLinearRemove.setVisibility(View.GONE);
      return;
    }
    if (videoId != 0) {
      tvAddVideo.setVisibility(View.GONE);
      mLinearRemove.setVisibility(View.VISIBLE);
    } else {
      tvAddVideo.setVisibility(View.VISIBLE);
      mLinearRemove.setVisibility(View.GONE);
    }
  }

  @Override public void onClick(View view, final Object object, final int position) {
    if (!checkPhoneVerified()) {
      presenter.callVerificationCodeApi();
      return;
    }
    if (object instanceof ImageModel) {
      if (view.getId() == R.id.imageRemove) {
        presenter.getProfileImage(false);
        final ImageModel imageModel = (ImageModel) object;
        showDeleteAlert(new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            if (hasNetworkConnectivity()) {
              presenter.removeImage(imageModel.getImageId());
              mPhotoList.remove(position);
              profileImagesAdapter.notifyDataSetChanged();
            } else {
              showNetworkError();
            }
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        });
      } else {
        presenter.showChangePhotoDialog();
      }
    } else if (object instanceof JobApplyModel) {
      tempPosition = position;
      JobApplyModel model = (JobApplyModel) object;
      HashMap<String, String> params = new HashMap<>(3);
      params.put("offerId", model.getId());
      if (view.getId() == R.id.ivAccept) {
        params.put("action", "1");
      } else {
        params.put("action", "2");
      }
      params.put("candidateId", getArguments().getString(Constants.KEY_ID));
      presenter.applyJob(params);
    } else if (object instanceof FormationModel) {
      editPosition = position;
      showAddInfo(TRAINING, true, object);
    } else if (object instanceof SkillModel) {
      editPosition = position;
      showAddInfo(SKILL, true, object);
    } else if (object instanceof LanguageModel) {
      editPosition = position;
      showAddInfo(LANGUAGE, true, object);
    } else if (object instanceof JobModel) {
      JobModel model = (JobModel) object;
      Bundle bundle = new Bundle();
      bundle.putString(Constants.KEY_ID, model.getRpId());
      bundle.putInt(Constants.KEY_POSITION, position);
      JobDetailFragment fragment = new JobDetailFragment();
      fragment.setTargetFragment(this, 1111);
      fragment.setArguments(bundle);
      ((HomeActivity) getActivity()).switchFragment(fragment, true);
    }
  }

  private void showDeleteAlert(DialogInterface.OnClickListener onClickListener,
      DialogInterface.OnClickListener negOnClickListener) {
    Utils.showDialog(getActivity(), getString(R.string.delete), getString(R.string.delete_message),
        getString(R.string.yes), getString(R.string.no), onClickListener, negOnClickListener)
        .show();
  }

  private void showAddInfo(final int reqCode, final boolean isUpdate, final Object object) {
    dialog = DialogPlus.newDialog(getActivity())
        .setContentHolder(new ViewHolder(R.layout.dialog_add_skill))
        .setOnDismissListener(new OnDismissListener() {
          @Override public void onDismiss(DialogPlus dialog) {
            LOGI(TAG,"onDismiss");
            Utils.hideKeyboard(etSkill, getActivity());
            Utils.hideKeyboard(getActivity());
          }
        })
        .setOnClickListener(new OnClickListener() {
          @Override public void onClick(DialogPlus dialog, View view) {
            if (view.getId() == R.id.tvAddDone) {
              if (isEmpty(Utils.getText(etSkill))) {
                if (reqCode == SKILL) {
                  Utils.showMessage(getActivity(), getString(R.string.enter_skill));
                } else if (reqCode == TRAINING) {
                  Utils.showMessage(getActivity(), getString(R.string.enter_training));
                } else if (reqCode == LANGUAGE) {
                  Utils.showMessage(getActivity(), getString(R.string.enter_language));
                }
                return;
              } else if (mRatingBar.getRating() < 1) {
                Utils.showMessage(getActivity(), getString(R.string.enter_rating));
                return;
              }
              addInfo(Utils.getText(etSkill), String.valueOf(mRatingBar.getRating()), reqCode,
                  isUpdate, object);
              dialog.dismiss();
            } else if (view.getId() == R.id.tvRemove) {
              removeItem(reqCode, object);
              dialog.dismiss();
            }
          }
        })
        .setGravity(Gravity.CENTER)
        .create();
    dialog.show();
    View view = dialog.getHolderView();
    view.setOnTouchListener(new View.OnTouchListener() {
      @Override public boolean onTouch(View v, MotionEvent event) {
        return true;
      }
    });
    etSkill = (EditText) view.findViewById(R.id.etSkillName);
    TextView tvTitle = (TextView) view.findViewById(R.id.tvTitle);
    TextView tvRemove = (TextView) view.findViewById(R.id.tvRemove);
    mRatingBar = (RatingBar) view.findViewById(R.id.ratingBar);
    mRatingBar.getLayoutParams().height = ratingBarHeight;
    if (isUpdate) {
      tvRemove.setVisibility(View.VISIBLE);
      if (object instanceof FormationModel) {
        etSkill.setText(((FormationModel) object).getTitle());
        float rate = (float) ((FormationModel) object).getRate();
        mRatingBar.setRating(rate);
      } else if (object instanceof SkillModel) {
        etSkill.setText(((SkillModel) object).getTitle());
        float rate = (float) ((SkillModel) object).getRate();
        mRatingBar.setRating(rate);
      } else if (object instanceof LanguageModel) {
        etSkill.setText(((LanguageModel) object).getTitle());
        float rate = (float) ((LanguageModel) object).getRate();
        mRatingBar.setRating(rate);
      }
    }
    if (reqCode == SKILL) {
      if (isUpdate) {
        tvTitle.setText(getString(R.string.edit_skill));
      } else {
        tvTitle.setText(getString(R.string.add_skill));
      }
    } else if (reqCode == TRAINING) {
      if (isUpdate) {
        tvTitle.setText(getString(R.string.edit_formation));
      } else {
        tvTitle.setText(getString(R.string.add_training));
      }
    } else if (reqCode == LANGUAGE) {
      if (isUpdate) {
        tvTitle.setText(getString(R.string.edit_language));
      } else {
        tvTitle.setText(getString(R.string.add_a_language));
      }
    }
  }

  private void removeItem(int type, Object object) {
    presenter.removeItem(type, object);
  }

  private void showRemainingToast() {
    if (isOtherProfile) {
      return;
    }
    final List<String> showMessage = new ArrayList<>();
    if (mExperienceList.size() == 0) {
      showMessage.add(getString(R.string.profile_add_exp));
    }
    if (mSkillList.size() == 0) {
      showMessage.add(getString(R.string.profile_add_skills));
    }
    if (mFormationList.size() == 0) {
      showMessage.add(getString(R.string.profile_add_formation));
    }
    if (mLanguageModelList.size() == 0) {
      showMessage.add(getString(R.string.profile_add_lang));
    }
    if (mPhotoList.size() == 0) {
      showMessage.add(getString(R.string.profile_add_photo));
    }
    if (videoId == 0) {
      showMessage.add(getString(R.string.profile_add_video));
    }
    final int size = showMessage.size();
    if (size < 1) {
      return;
    }
    final Handler handler = new Handler();
    handler.postDelayed(new Runnable() {
      @Override public void run() {
        if (tvNoPhoto != null) {
          Snackbar.with(getActivity().getApplicationContext()) // context
              .color(ContextCompat.getColor(getActivity(), R.color.color_green_accept))
              .textColor(Color.WHITE)
              .text(showMessage.get((int) (Math.random() * size))) // text to display
              .show(getActivity());
        }
        handler.removeCallbacks(this);
      }
    }, 2000);
  }

  @Override public void updateList(final String offerId) {
    JobModel jobModel = IterableUtils.find(mFavoriteList, new Predicate<JobModel>() {
      @Override public boolean evaluate(JobModel object) {
        return offerId.equalsIgnoreCase(object.getRpId());
      }
    });
    if (jobModel != null) {
      jobModel.setApplyJobBtnFlag(2); // applied
    }
  }
}
