/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.CircleImageView;
import com.bnbjobs.model.CandidateModel;
import com.bumptech.glide.Glide;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class HomeFavAdapter extends BaseRecyclerAdapter<BaseRecyclerAdapter.ViewHolder> {

  private Context context;
  private List<CandidateModel> mList;
  private final int VIEW_TYPE_ITEM = 0;
  private final int VIEW_TYPE_LOADING = 1;
  public HomeFavAdapter(Context context, List<CandidateModel> mList) {
    this.context = context;
    this.mList = mList;
  }

  @Override public BaseRecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    if (viewType == VIEW_TYPE_ITEM) {
      View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_fav_home, parent, false);
      return new MyViewHolder(view);
    } else if (viewType == VIEW_TYPE_LOADING) {
      View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.progress, parent, false);
      return new LoadingViewHolder(view);
    }
    return null;
  }

  @Override public void onBindViewHolder(BaseRecyclerAdapter.ViewHolder holder, int position) {
    if(holder instanceof MyViewHolder){
      MyViewHolder myViewHolder = (MyViewHolder) holder;
      myViewHolder.tvUserName.setText(mList.get(position).getfName());
      Glide.with(context)
          .load(mList.get(position).getuImageUrl())
          .placeholder(R.drawable.placeholder)
          .dontAnimate()
          .into(myViewHolder.ivUserImage);
    }else{
      LoadingViewHolder loadingViewHolder = (LoadingViewHolder) holder;
      loadingViewHolder.progressBar.setVisibility(View.VISIBLE);
      loadingViewHolder.progressBar.setIndeterminate(true);

    }

  }
  @Override public int getItemViewType(int position) {
    return mList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
  }

  @Override public int getItemCount() {
    return mList == null ? 0 : mList.size();
  }

  public class MyViewHolder extends BaseRecyclerAdapter.ViewHolder {
    @BindView(R.id.ivUserImage) CircleImageView ivUserImage;
    @BindView(R.id.tvUserName) TextView tvUserName;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
    }
  }
  private  class LoadingViewHolder extends BaseRecyclerAdapter.ViewHolder {

    ProgressBar progressBar;

    LoadingViewHolder(View itemView) {
      super(itemView);
      ProgressBar progressBarHor = (ProgressBar) itemView.findViewById(R.id.progressBar);
      progressBarHor.setVisibility(View.INVISIBLE);
      progressBar = (ProgressBar) itemView.findViewById(R.id.progressBarVertical);
    }
  }
}
