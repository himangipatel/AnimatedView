/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

/**
 * @author Harsh
 * @version 1.0
 */
public class JobPostDetail {

  private String jobPostName;
  private String jobLocation;
  private String jobShortDescription;
  private String salaryAmount;
  private String jobImageUrl;

  public String getJobPostName() {
    return jobPostName;
  }

  public void setJobPostName(String jobPostName) {
    this.jobPostName = jobPostName;
  }

  public String getJobLocation() {
    return jobLocation;
  }

  public void setJobLocation(String jobLocation) {
    this.jobLocation = jobLocation;
  }

  public String getJobShortDescription() {
    return jobShortDescription;
  }

  public void setJobShortDescription(String jobShortDescription) {
    this.jobShortDescription = jobShortDescription;
  }

  public String getSalaryAmount() {
    return salaryAmount;
  }

  public void setSalaryAmount(String salaryAmount) {
    this.salaryAmount = salaryAmount;
  }

  public String getJobImageUrl() {
    return jobImageUrl;
  }

  public void setJobImageUrl(String jobImageUrl) {
    this.jobImageUrl = jobImageUrl;
  }
}
