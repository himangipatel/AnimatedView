/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.os.Bundle;
import com.bnbjobs.R;

/**
 * @author Harsh
 * @version 1.0
 */

public class DetailImageActivity extends BaseActivity {
  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.detail_image_activity);

  }



}
