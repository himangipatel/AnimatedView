/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.presenter.InviteFriendsPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.view.InviteFriendsView;

/**
 * @author Harsh
 * @version 1.0
 */

public class InviteFriendsActivity extends BaseActivity implements InviteFriendsView {

  @BindView(R.id.linearHeader) LinearLayout linearHeader;
  @BindView(R.id.imgLogo) ImageView imgLogo;
  @BindView(R.id.inviteContacts) RelativeLayout inviteContacts;
  @BindView(R.id.inviteFriends) View inviteFriends;
  @BindView(R.id.tvTitle) TextView tvTitle;

  private Unbinder mUnbind;

  private InviteFriendsPresenter mInviteFriendsPresenter;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_invite_friends);
    mUnbind = ButterKnife.bind(this);

    tvTitle.setVisibility(View.VISIBLE);
    tvTitle.setText(getString(R.string.invite_friends));

    mInviteFriendsPresenter = new InviteFriendsPresenter();
    mInviteFriendsPresenter.attachView(this);
  }

  @OnClick({ R.id.inviteContacts, R.id.inviteFriends, R.id.imageBack })
  public void onClick(View view) {
    switch (view.getId()) {
      case R.id.inviteContacts:
        Intent intent = new Intent(this, InviteActivity.class);
        intent.putExtra(Constants.INVITE_FRIENDS_FROM, Constants.INVITE_FRIENDS_FROM_CONTACT);
        startActivity(intent);
        break;
      case R.id.inviteFriends:
        mInviteFriendsPresenter.onFbLogin();
        break;
      case R.id.imageBack:
        finish();
        break;
      default:
        break;
    }
  }

  @Override protected void onDestroy() {
    super.onDestroy();
    mUnbind.unbind();
  }

  @Override public void onFacebookLogin() {
    Intent intent = new Intent(this, InviteActivity.class);
    intent.putExtra(Constants.INVITE_FRIENDS_FROM, Constants.INVITE_FRIENDS_FROM_FB);
    startActivity(intent);
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {

  }

  @Override public void hideProgress() {

  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    mInviteFriendsPresenter.setResult(requestCode, resultCode, data);
  }
}
