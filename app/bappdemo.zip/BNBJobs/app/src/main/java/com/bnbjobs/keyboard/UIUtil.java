/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.keyboard;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

/**
 * Created by yshrsmz on 15/03/17.
 */
public final class UIUtil {

  /**
   * Supresses instantiation
   */
  private UIUtil() {
    throw new AssertionError();
  }

  public static float convertDpToPx(Context context, float dp) {
    Resources res = context.getResources();

    return dp * (res.getDisplayMetrics().densityDpi / 160f);
  }

  /**
   * hide keyboard
   *
   * @param context Context
   * @param target View that currently has focus
   */
  public static void hideKeyboard(Context context, View target) {
    if (context == null || target == null) {
      return;
    }

    InputMethodManager imm = getInputMethodManager(context);
    imm.hideSoftInputFromWindow(target.getWindowToken(), 0);
  }

  /**
   * hide keyboard
   *
   * @param activity Activity
   */
  public static void hideKeyboard(Activity activity) {
    View view = activity.getCurrentFocus();

    if (view != null) {
      hideKeyboard(activity, view);
    }
  }

  private static InputMethodManager getInputMethodManager(Context context) {
    return (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
  }
}
