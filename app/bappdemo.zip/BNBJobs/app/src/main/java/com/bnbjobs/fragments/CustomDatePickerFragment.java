/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.widget.DatePicker;

public class CustomDatePickerFragment extends DialogFragment {


  private OnDateSetListener mListener;

  private static boolean hasJellyBeanAndAbove() {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN;
  }

  @Override public void onAttach(Activity activity) {
    super.onAttach(activity);
  }

  @Override public void onDetach() {
    this.mListener = null;
    super.onDetach();
  }

  public void setListener(Fragment advance) {
    this.mListener = (OnDateSetListener) advance;
  }

  public void setListener(OnDateSetListener listener) {
    this.mListener = listener;
  }

  @NonNull @Override public Dialog onCreateDialog(Bundle savedInstanceState) {
    Bundle b = getArguments();

    int y = b.getInt("year");
    int m = b.getInt("month");
    int d = b.getInt("day");

    final DatePickerDialog picker =
        new DatePickerDialog(getActivity(), getConstructorListener(), y, m, d);

    if (!b.getBoolean("isStartTime")) {
      long milli = b.getLong("milli");
      picker.getDatePicker().setMinDate(milli);
    } else {
      picker.getDatePicker().setMinDate(System.currentTimeMillis() - 2000);
    }

    if (hasJellyBeanAndAbove()) {
      picker.setButton(DialogInterface.BUTTON_POSITIVE,
          getActivity().getString(android.R.string.ok), new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
              DatePicker dp = picker.getDatePicker();
              mListener.onDateSet(dp, dp.getYear(), dp.getMonth(), dp.getDayOfMonth());
            }
          });
      picker.setButton(DialogInterface.BUTTON_NEGATIVE,
          getActivity().getString(android.R.string.cancel), new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
            }
          });
    }
    return picker;
  }

  private OnDateSetListener getConstructorListener() {
    return hasJellyBeanAndAbove() ? null : mListener;
  }
}
