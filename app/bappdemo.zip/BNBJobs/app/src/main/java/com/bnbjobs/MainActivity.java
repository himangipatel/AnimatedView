/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.fragments.DummyFragment;

public class MainActivity extends BaseActivity {

  private FragmentTabHost mTabHost;
  private String[] tabNames;
  private Integer[] tabImages;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
    mTabHost.setup(this, getSupportFragmentManager(), R.id.realTabContent);
    tabImages = new Integer[] {
        R.drawable.dashboard_unselect, R.drawable.alertes_unselect, R.drawable.annonces_unselect,
        R.drawable.condidatures_unselect
    };
    tabNames =
        new String[] { "Dashboard", getString(R.string.alerts), "Announces", "Candidatures" };
    for (int i = 0; i < 4; i++) {
      mTabHost.addTab(mTabHost.newTabSpec(tabNames[i])
          .setIndicator(createTabView(tabNames[i], tabImages[i], i)), DummyFragment.class, null);
    }
  }

  private View createTabView(String tabText, int imgRes, int tag) {
    View view = LayoutInflater.from(this).inflate(R.layout.tab_custom, null, false);
    TextView tv = (TextView) view.findViewById(R.id.tvTabText);
    tv.setText(tabText);
    tv.setTextColor(customCreateList());
    TinTableImageView imgTab;
    imgTab = (TinTableImageView) view.findViewById(R.id.imgTab);
    imgTab.setCustomFilter(customCreateList());
    imgTab.setVisibility(View.VISIBLE);
    imgTab.setImageResource(imgRes);
    return view;
  }

  /**
   * create custom color list
   *
   * @return custom ColorStateList
   */
  private ColorStateList customCreateList() {
    int[][] states = new int[][] {
        new int[] { android.R.attr.state_selected }, // selected
        new int[] { android.R.attr.state_pressed },  // unPressed
        new int[] { -android.R.attr.state_selected }, // unSelected
        new int[] { -android.R.attr.state_pressed } // pressed
    };
    int[] colors = new int[] {
        ActivityCompat.getColor(this, R.color.theme_pink),
        ActivityCompat.getColor(this, R.color.theme_pink), Color.WHITE, Color.WHITE
    };
    return new ColorStateList(states, colors);
  }
}
