/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.DescriptionUpdate;
import com.bnbjobs.presenter.DescriptionPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.DescriptionView;
import java.net.SocketTimeoutException;
import org.greenrobot.eventbus.EventBus;

import static android.text.TextUtils.isEmpty;

/**
 * @author Harsh
 * @version 1.0
 */

public class DescriptionActivity extends BaseActivity implements DescriptionView {
  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.imageCenterLogo) ImageView imageCenterLogo;
  @BindView(R.id.rightImage) TinTableImageView rightImage;
  @BindView(R.id.toolbar) Toolbar toolbar;
  @BindView(R.id.etDescription) EditText etDescription;
  @BindView(R.id.linearProgress) LinearLayout mLinearProgress;

  private DescriptionPresenter presenter;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_edit_description);
    ButterKnife.bind(this);
    presenter = new DescriptionPresenter();
    presenter.attachView(this);
    tvTitle.setVisibility(View.VISIBLE);
    tvTitle.setText(getString(R.string.desc_title));
    tvTitle.requestLayout();
    rightImage.setVisibility(View.VISIBLE);
    setData();
  }

  /**
   * set description data
   */
  private void setData() {
    etDescription.setText(getIntent().getStringExtra(Constants.KEY_TEXT));
    etDescription.setEnabled(isEmpty(Utils.getText(etDescription)));
    if (etDescription.isEnabled()) {
      rightImage.setImageResource(R.drawable.top_check);
    } else {
      rightImage.setImageResource(R.drawable.edit_gray);
    }
  }

  @OnClick({ R.id.rightImage, R.id.linearProgress, R.id.imageBack }) void onClick(View view) {
    if (view.getId() == R.id.rightImage) {
      if (etDescription.isEnabled()) {
        // update description api called
        if (isEmpty(Utils.getText(etDescription))) {
          Utils.showMessage(this, getString(R.string.error_description));
          return;
        }
        Utils.hideKeyboard(etDescription,this);
        presenter.updateDesignation(Utils.getText(etDescription));
      } else {
        etDescription.setEnabled(true);
        rightImage.setImageResource(R.drawable.top_check);
      }
    } else if (view.getId() == R.id.imageBack) {
      if (!mLinearProgress.isShown()) onBackPressed();
    }
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    mLinearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    mLinearProgress.setVisibility(View.GONE);
  }

  @Override protected void onDestroy() {
    super.onDestroy();
    presenter.detachView();
  }

  @Override public void updateDesignation(int profilePercentage) {
    Utils.showMessage(this, getString(R.string.update_description));
    etDescription.setEnabled(false);
    rightImage.setImageResource(R.drawable.edit_gray);
    EventBus.getDefault().post(new DescriptionUpdate(Utils.getText(etDescription), profilePercentage));
    finish();
  }

  @Override public void onError(Throwable e) {
    handleError(e, new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        DescriptionActivity.this.onClick(rightImage);
      }
    });
  }

  private void handleError(Throwable e, DialogInterface.OnClickListener listener) {
    String error;
    if (e instanceof SocketTimeoutException) {
      error = getString(R.string.error_timeout);
    } else {
      error = getString(R.string.error_other);
    }
    AlertDialog dialog =
        Utils.showDialog(this, getString(R.string.alert), error, getString(R.string.retry),
            listener);
    dialog.show();
  }
}
