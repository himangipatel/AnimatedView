/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import android.text.Html;
import android.text.Spanned;
import android.text.TextUtils;
import com.bnbjobs.utils.LocaleHelper;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class JobOfferData implements Serializable {

  @SerializedName("rp_id") private int offerId;
  @SerializedName("rp_recruiter_id") private int recruiterId;
  @SerializedName("rp_designation_id") private int designationId;
  @SerializedName("rp_video") private String video;
  @SerializedName("rp_contract_type") private int contractType;
  @SerializedName("rp_start_date") private String startDate;
  @SerializedName("rp_end_date") private String endDate;
  @SerializedName("rp_location") private String location;
  @SerializedName("rp_latitude") private String latitude;
  @SerializedName("rp_longitude") private String longitude;
  @SerializedName("rp_references") private String references;
  @SerializedName("rp_description") private String description;
  @SerializedName("rp_salary") private String salary;
  @SerializedName("rp_salary_hour") private String salaryHour;

  @SerializedName("rp_status") private int status;
  @SerializedName("rp_experience_required") private int expRequired;
  @SerializedName("rp_profile_per") private String profilePer;
  @SerializedName("d_title_1") private String dTitle1;
  @SerializedName("d_title_2") private String dTitle2;
  @SerializedName("d_title_3") private String dTitle3;
  @SerializedName("rp_video_url") private String videoUrl;
  @SerializedName("rp_images") private List<PhotoModel> mPhotoList;
  @SerializedName("rp_quality") private String quality;
  @SerializedName("rp_other_benefits") private String otherBenefits;
  @SerializedName("rp_country") private String countryName;
  private String dTitle;

  public int getExpRequired() {
    return expRequired;
  }

  public void setExpRequired(int expRequired) {
    this.expRequired = expRequired;
  }

  public String getProfilePer() {
    return profilePer;
  }

  public void setProfilePer(String profilePer) {
    this.profilePer = profilePer;
  }

  public String getCountryName() {
    return countryName;
  }

  public void setCountryName(String countryName) {
    this.countryName = countryName;
  }

  public String getdTitle1() {
    return dTitle1;
  }

  public void setdTitle1(String dTitle1) {
    this.dTitle1 = dTitle1;
  }

  public String getdTitle2() {
    return dTitle2;
  }

  public void setdTitle2(String dTitle2) {
    this.dTitle2 = dTitle2;
  }

  public String getdTitle3() {
    return dTitle3;
  }

  public void setdTitle3(String dTitle3) {
    this.dTitle3 = dTitle3;
  }

  public int getOfferId() {
    return offerId;
  }

  public void setOfferId(int offerId) {
    this.offerId = offerId;
  }

  public int getRecruiterId() {
    return recruiterId;
  }

  public void setRecruiterId(int recruiterId) {
    this.recruiterId = recruiterId;
  }

  public int getDesignationId() {
    return designationId;
  }

  public void setDesignationId(int designationId) {
    this.designationId = designationId;
  }

  public String getVideo() {
    return video;
  }

  public void setVideo(String video) {
    this.video = video;
  }

  public int getContractType() {
    return contractType;
  }

  public void setContractType(int contractType) {
    this.contractType = contractType;
  }

  public String getStartDate() {
    return startDate;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public String getLatitude() {
    return latitude;
  }

  public void setLatitude(String latitude) {
    this.latitude = latitude;
  }

  public String getLongitude() {
    return longitude;
  }

  public void setLongitude(String longitude) {
    this.longitude = longitude;
  }

  public String getReferences() {
    return references;
  }

  public void setReferences(String references) {
    this.references = references;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getSalary() {
    return salary;
  }

  public void setSalary(String salary) {
    this.salary = salary;
  }

  public String getSalaryHour() {
    return salaryHour;
  }

  public void setSalaryHour(String salaryHour) {
    this.salaryHour = salaryHour;
  }

  public Spanned hourSalaryDisplay() {
    if (TextUtils.isEmpty(getSalaryHour())) return Html.fromHtml("");
    double salary = Double.parseDouble(getSalaryHour());
    DecimalFormat df = new DecimalFormat();
    df.setMaximumFractionDigits(2);
    return Html.fromHtml(df.format(salary) + "<small><sup>\u20ac/H</sup></small>");
  }

  public Spanned salaryDisplay() {
    if (TextUtils.isEmpty(getSalary())) return Html.fromHtml("");
    return Html.fromHtml(getSalary() + "<small><sup>\u20ac/M</sup></small>");
  }

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }

  public String getdTitle() {
    if (LocaleHelper.isFrench()) {
      return getdTitle2();
    } else if (LocaleHelper.isSpanish()) {
      return getdTitle3();
    } else {
      return getdTitle1();
    }
  }



  public String getQuality() {
    return quality;
  }

  public void setQuality(String quality) {
    this.quality = quality;
  }

  public String getOtherBenefits() {
    return otherBenefits;
  }

  public void setOtherBenefits(String otherBenefits) {
    this.otherBenefits = otherBenefits;
  }

  public void setdTitle(String dTitle) {
    this.dTitle = dTitle;
  }

  public String getVideoUrl() {
    return videoUrl;
  }

  public void setVideoUrl(String videoUrl) {
    this.videoUrl = videoUrl;
  }

  public List<PhotoModel> getmPhotoList() {
    return mPhotoList;
  }

  public void setmPhotoList(List<PhotoModel> mPhotoList) {
    this.mPhotoList = mPhotoList;
  }
}
