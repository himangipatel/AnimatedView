package com.bnbjobs.activity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Telephony;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.model.JobDetail;
import com.bnbjobs.model.PhotoModel;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.widget.ShareDialog;
import java.util.List;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.Utils.getEuro;

public class ShareActivity extends BaseActivity {

  @BindView(R.id.iv_close) ImageView ivClose;
  @BindView(R.id.tvEmail) TextView tvEmail;
  @BindView(R.id.tvSMS) TextView tvSMS;
  @BindView(R.id.tvCopy) TextView tvCopy;
  @BindView(R.id.tvfacebok) TextView tvfacebok;
  @BindView(R.id.tvMessager) TextView tvMessager;
  @BindView(R.id.tvWhatsApp) TextView tvWhatsApp;
  @BindView(R.id.tvPlus) TextView tvPlus;
  @BindView(R.id.relFacebook) RelativeLayout relFacebook;
  @BindView(R.id.relMessenger) RelativeLayout relMessenger;
  @BindView(R.id.relWhatsapp) RelativeLayout relWhatsApp;
  private ShareDialog shareDialog;
  private CallbackManager callbackManager;
  private JobDetail jobDetail;
  private String TAG = ShareActivity.class.getSimpleName();

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_share);
    ButterKnife.bind(this);
    jobDetail = getIntent().getParcelableExtra(Constants.KEY_OBJECT);
    callbackManager = CallbackManager.Factory.create();
    shareDialog = new ShareDialog(this);
    shareDialog.registerCallback(callbackManager, new FacebookCallback<Sharer.Result>() {
      @Override public void onSuccess(Sharer.Result result) {

      }

      @Override public void onCancel() {
        LOGI(TAG, "Cancel Share");
      }

      @Override public void onError(FacebookException error) {
        LOGI(TAG, Log.getStackTraceString(error));
      }
    });
  }

  @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    callbackManager.onActivityResult(requestCode, resultCode, data);
  }

  @OnClick({
      R.id.iv_close, R.id.tvEmail, R.id.tvSMS, R.id.tvCopy, R.id.tvfacebok, R.id.tvMessager,
      R.id.tvWhatsApp, R.id.tvPlus
  }) void onClick(View view) {
    int id = view.getId();
    Intent sharingIntent = new Intent(Intent.ACTION_SEND);
    if (id == R.id.iv_close) {
      finish();
    } else if (id == R.id.tvEmail) {
      String[] TO = { "" };
      String[] CC = { "" };
      sharingIntent.setData(Uri.parse("mailto:"));
      sharingIntent.setType("text/plain");
      sharingIntent.putExtra(Intent.EXTRA_EMAIL, TO);
      sharingIntent.putExtra(Intent.EXTRA_CC, CC);
      sharingIntent.putExtra(Intent.EXTRA_SUBJECT, jobDetail.getTitle());
      sharingIntent.putExtra(Intent.EXTRA_TEXT, getMailText());
      try {
        startActivity(Intent.createChooser(sharingIntent, "Send mail..."));
      } catch (android.content.ActivityNotFoundException ex) {
        Toast.makeText(this, "There is no email client installed.", Toast.LENGTH_SHORT).show();
      }
    } else if (id == R.id.tvSMS) {
      sendSMS("");
    } else if (id == R.id.tvCopy) {
      ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
      ClipData clip = ClipData.newPlainText("Copied text", getMailText());
      clipboard.setPrimaryClip(clip);
    } else if (id == R.id.tvfacebok) {
      send();
    } else if (id == R.id.tvMessager) {
      shareIntent("com.facebook.orca");
    } else if (id == R.id.tvWhatsApp) {
      shareIntent("com.whatsapp");
    } else if (id == R.id.tvPlus) {
      shareIntent("com.google.android.apps.plus");
    }
  }

  private void sendSMS(String phoneNumber) {
    // At least KitKat
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
      String defaultSmsPackageName =
          Telephony.Sms.getDefaultSmsPackage(this); // Need to change the build to API 19

      Intent sendIntent = new Intent(Intent.ACTION_SEND);
      sendIntent.setType("text/plain");
      sendIntent.putExtra(Intent.EXTRA_TEXT, getMailText());
      sendIntent.putExtra(Intent.EXTRA_PHONE_NUMBER, phoneNumber);
      // Can be null in case that there is no default, then the user would be able to choose
      if (defaultSmsPackageName != null) {
        sendIntent.setPackage(defaultSmsPackageName);
      }
      startActivity(sendIntent);
    } else {
      // For early versions, do what worked for you before.
      Intent smsIntent = new Intent(android.content.Intent.ACTION_VIEW);
      smsIntent.setType("vnd.android-dir/mms-sms");
      smsIntent.putExtra("address", phoneNumber);
      smsIntent.putExtra("sms_body", getMailText());
      startActivity(smsIntent);
    }
  }

  private void send() {
    if (ShareDialog.canShow(SharePhotoContent.class)) {
      ShareLinkContent linkContent =
          new ShareLinkContent.Builder().setContentTitle(jobDetail.getTitle())
              .setContentDescription(getMailText())
              .setContentUrl(Uri.parse(getImageUrl()))
              .setImageUrl(Uri.parse(getImageUrl()))
              .build();
      shareDialog.show(this, linkContent);
    }
  }

  private String getImageUrl() {
    List<PhotoModel> imageModels = jobDetail.getmImageList();
    if (!imageModels.isEmpty()) {
      LOGI(TAG, "image url is " + imageModels.get(0).getImageUrl());
      return imageModels.get(0).getImageUrl();
    }
    return "";
  }

  private void shareIntent(String packageName) {
    Intent sendIntent = new Intent();
    sendIntent.setAction(Intent.ACTION_SEND);
    sendIntent.putExtra(Intent.EXTRA_TEXT, getMailText());
    sendIntent.setType("text/plain");
    sendIntent.setPackage(packageName);
    try {
      startActivity(sendIntent);
    } catch (android.content.ActivityNotFoundException ex) {
      Toast.makeText(this, "Application not found.", Toast.LENGTH_LONG).show();
    }
  }

  private String getMailText() {
    return "Hi there,"
        + "\n"
        + "Check out this job "
        + jobDetail.getTitle()
        + "\n"
        + getString(R.string.description)
        + ": "
        + jobDetail.getDescription()
        + "\n"
        + getString(R.string.gross_salary)
        + " "
        + getSalary(jobDetail.getSalary())
        + "\n"
        + getString(R.string.experience)
        + ": "
        + getString(R.string.experience_label_year,
        String.valueOf(jobDetail.getExperienceRequired()))
        + "\n"
        + getString(R.string.required_qualities_label)
        + " "
        + jobDetail.getQuality()
        + "\n"
        + getString(R.string.other_benefits_label)
        + " "
        + jobDetail.getOtherBenefits()
        + "\n"
        + "https://play.google.com/store/apps/details?id="
        + getPackageName();
  }

  /**
   * for sup text format
   *
   * @param value text
   * @return html string
   */
  private Spanned getSalary(String value) {
    value = isEmpty(value) ? "0" : value;
    try {
      return Html.fromHtml(Utils.decimalFormat(Double.valueOf(value))
          + "<small><sup> "
          + getEuro()
          + "/M </sup></small>");
    } catch (Exception e) {
      LOGI(TAG, Log.getStackTraceString(e));
    }
    return Html.fromHtml("0");
  }
}
