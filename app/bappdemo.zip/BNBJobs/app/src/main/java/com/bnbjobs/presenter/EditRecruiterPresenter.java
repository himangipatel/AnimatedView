/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.model.UserModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.EditRecruiterView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.ActivityEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.util.HashMap;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */
public class EditRecruiterPresenter extends BasePresenter implements Presenter<EditRecruiterView> {

  private static final int CAMERA_BANNER = 112;
  private static final int GALLERY_BANNER = 113;
  private static final String TAG = makeLogTag(EditRecruiterPresenter.class);
  private EditRecruiterView mEditRecruiterView;

  @Override public void attachView(EditRecruiterView view) {
    mEditRecruiterView = view;
  }

  @Override public void detachView() {
    mEditRecruiterView = null;
  }

  @Override protected Context getBaseContext() {
    return mEditRecruiterView.getContext();
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseActivity) getBaseContext()).bindUntilEvent(ActivityEvent.DESTROY);
  }

  /**
   * showChangePhotoDialog
   * Show the dialog for photo selection options
   */
  public void showChangePhotoDialog() {
    imagePicker(new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        if (which == 0) {
          mEditRecruiterView.openCamera(false);
        } else if (which == 1) {
          mEditRecruiterView.openGallery(false);
        } else {
          mEditRecruiterView.setDefault(false);
        }
      }
    }, mEditRecruiterView.isImageSet()).show();
  }

  /**
   * showChangePhotoDialog
   * Show the dialog for photo selection options
   */
  public void showChangeBannerDialog() {
    imagePicker(new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        if (which == 0) {
          mEditRecruiterView.openCamera(true);
        } else if (which == 1) {
          mEditRecruiterView.openGallery(true);
        } else {
          mEditRecruiterView.setDefault(true);
        }
      }
    }, mEditRecruiterView.isImageSet()).show();
  }

  public void openCamera() {
    requestImageFromCamera(REQUEST_CODE_CAMERA);
  }

  public void openGallery() {
    requestImageFromGallery(REQUEST_CODE_GALLERY);
  }

  public void openCameraBanner() {
    requestImageFromCamera(CAMERA_BANNER);
  }

  public void openGalleryBanner() {
    requestImageFromGallery(GALLERY_BANNER);
  }

  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (resultCode == Activity.RESULT_OK) {
      Uri uri = null;
      String path = "";
      if (requestCode == REQUEST_CODE_CAMERA) {
        path = mCameraOutputPath;
        if (!isEmpty(path)) {
          mEditRecruiterView.showPhoto(path);
        }
      } else if (requestCode == REQUEST_CODE_GALLERY) {
        uri = data.getData();
        path = getRealPathFromURI(uri);
        if (!isEmpty(path)) {
          mEditRecruiterView.showPhoto(path);
        }
      } else if (requestCode == CAMERA_BANNER) {
        path = mCameraOutputPath;
        if (!isEmpty(path)) {
          mEditRecruiterView.showBannerPath(path);
        }
      } else if (requestCode == GALLERY_BANNER) {
        uri = data.getData();
        path = getRealPathFromURI(uri);
        if (!isEmpty(path)) {
          mEditRecruiterView.showBannerPath(path);
        }
      }
    }
  }

  private boolean isValid() {
    if (!Utils.isValidEmail(mEditRecruiterView.getEmail())) {
      showMessage(getBaseContext(), getString(R.string.enter_valid_email_address));
      return false;
    } else if (isEmpty(mEditRecruiterView.getFirstName())) {
      showMessage(getBaseContext(), getString(R.string.enter_valid_first_name));
      return false;
    } else if (!isEmpty(mEditRecruiterView.getPassword())
        && mEditRecruiterView.getPassword().length() < 8) {
      showMessage(getBaseContext(),
          getBaseContext().getString(R.string.enter_valid_password_length));
      return false;
    } else if (isEmpty(mEditRecruiterView.getLastName())) {
      showMessage(getBaseContext(), getString(R.string.enter_valid_last_name));
      return false;
    } else if (isEmpty(mEditRecruiterView.getPhoneNumber())) {
      showMessage(getBaseContext(), getString(R.string.enter_your_phone_number));
      return false;
    }
    return true;
  }

  public void updateProfile() {
    if (!isValid()) {
      return;
    }
    mEditRecruiterView.showProgress();
    HashMap<String, RequestBody> params = new HashMap<>(15);
    params.put("apiName", toRequestBody("updateRecruiterProfile"));
    params.put("email", toRequestBody(mEditRecruiterView.getEmail()));
    if (!isEmpty(mEditRecruiterView.getPassword())) {
      params.put("password", toRequestBody(mEditRecruiterView.getPassword()));
    }
    params.put("firstname", toRequestBody(mEditRecruiterView.getFirstName()));
    params.put("lastname", toRequestBody(mEditRecruiterView.getLastName()));
    params.put("phone", toRequestBody(mEditRecruiterView.getPhoneNumber()));
    params.put("company", toRequestBody(mEditRecruiterView.getCompanyName()));
    if (mEditRecruiterView.getProfilePhoto() != null) {
      params.put("profileImage\"; filename=\"pp.png\"",
          RequestBody.create(MediaType.parse("image/*"), mEditRecruiterView.getProfilePhoto()));
    }
    if (mEditRecruiterView.getBannerImage() != null) {
      params.put("bannerImage\"; filename=\"pp2.png\"",
          RequestBody.create(MediaType.parse("image/*"), mEditRecruiterView.getBannerImage()));
    }
    params.putAll(addParamsBody(params));
    RestClient.getInstance()
        .apiCallImage(params)
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            mEditRecruiterView.hideProgress();
          }

          @Override public void onNext(String s) {
            mEditRecruiterView.hideProgress();
            try {
              JSONObject object = new JSONObject(s);
              if (isResponseSuccess(s)) {
                JSONObject data = object.optJSONObject("data");
                JSONObject userData = data.optJSONObject("userData");
                UserModel userModel = new Gson().fromJson(userData.toString(), UserModel.class);
                mEditRecruiterView.onUpdated(userModel);
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }
}
