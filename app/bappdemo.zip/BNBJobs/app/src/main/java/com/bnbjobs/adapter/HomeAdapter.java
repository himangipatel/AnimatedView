/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.JobModel;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.List;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.Utils.openUrl;

/**
 * @author Harsh
 * @version 1.0
 */
public class HomeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

  private final int VIEW_TYPE_ITEM = 0;
  private final int VIEW_TYPE_LOADING = 1;
  private Context mContext;
  private int height;
  private List<JobModel> mJobModel = new ArrayList<>();
  private ClickImpl click;
  private boolean isFavorite;

  public HomeAdapter(Context mContext, int height, List<JobModel> mJobModelList, Fragment fragment) {
    this.mContext = mContext;
    this.height = height;
    this.mJobModel = mJobModelList;
    click = (ClickImpl) fragment;
  }

  public void setIsFavorite(boolean isFavorite) {
    this.isFavorite = isFavorite;
  }

  @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    if (viewType == VIEW_TYPE_ITEM) {
      View view;
      if (isFavorite) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_fav_job, parent, false);
      } else {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_home, parent, false);
      }
      RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) view.getLayoutParams();
      params.height = height / 2;
      view.setLayoutParams(params);
      return new MyViewHolder(view);
    } else if (viewType == VIEW_TYPE_LOADING) {
      View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.progress, parent, false);
      return new LoadingViewHolder(view);
    }
    return null;
  }

  @Override public void onBindViewHolder(RecyclerView.ViewHolder mHolder, int position) {
    if (mHolder instanceof MyViewHolder) {
      MyViewHolder holder = (MyViewHolder) mHolder;
      JobModel jobModel = mJobModel.get(position);
      holder.tvTitle.setText(jobModel.getdTitle());
      holder.tvDescription.setText(jobModel.getRpDescription());
      holder.tvLocation.setText(jobModel.getRpLocation());
      holder.tvSalary.setText(jobModel.getSalaryPrice(mContext.getResources().getString(R.string.month_label)));
      Glide.with(mContext).load(jobModel.getImage()).placeholder(R.drawable.placeholder).into(holder.imageView);
      if (isEmpty(jobModel.getRpVideoUrl())) {
        holder.linearPlay.setVisibility(View.GONE);
      } else {
        holder.linearPlay.setVisibility(View.VISIBLE);
      }
      holder.tvSalary.setBackgroundResource(jobModel.getAppliedColor());
      holder.tvSalary.setTextColor(jobModel.getColor());

    } else if (mHolder instanceof LoadingViewHolder) {
      LoadingViewHolder loadingViewHolder = (LoadingViewHolder) mHolder;
      loadingViewHolder.progressBar.setIndeterminate(true);
    }
  }

  @Override public int getItemViewType(int position) {
    return mJobModel.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
  }

  @Override public int getItemCount() {
    return mJobModel == null ? 0 : mJobModel.size();
  }

  private static class LoadingViewHolder extends RecyclerView.ViewHolder {
    ProgressBar progressBar;

    LoadingViewHolder(View itemView) {
      super(itemView);
      progressBar = (ProgressBar) itemView.findViewById(R.id.progressBar);
    }
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {
    @BindView(R.id.imageView) ImageView imageView;
    @BindView(R.id.tvTitle) TextView tvTitle;
    @BindView(R.id.tvLocation) TextView tvLocation;
    @BindView(R.id.linearPlay) LinearLayout linearPlay;
    @BindView(R.id.tvDescription) TextView tvDescription;
    @BindView(R.id.tvSalary) TextView tvSalary;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
      itemView.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          click.onClick(v, mJobModel.get(getLayoutPosition()), getLayoutPosition());
        }
      });
    }

    @OnClick({ R.id.linearPlay }) void onPlay() {
      openUrl(mContext, mJobModel.get(getLayoutPosition()).getRpVideoUrl());
    }
  }
}
