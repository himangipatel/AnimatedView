/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnEditorAction;
import butterknife.OnTouch;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.adapter.HomeRecruiterAdapter;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.CandidateModel;
import com.bnbjobs.presenter.HomeRecruiterPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.EndlessRecyclerViewScrollListener;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.HomeRecruiterView;
import java.util.ArrayList;
import java.util.List;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class SearchRecruiterDetailFragment extends BaseFragment
    implements HomeRecruiterView, ClickImpl<CandidateModel> {

  private static final String TAG = makeLogTag(HomeRecruiterFragment.class);
  private static final int REGULAR_TYPE = 1;
  private static final int PULL_TYPE = 2;
  private static final int SEARCH_TYPE = 3;
  @BindView(R.id.recyclerView) RecyclerView recyclerView;
  @BindView(R.id.filterRecycler) RecyclerView filterRecycler;
  @BindView(R.id.swipeRefresh) SwipeRefreshLayout mSwipeRefresh;
  @BindView(R.id.linearFilter) LinearLayout linearFilter;
  @BindView(R.id.tvCurrentLocation) TextView tvCurrentLocation;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.etSearch) EditText etSearch;
  @BindView(R.id.tvNoRecord) TextView tvNoRecord;
  @BindView(R.id.linearSearch) LinearLayout linearSearch;
  @BindView(R.id.imageFilter) ImageView imageFilter;
  private HomeRecruiterAdapter adapter;
  private HomeRecruiterPresenter presenter;
  private List<CandidateModel> mCandidateList = new ArrayList<>();
  private EndlessRecyclerViewScrollListener listener;
  private Unbinder unbinder;
  private boolean loadMore;
  private boolean isFooterAdd;

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_list, container, false);
    unbinder = ButterKnife.bind(this, view);
    if (presenter == null) {
      presenter = new HomeRecruiterPresenter();
    }
    presenter.attachView(this);
    presenter.setFragment(this);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    tvCurrentLocation.setText(getArguments().getString(Constants.KEY_TYPE));
    recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
    recyclerView.setLayoutManager(linearLayoutManager);
    linearSearch.setVisibility(View.GONE);
    linearFilter.setVisibility(View.GONE);
    imageFilter.setVisibility(View.GONE);
    presenter.setSearchDetail(getArguments());
    if (adapter == null && mCandidateList.isEmpty()) {
      adapter = new HomeRecruiterAdapter(getActivity(), mCandidateList, this);
      showProgress();
      presenter.getCandidates(REGULAR_TYPE);
    }
    recyclerView.setAdapter(adapter);
    mSwipeRefresh.setColorSchemeResources(R.color.colorPrimary, R.color.theme_blue,
        R.color.theme_pink, android.R.color.holo_orange_dark);
    mSwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
      @Override public void onRefresh() {
        onRefreshCall();
      }
    });

    recyclerView.addOnScrollListener(new EndlessRecyclerViewScrollListener(linearLayoutManager) {
      @Override public void onLoadMore(int page, int totalItemsCount) {
        listener = this;
        LOGI(TAG, "onLoadMore Called");
        if (loadMore) {
          LOGI(TAG, "onLoadMore Called inner");
          if (isFooterAdd) {
            return;
          }
          adapter.notifyItemInserted(mCandidateList.size() - 1);
          isFooterAdd = true;
          mCandidateList.add(null);
          presenter.getCandidates(isEmpty(Utils.getText(etSearch)) ? REGULAR_TYPE : SEARCH_TYPE);
        }
      }
    });
  }

  @Override public void onResume() {
    super.onResume();
    showToolbar(false);
  }

  private void onRefreshCall() {
    if (listener != null) {
      listener.setLoading(false);
    }
    presenter.resetRequest(PULL_TYPE);
  }

  private void clearFocus() {
    etSearch.clearFocus();
    InputMethodManager imm = (InputMethodManager) getActivity().getApplicationContext()
        .getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.hideSoftInputFromWindow(etSearch.getWindowToken(), 0);
  }

  @OnTouch(R.id.linearFilter) boolean relativeFilter() {
    return true;
  }

  @Override public Context getContext() {
    return getActivity();
  }

  @Override public void onDestroyView() {
    presenter.detachView();
    unbinder.unbind();
    super.onDestroyView();
  }

  @Override public void onStop() {
    super.onStop();
    if (isFooterAdd) {
      loadMore = true;
    }
    removeFooter();
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void setAdapter(List<CandidateModel> candidateModels,boolean clear) {
    removeFooter();
    if (clear || mCandidateList.isEmpty()) {
      this.mCandidateList.clear();
      mSwipeRefresh.setRefreshing(false);
    }
    this.mCandidateList.addAll(candidateModels);
    adapter.notifyDataSetChanged();
    if (adapter.getItemCount() > 0) {
      tvNoRecord.setVisibility(View.GONE);
    } else {
      tvNoRecord.setVisibility(View.VISIBLE);
    }
  }

  private void removeFooter() {
    if (isFooterAdd) {
      isFooterAdd = false;
      this.mCandidateList.remove(this.mCandidateList.size() - 1);
      adapter.notifyItemRemoved(this.mCandidateList.size());
    }
  }

  @OnEditorAction(R.id.etSearch) boolean onSearchPress(TextView v, int actionId, KeyEvent event) {
    if (actionId == EditorInfo.IME_ACTION_SEARCH) {
      clearFocus();
      return true;
    }
    return false;
  }

  @Override public void loadMore(boolean loadMore) {
    this.loadMore = loadMore;
  }

  @Override public void onError(String msg) {
    if (mSwipeRefresh.isRefreshing()) {
      mSwipeRefresh.setRefreshing(false);
    }
  }

  @Override public void clearData() {
    mCandidateList.clear();
  }

  @Override public void setFavAdapter(List<CandidateModel> candidateModelList, boolean clear) {

  }

  @Override public void setLoadMore(boolean loadMore) {

  }

  @Override public String getOffset() {
    return null;
  }

  @Override public void showSmallProgress(boolean show) {

  }

  @Override public void changeFavoriteStatus(CandidateModel candidateModel) {

  }

  @Override public void onClick(View view, CandidateModel object, int position) {
    ProfileFragment fragment = new ProfileFragment();
    Bundle bundle = new Bundle();
    bundle.putString(Constants.KEY_ID, object.getuId());
    fragment.setArguments(bundle);
    addFragment(fragment, true);
  }
}
