/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.DescriptionView;
import com.trello.rxlifecycle.ActivityEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.Utils.isResponseSuccess;

/**
 * @author Harsh
 * @version 1.0
 */

public class DescriptionPresenter extends BasePresenter implements Presenter<DescriptionView> {


  private DescriptionView mDescriptionView;

  @Override public void attachView(DescriptionView view) {
    mDescriptionView = view;
  }

  @Override public void detachView() {
    mDescriptionView = null;
  }


  public void updateDesignation(String text){
    mDescriptionView.showProgress();
    HashMap<String,String> params = new HashMap<>();
    params.put("apiName","editCandidateDescription");
    params.put("description",text);
    params.putAll(addParams(params));

    RestClient.getInstance(params)
        .compose(getBindEvent())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            mDescriptionView.hideProgress();
            LOGE(TAG,e.getMessage(),e);
            mDescriptionView.onError(e);
          }

          @Override public void onNext(String s) {
            mDescriptionView.hideProgress();
            if(isResponseSuccess(s)){
              try {
                JSONObject object = new JSONObject(s);
                mDescriptionView.updateDesignation(object.optInt("profilePercentage"));
              } catch (JSONException e) {
                e.printStackTrace();
              }
            }
          }
        });
  }


  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseActivity) getBaseContext()).bindUntilEvent(ActivityEvent.DESTROY);
  }
  @Override protected Context getBaseContext() {
    return mDescriptionView.getContext();
  }


}
