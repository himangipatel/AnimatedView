/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.utils;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * @author Harsh
 * @version 1.0
 */
public class CustomItemDecoration extends RecyclerView.ItemDecoration {

  private final int mVerticalSpaceHeight;

  public CustomItemDecoration(int mVerticalSpaceHeight) {
    this.mVerticalSpaceHeight = mVerticalSpaceHeight;
  }

  @Override public void getItemOffsets(Rect outRect, View view, RecyclerView parent,
      RecyclerView.State state) {
    int position = parent.getChildAdapterPosition(view);
    if (position == 0) {
      outRect.left = 0;
    } else {
      outRect.left = mVerticalSpaceHeight;
    }
  }
}
