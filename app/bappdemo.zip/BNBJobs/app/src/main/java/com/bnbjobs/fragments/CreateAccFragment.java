/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.utils.Constants;

import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class CreateAccFragment extends DialogFragment {

  private static final String TAG = makeLogTag(CreateAccFragment.class);
  @BindView(R.id.imgDetailIcon) ImageView imgDetailIcon;
  @BindView(R.id.linear_account_root) LinearLayout linearAccRoot;
  @BindView(R.id.iv_close) ImageView ivClose;
  @BindView(R.id.tv_create_profile) TextView tvCreateProfile;
  @BindView(R.id.tv_connect_yourself) TextView tvConnectYourSelf;
  @BindView(R.id.tvAccMsg) TextView tvAccMsg;
  @BindView(R.id.linear_acc_center) LinearLayout linear_acc_center;
  @BindView(R.id.tvOk) TextView tvOk;
  private Unbinder unbinder;
  private int imageHeight;
  private int profileVisibleType;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setStyle(DialogFragment.STYLE_NO_TITLE, R.style.DialogTheme);
    Drawable crossImage = ContextCompat.getDrawable(getActivity(), R.drawable.small_cross);
    imageHeight = crossImage.getIntrinsicHeight();
    profileVisibleType = getArguments().getInt(Constants.KEY_VISIBLE_TYPE);
  }

  @Nullable @Override public View onCreateView(LayoutInflater inflater, ViewGroup container,
      Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.creat_account, container, false);
    unbinder = ButterKnife.bind(this, view);
    setViewTreeObserver();
    setVisibilityViews();
    return view;
  }

  @Override public void onActivityCreated(Bundle savedInstanceState) {
    super.onActivityCreated(savedInstanceState);
    getDialog().setCancelable(true);
    final WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
    lp.copyFrom(getDialog().getWindow().getAttributes());
    lp.width = WindowManager.LayoutParams.MATCH_PARENT;
    lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
    lp.gravity = Gravity.CENTER;
    getDialog().getWindow().setAttributes(lp);
  }

  @Override public void onDestroyView() {
    super.onDestroyView();
    unbinder.unbind();
  }

  private void setViewTreeObserver() {
    ViewTreeObserver vto = linearAccRoot.getViewTreeObserver();
    vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
      @Override public void onGlobalLayout() {
        if (Build.VERSION.SDK_INT <= 16) {
          linearAccRoot.getViewTreeObserver().removeGlobalOnLayoutListener(this);
        } else {
          linearAccRoot.getViewTreeObserver().removeOnGlobalLayoutListener(this);
        }
        int[] points = new int[2];
        linearAccRoot.getLocationOnScreen(points);
        ivClose.setY(points[1] + (imageHeight / 2));
      }
    });
  }

  private void setVisibilityViews() {
    if (profileVisibleType == Constants.PROFILE_VISIBLE_TYPE1) {
      tvConnectYourSelf.setVisibility(View.GONE);
      tvCreateProfile.setVisibility(View.GONE);
      tvAccMsg.setVisibility(View.GONE);
      linear_acc_center.setVisibility(View.VISIBLE);
    } else if (profileVisibleType == Constants.PROFILE_VISIBLE_TYPE2) {
      tvConnectYourSelf.setVisibility(View.GONE);
      tvCreateProfile.setVisibility(View.GONE);
      tvAccMsg.setVisibility(View.GONE);
      linear_acc_center.setVisibility(View.VISIBLE);
    }
  }

  @OnClick({ R.id.iv_close }) void onClick(View view) {
    dismiss();
  }

  @OnClick({ R.id.linear_acc_center }) void onOkay(View view) {
    dismiss();
    // 3 is redirect to profile fragment
    ((HomeActivity) getActivity()).handleTab(3);
    ((HomeActivity) getActivity()).setSelectedTab(3);
  }
}
