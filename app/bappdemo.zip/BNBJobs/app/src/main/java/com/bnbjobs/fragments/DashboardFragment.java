/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.activity.DiscountActivity;
import com.bnbjobs.activity.EditRecruiterActivity;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.adapter.JobProviderRecyclePager;
import com.bnbjobs.customui.looppager.LoopRecyclerViewPager;
import com.bnbjobs.customui.looppager.RecyclerViewPager;
import com.bnbjobs.customui.views.CircleImageView;
import com.bnbjobs.customui.views.PagerSlidingTabStrip;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.CandidateModel;
import com.bnbjobs.model.DashboardData;
import com.bnbjobs.model.JobOfferData;
import com.bnbjobs.model.PaymentAction;
import com.bnbjobs.model.UpdateEvent;
import com.bnbjobs.model.UserModel;
import com.bnbjobs.presenter.DashboardPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.view.DashboardView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.getContractValue;

/**
 * @author Harsh
 * @version 1.0
 */
public class DashboardFragment extends BaseFragment implements DashboardView, ClickImpl<Object> {

  private static final String TAG = makeLogTag(DashboardFragment.class);
  @BindView(R.id.tvPhoneNo) TextView tvPhoneNo;
  @BindView(R.id.tvModifier) TextView tvModifier;
  @BindView(R.id.tvAddress) TextView tvAddress;
  @BindView(R.id.tvEmailAddress) TextView tvEmailAddress;
  @BindView(R.id.tvVisitCount) TextView tvVisitCount;
  @BindView(R.id.tvPostAd) TextView tvPostAd;
  @BindView(R.id.tvProfileAlert) TextView tvProfileAlert;
  @BindView(R.id.tvAlertLabel) TextView tvAlertLabel;
  @BindView(R.id.tvCandidateCount) TextView tvCandidateCount;
  @BindView(R.id.tvCandidaturesLabel) TextView tvCandidaturesLabel;
  @BindView(R.id.tv_photos_label) TextView tvPhotosLabel;
  @BindView(R.id.tv_contract_label) TextView tvContractLabel;
  @BindView(R.id.tvContractValue) TextView tvContractValue;
  @BindView(R.id.tv_debut_label) TextView tvDebutLabel;
  @BindView(R.id.tvDebutValue) TextView tvDebutValue;
  @BindView(R.id.tv_end_label) TextView tvEndLabel;
  @BindView(R.id.tvEndDate) TextView tvEndDate;
  @BindView(R.id.tvSalary) TextView tvSalary;
  @BindView(R.id.tvVacancyLabel) TextView tvVacancyLabel;
  @BindView(R.id.tvCandidateLabel) TextView tvCandidateLabel;
  @BindView(R.id.viewpager) LoopRecyclerViewPager mRecyclerViewPager;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.tvUserName) TextView tvUserName;
  @BindView(R.id.imageBanner) ImageView imageBanner;
  @BindView(R.id.pager) ViewPager pager;
  @BindView(R.id.tabs) PagerSlidingTabStrip tabs;
  @BindView(R.id.ivCircle) CircleImageView ivCircle;
  @BindView(R.id.tvNoRecord) TextView tvNoRecord;
  @BindView(R.id.tvSkipPremium) TextView tvSkipPremium;
  @BindView(R.id.linearPremiumOffer) LinearLayout linearPremiumOffer;
  private int approvedCandidate;
  private int favoriteCandidate;
  private int appliedCandidate;
  private int totalCandidate;
  private List<JobOfferData> jobPostDetails = new ArrayList<>();
  private DashboardPresenter presenter;
  private Unbinder unbinder;
  private JobProviderRecyclePager jobAdapter;
  private UserModel userDetail;
  private View view;
  private SampleFragmentPagerAdapter pagerAdapter;
  private boolean isPurchase;
  private String[] tabTitles;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    EventBus.getDefault().register(this);
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    if (view == null) {
      view = inflater.inflate(R.layout.fragment_dashboard, container, false);
    }
    unbinder = ButterKnife.bind(this, view);
    presenter = new DashboardPresenter();
    presenter.attachView(this);
    presenter.setFragment(this);
    return view;
  }

  /**
   * onView created
   *
   * @param view view
   * @param savedInstanceState save instance of fragment
   */
  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    setTitle("Dashboard Enterprise");
    initViewPager();
    if (userDetail == null) {
      presenter.getDashboard();
    }
  }

  /**
   * initialize view pager
   */
  private void initViewPager() {
    LinearLayoutManager layout =
        new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
    mRecyclerViewPager.setTriggerOffset(0.01f);
    mRecyclerViewPager.setFlingFactor(0.01f);
    mRecyclerViewPager.setLayoutManager(layout);
    mRecyclerViewPager.setHasFixedSize(true);
    mRecyclerViewPager.setLongClickable(true);
    mRecyclerViewPager.setSinglePageFling(true);
    mRecyclerViewPager.addOnPageChangedListener(new RecyclerViewPager.OnPageChangedListener() {
      @Override public void OnPageChanged(int oldPosition, int newPosition) {
        int actualPosition = newPosition % jobAdapter.getItemCount();
        if (jobPostDetails.size() > 0) {
          JobOfferData jobOfferData = jobPostDetails.get(actualPosition);
          setJobData(jobOfferData);
        }
      }
    });

  }

  @Override public void onResume() {
    super.onResume();
    showToolbar(true);
  }

  @Subscribe public void onEvent(UserModel model) {
    setUserDetail(model);
  }

  @Subscribe public void onEvent(PaymentAction action) {
    if (action.finish) {
      tvSkipPremium.setText(R.string.plan_purchased);
      tvSkipPremium.setBackgroundResource(R.drawable.green_drawable);
    }
  }

  @Subscribe public void onEvent(UpdateEvent event) {
    if (event.update) {
      view = null;
      userDetail = null;
    }
  }

  private void setJobData(JobOfferData jobOfferData) {
    tvContractValue.setText(getContractValue(jobOfferData.getContractType()));
    if (!isEmpty(jobOfferData.getStartDate())) {
      tvDebutValue.setText(showDate(jobOfferData.getStartDate()));
    }
    if (!isEmpty(jobOfferData.getEndDate())) {
      tvEndDate.setText(showDate(jobOfferData.getEndDate()));
    }
    tvSalary.setText(jobOfferData.hourSalaryDisplay());
  }

  /**
   * onDestroyView
   */
  @Override public void onDestroyView() {
    presenter.detachView();
    unbinder.unbind();
    super.onDestroyView();
  }

  @Override public void onDestroy() {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  /**
   * show progress on long running operation
   */
  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  /**
   * hide progress bar
   */
  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @OnClick(R.id.linearProgress) void onProgress() {
  }

  @OnClick(R.id.tvModifier) void onEdit() {
    Intent intent = new Intent(getActivity(), EditRecruiterActivity.class);
    intent.putExtra(Constants.KEY_OBJECT, userDetail);
    startActivity(intent);
  }

  @Override public RecyclerViewPager getRecyclerViewPager() {
    return mRecyclerViewPager;
  }

  @OnClick(R.id.linearPremiumOffer) void navigateToPremiumOffer() {
    if (isPurchase) {
      return;
    }
    startActivity(new Intent(getActivity(), DiscountActivity.class));
  }

  @Override public void setUserDetail(UserModel userDetail1) {
    this.userDetail = userDetail1;
    tvUserName.setText(userDetail.getfName() + " " + userDetail.getlName());
    tvPhoneNo.setText(userDetail.getU_phone());
    tvEmailAddress.setText(userDetail.getU_email());
    isPurchase = userDetail.isPremiumplan();
    if (isPurchase) {
      onEvent(new PaymentAction(true));
    }
    Glide.with(getActivity())
        .load(userDetail.getBannerImageUrl())
        .placeholder(R.drawable.placeholder)
        .dontAnimate()
        .into(imageBanner);
    Glide.with(getActivity())
        .load(userDetail.getImageThumb())
        .placeholder(R.drawable.user_placeholder)
        .dontAnimate()
        .into(ivCircle);
  }

  @Override public void setPagerAdapter() {
    pagerAdapter = new SampleFragmentPagerAdapter(getChildFragmentManager(), tabTitles);
    pager.setAdapter(pagerAdapter);
    pager.setOffscreenPageLimit(2);
    tabs.setViewPager(pager);
    tabs.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
      @Override public void onPageSelected(int position) {
        tabs.setSelectTab(position);
      }

      @Override
      public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
      }

      @Override public void onPageScrollStateChanged(int state) {
      }
    });
    tabs.setSelectTab(0);
  }

  @Override public void setJobOffer(List<JobOfferData> jobOffer) {
    ((ProfileRecruiterFragment) getParentFragment()).setJobOfferData(jobOffer);
    jobPostDetails.clear();
    jobPostDetails.addAll(jobOffer);
    if (jobOffer.size() > 0) {
      jobAdapter = new JobProviderRecyclePager(getActivity(), jobPostDetails, this);
      mRecyclerViewPager.setAdapter(jobAdapter);
      presenter.setRecyclerViewSettings();
    } else {
      mRecyclerViewPager.setVisibility(View.GONE);
      tvNoRecord.setVisibility(View.VISIBLE);
    }
  }

  @Override public void setCount(DashboardData dashboardData) {
    tvProfileAlert.setText(String.valueOf(dashboardData.getTotalAlertProfile()));
    tvCandidateCount.setText(String.valueOf(dashboardData.getTotalAllCandidate()));
    ((ProfileRecruiterFragment) getParentFragment()).setTvCount(
        String.valueOf(dashboardData.getTotalAllCandidate()));
    tvVisitCount.setText(String.valueOf(dashboardData.getTotalJobOfferVisitor()));
    totalCandidate = dashboardData.getTotalAllCandidate();
    appliedCandidate = dashboardData.getTotalAppliedCandidate();
    approvedCandidate = dashboardData.getTotalApproveCandidate();
    favoriteCandidate = dashboardData.getTotalFavoriteCandidate();
    tabTitles = new String[] {
        getString(R.string.all_tab, totalCandidate),
        getString(R.string.expectation_tab, appliedCandidate),
        getString(R.string.contacted_tab, approvedCandidate),
        getString(R.string.favourites_tab, favoriteCandidate)
    };
  }

  @Override public void setAddress(String address) {
    tvAddress.setText(address);
    userDetail.setLocalLocation(address);
  }

  public void totalCandidate(int type, boolean add) {
    switch (type) {
      case 1:
        if (!add) {
          totalCandidate -= 1;
          tabTitles[0] = getString(R.string.all_tab, totalCandidate);
          tvCandidateCount.setText(String.format(Locale.ENGLISH, "%s", totalCandidate));
          ((ProfileRecruiterFragment) getParentFragment()).setTvCount(
              Integer.toString(totalCandidate));
        }
        break;
      case 2:
        appliedCandidate -= 1;
        tabTitles[1] = getString(R.string.expectation_tab, appliedCandidate);
        break;
      case 3:
        if (add) {
          approvedCandidate += 1;
          tabTitles[2] = getString(R.string.contacted_tab, approvedCandidate);
        }
        break;
      case 4:
        if (add) {
          favoriteCandidate += 1;
        } else {
          favoriteCandidate -= 1;
        }
        tabTitles[3] = getString(R.string.favourites_tab, favoriteCandidate);
        break;
    }
    pagerAdapter.notifyDataSetChanged();
    tabs.notifyDataSetChanged();
  }

  public void candidateUpdate(CandidateModel model) {
    EventBus.getDefault().post(model);
  }

  @Override public void onClick(View view, Object object, int position) {
    if (object instanceof JobOfferData) {
      int actualPosition = mRecyclerViewPager.transformToActualPosition(position);
      Fragment fragment = new OfferFragment();
      Bundle bundle = new Bundle();
      bundle.putSerializable(OfferFragment.ARG_JOBOFFER_MODEL, jobPostDetails.get(actualPosition));
      fragment.setArguments(bundle);
      ((HomeActivity) getActivity()).setSelectedTab(2);
      addFragment(fragment, true);
    }
  }

  private class SampleFragmentPagerAdapter extends FragmentPagerAdapter {

    private String[] tabTitles;

    SampleFragmentPagerAdapter(FragmentManager childFragmentManager, String[] tabTitles) {
      super(childFragmentManager);
      this.tabTitles = tabTitles;
    }

    @Override public int getCount() {
      return tabTitles.length;
    }

    @Override public Fragment getItem(int position) {
      int type = position + 1;
      return AllListFragment.getInstance(type);
    }

    @Override public CharSequence getPageTitle(int position) {
      // Generate title based on item position
      return tabTitles[position];
    }
  }
}
