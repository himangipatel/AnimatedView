/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.adapter.AlertAdapter;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.CandidateModel;
import com.bnbjobs.model.UpdateEvent;
import com.bnbjobs.presenter.DashboardCandidatePresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.EndlessRecyclerViewScrollListener;
import com.bnbjobs.view.DashboardCandidateView;
import java.util.ArrayList;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import static android.R.attr.type;

/**
 * @author Harsh
 * @version 1.0
 */
public class CandidateFragment extends BaseFragment
    implements DashboardCandidateView, ClickImpl<CandidateModel> {

  @BindView(R.id.recyclerView) RecyclerView mRecyclerView;
  @BindView(R.id.tvNoRecord) TextView mTvNoRecord;
  @BindView(R.id.linearProgress) LinearLayout mLinearProgress;
  private Unbinder unbinder;

  private AlertAdapter adapter;
  private ArrayList<CandidateModel> candidateRequestArrayList = new ArrayList<>();
  private DashboardCandidatePresenter presenter;
  private boolean loadMore;
  private boolean isFooterAdd;
  private View view;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    //event bus register
    EventBus.getDefault().register(this);
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    if (view == null) {
      view = inflater.inflate(R.layout.fragment_all_list, container, false);
    }
    unbinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    if (presenter == null) {
      presenter = new DashboardCandidatePresenter();
    }
    presenter.attachView(this);
    presenter.setFragment(this);
    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
    mRecyclerView.setLayoutManager(linearLayoutManager);
    adapter = new AlertAdapter(getActivity(), candidateRequestArrayList, this);
    mRecyclerView.setAdapter(adapter);
    if (candidateRequestArrayList.size() < 1) {
      presenter.getCandidate(1);
    }
    mRecyclerView.addOnScrollListener(new EndlessRecyclerViewScrollListener(linearLayoutManager) {
      @Override public void onLoadMore(int page, int totalItemsCount) {
        if (loadMore) {
          loadMore = false;
          isFooterAdd = true;
          candidateRequestArrayList.add(null);
          adapter.notifyItemInserted(candidateRequestArrayList.size() - 1);
          presenter.getCandidate(type);
        }
      }
    });
  }

  @Override public void onResume() {
    super.onResume();
    showToolbar(true);
    setTitle(getString(R.string.candidatures));
  }

  @Override public void onDestroyView() {
    presenter.detachView();
    unbinder.unbind();
    super.onDestroyView();
  }

  @Override public void onDestroy() {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe public void onEvent(UpdateEvent event) {
    if (event.update) {
      view = null;
      candidateRequestArrayList.clear();
    }
  }

  @Override public void setRetryView() {
  }

  @Override public void setAdapter(List<CandidateModel> mUserModelList) {
    if (isFooterAdd) {
      isFooterAdd = false;
      this.candidateRequestArrayList.remove(this.candidateRequestArrayList.size() - 1);
      adapter.notifyItemRemoved(this.candidateRequestArrayList.size());
    }
    candidateRequestArrayList.addAll(mUserModelList);
    adapter.notifyDataSetChanged();
  }

  @Override public void applyStatus(String action) {
  }

  @Override public void showParentProcess() {
  }

  @Override public void hideParentProgress() {
  }

  @Override public String getOffset() {
    return Integer.toString(candidateRequestArrayList.size());
  }

  @Override public void setLoadMore(boolean loadMore) {
    this.loadMore = loadMore;
  }

  @Override public void showProgress() {
  }

  @Override public void hideProgress() {
  }

  @Override public void onClick(View view, CandidateModel object, int position) {
    ProfileFragment fragment = new ProfileFragment();
    Bundle bundle = new Bundle();
    bundle.putString(Constants.KEY_ID, object.getuId());
    fragment.setArguments(bundle);
    addFragment(fragment, true);
  }
}
