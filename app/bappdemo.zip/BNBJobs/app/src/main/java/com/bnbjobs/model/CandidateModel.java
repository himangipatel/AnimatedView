/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.bnbjobs.utils.LocaleHelper;
import com.bnbjobs.utils.Utils;
import com.google.gson.annotations.SerializedName;
import java.util.Locale;

/**
 * @author Harsh
 * @version 1.0
 */
public class CandidateModel implements Parcelable {
  private String distance;
  @SerializedName("u_id") private String uId;
  @SerializedName("u_fname") private String fName;
  @SerializedName("u_lname") private String lName;
  @SerializedName("u_image") private String uImage;
  private String d_title_1;
  private String d_title_2;
  private String d_title_3;
  @SerializedName("u_latitude") private String uLat;
  @SerializedName("u_longitude") private String uLng;
  @SerializedName("profilePercentage") private String profilePercentage;
  @SerializedName("planPurchase") private String planPurchase;
  @SerializedName("u_image_url") private String uImageUrl;
  @SerializedName("u_image_thumb_url") private String uThumbImage;
  @SerializedName("rp_id") private int offerId;
  private int applyJobBtnFlag;
  private String address;
  private boolean accept;
  @SerializedName("favorite_flag")
  private int isFavorite;
  @SerializedName("months") private int months;

  public boolean isFavorite() {
    return isFavorite==1;
  }

  public void setFavorite(int favorite) {
    isFavorite = favorite;
  }

  public int getMonths() {
    return months;
  }

  public void setMonths(int months) {
    this.months = months;
  }

  public boolean isAccept() {
    return accept;
  }

  public void setAccept(boolean accept) {
    this.accept = accept;
  }

  public int getApplyJobBtnFlag() {
    return applyJobBtnFlag;
  }

  public void setApplyJobBtnFlag(int applyJobBtnFlag) {
    this.applyJobBtnFlag = applyJobBtnFlag;
  }

  public String getDistance() {
    return distance;
  }

  public void setDistance(String distance) {
    this.distance = distance;
  }

  public String getuId() {
    return uId;
  }

  public void setuId(String uId) {
    this.uId = uId;
  }

  public String getfName() {
    return Utils.capitalize(fName);
  }

  public void setfName(String fName) {
    this.fName = fName;
  }

  public String getlName() {
    return lName;
  }

  public void setlName(String lName) {
    this.lName = lName;
  }

  public String getuImage() {
    return uImage;
  }

  public void setuImage(String uImage) {
    this.uImage = uImage;
  }

  public String getuLat() {
    return uLat;
  }

  public void setuLat(String uLat) {
    this.uLat = uLat;
  }

  public String getuLng() {
    return uLng;
  }

  public void setuLng(String uLng) {
    this.uLng = uLng;
  }

  public String getProfilePercentage() {
    return profilePercentage;
  }

  public void setProfilePercentage(String profilePercentage) {
    this.profilePercentage = profilePercentage;
  }

  public String getPlanPurchase() {
    return planPurchase;
  }

  public void setPlanPurchase(String planPurchase) {
    this.planPurchase = planPurchase;
  }

  public String getuImageUrl() {
    return uImageUrl;
  }

  public void setuImageUrl(String uImageUrl) {
    this.uImageUrl = uImageUrl;
  }

  public String getuThumbImage() {
    return uThumbImage;
  }

  public void setuThumbImage(String uThumbImage) {
    this.uThumbImage = uThumbImage;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public int getOfferId() {
    return offerId;
  }

  public void setOfferId(int offerId) {
    this.offerId = offerId;
  }

  @Override public int describeContents() {
    return 0;
  }

  public String getExperience() {
    int months = getMonths();
    int year;
    if (months > 12) {
      year = months / 12;
      if (year >= 5) {
        return String.format(Locale.getDefault(), "%s+ ", year);
      } else {
        int tempYear = year + 1;
        return String.format(Locale.getDefault(), "%s - %s ", year, tempYear);
      }
    } else {
      int pMonth = months - 1;
      int eMonth = months + 1;
      return String.format(Locale.getDefault(), "%s - %s ", pMonth, eMonth);
    }
  }

  public String getD_title_1() {
    return d_title_1;
  }

  public String getD_title_2() {
    return d_title_2;
  }

  public String getD_title_3() {
    return d_title_3;
  }

  public String getTitle() {
    if (LocaleHelper.isFrench()) {
      return getD_title_2();
    } else if (LocaleHelper.isSpanish()) {
      return getD_title_3();
    } else {
      return getD_title_1();
    }
  }
  @Override public String toString() {
    return getuId() + "\n" + getfName() + "\n" + getlName();
  }

  public static final Creator<CandidateModel> CREATOR = new Creator<CandidateModel>() {
    @Override public CandidateModel createFromParcel(Parcel in) {
      CandidateModel candidateModel = new CandidateModel();
      candidateModel.readIn(in);
      return candidateModel;
    }

    @Override public CandidateModel[] newArray(int size) {
      return new CandidateModel[size];
    }
  };
  public void readIn(Parcel in) {
    distance = in.readString();
    uId = in.readString();
    fName = in.readString();
    lName = in.readString();
    uImage = in.readString();
    d_title_1= in.readString();
    d_title_2= in.readString();
    d_title_3= in.readString();
    uLat = in.readString();
    uLng = in.readString();
    profilePercentage = in.readString();
    planPurchase = in.readString();
    uImageUrl = in.readString();
    uThumbImage = in.readString();
    offerId = in.readInt();
    applyJobBtnFlag = in.readInt();
    address = in.readString();
    accept = in.readByte() != 0;
    isFavorite = in.readInt();
    months = in.readInt();
  }


  @Override public void writeToParcel(Parcel dest, int flags) {
    dest.writeString(distance);
    dest.writeString(uId);
    dest.writeString(fName);
    dest.writeString(lName);
    dest.writeString(uImage);
    dest.writeString(d_title_1);
    dest.writeString(d_title_2);
    dest.writeString(d_title_3);
    dest.writeString(uLat);
    dest.writeString(uLng);
    dest.writeString(profilePercentage);
    dest.writeString(planPurchase);
    dest.writeString(uImageUrl);
    dest.writeString(uThumbImage);
    dest.writeInt(offerId);
    dest.writeInt(applyJobBtnFlag);
    dest.writeString(address);
    dest.writeByte((byte) (accept ? 1 : 0));
    dest.writeInt(isFavorite);
    dest.writeInt(months);
  }
}


