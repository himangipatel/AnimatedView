/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.bnbjobs.model.Experience;
import java.io.File;

/**
 * @author Harsh
 * @version 1.0
 */
public interface ExperienceView extends MainView {

    String getCompanyName();

    String getDTitle();

    String getStartYear();

    String getEndYear();

    File getProfile();

    void openCamera();

    void openGallery();

    void showPhoto(String path);

    void setDefault();

    boolean isImageSet();

    int getSMonth();

    int getSYear();

    int getEMonth();

    int getEYear();

    boolean isEdit();

    String getId();

    void onDone(Experience experience);

    void setStartDate(String text);

    void setEndDate(String text);
}
