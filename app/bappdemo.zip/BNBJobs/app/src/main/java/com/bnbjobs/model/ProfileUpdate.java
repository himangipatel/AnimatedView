/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

/**
 * @author Harsh
 * @version 1.0
 */

public class ProfileUpdate {

  private int profilePercent;
  private int eId;
  public ProfileUpdate(int profilePercent) {
    this.profilePercent = profilePercent;
  }

  public ProfileUpdate(int profilePercent, int eId) {
    this.profilePercent = profilePercent;
    this.eId = eId;
  }

  public int geteId() {
    return eId;
  }

  public int getProfilePercent() {
    return profilePercent;
  }
}
