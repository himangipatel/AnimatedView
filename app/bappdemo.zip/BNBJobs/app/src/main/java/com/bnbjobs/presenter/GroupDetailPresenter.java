/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.app.Fragment;
import android.util.Log;
import com.bnbjobs.R;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.GroupModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.RxUtil;
import com.bnbjobs.view.GroupDetailView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;
import rx.Subscription;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class GroupDetailPresenter extends BasePresenter implements Presenter<GroupDetailView> {

  private GroupDetailView mGroupDetailView;
  private Fragment fragment;
  private Subscription subscription;

  @Override public void attachView(GroupDetailView view) {
    mGroupDetailView = view;
  }

  @Override public void detachView() {
    if (subscription != null && !subscription.isUnsubscribed()) {
      subscription.unsubscribe();
    }
  }

  public void getGroupDetail(final String gId) {
    if (hasNetworkConnectivity()) {
      mGroupDetailView.showProgress();
      HashMap<String, String> params = new HashMap<>();
      params.put("apiName", "group_details");
      params.put("group_id", gId);
      params.putAll(addParams(params));

      subscription = RestClient.getInstance(params)
          .compose(getBindEvent())
          .subscribe(new Subscriber<String>() {
            @Override public void onCompleted() {

            }

            @Override public void onError(Throwable e) {
              LOGE(TAG, e.getMessage(), e);
              mGroupDetailView.hideProgress();
              String error;
              if (e instanceof SocketTimeoutException) {
                error = getBaseContext().getString(R.string.error_timeout);
              } else {
                error = getBaseContext().getString(R.string.error_other);
              }
              showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
                  getBaseContext().getString(R.string.retry),
                  new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                      dialog.dismiss();
                      getGroupDetail(gId);
                    }
                  }).show();
            }

            @Override public void onNext(String s) {
              mGroupDetailView.hideProgress();
              try {
                JSONObject object = new JSONObject(s);
                if(object.getBoolean("success")){
                  JSONObject dateObject = object.getJSONObject("data");
                  GroupModel model = new Gson().fromJson(dateObject.toString(), GroupModel.class);
                  mGroupDetailView.onSuccess(model);
                }else{
                  mGroupDetailView.onError(object.getString("message"));
                }
              } catch (JSONException e) {
                e.printStackTrace();
              }
            }
          });
    }
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }

  @Override protected Context getBaseContext() {
    return mGroupDetailView.getContext();
  }

  public void deleteGroup(final String groupId) {
    mGroupDetailView.showProgress();
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "delete_group");
    params.put("group_id", groupId);
    params.putAll(addParams(params));
    RxUtil.unsubscribe(subscription);
    subscription = RestClient.getInstance(params).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        mGroupDetailView.hideProgress();
        LOGE(TAG, Log.getStackTraceString(e));
        String error;
        if (e instanceof SocketTimeoutException) {
          error = getBaseContext().getString(R.string.error_timeout);
        } else {
          error = getBaseContext().getString(R.string.error_other);
        }
        showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error, getBaseContext().getString(R.string.retry),
            new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                deleteGroup(groupId);
              }
            }).show();
      }

      @Override public void onNext(String s) {
        mGroupDetailView.hideProgress();
        try {
          JSONObject object = new JSONObject(s);
          if (object.getBoolean("success")) {
            mGroupDetailView.onDeleteSuccess();
          } else {
            mGroupDetailView.onError(object.getString("message"));
          }
        } catch (JSONException e) {
          e.printStackTrace();
        }

      }
    });
  }

  public void joinGroup(final String groupId, final boolean isJoin) {
    mGroupDetailView.showProgress();
    HashMap<String, String> params = new HashMap<>();
    if (isJoin) {
      params.put("apiName", "join_group");
    } else {
      params.put("apiName", "leave_group");
    }
    params.put("group_id", groupId);
    params.putAll(addParams(params));
    RxUtil.unsubscribe(subscription);
    mGroupDetailView.showProgress();
    subscription = RestClient.getInstance(params).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        mGroupDetailView.hideProgress();
        LOGE(TAG, Log.getStackTraceString(e));
        String error;
        if (e instanceof SocketTimeoutException) {
          error = getBaseContext().getString(R.string.error_timeout);
        } else {
          error = getBaseContext().getString(R.string.error_other);
        }
        showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error, getBaseContext().getString(R.string.retry),
            new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                joinGroup(groupId,isJoin);
              }
            }).show();
      }

      @Override public void onNext(String s) {
        mGroupDetailView.hideProgress();
        try {
          JSONObject object = new JSONObject(s);
          if (object.getBoolean("success")) {
            mGroupDetailView.onJoinSuccess(isJoin);
          } else {
            mGroupDetailView.onError(object.getString("message"));
          }
        } catch (JSONException e) {
          e.printStackTrace();
        }

      }
    });
  }
}
