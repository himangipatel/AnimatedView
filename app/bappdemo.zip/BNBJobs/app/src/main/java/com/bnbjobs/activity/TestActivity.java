/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import com.bnbjobs.R;
import com.bnbjobs.rest.ToStringConverterFactory;
import java.io.IOException;
import java.util.HashMap;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

import static com.bnbjobs.utils.LogUtils.LOGI;

/**
 * @author Harsh
 * @version 1.0
 */
public class TestActivity extends BaseActivity {

  @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.fragment_profile);
    //callAPi();
  }


  private void callAPi(){

    Retrofit retrofit = new Retrofit.Builder()
        .baseUrl("http://www.chiripalpolyfilms.in/")
        .addConverterFactory(new ToStringConverterFactory())
        .build();

    Api api = retrofit.create(Api.class);
    HashMap<String,String> params = new HashMap<>();
    params.put("accesstoken","'sdbs456hb1234fkbsd'");
    params.put("email","jemspeter007@40gmail.com");
    params.put("name","Jems Peter");
    params.put("phone_number","9825098250");
    params.put("company_name","'iMobDev'");
    params.put("message","this is dummy message");
    api.callAPi(params).enqueue(new Callback<String>() {
      @Override public void onResponse(Call<String> call, Response<String> response) {
        LOGI("DEMO",response.body());
        try {
          LOGI("DEMO",response.errorBody().string());
        } catch (IOException e) {
          e.printStackTrace();
        }
      }

      @Override public void onFailure(Call<String> call, Throwable t) {
        LOGI("DEMO", Log.getStackTraceString(t));
      }
    });
  }


  interface Api{
    @FormUrlEncoded
    @POST("mail/mail_send.php") Call<String> callAPi(@FieldMap HashMap<String,String> params);
  }
}
