/*
 * Copyright (c) 2017 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.CircleImageView;
import com.bnbjobs.model.GroupModel;
import com.bnbjobs.utils.Utils;
import com.bumptech.glide.Glide;
import java.util.List;

import static com.bnbjobs.fragments.BaseFragment.getUserId;

public class GroupListAdapter extends BaseRecyclerAdapter<GroupListAdapter.MyViewHolder> {

  private List<GroupModel> groupModelsList;
  private Context context;
  private boolean isUserGroup;

  public GroupListAdapter(Context context, List<GroupModel> groupModelsList) {
    this.context = context;
    this.groupModelsList = groupModelsList;
  }

  public void setIsUserGroup(boolean isUserGroup) {
    this.isUserGroup = isUserGroup;
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view;
    if (isUserGroup) {
      view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_my_group, parent, false);
    } else {
      view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_group_item, parent, false);
    }
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {
    if (groupModelsList.get(position).isShowAdd()) {
      holder.linearFirst.setVisibility(View.GONE);
      holder.linearSecond.setVisibility(View.VISIBLE);
    } else {
      holder.linearFirst.setVisibility(View.VISIBLE);
      holder.linearSecond.setVisibility(View.GONE);
      Glide.with(context).load(groupModelsList.get(position).getGroupThumbImageUrl()).into(holder.ivGroupImage);
      Glide.with(context).load(groupModelsList.get(position).getuThumbImageUrl()).into(holder.ivUserImage);
      holder.tvGroupLocation.setText(groupModelsList.get(position).getLocation());
      holder.tvDate.setText(Utils.getDateSlash(Long.parseLong(groupModelsList.get(position).getStartTime())));
      holder.tvGroupMember.setText(String.valueOf(groupModelsList.get(position).getTotalMember() + "/" + groupModelsList.get(position).getMaxMember()));
      holder.tvGroupName.setText(groupModelsList.get(position).getTitle());
      holder.tvUserName.setText(groupModelsList.get(position).getuFname() + " " + groupModelsList.get(position).getuLname());
      if (groupModelsList.get(position).getuId() == getUserId(context)) {
        holder.tvJoin.setText(R.string.delete_group);
        holder.tvJoin.setBackgroundResource(R.drawable.round_corner_red);
      } else if (groupModelsList.get(position).getMemberFlag()) {
        holder.tvJoin.setText(R.string.remove_group);
        holder.tvJoin.setBackgroundResource(R.drawable.round_corner_red);
      } else {
        holder.tvJoin.setText(R.string.to_come_up);
        holder.tvJoin.setBackgroundResource(R.drawable.rounded_grey_exp);
      }
    }
  }

  @Override public int getItemCount() {
      return groupModelsList.size();
  }

  class MyViewHolder extends BaseRecyclerAdapter.ViewHolder {
    @BindView(R.id.ivGroupImage) ImageView ivGroupImage;
    @BindView(R.id.ivUserImage) CircleImageView ivUserImage;
    @BindView(R.id.tvGroupName) TextView tvGroupName;
    @BindView(R.id.tvGroupLocation) TextView tvGroupLocation;
    @BindView(R.id.linearSecond) LinearLayout linearSecond;
    @BindView(R.id.linearFirst) LinearLayout linearFirst;
    @BindView(R.id.tvDate) TextView tvDate;
    @BindView(R.id.tvGroupMember) TextView tvGroupMember;
    @BindView(R.id.tvJoin) TextView tvJoin;
    @BindView(R.id.tvSeeGroup) TextView tvSeeGroup;
    @BindView(R.id.tvUserName) TextView tvUserName;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
      clickableViews(tvJoin,itemView);
    }
  }
}