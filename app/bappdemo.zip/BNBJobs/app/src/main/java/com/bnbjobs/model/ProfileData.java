/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class ProfileData {

  @SerializedName("userData") private UserModel userModel;
  @SerializedName("userProfileData") private UserProfileData userProfileData;
  @SerializedName("experienceData") private List<Experience> experienceList;
  @SerializedName("formationData") private List<FormationModel> formationModelList;
  @SerializedName("skillData") private List<SkillModel> skillModelList;
  @SerializedName("imageData") private List<ImageModel> imageModelList;
  @SerializedName("languageData") private List<LanguageModel> mLanguageModelList;
  @SerializedName("videoUrl") private String videoUrl;
  @SerializedName("videoId") private int videoId;
  @SerializedName("totalFormations") private int totalFormations;
  @SerializedName("totalExperiences") private int totalExperiences;

  public List<LanguageModel> getLanguageModelList() {
    return mLanguageModelList;
  }

  public void setLanguageModelList(List<LanguageModel> languageModelList) {
    mLanguageModelList = languageModelList;
  }

  public int getTotalFormations() {
    return totalFormations;
  }

  public void setTotalFormations(int totalFormations) {
    this.totalFormations = totalFormations;
  }

  public int getTotalExperiences() {
    return totalExperiences;
  }

  public void setTotalExperiences(int totalExperiences) {
    this.totalExperiences = totalExperiences;
  }

  public int getVideoId() {
    return videoId;
  }

  public void setVideoId(int videoId) {
    this.videoId = videoId;
  }

  public UserModel getUserModel() {
    return userModel;
  }

  public void setUserModel(UserModel userModel) {
    this.userModel = userModel;
  }

  public UserProfileData getUserProfileData() {
    return userProfileData;
  }

  public void setUserProfileData(UserProfileData userProfileData) {
    this.userProfileData = userProfileData;
  }

  public List<Experience> getExperienceList() {
    return experienceList;
  }

  public void setExperienceList(List<Experience> experienceList) {
    this.experienceList = experienceList;
  }

  public List<FormationModel> getFormationModelList() {
    return formationModelList;
  }

  public void setFormationModelList(List<FormationModel> formationModelList) {
    this.formationModelList = formationModelList;
  }

  public List<SkillModel> getSkillModelList() {
    return skillModelList;
  }

  public void setSkillModelList(List<SkillModel> skillModelList) {
    this.skillModelList = skillModelList;
  }

  public List<ImageModel> getImageModelList() {
    return imageModelList;
  }

  public void setImageModelList(List<ImageModel> imageModelList) {
    this.imageModelList = imageModelList;
  }

  public String getVideoUrl() {
    return videoUrl;
  }

  public void setVideoUrl(String videoUrl) {
    this.videoUrl = videoUrl;
  }
}
