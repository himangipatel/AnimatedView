/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.fragments.ChooseOfferFragment;
import com.bnbjobs.model.PaymentAction;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import static com.bnbjobs.R.id.toolbar;

/**
 * @author Harsh
 * @version 1.0
 */
public class DiscountActivity extends BaseActivity {

  @BindView(R.id.imageBack) TinTableImageView mImageBack;
  @BindView(R.id.tvTitle) TextView mTvTitle;
  @BindView(R.id.imageCenterLogo) ImageView mImageCenterLogo;
  @BindView(R.id.rightImage) TinTableImageView mRightImage;
  @BindView(toolbar) Toolbar mToolbar;
  @BindView(R.id.container) FrameLayout mContainer;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_discount);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    mToolbar.setBackgroundColor(Color.WHITE);
    mTvTitle.setText(getString(R.string.choose_offer));
    mTvTitle.setVisibility(View.VISIBLE);
    if (savedInstanceState == null) {
       getSupportFragmentManager()
          .beginTransaction()
          .replace(R.id.container, new ChooseOfferFragment())
          .commit();
    }
  }

  @OnClick(R.id.imageBack) void onClick() {
    onBackPressed();
  }

  @Override protected void onDestroy() {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe public void onEvent(PaymentAction action) {
    if (action.finish) {
      finish();
    }
  }
}
