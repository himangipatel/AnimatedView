/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.adapter.PlaceAutocompleteAdapter;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.MapModel;
import com.bnbjobs.presenter.MapPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Prefs;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.JobOfferMapView;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.location.places.AutocompletePrediction;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlaceBuffer;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.ui.IconGenerator;
import java.util.ArrayList;
import java.util.List;

import static android.text.TextUtils.isEmpty;

/**
 * @author Harsh
 * @version 1.0
 */

public class JobMapFragment extends BaseFragment
    implements OnMapReadyCallback, JobOfferMapView, GoogleMap.OnMarkerClickListener,
    GoogleApiClient.OnConnectionFailedListener {

  @BindView(R.id.map) MapView mapView;
  @BindView(R.id.relativeProgress) LinearLayout linearLayout;
  @BindView(R.id.autocomplete_places) AutoCompleteTextView mAutocompleteView;
  @BindView(R.id.imageBack) TinTableImageView mBack;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.toolbar) Toolbar toolbar;

  /* GoogleApiClient wraps our service connection to Google Play Services and provides access
  * to the user's sign in state as well as the Google's APIs.
      */
  protected GoogleApiClient mGoogleApiClient;
  private String lat;
  private String lng;
  private PlaceAutocompleteAdapter mAdapter;
  private GoogleMap mGoogleMap;
  private MapPresenter presenter;
  private List<MapModel> mapModelList = new ArrayList<>();
  private static final String TAG = JobMapFragment.class.getSimpleName();

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_map_view, container, false);
    ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    toolbar.setBackgroundColor(Color.WHITE);
    tvTitle.setText(R.string.job_search);
    tvTitle.setVisibility(View.VISIBLE);
    if (mGoogleApiClient == null) {
      setUpGoogleClient();
    }
    presenter = new MapPresenter();
    presenter.attachView(this);
    presenter.setFragment(this);
    mapView.onCreate(savedInstanceState);
    mapView.getMapAsync(this);
    mAutocompleteView.setOnItemClickListener(mAutocompleteClickListener);
    mAdapter = new PlaceAutocompleteAdapter(getActivity(), mGoogleApiClient, null, null);
    mAutocompleteView.setAdapter(mAdapter);
  }

  @OnClick({ R.id.relativeProgress }) void onClick() {
    // do nothing
  }

  @Override public void onMapReady(GoogleMap googleMap) {
    mGoogleMap = googleMap;
    mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
    mGoogleMap.setOnMarkerClickListener(this);
    MapsInitializer.initialize(this.getActivity());
    if(isEmpty(lat)){
      lat = Prefs.with(getActivity()).getString(QuickstartPreferences.LAT, "");
      lng = Prefs.with(getActivity()).getString(QuickstartPreferences.LNG, "");
    }
    if (!isEmpty(lat)) {
      CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(Double.parseDouble(lat), Double.parseDouble(lng)), 10);
      mGoogleMap.moveCamera(cameraUpdate);
    }
    if (mapModelList.isEmpty()) {
      presenter.getJobList(lat, lng);
    } else {
      setMarkerOnMap();
    }
  }

  @OnClick(R.id.imageBack) void onBack(){
    getFragmentManager().popBackStack();
  }

  private void setUpGoogleClient() {
    mGoogleApiClient =
        new GoogleApiClient.Builder(getActivity()).enableAutoManage(getActivity(), 0, this)
            .addApi(Places.GEO_DATA_API)
            .build();
  }

  @Override public void onResume() {
    mapView.onResume();
    super.onResume();
  }

  @Override public void onDestroy() {
    mapView.onDestroy();
    super.onDestroy();
  }

  @Override public void onLowMemory() {
    mapView.onLowMemory();
    super.onLowMemory();
  }

  @Override public void setMarker(BaseContainer<MapModel> jobModelBaseContainer) {
    mGoogleMap.clear();
    if(mapModelList!=null && !mapModelList.isEmpty()){
      mapModelList.clear();
    }
    mapModelList = jobModelBaseContainer.getDataList();
    if (mapModelList!=null && !mapModelList.isEmpty()){
      setMarkerOnMap();
    }
  }

  private void setMarkerOnMap() {
    IconGenerator iconFactory = new IconGenerator(getActivity());
    iconFactory.setRotation(0);
    iconFactory.setContentRotation(0);
    iconFactory.setStyle(IconGenerator.STYLE_GREEN);
    for (MapModel mapModel : mapModelList) {
      addIcon(iconFactory, mapModel.getTitle(),new LatLng(Double.parseDouble(mapModel.getLat()), Double.parseDouble(mapModel.getLng())));
    }
  }

  private void addIcon(IconGenerator iconFactory, CharSequence text, LatLng position) {
    MarkerOptions markerOptions = new MarkerOptions().
        icon(BitmapDescriptorFactory.fromBitmap(iconFactory.makeIcon(text))).
        position(position).
        anchor(iconFactory.getAnchorU(), iconFactory.getAnchorV());
    mGoogleMap.addMarker(markerOptions);
  }

  @Override public void showProgress() {
    linearLayout.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearLayout.setVisibility(View.GONE);
  }

  @Override public boolean onMarkerClick(Marker marker) {
    int id = Integer.parseInt(marker.getId().replace("m", ""));
    Bundle bundle = new Bundle();
    bundle.putString(Constants.KEY_ID, String.valueOf(mapModelList.get(id).getId()));
    bundle.putInt(Constants.KEY_POSITION, id);
    JobDetailFragment fragment = new JobDetailFragment();
    fragment.setTargetFragment(this, 1111);
    fragment.setArguments(bundle);
    ((HomeActivity) getActivity()).switchFragment(fragment, true);
    return false;
  }

  /**
   * Listener that handles selections from suggestions from the AutoCompleteTextView that
   * displays Place suggestions.
   * Gets the place id of the selected item and issues a request to the Places Geo Data API
   * to retrieve more details about the place.
   *
   * @see com.google.android.gms.location.places.GeoDataApi#getPlaceById(com.google.android.gms.common.api.GoogleApiClient,
   * String...)
   */
  private AdapterView.OnItemClickListener mAutocompleteClickListener = new AdapterView.OnItemClickListener() {
        @Override public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            /*
             Retrieve the place ID of the selected item from the Adapter.
             The adapter stores each Place suggestion in a AutocompletePrediction from which we
             read the place ID and title.
              */
          final AutocompletePrediction item = mAdapter.getItem(position);
          if (item != null) {
            final String placeId = item.getPlaceId();
            final CharSequence primaryText = item.getPrimaryText(null);
            Log.i(TAG, "Autocomplete item selected: " + primaryText);
            PendingResult<PlaceBuffer> placeResult =
                Places.GeoDataApi.getPlaceById(mGoogleApiClient, placeId);
            placeResult.setResultCallback(mUpdatePlaceDetailsCallback);
            Log.i(TAG, "Called getPlaceById to get Place details for " + placeId);
          }
        }
      };

  /**
   * Callback for results from a Places Geo Data API query that shows the first place result in
   * the details view on screen.
   */
  private ResultCallback<PlaceBuffer> mUpdatePlaceDetailsCallback =
      new ResultCallback<PlaceBuffer>() {
        @Override public void onResult(@NonNull PlaceBuffer places) {
          if (!places.getStatus().isSuccess()) {
            // Request did not complete successfully
            Log.e(TAG, "Place query did not complete. Error: " + places.getStatus().toString());
            places.release();
            return;
          }
          // Get the Place object from the buffer.
          final Place place = places.get(0);
          LatLng latLng = place.getLatLng();
          Log.i(TAG, "Place details received: " + place.getLatLng());
          places.release();
          if (latLng != null) {
            lat = String.valueOf(latLng.latitude);
            lng = String.valueOf(latLng.longitude);
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 10);
            mGoogleMap.moveCamera(cameraUpdate);
            presenter.getJobList(String.valueOf(latLng.latitude), String.valueOf(latLng.longitude));
          }
          Utils.hideKeyboard(mAutocompleteView, getActivity());
        }
      };

  /**
   * Called when the Activity could not connect to Google Play services and the auto manager
   * could resolve the error automatically.
   * In this case the API is not available and notify the user.
   *
   * @param connectionResult can be inspected to determine the cause of the failure
   */
  @Override public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    Log.e(TAG,
        "onConnectionFailed: ConnectionResult.getErrorCode() = " + connectionResult.getErrorCode());
  }

  @Override public void onDestroyView() {
    mGoogleApiClient.stopAutoManage(getActivity());
    mGoogleApiClient.disconnect();
    super.onDestroyView();
  }
}
