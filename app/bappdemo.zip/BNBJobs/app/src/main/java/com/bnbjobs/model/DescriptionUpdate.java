/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

/**
 * @author Harsh
 * @version 1.0
 */
public class DescriptionUpdate {
  private String text;
  private int profilePercentage;

  public DescriptionUpdate(String text,int profilePercentage) {
    this.text = text;
    this.profilePercentage = profilePercentage;

  }

  public int getProfilePercentage() {
    return profilePercentage;
  }

  public String getText() {
    return text;
  }
}
