/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import java.io.Serializable;

/**
 * Created by jay shah on 6/9/16.
 */
public class EditExperience implements Serializable,Cloneable{

    private String designation_title;
    private int type;
    private String progress_title;
    private String progress_subtitle;
    private int progressinmonths;


    public String getDesignation_title() {
        return designation_title;
    }

    public void setDesignation_title(String designation_title) {
        this.designation_title = designation_title;
    }

    public String getProgress_title() {
        return progress_title;
    }

    public void setProgress_title(String progress_title) {
        this.progress_title = progress_title;
    }

    public String getProgress_subtitle() {
        return progress_subtitle;
    }

    public void setProgress_subtitle(String progress_subtitle) {
        this.progress_subtitle = progress_subtitle;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getProgressinmonths() {
        return progressinmonths;
    }

    public void setProgressinmonths(int progressinmonths) {
        this.progressinmonths = progressinmonths;
    }

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
