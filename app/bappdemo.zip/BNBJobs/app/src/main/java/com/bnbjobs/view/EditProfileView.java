/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.bnbjobs.model.ProfileData;
import java.io.File;

/**
 * @author Harsh
 * @version 1.0
 */
public interface EditProfileView extends MainView {

  void setPersonalData(ProfileData mData);

  File getProfile();

  void openCamera();

  void openGallery();

  void showPhoto(String path);

  void setDefault();

  boolean isImageSet();

  String getEmail();

  String getPassword();

  boolean isRemember();

  String getFirstName();

  String getLastName();

  String getPhoneNumber();

  String getFbLink();

  String getTwLink();

  boolean isFbLinkShow();

  boolean isTwLinkShow();

  void onUpdated(ProfileData mData);

  void onCodeResend(boolean result, String message);
}
