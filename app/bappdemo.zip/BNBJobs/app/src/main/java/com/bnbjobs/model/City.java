/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by krupal on 2/8/16.
 */

public class City {

  @SerializedName("c_id") private String cityId;
  @SerializedName("c_name") private String cityName;
  @SerializedName("c_image") private String cityImage;
  @SerializedName("c_status") private String cityStatus;
  @SerializedName("c_created_at") private String cityCreatedAt;
  @SerializedName("c_updated_at") private String cityUpdateAt;
  @SerializedName("c_image_url") private String cityImageUrl;
  @SerializedName("c_image_thumb_url") private String cityImageThumbUrl;
  @SerializedName("c_latitude") private String c_latitude;
  @SerializedName("c_longitude") private String c_longitude;

  public String getC_latitude() {
    return c_latitude;
  }

  public void setC_latitude(String c_latitude) {
    this.c_latitude = c_latitude;
  }

  public String getC_longitude() {
    return c_longitude;
  }

  public void setC_longitude(String c_longitude) {
    this.c_longitude = c_longitude;
  }

  public String getCityId() {
    return cityId;
  }

  public void setCityId(String cityId) {
    this.cityId = cityId;
  }

  public String getCityName() {
    return cityName;
  }

  public void setCityName(String cityName) {
    this.cityName = cityName;
  }

  public String getCityImage() {
    return cityImage;
  }

  public void setCityImage(String cityImage) {
    this.cityImage = cityImage;
  }

  public String getCityStatus() {
    return cityStatus;
  }

  public void setCityStatus(String cityStatus) {
    this.cityStatus = cityStatus;
  }

  public String getCityCreatedAt() {
    return cityCreatedAt;
  }

  public void setCityCreatedAt(String cityCreatedAt) {
    this.cityCreatedAt = cityCreatedAt;
  }

  public String getCityUpdateAt() {
    return cityUpdateAt;
  }

  public void setCityUpdateAt(String cityUpdateAt) {
    this.cityUpdateAt = cityUpdateAt;
  }

  public String getCityImageUrl() {
    return cityImageUrl;
  }

  public void setCityImageUrl(String cityImageUrl) {
    this.cityImageUrl = cityImageUrl;
  }

  public String getCityImageThumbUrl() {
    return cityImageThumbUrl;
  }

  public void setCityImageThumbUrl(String cityImageThumbUrl) {
    this.cityImageThumbUrl = cityImageThumbUrl;
  }
}
