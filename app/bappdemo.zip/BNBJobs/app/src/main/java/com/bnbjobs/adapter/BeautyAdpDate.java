/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.interfaces.RecycleOnItemClickListner;
import java.util.List;

/**
 * The type Beauty adp date.
 *
 * @author Harsh
 * @version 1.0
 */
public class BeautyAdpDate extends RecyclerView.Adapter<BeautyAdpDate.ViewHolder> {

  private List<String> list;

  private Context context;

  private RecycleOnItemClickListner onItemClick;

  private TextView editText;

  /**
   * Instantiates a new Beauty adp date.
   *
   * @param context the context
   * @param list the list
   * @param onItemClickListener the on item click listener
   * @param editText the edit text
   */
  public BeautyAdpDate(Context context, List<String> list,
      RecycleOnItemClickListner onItemClickListener, TextView editText) {
    this.list = list;
    this.onItemClick = onItemClickListener;
    this.context = context;
    this.editText = editText;
  }

  @Override public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    ViewHolder holder;
    View view = LayoutInflater.from(context).inflate(R.layout.ly_date_spinner, parent, false);
    holder = new ViewHolder(view);
    return holder;
  }

  @Override public void onBindViewHolder(ViewHolder holder, int position) {
    holder.setData(position);
  }

  @Override public int getItemCount() {
    return list.size();
  }

  /**
   * The type View holder.
   */
  public class ViewHolder extends RecyclerView.ViewHolder {

    /**
     * The Edt name.
     */
    @BindView(R.id.edtName) TextView edtName;
    /**
     * The View line.
     */
    @BindView(R.id.viewLine) View viewLine;

    /**
     * Instantiates a new View holder.
     *
     * @param itemView the item view
     */
    public ViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
      //edtName.setPadding(3, 3, 3, 3);
      edtName.setBackgroundColor(Color.TRANSPARENT);
      if (editText.getId() == R.id.tvCardSelected
          || editText.getId() == R.id.tvMonth
          || editText.getId() == R.id.tvYear) {
        edtName.setTextColor(ActivityCompat.getColor(context, R.color.dark_grey));
        edtName.setGravity(Gravity.NO_GRAVITY);
      }
    }

    /**
     * Sets data.
     *
     * @param pos the pos
     */
    public void setData(final int pos) {
      if (pos == list.size() - 1) {
        viewLine.setVisibility(View.GONE);
      }
      edtName.setText(list.get(pos));
      edtName.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          onItemClick.onItemClick(editText, getAdapterPosition());
        }
      });
    }
  }
}
