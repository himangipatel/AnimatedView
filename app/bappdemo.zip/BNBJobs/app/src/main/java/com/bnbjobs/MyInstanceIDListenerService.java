/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs;

import android.content.Intent;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

import static com.bnbjobs.utils.LogUtils.LOGI;

/**
 * @author Harsh
 * @version 1.0
 */
public class MyInstanceIDListenerService extends FirebaseInstanceIdService {

  private static final String TAG = "MyInstanceIDLS";

  /**
   * Called if InstanceID token is updated. This may occur if the security of
   * the previous token had been compromised. This call is initiated by the
   * InstanceID provider.
   */
  // [START refresh_token]
  @Override public void onTokenRefresh() {
    // Fetch updated Instance ID token and notify our app's server of any changes (if applicable).
    String token = FirebaseInstanceId.getInstance().getToken();
    LOGI(TAG, "GCM Registration Token: " + token);
    Intent intent = new Intent(this, RegistrationIntentService.class);
    startService(intent);
  }
  // [END refresh_token]
}