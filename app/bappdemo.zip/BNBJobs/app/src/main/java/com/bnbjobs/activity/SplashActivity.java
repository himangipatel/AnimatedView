/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.LinearLayout;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.ProHelperImpl;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.RegistrationIntentService;
import com.bnbjobs.presenter.LandingPresenter;
import com.bnbjobs.services.CountryStoreService;
import com.bnbjobs.tour.TourActivity;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.LocaleHelper;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.LandingScreenView;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.trello.rxlifecycle.ActivityEvent;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnNeverAskAgain;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;
import rx.Observable;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.ActivityUtils.launchActivity;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
@RuntimePermissions public class SplashActivity extends BaseActivity implements LandingScreenView {

  private static final int REQUEST_CHECK_SETTINGS = 0x1;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  private LandingPresenter presenter;
  private String TAG = makeLogTag(SplashActivity.class);
  private boolean isEveryThingSet;

  @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
    getWindow().setBackgroundDrawableResource(R.drawable.splash);
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_splash);
    ButterKnife.bind(this);

    //store country in db
    startService(new Intent(this, CountryStoreService.class));
    // removing old location
    getPrefs(this).remove(QuickstartPreferences.LAT);
    getPrefs(this).remove(QuickstartPreferences.LNG);
    // start service for deviceToken
    startService(new Intent(this, RegistrationIntentService.class));
    presenter = new LandingPresenter();
    presenter.attachView(this);
    isGooglePlayServicesAvailable(this);
    presenter.setUpLocationClient();
  }

  private boolean isGooglePlayServicesAvailable(Activity activity) {
    GoogleApiAvailability googleApiAvailability = GoogleApiAvailability.getInstance();
    int status = googleApiAvailability.isGooglePlayServicesAvailable(activity);
    if (status != ConnectionResult.SUCCESS) {
      if (googleApiAvailability.isUserResolvableError(status)) {
        googleApiAvailability.getErrorDialog(activity, status, 2404).show();
      }
      return false;
    }
    return true;
  }

  @NeedsPermission({
      Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
  }) void startLocationUpdates() {
    LOGI(TAG, "onStartLocationUpdates");
    presenter.startLocationUpdate();
  }

  @OnShowRationale({
      Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
  }) void showRationaleForLocation(final PermissionRequest request) {
    Utils.showDialog(this, getString(R.string.alert), getString(R.string.permission_location_denied), getString(R.string.button_allow),
        getString(R.string.button_deny), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.proceed();
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.cancel();
          }
        }).show();
  }

  @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    SplashActivityPermissionsDispatcher.onRequestPermissionsResult(this, requestCode, grantResults);
  }

  @OnPermissionDenied({
      Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
  }) void showDeniedForLocation() {
    //Utils.showMessage(this, getString(R.string.permission_location_denied));
    hideProgress();
    showCurrentAddress("");
  }

  @OnNeverAskAgain({
      Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
  }) void showNeverAskForLocation() {
    //Utils.showMessage(this, getString(R.string.permission_location_never_askagain));
    hideProgress();
    showCurrentAddress("");
  }

  @Override protected void onResume() {
    super.onResume();
    presenter.onResume();
    if (isEveryThingSet) {
      startTimer();
    }
  }

  @Override protected void onPause() {
    super.onPause();
    presenter.onPause();
  }

  @Override public void checkLocationPermission() {
    checkPermission();
  }

  @Override public void showCurrentJob(String currentJob) {
  }

  /**
   * @param address get geo country and according to set app's language
   * if address is empty then it will set french language
   */
  @Override public void showCurrentAddress(String address) {
    LOGI(TAG, address);
    if (!isEmpty(address)) {
      getPrefs(this).save(QuickstartPreferences.COUNTRY_CODE, address);
    } else {
      getPrefs(this).save(QuickstartPreferences.COUNTRY_CODE, "FR");
    }
    if (!new ProHelperImpl().isPro()) {
      LocaleHelper.setLocale(this, Locale.getDefault().getLanguage());
    } else {
      if (!isEmpty(address)) {
        if (address.equalsIgnoreCase("FR")) {
          LocaleHelper.setLocale(getApplicationContext(), "fr");
        } else if (address.equalsIgnoreCase("ES")) {
          LocaleHelper.setLocale(getApplicationContext(), "es");
        } else {
          LocaleHelper.setLocale(getApplicationContext(), "en");
        }
      } else {
        LocaleHelper.setLocale(getApplicationContext(), "fr");
      }
    }
    isEveryThingSet = true;
    startTimer();
  }

  private void startTimer() {
    Observable.timer(1, TimeUnit.SECONDS)
        .subscribeOn(Schedulers.newThread())
        .compose(this.<Long>bindUntilEvent(ActivityEvent.PAUSE))
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Observer<Long>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
          }

          @Override public void onNext(Long aLong) {
            if (getPrefs(SplashActivity.this).getBoolean(QuickstartPreferences.IS_LOGIN, false)) {
              int status = getPrefs(getBaseContext()).getInt(QuickstartPreferences.USER_PHONE_VERIFIED, 0);
              if (status == 2) {
                Intent intent = new Intent(SplashActivity.this, PhoneNumberActivity.class);
                startActivity(intent);
              } else {
                Bundle bundle = new Bundle();
                if (getIntent().hasExtra(Constants.KEY_ID)) {
                  bundle.putString(Constants.KEY_ID, getIntent().getStringExtra(Constants.KEY_ID));
                }
                if (getIntent().hasExtra(Constants.KEY_GROUP_ID)) {
                  bundle.putInt(Constants.KEY_GROUP_ID, getIntent().getIntExtra(Constants.KEY_GROUP_ID, 0));
                }
                launchActivity(SplashActivity.this, HomeActivity.class, true, bundle);
              }
            } else {
              launchActivity(SplashActivity.this, TourActivity.class, true);
            }
          }
        });
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    switch (requestCode) {
      case REQUEST_CHECK_SETTINGS:
        switch (resultCode) {
          case Activity.RESULT_OK:
            LOGI(TAG, "User agreed to make required location settings changes.");
            checkPermission();
            break;
          case Activity.RESULT_CANCELED:
            LOGI(TAG, "User chose not to make required location settings changes.");
            hideProgress();
            showCurrentAddress("");
            break;
        }
        break;
    }
  }

  private void checkPermission() {
    SplashActivityPermissionsDispatcher.startLocationUpdatesWithCheck(this);
  }

  @Override protected void onStart() {
    super.onStart();
    presenter.onStart();
  }

  @Override protected void onStop() {
    presenter.onStop();
    super.onStop();
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }
}
