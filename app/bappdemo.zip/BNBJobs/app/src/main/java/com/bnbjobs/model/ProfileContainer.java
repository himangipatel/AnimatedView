/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class ProfileContainer {
  private boolean success;
  private String message;
  private int profilePercentage;
  private boolean planPurchaseFlg;
  private boolean favoriteFlag;
  private ProfileData data;
  @SerializedName("jobApplyDataArr") private List<JobApplyModel> mJobApplyModels;

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public int getProfilePercentage() {
    return profilePercentage;
  }

  public void setProfilePercentage(int profilePercentage) {
    this.profilePercentage = profilePercentage;
  }

  public boolean isPlanPurchaseFlg() {
    return planPurchaseFlg;
  }

  public void setPlanPurchaseFlg(boolean planPurchaseFlg) {
    this.planPurchaseFlg = planPurchaseFlg;
  }

  public boolean isFavoriteFlag() {
    return favoriteFlag;
  }

  public void setFavoriteFlag(boolean favoriteFlag) {
    this.favoriteFlag = favoriteFlag;
  }

  public ProfileData getData() {
    return data;
  }

  public void setData(ProfileData data) {
    this.data = data;
  }

  public List<JobApplyModel> getJobApplyModels() {
    return mJobApplyModels;
  }

  public void setJobApplyModels(List<JobApplyModel> jobApplyModels) {
    mJobApplyModels = jobApplyModels;
  }
}
