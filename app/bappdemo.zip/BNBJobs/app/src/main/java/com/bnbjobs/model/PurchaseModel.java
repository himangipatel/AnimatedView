/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;

/**
 * @author Harsh
 * @version 1.0
 */
public class PurchaseModel {
  @SerializedName("p_id") private int pId;
  @SerializedName("p_1_week") private String pFirstWeek;
  @SerializedName("p_2_week") private String pSecondWeek;
  @SerializedName("p_monthly") private String pMonthly;
  @SerializedName("p_yearly") private String pYearly;
  @SerializedName("p_plan_type") private int planType;

  public int getpId() {
    return pId;
  }

  public void setpId(int pId) {
    this.pId = pId;
  }

  public String getpFirstWeek() {
    return pFirstWeek;
  }

  public void setpFirstWeek(String pFirstWeek) {
    this.pFirstWeek = pFirstWeek;
  }

  public String getpSecondWeek() {
    return pSecondWeek;
  }

  public void setpSecondWeek(String pSecondWeek) {
    this.pSecondWeek = pSecondWeek;
  }

  public String getpMonthly() {
    return pMonthly;
  }

  public void setpMonthly(String pMonthly) {
    this.pMonthly = pMonthly;
  }

  public String getpYearly() {
    return pYearly;
  }

  public void setpYearly(String pYearly) {
    this.pYearly = pYearly;
  }

  public int getPlanType() {
    return planType;
  }

  public void setPlanType(int planType) {
    this.planType = planType;
  }
}

