/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.Toolbar;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.fragments.BestCandidateFragment;
import com.bnbjobs.fragments.ChatFragment;
import com.bnbjobs.fragments.GroupListFragment;
import com.bnbjobs.fragments.HomeNewFragment;
import com.bnbjobs.fragments.HomeRecruiterFragment;
import com.bnbjobs.fragments.NotificationFragment;
import com.bnbjobs.fragments.OfferFragment;
import com.bnbjobs.fragments.ProfileFragment;
import com.bnbjobs.fragments.ProfileRecruiterFragment;
import com.bnbjobs.fragments.SearchFragment;
import com.bnbjobs.model.ImageModel;
import com.bnbjobs.model.PhoneNumberEvent;
import com.bnbjobs.presenter.HomePresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.HomeView;
import com.facebook.rebound.BaseSpringSystem;
import com.facebook.rebound.SimpleSpringListener;
import com.facebook.rebound.Spring;
import com.facebook.rebound.SpringSystem;
import com.facebook.rebound.SpringUtil;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnNeverAskAgain;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * The type Home activity.
 *
 * @author Harsh
 * @version 1.0
 */
@RuntimePermissions public class HomeActivity extends BaseActivity implements HomeView {

  private static final String TAG = makeLogTag(HomeActivity.class);
  /**
   * The M linear tab.
   */
  @BindView(R.id.linearBottom) public LinearLayout mLinearTab;
  /**
   * The Ll home.
   */
  @BindView(R.id.llHome) public RelativeLayout llHome;
  /**
   * The Is media sel.
   */
  public boolean isMediaSel = false;
  /**
   * The Search.
   */
  @BindString(R.string.search) String search;
  /**
   * The Add offer.
   */
  @BindString(R.string.add_offer) String addOffer;
  /**
   * The Image back.
   */
  @BindView(R.id.imageBack) TinTableImageView imageBack;
  /**
   * The Tv title.
   */
  @BindView(R.id.tvTitle) TextView tvTitle;
  /**
   * The Image center logo.
   */
  @BindView(R.id.imageCenterLogo) ImageView imageCenterLogo;
  /**
   * The Linear header.
   */
  @BindView(R.id.linearHeader) LinearLayout linearHeader;
  /**
   * The Toolbar.
   */
  @BindView(R.id.toolbar) Toolbar toolbar;
  /**
   * The Right image.
   */
  @BindView(R.id.rightImage) TinTableImageView rightImage;
  /**
   * The Container layout.
   */
  @BindView(R.id.containerLayout) FrameLayout containerLayout;
  /**
   * The Linear progress.
   */
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  private String[] tabNames;
  private Integer[] tabImages;
  private int lastPosition = -1;
  private HomePresenter homePresenter;
  private static final int SINGLE_SELECT = 1;

  private final BaseSpringSystem mSpringSystem = SpringSystem.create();
  private final ExampleSpringListener mSpringListener = new ExampleSpringListener();
  private Spring mScaleSpring;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_home);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    homePresenter = new HomePresenter();
    homePresenter.attachView(this);
    setSupportActionBar(toolbar);
    // Create the animation spring.
    mScaleSpring = mSpringSystem.createSpring();
    if (isCandidate()) {
      tabImages = new Integer[] {
          R.drawable.home_bottom/*, R.drawable.search_icon*/, R.drawable.chat_icon,
          R.drawable.notification_icon, R.drawable.group_select, R.drawable.profile_bottom
      };
      tabNames = new String[] { "Home", "Chat", "Notific", "Group", "Profile" };
    } else {
      tabImages = new Integer[] {
          R.drawable.profile_bottom, R.drawable.chat_icon, R.drawable.add_icon,
          R.drawable.notification_icon, R.drawable.search_icon
      };
      tabNames = new String[] { "Profile", "Chat", addOffer, "Notifi", search };
    }
    setStatusBarColor();
    insertView();
    registerBackStackChangeListener();

    if (savedInstanceState == null) {
      int status = getPrefs(getBaseContext()).getInt(QuickstartPreferences.USER_PHONE_VERIFIED, 0);
      if (status == 2) {
        Intent intent = new Intent(this, PhoneNumberActivity.class);
        startActivity(intent);
      }
      if (isCandidate()) {
        handleTab(0);
        setSelectedTab(0);
        openDesignationSelection();
      } else {
        switchFragment(new HomeRecruiterFragment(), false);
      }
    } else {
      setSelectedTab(savedInstanceState.getInt(Constants.KEY_POSITION));
    }
    onNotification(getIntent());
  }

  private void openDesignationSelection() {
    if (getPrefs(this).getBoolean(QuickstartPreferences.SHOW_DESIGNATION, false)) {
      Intent intent = new Intent(this, DesignationSelectActivity.class);
      intent.putExtra(Constants.KEY_TYPE, SINGLE_SELECT);
      intent.putExtra(Constants.KEY_USER_TYPE, 1);
      startActivityForResult(intent, 7777);
    }
  }

  @Override protected void onResume() {
    super.onResume();
    // Add a listener to the spring when the Activity resumes.
    mScaleSpring.addListener(mSpringListener);
  }

  @Override protected void onPause() {
    super.onPause();
    // Remove the listener to the spring when the Activity pauses.
    mScaleSpring.removeListener(mSpringListener);
  }

  private class ExampleSpringListener extends SimpleSpringListener {
    @Override
    public void onSpringUpdate(Spring spring) {
      // On each update of the spring value, we adjust the scale of the image view to match the
      // springs new value. We use the SpringUtil linear interpolation function mapValueFromRangeToRange
      // to translate the spring's 0 to 1 scale to a 100% to 50% scale range and apply that to the View
      // with setScaleX/Y. Note that rendering is an implementation detail of the application and not
      // Rebound itself. If you need Gingerbread compatibility consider using NineOldAndroids to update
      // your view properties in a backwards compatible manner.
      float mappedValue = (float) SpringUtil.mapValueFromRangeToRange(spring.getCurrentValue(), 0, 1, 1, 0.5);

      if(getSelectedView()!=null){
        getSelectedView().setScaleX(mappedValue);
        getSelectedView().setScaleY(mappedValue);
      }

    }
  }

  /**
   * saving fragment state on low memory
   * @param outState saved data
   */
  @Override protected void onSaveInstanceState(Bundle outState) {
    super.onSaveInstanceState(outState);
    outState.putInt(Constants.KEY_POSITION, lastPosition);
    getSupportFragmentManager().putFragment(outState, "mContent",
        getSupportFragmentManager().findFragmentById(R.id.containerLayout));
  }

  /**
   * Show header.
   *
   * @param show the show
   */
  public void showHeader(boolean show) {
    if (show) {
      linearHeader.setVisibility(View.VISIBLE);
    } else {
      linearHeader.setVisibility(View.GONE);
    }
  }

  /**
   * Change tool bar color.
   *
   * @param color the color
   */
  public void changeToolBarColor(int color) {
    toolbar.setBackgroundColor(color);
  }

  /**
   * Sets image back color.
   *
   * @param color the color
   */
  public void setImageBackColor(int color) {
    imageBack.setColorFilter(color);
  }

  /**
   * Sets right image color.
   *
   * @param color the color
   */
  public void setRightImageColor(int color) {
    rightImage.setColorFilter(color);
  }

  /**
   * Sets right image.
   *
   * @param res the res
   */
  public void setRightImage(int res) {
    rightImage.setImageResource(res);
  }

  /**
   * Gets toolbar.
   *
   * @return the toolbar
   */
  public Toolbar getToolbar() {
    return toolbar;
  }

  /**
   * Sets toolbar title.
   *
   * @param text the text
   */
  public void setToolbarTitle(String text) {
    tvTitle.setText(text);
    tvTitle.setVisibility(View.VISIBLE);
  }

  @Override protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    onNotification(intent);
  }

  /**
   * redirect screen as per notification type
   * @param intent intent
   */
  private void onNotification(Intent intent) {
    if (intent.hasExtra(Constants.KEY_ID)) {
      BestCandidateFragment mFragment = new BestCandidateFragment();
      Bundle bundle = new Bundle();
      bundle.putString(Constants.KEY_ID, intent.getStringExtra(Constants.KEY_ID));
      mFragment.setArguments(bundle);
      switchFragment(mFragment, true);
    }else if (intent.hasExtra(Constants.KEY_GROUP_ID)) {
      setSelectedTab(3);
      lastPosition = 3;
      GroupListFragment listFragment = new GroupListFragment();
      Bundle bundle = new Bundle();
      bundle.putInt(Constants.KEY_GROUP_ID,intent.getIntExtra(Constants.KEY_GROUP_ID,0));
      listFragment.setArguments(bundle);
      switchFragment(listFragment,false);
    }
  }

  /**
   * Reset toolbar.
   */
  public void resetToolbar() {
    toolbar.setBackgroundColor(Color.WHITE);
    linearHeader.setVisibility(View.GONE);
    rightImage.setVisibility(View.GONE);
    imageBack.setVisibility(View.VISIBLE);
  }

  /**
   * Show left image.
   *
   * @param show the show
   */
  public void showLeftImage(boolean show) {
    if (show) {
      imageBack.setVisibility(View.VISIBLE);
    } else {
      imageBack.setVisibility(View.GONE);
    }
  }

  /**
   * Show right image.
   *
   * @param show the show
   */
  public void showRightImage(boolean show) {
    if (show) {
      rightImage.setVisibility(View.VISIBLE);
    } else {
      rightImage.setVisibility(View.GONE);
    }
  }

  /**
   * custom tab view
   * @param tabText tab text
   * @param imgRes image
   * @param tag tag to detect click
   * @return view
   */
  private View createTabView(String tabText, int imgRes, int tag) {
    View view = getLayoutInflater().inflate(R.layout.tab_custom, mLinearTab, false);
    TextView tv = (TextView) view.findViewById(R.id.tvTabText);
    tv.setText(tabText);
    //tv.setVisibility(View.GONE);
    ImageView imgTab;
    if (!isCandidate() && tag == 2) {
      imgTab = (ImageView) view.findViewById(R.id.imgAdd);
    } else {
      imgTab = (TinTableImageView) view.findViewById(R.id.imgTab);
    }
    view.setOnTouchListener(new View.OnTouchListener() {
      @Override public boolean onTouch(View v, MotionEvent event) {
        clickHandle(v);
        switch (event.getAction()) {
          case MotionEvent.ACTION_DOWN:
            // When pressed start solving the spring to 1.
            mScaleSpring.setEndValue(1);
            break;
          case MotionEvent.ACTION_UP:
          case MotionEvent.ACTION_CANCEL:
            // When released start solving the spring to 0.
            mScaleSpring.setEndValue(0);
            break;
        }
        return true;
      }
    });
    imgTab.setVisibility(View.VISIBLE);
    imgTab.setImageResource(imgRes);
    view.setTag(tag);

    return view;
  }

  private void clickHandle(View v){
    if (lastPosition == (int) v.getTag()) {
      return;
    }
    /*if ((int) v.getTag() != 2) {
      unSelectAllView();
      v.setSelected(true);
    } else if (isCandidate()) {

    } else if (isMediaSel) {
      unSelectAllView();
      v.setSelected(true);
    }*/
    unSelectAllView();
    v.setSelected(true);
    handleTab((Integer) v.getTag());
  }

  /**
   * Sets selected tab.
   *
   * @param position the position
   */
  public void setSelectedTab(int position) {
    if (position != -1) {
      unSelectAllView();
      lastPosition = position;
      mLinearTab.getChildAt(position).setSelected(true);
    }
  }

  /**
   * Handle tab.
   *
   * @param position the position
   */
  public void handleTab(int position) {
    Fragment fragment = null;
    if (position == 0) {
      if (isCandidate()) {
        fragment = new HomeNewFragment();
      } else {
        fragment = new ProfileRecruiterFragment();
      }
    } else if (position == 1) {
      fragment = new ChatFragment();
    } else if (position == 2) {
      if (isCandidate()) {
        fragment = new NotificationFragment();
      } else {
        fragment = new OfferFragment();
      }
    } else if (position == 3) {
      if (isCandidate()) {
        fragment = new GroupListFragment();
      } else {
        fragment = new NotificationFragment();
      }
    } else if (position == 4) {
      if (isCandidate()) {
        fragment = new ProfileFragment();
      } else {
        fragment = new SearchFragment();
      }
    }
    transitFragment(position, fragment);
  }

  private void transitFragment(int position, Fragment fragment) {
    lastPosition = position;
    getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
    switchFragment(fragment, !isCandidate());
  }

  /**
   * Switch fragment.
   *
   * @param fragment the fragment
   * @param addToBackStack the add to back stack
   */
  public void switchFragment(Fragment fragment, boolean addToBackStack) {
    FragmentManager fragmentManager = getSupportFragmentManager();
    FragmentTransaction transaction = fragmentManager.beginTransaction();
    transaction.replace(R.id.containerLayout, fragment, fragment.getClass().getName());
    if (addToBackStack) {
      transaction.addToBackStack(fragment.getClass().getName());
    }
    transaction.commit();
  }

  private void unSelectAllView() {
    for (int i = 0; i < mLinearTab.getChildCount(); i++) {
      mLinearTab.getChildAt(i).setSelected(false);
    }
  }

  @Nullable
  private View getSelectedView(){
    View view = null;
    for (int i = 0; i < mLinearTab.getChildCount(); i++) {
      view =mLinearTab.getChildAt(i);
      if(view.isSelected())
        break;
    }
    return view;
  }

  /**
   * On image back.
   *
   * @param view the view
   */
  @OnClick(R.id.imageBack) void onImageBack(View view) {
    BaseFragment fragment =
        (BaseFragment) getSupportFragmentManager().findFragmentById(R.id.containerLayout);
    if (fragment != null) {
      fragment.onBack(view);
    }
  }

  /**
   * On right image.
   *
   * @param view the view
   */
  @OnClick(R.id.rightImage) void onRightImage(View view) {
    BaseFragment fragment =
        (BaseFragment) getSupportFragmentManager().findFragmentById(R.id.containerLayout);
    if (fragment != null) {
      fragment.onRight(view);
    }
  }

  private boolean isSelected() {
    boolean check = false;
    for (int i = 0; i < mLinearTab.getChildCount(); i++) {
      if (mLinearTab.getChildAt(i).isSelected()) {
        check = true;
      }
    }
    return check;
  }

  private void insertView() {
    LinearLayout.LayoutParams param =
        new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f);
    for (int i = 0; i < tabImages.length; i++) {
      View view = createTabView(tabNames[i], tabImages[i], i);
      if (!isCandidate()) {
        if (i == 2) {
          param = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1.2f);
        } else {
          param = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 0.8f);
        }
      }
      view.setLayoutParams(param);
      mLinearTab.addView(view);
    }
  }

  @Override protected void onDestroy() {
    homePresenter.detachView();
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  /**
   * baseFragment.onBackPressed()
   * true means default behavior
   * false means handle by us
   */
  @Override public void onBackPressed() {
    BaseFragment baseFragment = getCurrentFragment();
    if (baseFragment != null && baseFragment.onBackPressed()) {
      return;
    }
    if (!isCandidate() && isSelected()) {
      unSelectAllView();
    }
    lastPosition = -1;
    super.onBackPressed();
  }

  private BaseFragment getCurrentFragment() {
    return (BaseFragment) getSupportFragmentManager().findFragmentById(R.id.containerLayout);
  }

  public void showMediaDialog() {
    homePresenter.showMediaDialog();
  }

  @Override public void openCamera() {
    HomeActivityPermissionsDispatcher.showCameraWithCheck(this, true, false);
  }

  @Override public void openGallery() {
    HomeActivityPermissionsDispatcher.showCameraWithCheck(this, false, false);
  }

  @Override public void opeVideoCamera() {
    HomeActivityPermissionsDispatcher.showCameraWithCheck(this, true, true);
  }

  @Override public void openVideoGallery() {
    HomeActivityPermissionsDispatcher.showCameraWithCheck(this, false, true);
  }

  @Override public void addImage(ImageModel imageModel, int posSel) {
    navigateToOfferFragment(imageModel);
  }

  @Override public void addVideo(ImageModel imgVideo) {
    imgVideo.setVideo(true);
    navigateToOfferFragment(imgVideo);
  }

  private void navigateToOfferFragment(ImageModel imageModel) {
    unSelectAllView();
    Fragment fragment = new OfferFragment();
    Bundle bundle = new Bundle();
    bundle.putSerializable(OfferFragment.ARG_IMAGE_MODEL, imageModel);
    fragment.setArguments(bundle);
    transitFragment(2, fragment);
  }

  @Override public Context getContext() {
    return HomeActivity.this;
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void setDefault() {
  }

  @Override public boolean isImageSet() {
    return false;
  }

  @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == RESULT_OK && requestCode == 7777) {
      String dId = data.getStringExtra(Constants.KEY_TEXT);
      homePresenter.updateDesignation(dId);
    } else {
      if (resultCode == RESULT_OK) {
        if (requestCode == Constants.REQUEST_CODE_PERSONAL_INFO) {
          showMediaDialog();
          isMediaSel = true;
        } else {
          homePresenter.onActivityResult(requestCode, resultCode, data);
        }
      }
    }
  }

  /**
   * Show camera.
   *
   * @param isCamera the is camera
   * @param isVideo the is video
   */
  @NeedsPermission({ Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE })
  public void showCamera(boolean isCamera, boolean isVideo) {
    if (isVideo) {
      if (isCamera) {
        homePresenter.openVideoCamera();
      } else {
        homePresenter.openVideoGallery();
      }
    } else {
      if (isCamera) {
        homePresenter.openCamera();
      } else {
        homePresenter.openGallery();
      }
    }
  }

  /**
   * Show rationale for camera.
   *
   * @param request the request
   */
  @OnShowRationale({ Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE })
  void showRationaleForCamera(final PermissionRequest request) {
    LOGI(OfferFragment.class.getName(), "OnShowRationale");
    Utils.showDialog(getContext(), getString(R.string.alert),
        getString(R.string.permission_camera_rationale), getString(R.string.button_allow),
        getString(R.string.button_deny), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.proceed();
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.cancel();
          }
        }).show();
  }

  @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
      @NonNull int[] grantResults) {
    HomeActivityPermissionsDispatcher.onRequestPermissionsResult(this, requestCode, grantResults);
  }

  /**
   * Show denied for camera.
   */
  @OnPermissionDenied({ Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE })
  void showDeniedForCamera() {
    LOGI(OfferFragment.class.getName(), "OnPermissionDenied");
    showPermissionDialog();
  }

  /**
   * Show never ask for camera.
   */
  @OnNeverAskAgain({ Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE })
  void showNeverAskForCamera() {
    LOGI(OfferFragment.class.getName(), "OnNeverAskAgain");
    showPermissionDialog();
  }

  private void showPermissionDialog() {
    Utils.showDialog(getContext(), getString(R.string.alert),
        getString(R.string.permission_camera_never_askagain), getString(android.R.string.ok),
        new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }

  private void registerBackStackChangeListener() {
    getSupportFragmentManager().addOnBackStackChangedListener(
        new FragmentManager.OnBackStackChangedListener() {
          @Override public void onBackStackChanged() {
            new Handler().postDelayed(new Runnable() {
              @Override public void run() {
                changeTabVisibility(true);
              }
            }, 250);
          }
        });
  }

  /**
   * Change tab visibility.
   *
   * @param visible the visible
   */
  public void changeTabVisibility(boolean visible) {
    if (visible) {
      mLinearTab.setVisibility(View.VISIBLE);
    } else {
      mLinearTab.setVisibility(View.GONE);
    }
  }

  /**
   * Sets last position.
   */
  public void setLastPosition() {
    lastPosition = -1;
  }

  /**
   * On event.
   *
   * @param event the event
   */
  @Subscribe public void onEvent(PhoneNumberEvent event) {
    if (event.isCloseCurrentActivity()) openDesignationSelection();
  }
}
