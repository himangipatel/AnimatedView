/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.bnbjobs.utils.LocaleHelper;
import com.google.gson.annotations.SerializedName;
import java.util.Locale;

import static android.text.TextUtils.isEmpty;

/**
 * @author Harsh
 * @version 1.0
 */

public class Experience implements Parcelable, Cloneable {
  @SerializedName("upe_id") private int eId;
  @SerializedName("upe_month") private String progressInMonths;
  @SerializedName("d_title_1") private String d_title_1;
  @SerializedName("d_title_2") private String d_title_2;
  @SerializedName("d_title_3") private String d_title_3;
  @SerializedName("d_id") private int d_id;
  private int type;
  private String progress_title;
  private String progress_subtitle;
  private int profilePercent;
  private boolean isDeleted;
  private void readIn(Parcel in) {
    eId = in.readInt();
    progressInMonths = in.readString();
    d_title_1 = in.readString();
    d_title_2 = in.readString();
    d_title_3 = in.readString();
    d_id = in.readInt();
    type = in.readInt();
    progress_title = in.readString();
    progress_subtitle = in.readString();
    profilePercent = in.readInt();
    isDeleted = in.readByte() != 0;
  }

  @Override public void writeToParcel(Parcel dest, int flags) {
    dest.writeInt(eId);
    dest.writeString(progressInMonths);
    dest.writeString(d_title_1);
    dest.writeString(d_title_2);
    dest.writeString(d_title_3);
    dest.writeInt(d_id);
    dest.writeInt(type);
    dest.writeString(progress_title);
    dest.writeString(progress_subtitle);
    dest.writeInt(profilePercent);
    dest.writeByte((byte) (isDeleted ? 1 : 0));
  }

  @Override public int describeContents() {
    return 0;
  }

  public static final Creator<Experience> CREATOR = new Creator<Experience>() {
    @Override public Experience createFromParcel(Parcel in) {
      Experience mExperience = new Experience();
      mExperience.readIn(in);
      return mExperience;
    }

    @Override public Experience[] newArray(int size) {
      return new Experience[size];
    }
  };

  public boolean isDeleted() {
    return isDeleted;
  }

  public void setDeleted(boolean deleted) {
    isDeleted = deleted;
  }

  public int getProfilePercent() {
    return profilePercent;
  }

  public void setProfilePercent(int profilePercent) {
    this.profilePercent = profilePercent;
  }

  public int getD_id() {
    return d_id;
  }

  public void setD_id(int d_id) {
    this.d_id = d_id;
  }

  public int geteId() {
    return eId;
  }

  public void seteId(int eId) {
    this.eId = eId;
  }

  public String getD_title_1() {
    return d_title_1;
  }

  public void setD_title_1(String d_title_1) {
    this.d_title_1 = d_title_1;
  }

  public String getD_title_2() {
    return d_title_2;
  }

  public void setD_title_2(String d_title_2) {
    this.d_title_2 = d_title_2;
  }

  public String getD_title_3() {
    return d_title_3;
  }

  public void setD_title_3(String d_title_3) {
    this.d_title_3 = d_title_3;
  }

  public int getType() {
    return type;
  }

  public void setType(int type) {
    this.type = type;
  }

  public String getProgress_title() {
    return progress_title;
  }

  public void setProgress_title(String progress_title) {
    this.progress_title = progress_title;
  }

  public String getProgress_subtitle() {
    return progress_subtitle;
  }

  public void setProgress_subtitle(String progress_subtitle) {
    this.progress_subtitle = progress_subtitle;
  }

  public int getProgressInMonths() {
    return isEmpty(progressInMonths) ? 0 : Integer.parseInt(progressInMonths);
  }

  public void setProgressInMonths(String progressInMonths) {
    this.progressInMonths = progressInMonths;
  }

  public String getTitle() {
    if (LocaleHelper.isFrench()) {
      return getD_title_2();
    } else if (LocaleHelper.isSpanish()) {
      return getD_title_3();
    } else {
      return getD_title_1();
    }
  }

  public String getExperience() {
    int months = getProgressInMonths();
    int year;
    if (months > 12) {
      year = months / 12;
      if (year >= 5) {
        return String.format(Locale.getDefault(), "%s+ ", year);
      } else {
        int tempYear = year + 1;
        return String.format(Locale.getDefault(), "%s - %s ", year, tempYear);
      }
    } else {
      int pMonth = months - 1;
      int eMonth = months + 1;
      return String.format(Locale.getDefault(), "%s - %s ", pMonth, eMonth);
    }
  }

  public Object clone() throws CloneNotSupportedException {
    return super.clone();
  }
}


