/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.adapter.AlertAdapter;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.CandidateModel;
import com.bnbjobs.model.UpdateEvent;
import com.bnbjobs.presenter.AlertPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.view.AlertView;
import java.util.ArrayList;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

/**
 * @author Harsh
 * @version 1.0
 */
public class AlertFragment extends BaseFragment implements AlertView, ClickImpl<CandidateModel> {

  @BindView(R.id.recyclerView) RecyclerView mRecyclerView;
  @BindView(R.id.tvNoRecord) TextView mTvNoRecord;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  private Unbinder unbinder;
  private AlertPresenter presenter;
  private AlertAdapter mAlertAdapter;
  private List<CandidateModel> mUserModelList = new ArrayList<>();
  private View view;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    EventBus.getDefault().register(this);
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    if (view == null) {
      view = inflater.inflate(R.layout.fragment_all_list, container, false);
    }
    unbinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    presenter = new AlertPresenter();
    presenter.attachView(this);
    presenter.setFragment(this);
    mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
    if (mUserModelList.size() < 1) {
      presenter.getAlerts();
      mAlertAdapter = new AlertAdapter(getActivity(), mUserModelList, this);
    }
    mRecyclerView.setAdapter(mAlertAdapter);
  }

  @Override public void onResume() {
    super.onResume();
    showToolbar(true);
    setTitle(getString(R.string.alerts));
  }

  @Override public void onDestroyView() {
    super.onDestroyView();
    unbinder.unbind();
  }

  @Override public void onDestroy() {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe public void onEvent(UpdateEvent event) {
    if (event.update) {
      view = null;
      mUserModelList.clear();
    }
  }

  @Override public void setAdapter(List<CandidateModel> userModelList) {
    mUserModelList.addAll(userModelList);
    mAlertAdapter.notifyDataSetChanged();
    if(mUserModelList.isEmpty())
      mTvNoRecord.setVisibility(View.VISIBLE);
    else
      mTvNoRecord.setVisibility(View.GONE);
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @OnClick(R.id.linearProgress) void onLinearProgress() {
  }

  @Override public void onClick(View view, CandidateModel object, int position) {
    ProfileFragment fragment = new ProfileFragment();
    Bundle bundle = new Bundle();
    bundle.putString(Constants.KEY_ID, object.getuId());
    bundle.putBoolean(Constants.KEY_VISIBLE_TYPE, true);
    fragment.setArguments(bundle);
    addFragment(fragment, true);
  }
}
