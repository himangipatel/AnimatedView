/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.bnbjobs.utils.LocaleHelper;
import com.google.gson.annotations.SerializedName;

/**
 * @author Harsh
 * @version 1.0
 */
public class UserProfileData {

    private String d_title_1;
    private String d_title_2;
    private String d_title_3;
    @SerializedName("up_description")
    private String description;
    @SerializedName("up_facebook_link")
    private String fbLink;
    @SerializedName("up_twitter_link")
    private String twitterLink;
    @SerializedName("up_bod")
    private String birthdate;
    @SerializedName("up_gender")
    private String gender;
    @SerializedName("d_id")
    private int designationId;
    @SerializedName("u_active_status")
    private int activeStatus;

    public int getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(int activeStatus) {
        this.activeStatus = activeStatus;
    }

    public int getDesignationId() {
        return designationId;
    }

    public void setDesignationId(int designationId) {
        this.designationId = designationId;
    }


    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getD_title_1() {
        return d_title_1;
    }

    public void setD_title_1(String d_title_1) {
        this.d_title_1 = d_title_1;
    }

    public String getD_title_2() {
        return d_title_2;
    }

    public void setD_title_2(String d_title_2) {
        this.d_title_2 = d_title_2;
    }

    public String getD_title_3() {
        return d_title_3;
    }

    public void setD_title_3(String d_title_3) {
        this.d_title_3 = d_title_3;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFbLink() {
        return fbLink;
    }

    public void setFbLink(String fbLink) {
        this.fbLink = fbLink;
    }

    public String getTwitterLink() {
        return twitterLink;
    }

    public void setTwitterLink(String twitterLink) {
        this.twitterLink = twitterLink;
    }

    public String getTitle() {
        if (LocaleHelper.isFrench()) {
            return getD_title_2();
        } else if (LocaleHelper.isSpanish()) {
            return getD_title_3();
        } else {
            return getD_title_1();
        }
    }
}
