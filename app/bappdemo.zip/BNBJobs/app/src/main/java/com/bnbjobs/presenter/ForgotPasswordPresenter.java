/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.widget.EditText;
import com.bnbjobs.R;
import com.bnbjobs.activity.ForgotActivity;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.LocaleHelper;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.ForgotPasswordView;
import com.trello.rxlifecycle.ActivityEvent;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Observer;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.getText;
import static com.bnbjobs.utils.Utils.hideKeyboard;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.isValidEmail;
import static com.bnbjobs.utils.Utils.showDialog;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */
public class ForgotPasswordPresenter extends BasePresenter
    implements Presenter<ForgotPasswordView> {
  private static final String TAG = makeLogTag(ForgotPasswordPresenter.class);
  private ForgotPasswordView mForgotPasswordView;
  private EditText etEmail;

  @Override public void attachView(ForgotPasswordView view) {
    this.mForgotPasswordView = view;
  }

  @Override public void detachView() {
    mForgotPasswordView = null;
  }

  public void onSubmit(EditText etEmail) {
    this.etEmail = etEmail;
    if (checkValidation()) {
      hideKeyboard(getContext());
      if (hasNetworkConnectivity()) {
        mForgotPasswordView.showProgress();
        onRequest();
      } else {
        showNetworkError();
      }
    }
  }

  private boolean checkValidation() {
    if (!isValidEmail(Utils.getText(etEmail))) {
      showMessage(getContext(), getContext().getString(R.string.enter_valid_email_address));
      return false;
    }
    return true;
  }

  private void onRequest() {
    HashMap<String, String> params = new HashMap<>(3);
    params.put("apiName", "forgotPassword");
    params.put("email", getText(etEmail));
    params.put("language", LocaleHelper.getLanguage(getContext()));

    RestClient.getInstance(params)
        .compose(getContext().<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Observer<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            mForgotPasswordView.hideProgress();
            LOGE(TAG, Log.getStackTraceString(e));
            retryMethod(e);
          }

          @Override public void onNext(final String s) {
            LOGI(TAG, "response: " + s);
            mForgotPasswordView.hideProgress();
            try {
              JSONObject object = new JSONObject(s);
              showDialog(getContext(), getContext().getString(R.string.alert),
                  object.getString("message"), getContext().getString(android.R.string.ok),
                  new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                      dialog.dismiss();
                      if (isResponseSuccess(s)) {
                        mForgotPasswordView.onDone();
                      }
                    }
                  }).show();
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(Throwable e) {
    String error = "";
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            onRequest();
          }
        }).show();
  }

  private ForgotActivity getContext() {
    return (ForgotActivity) mForgotPasswordView.getContext();
  }

  @Override protected Context getBaseContext() {
    return getContext();
  }
}
