/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.RegisterActivity;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.AeSimpleSHA1;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.RegisterView;
import com.trello.rxlifecycle.ActivityEvent;
import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Observer;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.getText;
import static com.bnbjobs.utils.Utils.hideKeyboard;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.isValidEmail;
import static com.bnbjobs.utils.Utils.showDialog;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */
public class RegisterPresenter extends BasePresenter implements Presenter<RegisterView> {

  private static final String TAG = makeLogTag(RegisterPresenter.class);
  private RegisterView mRegisterView;
  private EditText etFirstName;
  private EditText etEmailAddress;
  private EditText etPassword;
  private EditText etLastName;
  private EditText etCompany;

  @Override public void attachView(RegisterView view) {
    mRegisterView = view;
  }

  @Override public void detachView() {
    mRegisterView = null;
  }

  public void doRegister(EditText etFirstName, EditText etLastName, EditText etEmailAddress,
      EditText etPassword, EditText etCompany) {
    this.etLastName = etLastName;
    this.etFirstName = etFirstName;
    this.etEmailAddress = etEmailAddress;
    this.etPassword = etPassword;
    this.etCompany = etCompany;
    if (checkValidation()) {
      hideKeyboard(getContext());
      if (hasNetworkConnectivity()) {
        registerUser();
      } else {
        showNetworkError();
      }
    }
  }

  private void registerUser() {
    mRegisterView.showProgress();
    HashMap<String, String> params = new HashMap<>(12);
    params.put("apiName", "register");
    params.put("firstName", getText(etFirstName));
    params.put("lastName", getText(etLastName));
    params.put("email", getText(etEmailAddress));
    try {
      params.put("password", AeSimpleSHA1.SHA1(getText(etPassword)));
    } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
      e.printStackTrace();
    }

    params.put("registerType", Constants.REG_NORMAL);
    params.put("latitude", getPrefs(getBaseContext()).getString(QuickstartPreferences.LAT, ""));
    params.put("longitude", getPrefs(getBaseContext()).getString(QuickstartPreferences.LNG, ""));
    String userType = getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_TYPE, "");
    params.put("userType", userType);
    if (userType.equalsIgnoreCase(Constants.RECRUITER) && !TextUtils.isEmpty(getText(etCompany))) {
      params.put("company", getText(etCompany));
    }
    params.putAll(addDefaultParams(params));
    LOGI(TAG, params.toString());
    RestClient.getInstance(params)
        .compose(getContext().<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Observer<String>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            mRegisterView.hideProgress();
            LOGE(TAG, Log.getStackTraceString(e));
            retryMethod(e);
          }

          @Override public void onNext(String s) {
            mRegisterView.hideProgress();
            try {
              JSONObject object = new JSONObject(s);
              if (isResponseSuccess(s)) {
                showMessage(getContext(), "Register Successfully");
                getPrefs(getBaseContext()).save(QuickstartPreferences.ACCESS_TOKEN,
                    object.getString("accessToken"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.SHOW_DESIGNATION,
                    object.getBoolean("designationFlag"));
                JSONObject userObject = object.getJSONObject("userData");
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_ID,
                    userObject.getString("u_id"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_FNAME,
                    userObject.getString("u_fname"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_LNAME,
                    userObject.getString("u_lname"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.CREATED_AT,
                    userObject.getString("u_created_at"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.IS_LOGIN, true);
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_PHONENUMBER,
                    userObject.optString("u_phone", ""));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_PHONE_VERIFIED,
                    userObject.optInt("u_phone_verified"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_PHONE_TOKEN,
                    userObject.optString("u_phone_token", ""));
                mRegisterView.onRegister();
              } else {
                showDialog(getContext(), getContext().getString(R.string.alert),
                    object.getString("message"), getContext().getString(android.R.string.ok),
                    new DialogInterface.OnClickListener() {
                      @Override public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                      }
                    }).show();
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(Throwable e) {
    String error;
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            registerUser();
          }
        }).show();
  }

  private boolean checkValidation() {
    if (isEmpty(Utils.getText(etFirstName))) {
      showMessage(getContext(), getContext().getString(R.string.enter_valid_first_name));
      return false;
    } else if (isEmpty(Utils.getText(etLastName))) {
      showMessage(getContext(), getContext().getString(R.string.enter_valid_last_name));
      return false;
    } else if (!isValidEmail(Utils.getText(etEmailAddress))) {
      showMessage(getContext(), getContext().getString(R.string.enter_valid_email_address));
      return false;
    } else if (isEmpty(Utils.getText(etPassword))) {
      showMessage(getContext(), getContext().getString(R.string.enter_valid_password));
      return false;
    } else if (Utils.getText(etPassword).length() < 8) {
      showMessage(getContext(), getContext().getString(R.string.enter_valid_password_length));
      return false;
    }
    return true;
  }

  private RegisterActivity getContext() {
    return (RegisterActivity) mRegisterView.getContext();
  }

  @Override protected Context getBaseContext() {
    return getContext();
  }
}
