/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.bnbjobs.model.NotificationModel;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public interface NotificationView extends MainView {

  void setData(List<NotificationModel> mNotificationModel);
}
