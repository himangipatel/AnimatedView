/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class DashboardData {

  @SerializedName("userData") private UserModel userModel;
  @SerializedName("jobOfferData") private List<JobOfferData> jobOfferDataList;

  private int totalJobOfferVisitor;
  private int totalAlertProfile;
  private int totalAllCandidate;
  private int totalAppliedCandidate;
  private int totalApproveCandidate;
  private int totalFavoriteCandidate;

  public UserModel getUserModel() {
    return userModel;
  }

  public void setUserModel(UserModel userModel) {
    this.userModel = userModel;
  }

  public List<JobOfferData> getJobOfferDataList() {
    return jobOfferDataList;
  }

  public void setJobOfferDataList(List<JobOfferData> jobOfferDataList) {
    this.jobOfferDataList = jobOfferDataList;
  }

  public int getTotalJobOfferVisitor() {
    return totalJobOfferVisitor;
  }

  public void setTotalJobOfferVisitor(int totalJobOfferVisitor) {
    this.totalJobOfferVisitor = totalJobOfferVisitor;
  }

  public int getTotalAlertProfile() {
    return totalAlertProfile;
  }

  public void setTotalAlertProfile(int totalAlertProfile) {
    this.totalAlertProfile = totalAlertProfile;
  }

  public int getTotalAllCandidate() {
    return totalAllCandidate;
  }

  public void setTotalAllCandidate(int totalAllCandidate) {
    this.totalAllCandidate = totalAllCandidate;
  }

  public int getTotalAppliedCandidate() {
    return totalAppliedCandidate;
  }

  public void setTotalAppliedCandidate(int totalAppliedCandidate) {
    this.totalAppliedCandidate = totalAppliedCandidate;
  }

  public int getTotalApproveCandidate() {
    return totalApproveCandidate;
  }

  public void setTotalApproveCandidate(int totalApproveCandidate) {
    this.totalApproveCandidate = totalApproveCandidate;
  }

  public int getTotalFavoriteCandidate() {
    return totalFavoriteCandidate;
  }

  public void setTotalFavoriteCandidate(int totalFavoriteCandidate) {
    this.totalFavoriteCandidate = totalFavoriteCandidate;
  }
}
