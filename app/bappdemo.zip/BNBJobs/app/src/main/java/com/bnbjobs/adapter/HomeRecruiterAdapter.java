/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import atownsend.swipeopenhelper.BaseSwipeOpenViewHolder;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.CircleImageView;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.CandidateModel;
import com.bumptech.glide.Glide;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class HomeRecruiterAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

  private final int VIEW_TYPE_ITEM = 0;
  private final int VIEW_TYPE_LOADING = 1;
  private Context mContext;
  private List<CandidateModel> mCandidateList;
  private ClickImpl mClick;
  private Fragment fragment;

  public HomeRecruiterAdapter(Context mContext, List<CandidateModel> mCandidateList, Fragment fragment) {
    this.mContext = mContext;
    this.mCandidateList = mCandidateList;
    mClick = (ClickImpl) fragment;
    this.fragment = fragment;
  }

  @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    if (viewType == VIEW_TYPE_ITEM) {
      View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_recruiter_home, parent, false);
      return new MyViewHolder(view);
    } else if (viewType == VIEW_TYPE_LOADING) {
      View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.progress, parent, false);
      return new LoadingViewHolder(view);
    }
    return null;
  }

  @Override public void onBindViewHolder(RecyclerView.ViewHolder mHolder, int position) {
    if (mHolder instanceof MyViewHolder) {
      MyViewHolder holder = (MyViewHolder) mHolder;
      Glide.with(mContext)
          .load(mCandidateList.get(position).getuImageUrl())
          .placeholder(R.drawable.user_placeholder)
          .dontAnimate()
          .into(holder.imgAvatar);
      final String name = TextUtils.join(" ", new String[] { mCandidateList.get(position).getfName(), mCandidateList.get(position).getlName() });
      holder.tvUserName.setText(name);
      holder.tvUserAddress.setText(mCandidateList.get(position).getTitle());
      holder.tvDistance.setText(String.format("%s . %s", mCandidateList.get(position).getDistance(), mCandidateList.get(position).getAddress()));
      if(mCandidateList.get(position).isFavorite())
        holder.ivFav.setImageResource(R.drawable.star_fav_white);
      else
        holder.ivFav.setImageResource(R.drawable.star_white);
    } else if (mHolder instanceof LoadingViewHolder) {
      LoadingViewHolder loadingViewHolder = (LoadingViewHolder) mHolder;
      loadingViewHolder.progressBar.setIndeterminate(true);
    }
  }

  @Override public int getItemViewType(int position) {
    return mCandidateList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
  }

  @Override public int getItemCount() {
    return mCandidateList == null ? 0 : mCandidateList.size();
  }

  public static class LoadingViewHolder extends RecyclerView.ViewHolder {
    @BindView(R.id.progressBar)
    ProgressBar progressBar;
    LoadingViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this,itemView);
    }
  }

  public class MyViewHolder extends BaseSwipeOpenViewHolder {

    @BindView(R.id.imgAvatar) CircleImageView imgAvatar;
    @BindView(R.id.tvUserName) TextView tvUserName;
    @BindView(R.id.tvUserAddress) TextView tvUserAddress;
    @BindView(R.id.tvDistance) TextView tvDistance;
    @BindView(R.id.linearSwipe) LinearLayout linearSwipe;
    @BindView(R.id.relativeSwipe) RelativeLayout relativeSwipe;
    @BindView(R.id.ivStar) ImageView ivFav;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
    }

    @OnClick({ R.id.relativeSwipe, R.id.ivStar, R.id.ivChat, R.id.ivProfileWhite }) void onClick(View v) {
      mClick.onClick(v, mCandidateList.get(getLayoutPosition()), getLayoutPosition());
    }

    @NonNull @Override public View getSwipeView() {
      return relativeSwipe;
    }

    @Override public float getEndHiddenViewSize() {
      return linearSwipe.getMeasuredWidth();
    }

    @Override public float getStartHiddenViewSize() {
      return 0;
    }
  }
}
