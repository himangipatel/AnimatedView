/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.model.LandingEvent;
import com.bnbjobs.presenter.LandingPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.LandingScreenView;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnNeverAskAgain;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.ActivityUtils.launchActivity;
import static com.bnbjobs.utils.LogUtils.LOGD;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
@RuntimePermissions public class LandingScreen extends BaseActivity implements LandingScreenView {

  private static final int REQUEST_CHECK_SETTINGS = 0x1;
  @BindView(R.id.tvJobCount) TextView tvJobCount;
  @BindView(R.id.linearJob) RelativeLayout linearJob;
  @BindView(R.id.tvLocation) TextView tvLocation;
  @BindView(R.id.imageView2) ImageView imageViewCenter;
  @BindView(R.id.progressBar) ProgressBar progressBar;
  @BindView(R.id.tvLogin) TextView tvLogin;
  @BindView(R.id.tvRegister) TextView tvRegister;
  @BindView(R.id.tvCountType) TextView tvCountType;
  private LandingPresenter presenter;
  private String TAG = makeLogTag(LandingScreen.class);

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_landing);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    if (!getPrefs(this).getString(QuickstartPreferences.USER_TYPE,Constants.CANDIDATE)
        .equalsIgnoreCase(Constants.CANDIDATE)) {
      tvCountType.setText(getString(R.string.candidate));
    }
    presenter = new LandingPresenter();
    presenter.attachView(this);
    Drawable drawable = imageViewCenter.getDrawable();
    int height = drawable.getIntrinsicHeight() / 2;
    RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) linearJob.getLayoutParams();
    params.setMargins(0, height + getResources().getDimensionPixelOffset(R.dimen._4sdp), 0, 0);
    linearJob.setLayoutParams(params);
    presenter.setUpLocationClient();
    if (getIntent().hasExtra(Constants.KEY_SHOW)) {
      Utils.showMessage(this, "Your session has expired. please login again.");
    }
  }

  @OnClick(R.id.tvRegister) public void onRegister() {
    launchActivity(this, RegisterActivity.class, false);
  }

  @OnClick(R.id.tvLogin) public void onLogin() {
    launchActivity(this, LoginActivity.class, false);
  }

  @NeedsPermission({
      Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
  }) void startLocationUpdates() {
    presenter.startLocationUpdate();
  }

  @OnShowRationale({
      Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
  }) void showRationaleForLocation(final PermissionRequest request) {
    Utils.showDialog(this, getString(R.string.alert),
        getString(R.string.permission_location_rationale), getString(R.string.button_allow),
        getString(R.string.button_deny), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.proceed();
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            request.cancel();
          }
        }).show();
  }

  @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
      @NonNull int[] grantResults) {
    LandingScreenPermissionsDispatcher.onRequestPermissionsResult(this, requestCode, grantResults);
  }

  @OnPermissionDenied({
      Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
  }) void showDeniedForLocation() {
    hideProgress();
    showPermissionDialog();
  }

  @OnNeverAskAgain({
      Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
  }) void showNeverAskForLocation() {
    hideProgress();
    showPermissionDialog();
    //Utils.showMessage(this, getString(R.string.permission_location_never_askagain));
  }

  private void showPermissionDialog() {
    Utils.showDialog(this, getString(R.string.alert),
        getString(R.string.permission_location_never_askagain), getString(android.R.string.ok),
        new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }

  @Override protected void onResume() {
    super.onResume();
    presenter.onResume();
  }

  @Override protected void onPause() {
    super.onPause();
    presenter.onPause();
  }

  @Override public void checkLocationPermission() {
    LOGD(TAG, "here checking permission");
    LandingScreenPermissionsDispatcher.startLocationUpdatesWithCheck(this);
  }

  @Override public void showCurrentJob(String currentJob) {
    tvJobCount.setText(currentJob);
  }

  @Override public void showCurrentAddress(String address) {
    tvLocation.setText(address);
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    switch (requestCode) {
      case REQUEST_CHECK_SETTINGS:
        switch (resultCode) {
          case Activity.RESULT_OK:
            LOGI(TAG, "User agreed to make required location settings changes.");
            LandingScreenPermissionsDispatcher.startLocationUpdatesWithCheck(this);
            break;
          case Activity.RESULT_CANCELED:
            LOGI(TAG, "User chose not to make required location settings changes.");
            hideProgress();
            tvLocation.setText(getString(R.string.no_location_data_provided));
            break;
        }
        break;
    }
  }

  @Override protected void onStart() {
    super.onStart();
    presenter.onStart();
  }

  @Override protected void onStop() {
    presenter.onStop();
    super.onStop();
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    tvJobCount.setVisibility(View.INVISIBLE);
    progressBar.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    tvJobCount.setVisibility(View.VISIBLE);
    progressBar.setVisibility(View.GONE);
  }

  @Override protected void onDestroy() {
    EventBus.getDefault().unregister(this);
    presenter.detachView();
    super.onDestroy();
  }

  @Subscribe public void onMessage(LandingEvent event) {
    if (event.isFinish) {
      finish();
    }
  }
}
