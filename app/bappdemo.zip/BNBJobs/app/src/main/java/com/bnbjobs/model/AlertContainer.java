/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class AlertContainer {

  private boolean success;
  private String message;
  @SerializedName("data") private List<CandidateModel> mUserModelList;

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public List<CandidateModel> getUserModelList() {
    return mUserModelList;
  }

  public void setUserModelList(List<CandidateModel> userModelList) {
    mUserModelList = userModelList;
  }
}
