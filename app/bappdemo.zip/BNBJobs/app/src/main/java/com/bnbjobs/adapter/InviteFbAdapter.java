/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.model.FbFriends;
import com.bumptech.glide.Glide;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class InviteFbAdapter extends RecyclerView.Adapter<InviteFbAdapter.MyViewHolder> {
  private List<FbFriends.FbFriendsList> fbFriendsLists;
  private Context context;

  public InviteFbAdapter(Context context, List<FbFriends.FbFriendsList> fbFriendsLists) {
    this.fbFriendsLists = fbFriendsLists;
    this.context = context;
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view =
        LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_invite, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {
    holder.tvUserName.setText(fbFriendsLists.get(position).getName());
    holder.tvInvite.setTextColor(Color.WHITE);
    holder.tvInvite.setText(context.getString(R.string.invited));
    holder.tvInvite.setBackgroundResource(R.drawable.round_fill_pink_invite);
    Glide.with(context)
        .load("http://graph.facebook.com/"
            + fbFriendsLists.get(position).getId()
            + "/picture?type=large")
        .into(holder.imgAvatar);
  }

  @Override public int getItemCount() {
    return fbFriendsLists.size();
  }

  static class MyViewHolder extends RecyclerView.ViewHolder {
    @BindView(R.id.imgAvatar) ImageView imgAvatar;
    @BindView(R.id.tvUserName) TextView tvUserName;
    @BindView(R.id.tvUserAddress) TextView tvUserAddress;
    @BindView(R.id.tvInvite) TextView tvInvite;

    MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
    }
  }
}
