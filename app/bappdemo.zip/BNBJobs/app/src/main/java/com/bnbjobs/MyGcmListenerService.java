/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.activity.SplashActivity;
import com.bnbjobs.main.AppClass;
import com.bnbjobs.utils.Constants;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import org.json.JSONException;
import org.json.JSONObject;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.utils.LogUtils.LOGI;

/**
 * @author Harsh
 * @version 1.0
 */
public class MyGcmListenerService extends FirebaseMessagingService {

  private static final String TAG = "MyGcmListenerService";
  private int OFFERID = 1;
  private int GROUPID = 2;

  /**
   * Called when message is received.
   *
   * @param from SenderID of the sender.
   * @param data Data bundle containing message data as key/value pairs.
   * For Set of keys use data.keySet().
   */
  // [START receive_message]
  public void onMessageasd(String from, Bundle data) {
    //String message = data.getString("message");
  }

  @Override public void onMessageReceived(RemoteMessage remoteMessage) {
    super.onMessageReceived(remoteMessage);
    LOGI(TAG, "Message: " + remoteMessage.getData());
    if (remoteMessage.getData() != null && remoteMessage.getData().containsKey("android")) {
      String response = remoteMessage.getData().get("android");
      try {
        JSONObject object = new JSONObject(response);
        if (!isEmpty(object.optString("title"))) {
          String id = "";
          int type = 0;
          if (!isEmpty(object.optString("rp_id"))) {
            id = object.getString("rp_id");
            type = OFFERID;
          } else if (!isEmpty(object.optString("group_id"))) {
            id = object.getString("group_id");
            type = GROUPID;
          }
          sendNotification(object.optString("title"), type, id);
        }
      } catch (JSONException e) {
        e.printStackTrace();
      }
    }
  }

  /**
   * Create and show a simple notification containing the received GCM message.
   *
   * @param title GCM message received.
   * @param TYPE type
   */
  private void sendNotification(String title, int TYPE,String id) {
    Intent intent;
    if (((AppClass) getApplication()).isAppRunning()) {
      intent = new Intent(this, HomeActivity.class);
      intent.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    } else {
      intent = new Intent(this, SplashActivity.class);
    }
    if (TYPE == OFFERID) {
      intent.putExtra(Constants.KEY_ID, id);
    }else if (TYPE == GROUPID) {
      intent.putExtra(Constants.KEY_GROUP_ID, Integer.parseInt(id));
    }
    PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
    Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
    NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
        .setSmallIcon(R.drawable.ic_notification)
        .setContentTitle(getString(R.string.app_name))
        .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.mipmap.ic_launcher))
            .setContentText(title)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setContentIntent(pendingIntent);
    NotificationManager notificationManager =
        (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    notificationManager.notify((int) System.currentTimeMillis(), notificationBuilder.build());
  }
}