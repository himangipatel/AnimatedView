/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.adapter.BaseRecyclerAdapter;
import com.bnbjobs.customui.views.CircleImageView;
import com.bnbjobs.model.DeleteEvent;
import com.bnbjobs.model.GroupModel;
import com.bnbjobs.model.UserModel;
import com.bnbjobs.presenter.GroupDetailPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.OverlapDecoration;
import com.bnbjobs.utils.Prefs;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.GroupDetailView;
import com.bumptech.glide.Glide;
import java.util.List;

import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */
public class GroupDetailFragment extends BaseFragment implements GroupDetailView {

  @BindView(R.id.ivBannerImage) ImageView ivBannerImage;
  @BindView(R.id.ivUserImage) CircleImageView ivUserImage;
  @BindView(R.id.tvUserName) TextView tvUserName;
  @BindView(R.id.tvPlaceName) TextView tvPlaceName;
  @BindView(R.id.recyclerView) RecyclerView recyclerView;
  @BindView(R.id.tvStartDate) TextView tvStartDate;
  @BindView(R.id.tvEndDate) TextView tvEndDate;
  @BindView(R.id.tvPlace) TextView tvPlace;
  @BindView(R.id.tvDescription) TextView tvDescription;
  @BindView(R.id.tvJoinGroup) TextView tvJoinGroup;
  @BindView(R.id.tvNumberCount) TextView tvNumberCount;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;

  private static final String TAG = GroupDetailFragment.class.getSimpleName();
  private GroupDetailPresenter presenter;
  private boolean isUser;
  private int gId;
  private boolean isJoin;

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_group_detail, container, false);
    ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    if (presenter == null) {
      presenter = new GroupDetailPresenter();
      presenter.setFragment(this);
      presenter.attachView(this);
    }
    presenter.getGroupDetail(String.valueOf(getArguments().getInt(Constants.KEY_ID)));
    LinearLayoutManager linearLayoutManager =new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
    recyclerView.setLayoutManager(linearLayoutManager);
    recyclerView.addItemDecoration(new OverlapDecoration());
  }

  private void setData(GroupModel model) {
    isUser =String.valueOf(model.getuId()).equalsIgnoreCase(Prefs.with(getActivity()).getString(QuickstartPreferences.USER_ID,""));
    isJoin = model.getMemberFlag();
    if(isUser){
      tvJoinGroup.setText(R.string.delete_group);
    }else if(isJoin){
      tvJoinGroup.setText(R.string.remove_group);
    }else{
      tvJoinGroup.setText(R.string.join_this_group);
    }
    gId = model.getgId();
    Glide.with(this).load(model.getGroupImageUrl()).into(ivBannerImage);
    Glide.with(this).load(model.getuThumbImageUrl()).into(ivUserImage);
    tvUserName.setText(String.format("%s %s", model.getuFname(), model.getuLname()));
    tvPlaceName.setText(model.getLocation());
    tvNumberCount.setText(model.getTotalMember() + "/" + model.getMaxMember());
    tvStartDate.setText(Utils.getDate(Long.parseLong(model.getStartTime())));
    tvEndDate.setText(Utils.getDate(Long.parseLong(model.getEndTime())));
    tvPlace.setText(model.getLocation());
    tvDescription.setText(model.getgDescription());
    GroupInviteAdapter adapter = new GroupInviteAdapter(getContext(),model.getUserModels());
    recyclerView.setAdapter(adapter);
    showToolbar(true);
    setTitle(model.getTitle());
  }



  @Override public void onBack(View view) {
    super.onBack(view);
    getFragmentManager().popBackStack();
  }

  @OnClick(R.id.tvJoinGroup) void onJoin(){
    if(isUser){
      presenter.deleteGroup(String.valueOf(gId));
    }else{
      presenter.joinGroup(String.valueOf(gId),!isJoin);
    }
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void onSuccess(GroupModel groupModel) {
    setData(groupModel);
  }

  @Override public void onError(String message) {
    showMessage(getActivity(), message);
  }

  @Override public void onDeleteSuccess() {
    GroupListFragment fragment = (GroupListFragment) getTargetFragment();
    if(fragment!=null){
      fragment.onEvent(new DeleteEvent(gId));
    }
    getFragmentManager().popBackStack();
  }

  @Override public void onJoinSuccess(boolean b) {
      isJoin  = b;
    GroupListFragment fragment = (GroupListFragment) getTargetFragment();
    if(fragment!=null){
      fragment.onJoinEvent(isJoin,gId);
    }
    if(isJoin){
      tvJoinGroup.setText(R.string.remove_group);
    }else{
      tvJoinGroup.setText(R.string.join_this_group);
    }
  }

  static class GroupInviteAdapter extends BaseRecyclerAdapter<GroupInviteAdapter.MyViewHolder> {

    private List<UserModel> mUserModel;
    private Context context;

    GroupInviteAdapter(Context context,List<UserModel> mUserModel) {
      this.context = context;
      this.mUserModel = mUserModel;
    }

    @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
      View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_group_invite, parent, false);
      return new MyViewHolder(view);
    }

    @Override public void onBindViewHolder(MyViewHolder holder, int position) {
        Glide.with(context).load(mUserModel.get(position).getImageUrl()).into(holder.ivUserImage);
    }

    @Override public int getItemCount() {
      return mUserModel.size();
    }

    class MyViewHolder extends BaseRecyclerAdapter.ViewHolder {
      @BindView(R.id.ivUserImage) CircleImageView ivUserImage;
      public MyViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
      }
    }
  }
}
