/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import android.support.v7.widget.RecyclerView;
import com.bnbjobs.model.UserModel;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public interface InviteGroupView extends MainView {

  String getSearchString();

  String getRadius();

  String getActiveFlag();

  void onSuccess(List<UserModel> userModels,boolean clear);
  void onError(String msg);

  RecyclerView getRecyclerView();
}
