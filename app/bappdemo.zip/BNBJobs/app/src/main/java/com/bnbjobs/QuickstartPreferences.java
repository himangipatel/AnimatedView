/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs;

/**
 * @author Harsh
 * @version 1.0
 */
public class QuickstartPreferences {

  public static final String SENT_TOKEN_TO_SERVER = "sentTokenToServer";
  public static final String REGISTRATION_COMPLETE = "registrationComplete";
  public static final String REGISTRATION_TOKEN = "registrationToken";
  public static final String LANGUAGE = "language";
  public static final String IS_LOGIN = "is_login";

  public static final String LAT = "lat";
  public static final String LNG = "lng";
  public static final String USER_TYPE = "user_type";
  public static final String ACCESS_TOKEN = "access_token";
  public static final String USER_ID = "user_id";
  public static final String IS_NORMAL_USER = "is_normal_user";
  public static final String PLACE_NAME = "place_name";
  public static final String SHOW_DESIGNATION = "designation_set";
  public static final String CREATED_AT = "created_at";
  public static final String USER_FNAME = "user_fname";
  public static final String USER_LNAME = "user_lname";
  public static final String USER_PHONENUMBER = "user_phone_num";
  public static final String USER_PHONE_VERIFIED = "user_phone_verified_status";
  public static final String USER_PHONE_TOKEN = "user_phone_token";
  public static final String KEY_ALL_SAVE = "key_all_save";
  public static final String IS_CITY_STORE = "is_city_store";
  public static final String COUNTRY_CODE = "key_country_code";
  public static final String KEY_SEARCH_ADDRESS = "key_search_address";
  public static final String KEY_SEARCH_ADDRESS_LAT = "key_search_address_lat";
  public static final String KEY_SEARCH_ADDRESS_LNG = "key_search_address_lng";
}


