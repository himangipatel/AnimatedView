/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.os.Bundle;
import android.widget.EditText;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.GradientView;
import com.bnbjobs.customui.views.TinTableImageView;

/**
 * @author Harsh
 * @version 1.0
 */
public class SearchActivity extends BaseActivity {

  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.etJobSearch) EditText etJobSearch;
  @BindView(R.id.etJobSearchLocation) EditText etJobSearchLocation;
  @BindView(R.id.tvSearch) GradientView tvSearch;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_search_new);
    ButterKnife.bind(this);
  }

  @OnClick(R.id.tvSearch) void onSearch() {

  }

  @OnClick(R.id.imageBack) void onBack() {
    onBackPressed();
  }
}
