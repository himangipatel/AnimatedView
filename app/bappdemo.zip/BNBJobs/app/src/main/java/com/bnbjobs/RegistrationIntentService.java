/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;
import com.bnbjobs.utils.Prefs;
import com.google.firebase.iid.FirebaseInstanceId;

import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */

public class RegistrationIntentService extends IntentService {

  private static final String TAG = makeLogTag(RegistrationIntentService.class);

  public RegistrationIntentService() {
    super("RegistrationIntentService");
  }

  @Override protected void onHandleIntent(Intent intent) {
    try {

      //InstanceID instanceID = InstanceID.getInstance(this);
      //testinga599
      /**
       *Api Key
       *AIzaSyDzv0SsgZ43uYvM-4U7R2oGCLaUjmUCxCs
       *Sender ID
       *946246511340
       */
      //String token = instanceID.getToken(getString(R.string.gcm_defaultSenderId), GoogleCloudMessaging.INSTANCE_ID_SCOPE, null);
      String token = FirebaseInstanceId.getInstance().getToken();
      LOGI(TAG, "GCM Registration Token: " + token);

      Prefs.with(this).save(QuickstartPreferences.REGISTRATION_TOKEN, token);
      Prefs.with(this).save(QuickstartPreferences.SENT_TOKEN_TO_SERVER, true);
    } catch (Exception e) {
      LOGI(TAG, "Failed to complete token refresh " + Log.getStackTraceString(e));
      Prefs.with(this).save(QuickstartPreferences.SENT_TOKEN_TO_SERVER, false);
    }
    // Notify UI that registration has completed, so the progress indicator can be hidden.
        /*Intent registrationComplete = new Intent(QuickstartPreferences.REGISTRATION_COMPLETE);
        LocalBroadcastManager.getInstance(this).sendBroadcast(registrationComplete);*/
  }
}