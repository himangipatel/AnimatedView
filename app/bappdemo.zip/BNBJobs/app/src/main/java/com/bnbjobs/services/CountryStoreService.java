/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.services;

import android.app.IntentService;
import android.content.Intent;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.model.CountryModel;
import com.bnbjobs.utils.Utils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import io.realm.Realm;
import java.util.List;

import static com.bnbjobs.main.AppClass.getPrefs;

/**
 * @author Harsh
 * @version 1.0
 */
public class CountryStoreService extends IntentService {

  /**
   * Creates an IntentService.  Invoked by your subclass's constructor.
   */
  public CountryStoreService() {
    super(CountryStoreService.class.getSimpleName());
  }

  @Override protected void onHandleIntent(Intent intent) {
    storeCountry();
  }

  private void storeCountry() {
    if (!getPrefs(this).getBoolean(QuickstartPreferences.IS_CITY_STORE, false)) {
      String response = Utils.loadJSONFromAsset(this);
      Realm realm = Realm.getDefaultInstance();
      List<CountryModel> mList = new Gson().fromJson(response, new TypeToken<List<CountryModel>>() {
      }.getType());
      realm.beginTransaction();
      realm.copyToRealmOrUpdate(mList);
      realm.commitTransaction();
      getPrefs(this).save(QuickstartPreferences.IS_CITY_STORE, true);
      realm.close();
    }
  }
}
