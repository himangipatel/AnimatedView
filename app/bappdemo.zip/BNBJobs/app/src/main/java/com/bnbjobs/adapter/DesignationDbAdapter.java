/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.DesignationDbModel;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class DesignationDbAdapter extends RecyclerView.Adapter<DesignationDbAdapter.MyViewHolder> {

  private List<DesignationDbModel> mDesignationDbModels;
  private ClickImpl mClick;

  public DesignationDbAdapter(Context context, List<DesignationDbModel> designationDbModels,
      ClickImpl mClick) {
    mDesignationDbModels = designationDbModels;
    this.mClick = mClick;
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.inflater_designation, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {
    holder.bindData(mDesignationDbModels.get(position));
  }

  @Override public int getItemCount() {
    return mDesignationDbModels.size();
  }

  class MyViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.tvSuggestion) TextView mTvSuggestion;

    MyViewHolder(View view) {
      super(view);
      ButterKnife.bind(this, view);
    }

    void bindData(DesignationDbModel model) {
      mTvSuggestion.setText(model.getTitle());
    }

    @OnClick(R.id.tvSuggestion) void onItemClick(View view) {
      mClick.onClick(view, mDesignationDbModels.get(getLayoutPosition()), getLayoutPosition());
    }
  }
}
