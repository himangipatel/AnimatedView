/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

/**
 * @author Harsh
 * @version 1.0
 */
public class PhoneNumberEvent {
  private boolean closeCurrentActivity;

  public PhoneNumberEvent(boolean closeCurrentActivity) {
    this.closeCurrentActivity = closeCurrentActivity;
  }

  public boolean isCloseCurrentActivity() {
    return closeCurrentActivity;
  }

  public void setCloseCurrentActivity(boolean closeCurrentActivity) {
    this.closeCurrentActivity = closeCurrentActivity;
  }
}
