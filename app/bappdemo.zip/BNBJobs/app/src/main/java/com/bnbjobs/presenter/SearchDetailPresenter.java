/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.app.Fragment;
import com.bnbjobs.R;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.JobContainer;
import com.bnbjobs.model.JobModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.GetReverseGeoCoding;
import com.bnbjobs.view.SearchDetailView;
import com.google.android.gms.maps.model.LatLng;
import com.google.gson.Gson;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static com.bnbjobs.utils.Constants.FOR_ALL_CONTRACT;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class SearchDetailPresenter extends BasePresenter implements Presenter<SearchDetailView> {

  private final static int REGULAR_TYPE = 1;
  private final static int PULL_TYPE = 2;
  private SearchDetailView mSearchDetailView;
  private Fragment fragment;
  private int page;
  private int perPage = 10;
  private boolean loadMore;
  private Subscription subscription;
  private int requestType;
  private boolean showProgress;
  private boolean isFromCountry;
  private String countryName;

  @Override public void attachView(SearchDetailView view) {
    mSearchDetailView = view;
  }

  @Override public void detachView() {
    mSearchDetailView = null;
  }

  public void getSearchResults(int regularType) {
    if (showProgress) mSearchDetailView.showProgress();
    this.requestType = regularType;
    HashMap<String, String> params = new HashMap<>(14);
    if (isFromCountry) {
      params.put("apiName", "getAllJobOffersForCountries");
      params.put("countryName", countryName);
    } else {
      params.put("apiName", "getAllJobOffers");
      LatLng latLng = mSearchDetailView.getLatLng();
      params.put("latitude", String.valueOf(latLng.latitude));
      params.put("longitude", String.valueOf(latLng.longitude));
      params.put("title", mSearchDetailView.getDesignation());
    }
    params.put("contractType", FOR_ALL_CONTRACT);
    if (loadMore) params.put("page", String.valueOf(page));
    params.put("perPage", String.valueOf(perPage));

    params.putAll(addParams(params));
    mSearchDetailView.loadMore(false);
    if (subscription != null && !subscription.isUnsubscribed()) subscription.unsubscribe();
    subscription =
        RestClient.getInstance(params).compose(getBindEvent()).subscribe(getSubscriber());
  }

  private Subscriber<String> getSubscriber() {
    if (requestType == REGULAR_TYPE) {
      return regularRequest();
    } else {
      return pullToSubscribe();
    }
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).<String>bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  private Subscriber<String> regularRequest() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mSearchDetailView.hideProgress();
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        mSearchDetailView.hideProgress();
        showProgress = false;
        JobContainer container = new Gson().fromJson(s, JobContainer.class);
        setData(container);
      }
    };
  }

  public void resetRequest(int requestType) {
    this.requestType = requestType;
    page = 1;
    loadMore = false;
    showProgress = false;
    getSearchResults(requestType);
  }

  public void getAddress(LatLng location){
    mSearchDetailView.showProgress();
    Observable.just(location)
        .map(new Func1<LatLng, String>() {
      @Override public String call(LatLng latLng) {
        GetReverseGeoCoding getReverseGeoCoding = new GetReverseGeoCoding();
        getReverseGeoCoding.getAddress(latLng);
        return getReverseGeoCoding.getCountry();
      }
    }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mSearchDetailView.hideProgress();
        mSearchDetailView.onErrorCountry();
      }

      @Override public void onNext(String s) {
        mSearchDetailView.hideProgress();
        mSearchDetailView.setCountry(s);
      }
    });
  }
  private Subscriber<String> pullToSubscribe() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mSearchDetailView.hideProgress();
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        mSearchDetailView.hideProgress();
        JobContainer container = new Gson().fromJson(s, JobContainer.class);
        setData(container);
      }
    };
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(final Throwable e) {
    String error = "";
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            getSearchResults(REGULAR_TYPE);
          }
        }).show();
  }

  private void setData(JobContainer container) {
    if (container.isSuccess()) {
      page = container.getCurrentPage() + 1;
      loadMore = container.getTotalPage() != container.getCurrentPage();
      mSearchDetailView.loadMore(loadMore);
      mSearchDetailView.setAdapter(container.getmJobModel());
    } else {
      loadMore = false;
      mSearchDetailView.loadMore(false);
      mSearchDetailView.setAdapter(new ArrayList<JobModel>());
    }
  }

  public void setPage(int page) {
    this.page = page;
  }

  @Override protected Context getBaseContext() {
    return mSearchDetailView.getContext();
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }

  public void setIsFromCountry(boolean isFromCountry, String countryName) {
    this.isFromCountry = isFromCountry;
    this.countryName = countryName;
  }
}


