/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

/**
 * Created by jay shah on 5/7/16.
 */
public class ChooseOfferItem {

  private String offerType;
  private String offerDescription;
  private String price;
  private String discount;
  private String color;
  private String discountLabel;

  public ChooseOfferItem() {
  }

  public String getOfferType() {
    return offerType;
  }

  public void setOfferType(String offerType) {
    this.offerType = offerType;
  }

  public String getOfferDescription() {
    return offerDescription;
  }

  public void setOfferDescription(String offerDescription) {
    this.offerDescription = offerDescription;
  }

  public String getPrice() {
    return price;
  }

  public void setPrice(String price) {
    this.price = price;
  }

  public String getDiscount() {
    return discount;
  }

  public void setDiscount(String discount) {
    this.discount = discount;
  }

  public String getColor() {
    return color;
  }

  public void setColor(String color) {
    this.color = color;
  }

  public String getDiscountLabel() {
    return discountLabel;
  }

  public void setDiscountLabel(String discountLabel) {
    this.discountLabel = discountLabel;
  }
}



