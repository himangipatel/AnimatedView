/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.customui.looppager.RecyclerViewPager;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.main.AppClass;
import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.CountryListModel;
import com.bnbjobs.model.GroupModel;
import com.bnbjobs.model.JobModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.EndlessRecyclerViewScrollListener;
import com.bnbjobs.view.HomeNewFragmentView;
import com.google.android.gms.location.places.Place;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.jakewharton.rxbinding.widget.RxTextView;
import com.jakewharton.rxbinding.widget.TextViewTextChangeEvent;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.lang.reflect.Type;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;

import static com.bnbjobs.utils.Constants.FOR_ALL_CONTRACT;
import static com.bnbjobs.utils.Constants.PER_PAGE;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;

public class HomeNewFragmentPresenter extends BasePresenter
    implements Presenter<HomeNewFragmentView> {

  private final int LOAD_MORE_START_INDEX = 3;
  private HomeNewFragmentView mHomeFragmentView;
  private Fragment fragment;
  private int jobListCurrentPage = -1, jobListTotalPages = -1;
  private int jobKmListCurrentPage = -1, jobKmListTotalPages = -1;
  private int groupCurrentPage = -1, groupTotalPages = -1;
  private int myCityCurrentPage = -1, myCityTotalPages = -1;
  private int todayDealCurrentPage = -1,todayListTotalPages = -1;
  private boolean jobListLoading, cityListLoading, recentSearchLoading, jobKmListLoading, todayDealJobList, groupLoadingList;

  private String designationTitle;
  private float scaleFactor = 0.95f;

  private boolean isDataLoaded;
  private RecyclerView cityRecyclerView;
  private RecyclerView kmRecyclerView;
  private RecyclerView mGroupRecycler;

  private EndlessRecyclerViewScrollListener mEndlessRecyclerViewScrollListener;
  private EndlessRecyclerViewScrollListener mKmEndlessRecyclerViewScrollListener;
  private EndlessRecyclerViewScrollListener mGroupEndlessRecyclerViewScrollListener;

  @Override protected Context getBaseContext() {
    return mHomeFragmentView.getContext();
  }

  @Override public void attachView(HomeNewFragmentView view) {
    mHomeFragmentView = view;
    RecyclerViewPager searchRecyclerView = view.getRvRecentJobs();
    RecyclerViewPager jobRecyclerView = view.getRvSelectionJobs();
    cityRecyclerView = view.getRvCities();
    kmRecyclerView = view.getKmJob();
    mGroupRecycler = view.getGroupRecycle();
    setRecyclerViewLayoutManagers(searchRecyclerView);
    setRecyclerViewLayoutManagers(jobRecyclerView);
    setRecyclerViewLayoutManagers(view.getTodayDeal());
    cityRecyclerView.setLayoutManager(new LinearLayoutManager(mHomeFragmentView.getContext(), LinearLayoutManager.HORIZONTAL,false));
    kmRecyclerView.setLayoutManager(new LinearLayoutManager(mHomeFragmentView.getContext(), LinearLayoutManager.HORIZONTAL,false));
    mGroupRecycler.setLayoutManager(new LinearLayoutManager(mHomeFragmentView.getContext(), LinearLayoutManager.HORIZONTAL,false));
    setEndlessListener();
    setKmEndlessListener();
    setGroupEndlessListener();
    cityRecyclerView.addOnScrollListener(mEndlessRecyclerViewScrollListener);
    kmRecyclerView.addOnScrollListener(mKmEndlessRecyclerViewScrollListener);
    mGroupRecycler.addOnScrollListener(mGroupEndlessRecyclerViewScrollListener);

    mHomeFragmentView.onLocationSet(AppClass.getPrefs(getBaseContext()).getString(QuickstartPreferences.PLACE_NAME, ""));
    if (hasNetworkConnectivity() && !isDataLoaded) {
      getAllDataApi(true);
    }
  }

  private void setEndlessListener(){
    mEndlessRecyclerViewScrollListener = new EndlessRecyclerViewScrollListener((LinearLayoutManager) cityRecyclerView.getLayoutManager()) {
      @Override public void onLoadMore(int page, int totalItemsCount) {
        HomeNewFragmentPresenter.this.onLoadMore(cityRecyclerView);
      }
    }.setVisibleThreshold(LOAD_MORE_START_INDEX);
  }


  private void setKmEndlessListener(){
    mKmEndlessRecyclerViewScrollListener = new EndlessRecyclerViewScrollListener((LinearLayoutManager) kmRecyclerView.getLayoutManager()) {
      @Override public void onLoadMore(int page, int totalItemsCount) {
        HomeNewFragmentPresenter.this.onLoadMore(kmRecyclerView);
      }
    }.setVisibleThreshold(LOAD_MORE_START_INDEX);
  }

  private void setGroupEndlessListener(){
    mGroupEndlessRecyclerViewScrollListener = new EndlessRecyclerViewScrollListener((LinearLayoutManager) mGroupRecycler.getLayoutManager()) {
      @Override public void onLoadMore(int page, int totalItemsCount) {
        HomeNewFragmentPresenter.this.onLoadMore(mGroupRecycler);
      }
    }.setVisibleThreshold(LOAD_MORE_START_INDEX);
  }

  private void getAllDataApi(boolean showProgress) {
    if (showProgress) {
      showProgress(true);
    }
    isDataLoaded = true;
    getRecentSearchJobList(1);
    getJobOfferList(1, designationTitle);
    getCityList(1);
    getKmList(1);
    getTodayDealList(1);
    getGroupList(1);
  }



  @Override public void detachView() {
    mHomeFragmentView = null;
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }

  private void getRecentSearchJobList(int page) {
    if (hasNetworkConnectivity()) {
      recentSearchLoading = true;
      HashMap<String, String> params = new HashMap<>(8);
      params.put("apiName", "candidateDashboard");
      params.put("perPage", String.valueOf(PER_PAGE));
      params.putAll(addDefaultParamsWitLat(params));
      if (page > 0) {
        params.put("page", String.valueOf(page));
      }
      RestClient.getInstance(params).
          compose(getBindEvent()).subscribe(recentSearchRequest());
    }
  }



  private void getJobOfferList(int page, String designationTitle) {
    if (hasNetworkConnectivity()) {
      jobListLoading = true;
      HashMap<String, String> params = new HashMap<>(10);
      params.put("apiName", "getAllJobOffers");
      params.put("perPage", String.valueOf(PER_PAGE));
      params.put("contractType", FOR_ALL_CONTRACT);
      if (!TextUtils.isEmpty(designationTitle)) {
        params.put("title", designationTitle);
      }
      params.putAll(addDefaultParamsWitLat(params));
      params.put("page", String.valueOf(page));
      RestClient.getInstance(params).compose(getBindEvent()).subscribe(getAllJobOfferSubscriber());
    }
  }

  private void getTodayDealList(int page) {
    if (hasNetworkConnectivity()) {
      todayDealJobList = true;
      HashMap<String, String> params = new HashMap<>(10);
      params.put("apiName", "getAllJobOffers");
      params.put("perPage", String.valueOf(PER_PAGE));
      params.put("contractType", FOR_ALL_CONTRACT);
      params.put("today_deal","1");
      params.putAll(addDefaultParamsWitLat(params));
      params.put("page", String.valueOf(page));
      RestClient.getInstance(params).compose(getBindEvent()).subscribe(getAllTodayDeal());
    }
  }

  private void getGroupList(final int page) {
    if (hasNetworkConnectivity()) {
      groupLoadingList = true;
      HashMap<String, String> params = new HashMap<>(10);
      params.put("apiName", "list_all_group");
      params.put("my_groups", "1");
      params.putAll(addDefaultParamsWitLat(params));
      params.put("page", String.valueOf(page));
      params.put("perPage", String.valueOf(PER_PAGE));
      RestClient.getInstance(params).compose(getBindEvent()).subscribe(getAllGroupSubscriber());
    }
  }

  private Subscriber<String> getAllGroupSubscriber() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {
        groupLoadingList = false;
      }

      @Override public void onError(Throwable e) {
        groupLoadingList = false;
        LOGE(TAG, e.getMessage(), e);
        hideProgress();
      }

      @Override public void onNext(String s) {
        LOGI(TAG,"APi getGroup ");
        groupLoadingList = false;
        hideProgress();
        GsonBuilder builder = new GsonBuilder();
        Type collectionType = new TypeToken<BaseContainer<GroupModel>>() {}.getType();
        BaseContainer<GroupModel> jobSearchBaseContainer =  builder.create().fromJson(s, collectionType);
        groupCurrentPage = jobSearchBaseContainer.getCurrentPage();
        groupTotalPages = jobSearchBaseContainer.getTotalPages();
        mHomeFragmentView.onGroupSuccess(jobSearchBaseContainer.getDataList(),jobSearchBaseContainer.getCurrentPage()==1);
      }
    };
  }

  private void getKmList(int page) {
    if (hasNetworkConnectivity()) {
      jobKmListLoading = true;
      HashMap<String, String> params = new HashMap<>(8);
      params.put("apiName", "get1KmJobOffers");
      params.put("perPage", String.valueOf(PER_PAGE));
      params.put("contractType", FOR_ALL_CONTRACT);
      params.putAll(addDefaultParamsWitLat(params));
      if (page > 0) {
        params.put("page", String.valueOf(page));
      }
      RestClient.getInstance(params)
          .compose(getBindEvent())
          .subscribe(getKmJobOfferSubscriber());
    }
  }

  private void getCityList(int page) {
    if (hasNetworkConnectivity()) {
      cityListLoading = true;
      HashMap<String, String> params = new HashMap<>(8);
      params.put("apiName", "getCountries");
      params.put("perPage", String.valueOf(PER_PAGE));
      params.putAll(addDefaultParamsWitLat(params));
      params.put("page", String.valueOf(page));
      RestClient.getInstance(params).compose(getBindEvent()).subscribe(cityListSubscriber());
    }
  }

  public void updateUserLocation(Place place) {
    mHomeFragmentView.onLocationSet(place.getName().toString());
    HashMap<String, String> params = new HashMap<>(6);
    params.put("apiName", "updateUserLocation");
    params.putAll(addDefaultParamsWitLat(params));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
      }

      @Override public void onNext(String s) {
        if (isResponseSuccess(s)) {
          mHomeFragmentView.clearData();
          getJobOfferList(1, designationTitle);
        }
      }
    });
  }

  public void onSearch(final EditText editText) {
    RxTextView.textChangeEvents(editText)
        .debounce(400, TimeUnit.MILLISECONDS)
        .observeOn(AndroidSchedulers.mainThread())
        .compose(((BaseFragment) fragment).<TextViewTextChangeEvent>bindUntilEvent(
            FragmentEvent.DESTROY_VIEW))
        .subscribe(new Subscriber<TextViewTextChangeEvent>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
          }

          @Override public void onNext(TextViewTextChangeEvent textViewTextChangeEvent) {
            designationTitle = String.valueOf(textViewTextChangeEvent.text());
            if (!editText.hasFocus()) {
              return;
            }
            mHomeFragmentView.showSearchProgress();
            getJobOfferList(1, designationTitle);
          }
        });
  }

  private Subscriber<String> recentSearchRequest() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {
        recentSearchLoading = false;
        hideProgress();
      }

      @Override public void onError(Throwable e) {
        recentSearchLoading = false;
        LOGE(TAG, e.getMessage(), e);
        hideProgress();
                /*retryMethod(e);*/
      }

      @Override public void onNext(String s) {
        LOGI(TAG,"APi Recent Search");
        recentSearchLoading = false;
        GsonBuilder builder = new GsonBuilder();
        Type collectionType = new TypeToken<BaseContainer<JobModel>>() {
        }.getType();
        BaseContainer<JobModel> jobSearchBaseContainer =
            builder.create().fromJson(s, collectionType);
        mHomeFragmentView.setRecentJobAdapter(jobSearchBaseContainer);
      }
    };
  }

  private void hideProgress() {
    if (mEndlessRecyclerViewScrollListener != null) {
      mEndlessRecyclerViewScrollListener.setLoading(false);
    }
    if (mKmEndlessRecyclerViewScrollListener != null) {
      mKmEndlessRecyclerViewScrollListener.setLoading(false);
    }

    if (mGroupEndlessRecyclerViewScrollListener != null) {
      mGroupEndlessRecyclerViewScrollListener.setLoading(false);
    }
    if (needToProgressHide()) {
      showProgress(false);
    }
  }

  private Subscriber<String> getAllJobOfferSubscriber() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {
        jobListLoading = false;
        hideProgress();
      }

      @Override public void onError(Throwable e) {
        jobListLoading = false;
        LOGE(TAG, e.getMessage(), e);
                /*retryMethod(e);*/
        hideProgress();
      }

      @Override public void onNext(String s) {
        LOGI(TAG,"APi getAllJobOfferSubscriber");
        jobListLoading = false;
        GsonBuilder builder = new GsonBuilder();
        Type collectionType = new TypeToken<BaseContainer<JobModel>>() {
        }.getType();
        BaseContainer<JobModel> jobSearchBaseContainer =
            builder.create().fromJson(s, collectionType);
        jobListCurrentPage = jobSearchBaseContainer.getCurrentPage();
        jobListTotalPages = jobSearchBaseContainer.getTotalPages();
        mHomeFragmentView.setSelectionJobAdapter(jobSearchBaseContainer);
      }
    };
  }

  private Subscriber<String> getAllTodayDeal() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {
        todayDealJobList= false;
        hideProgress();
      }

      @Override public void onError(Throwable e) {
        todayDealJobList= false;
        LOGE(TAG, e.getMessage(), e);
        hideProgress();
      }

      @Override public void onNext(String s) {
        LOGI(TAG,"APi getTODAY DEAL");
        todayDealJobList= false;
        GsonBuilder builder = new GsonBuilder();
        Type collectionType = new TypeToken<BaseContainer<JobModel>>() {
        }.getType();
        BaseContainer<JobModel> jobSearchBaseContainer =
            builder.create().fromJson(s, collectionType);
        todayDealCurrentPage = jobSearchBaseContainer.getCurrentPage();
        todayListTotalPages = jobSearchBaseContainer.getTotalPages();
        mHomeFragmentView.setTodayDealList(jobSearchBaseContainer);
      }
    };
  }

  private Subscriber<String> getKmJobOfferSubscriber() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {
        jobKmListLoading = false;
        hideProgress();
      }

      @Override public void onError(Throwable e) {
        jobKmListLoading = false;
        LOGE(TAG, e.getMessage(), e);
        hideProgress();
      }

      @Override public void onNext(String s) {
        LOGI(TAG,"APi getKMLIST");
        jobKmListLoading = false;
        GsonBuilder builder = new GsonBuilder();
        Type collectionType = new TypeToken<BaseContainer<JobModel>>() {
        }.getType();
        BaseContainer<JobModel> jobSearchBaseContainer =
            builder.create().fromJson(s, collectionType);
        jobKmListCurrentPage = jobSearchBaseContainer.getCurrentPage();
        jobKmListTotalPages = jobSearchBaseContainer.getTotalPages();
        mHomeFragmentView.setKmJobAdapter(jobSearchBaseContainer);
      }
    };
  }

  private Subscriber<String> cityListSubscriber() {
    return new Subscriber<String>() {

      @Override public void onCompleted() {
        cityListLoading = false;
        hideProgress();
      }

      @Override public void onError(Throwable e) {
        cityListLoading = false;
        LOGE(TAG, e.getMessage(), e);
                /*retryMethod(e);*/
        hideProgress();
      }

      @Override public void onNext(String s) {
        LOGI(TAG,"APi getCityList");
        cityListLoading = false;
        GsonBuilder builder = new GsonBuilder();
        Type collectionType = new TypeToken<BaseContainer<CountryListModel>>() {
        }.getType();
        BaseContainer<CountryListModel> cityBaseContainer =
            builder.create().fromJson(s, collectionType);
        myCityCurrentPage = cityBaseContainer.getCurrentPage();
        myCityTotalPages = cityBaseContainer.getTotalPages();
        mHomeFragmentView.setMyCityAdapter(cityBaseContainer);
      }
    };
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(final Throwable e) {
    String error = getBaseContext().getString(R.string.error_other);
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            getRecentSearchJobList(0);
          }
        }).show();
  }

  private void setRecyclerViewLayoutManagers(final RecyclerViewPager mRecyclerViewPager) {
    LinearLayoutManager layoutManager =
        new LinearLayoutManager(getBaseContext(), LinearLayoutManager.HORIZONTAL, false);
    mRecyclerViewPager.setTriggerOffset(0.01f);
    mRecyclerViewPager.setFlingFactor(0.01f);
    mRecyclerViewPager.setLayoutManager(layoutManager);
    mRecyclerViewPager.setHasFixedSize(true);
    mRecyclerViewPager.setLongClickable(true);
    mRecyclerViewPager.setSinglePageFling(true);
    mRecyclerViewPager.addOnPageChangedListener(new RecyclerViewPager.OnPageChangedListener() {
      @Override public void OnPageChanged(int oldPosition, int newPosition) {
        RecyclerView.Adapter mAdapter = mRecyclerViewPager.getAdapter();
        if (mAdapter != null && mAdapter.getItemCount() > LOAD_MORE_START_INDEX) {
          int totalItems = mAdapter.getItemCount();
          if (newPosition >= totalItems - LOAD_MORE_START_INDEX) {
            onLoadMore(mRecyclerViewPager);
          }
        }
      }
    });
    mRecyclerViewPager.addOnScrollListener(new RecyclerView.OnScrollListener() {
      @Override public void onScrollStateChanged(RecyclerView recyclerView, int scrollState) {
      }

      @Override public void onScrolled(RecyclerView recyclerView, int i, int i2) {
        int childCount = mRecyclerViewPager.getChildCount();
        int width = mRecyclerViewPager.getChildAt(0).getWidth();
        int padding = (mRecyclerViewPager.getWidth() - width) / 2;

        for (int j = 0; j < childCount; j++) {
          View v = recyclerView.getChildAt(j);
          float rate = 0;
          if (v.getLeft() <= padding) {
            if (v.getLeft() >= padding - v.getWidth()) {
              rate = (padding - v.getLeft()) * 1f / v.getWidth();
            } else {
              rate = 1;
            }
            v.setScaleX(1 - rate * (1 - scaleFactor));
          } else {
            if (v.getLeft() <= recyclerView.getWidth() - padding) {
              rate = (recyclerView.getWidth() - padding - v.getLeft()) * 1f / v.getWidth();
            }
            v.setScaleX(scaleFactor + rate * (1 - scaleFactor));
          }
        }
      }
    });
    // add on layout change listener
    mRecyclerViewPager.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
      @Override
      public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft,
          int oldTop, int oldRight, int oldBottom) {
        if (mRecyclerViewPager.getChildCount() < 3) {
          if (mRecyclerViewPager.getChildAt(1) != null) {
            if (mRecyclerViewPager.getCurrentPosition() == 0) {
              View v1 = mRecyclerViewPager.getChildAt(1);
              v1.setScaleX(scaleFactor);
            } else {
              View v1 = mRecyclerViewPager.getChildAt(0);
              v1.setScaleX(scaleFactor);
            }
          }
        } else {
          if (mRecyclerViewPager.getChildAt(0) != null) {
            View v0 = mRecyclerViewPager.getChildAt(0);
            v0.setScaleX(scaleFactor);
          }
          if (mRecyclerViewPager.getChildAt(2) != null) {
            View v2 = mRecyclerViewPager.getChildAt(2);
            v2.setScaleX(scaleFactor);
          }
        }
      }
    });
  }

  private void onLoadMore(RecyclerView mRecyclerViewPager) {
    switch (mRecyclerViewPager.getId()) {
      case R.id.jobRecyclerView:
        if (jobListCurrentPage < jobListTotalPages && !jobListLoading) {
          getJobOfferList(jobListCurrentPage + 1, designationTitle);
        }
        break;
      case R.id.todayRecyclerView:
        if (todayDealCurrentPage< todayListTotalPages&& !todayDealJobList) {
          getTodayDealList(todayDealCurrentPage + 1);
        }
        break;
      case R.id.cityRecyclerView:
        if (myCityCurrentPage < myCityTotalPages && !cityListLoading) {
          getCityList(myCityCurrentPage + 1);
        }
        break;
      case R.id.jobKmRecyclerView:
        if (jobKmListCurrentPage < jobKmListTotalPages && !jobKmListLoading) {
          getKmList(jobKmListCurrentPage + 1);
        }
        break;

      case R.id.rvGroupRecyclerView:
        if (groupCurrentPage < groupTotalPages && !groupLoadingList) {
          getGroupList(groupCurrentPage + 1);
        }
        break;
    }
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  private boolean needToProgressHide() {
    boolean hide  =!jobListLoading && !recentSearchLoading && !cityListLoading && !jobKmListLoading && !groupLoadingList && !todayDealJobList;
    LOGI(TAG,hide+" progress");
    return hide;
  }

  private void showProgress(boolean show) {
    if (show) {
      mHomeFragmentView.showProgress();
    } else {
      mHomeFragmentView.hideProgress();
      mHomeFragmentView.hideSearchProgress();
    }
  }

  public void onSwipeRefresh(SwipeRefreshLayout mSwipeRefreshLayout) {
    mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
      @Override public void onRefresh() {
        getAllDataApi(false);
      }
    });
  }


  public void deleteGroup(final String groupId) {
    mHomeFragmentView.showProgress();
    HashMap<String, String> params = new HashMap<>();
    params.put("apiName", "delete_group");
    params.put("group_id", groupId);
    params.putAll(addParams(params));

    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        mHomeFragmentView.hideProgress();
        LOGE(TAG, Log.getStackTraceString(e));
        String error;
        if (e instanceof SocketTimeoutException) {
          error = getBaseContext().getString(R.string.error_timeout);
        } else {
          error = getBaseContext().getString(R.string.error_other);
        }
        showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error, getBaseContext().getString(R.string.retry),
            new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                deleteGroup(groupId);
              }
            }).show();
      }

      @Override public void onNext(String s) {
        mHomeFragmentView.hideProgress();
        try {
          JSONObject object = new JSONObject(s);
          if (object.getBoolean("success")) {
            mHomeFragmentView.onDeleteSuccess(groupId);
          } else {
            mHomeFragmentView.onError(object.getString("message"));
          }
        } catch (JSONException e) {
          e.printStackTrace();
        }

      }
    });
  }
}
