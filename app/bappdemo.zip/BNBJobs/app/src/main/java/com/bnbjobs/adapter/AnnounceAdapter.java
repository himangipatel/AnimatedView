/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.JobOfferData;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class AnnounceAdapter extends RecyclerView.Adapter<AnnounceAdapter.MyViewHolder> {

  private Context mContext;
  private List<JobOfferData> mJobOfferDataList;
  private ClickImpl mClick;

  public AnnounceAdapter(Context context, List<JobOfferData> jobOfferDataList, Fragment fragment) {
    mContext = context;
    mJobOfferDataList = jobOfferDataList;
    mClick = (ClickImpl) fragment;
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view =
        LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_announces, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {
    holder.mTvTitleName.setText(mJobOfferDataList.get(position).getdTitle());
  }

  @Override public int getItemCount() {
    return mJobOfferDataList.size();
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.tvTitleName) TextView mTvTitleName;
    @BindView(R.id.imgDelete) ImageView mImgDelete;
    @BindView(R.id.imgEdit) ImageView mImgEdit;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
      itemView.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          mClick.onClick(v, mJobOfferDataList.get(getLayoutPosition()), getLayoutPosition());
        }
      });
    }

    @OnClick(R.id.imgDelete) void onDelete(View v) {
      mClick.onClick(v, mJobOfferDataList.get(getLayoutPosition()), getLayoutPosition());
    }
  }
}
