/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.bnbjobs.R;
import com.bnbjobs.chipview.Chip;
import com.bnbjobs.chipview.ChipView;
import com.bnbjobs.customui.views.CircularProgressBar;
import com.bnbjobs.customui.views.ExperienceView;
import com.bnbjobs.model.Experience;
import com.bnbjobs.model.Tag;
import com.bnbjobs.utils.ExperienceTypes;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class EditExperienceAdapter extends RecyclerView.Adapter<EditExperienceAdapter.MyViewHolder>
    implements ExperienceView.OnclickViewListener {

  private Context context;
  private ArrayList<Experience> editExperienceList;
  private DesignationSelection designationSelection;

  private int modifyingPos;
  private Experience modifyExperience;

  public EditExperienceAdapter(Context context, ArrayList<Experience> editExperienceList) {
    this.context = context;
    this.editExperienceList = editExperienceList;
  }

  public void setDesignationClickListener(DesignationSelection designationSelection) {
    this.designationSelection = designationSelection;
  }

  /*public void updateExpListData(ArrayList<Experience> editExperienceList) {
    this.editExperienceList = editExperienceList;
    notifyDataSetChanged();
  }*/

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View rowView;
    switch (viewType) {
      case ExperienceTypes.TYPE_EXP_COMMON_LISTING:
        rowView =
            LayoutInflater.from(context).inflate(R.layout.exp_listing_inflater, parent, false);
        break;
      case ExperienceTypes.TYPE_EXP_CHIP_VIEWS_LISTING:
        rowView =
            LayoutInflater.from(context).inflate(R.layout.exp_designations_inflater, parent, false);
        break;
      case ExperienceTypes.TYPE_EXP_EDIT_LISTING:
        rowView =
            LayoutInflater.from(context).inflate(R.layout.exp_edit_mode_inflater, parent, false);
        break;
      default:
        rowView =
            LayoutInflater.from(context).inflate(R.layout.exp_listing_inflater, parent, false);
        break;
    }
    return new MyViewHolder(rowView, viewType);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {
    Experience editExperience = editExperienceList.get(position);
    holder.setData(editExperience, position);
  }

  @Override public int getItemCount() {
    return editExperienceList.size();
  }

  @Override
  public void onClickView(int pos, String progressTitle, String progressSubTitle, int expMonth) {
    modifyExperience.setProgress_subtitle(progressSubTitle);
    modifyExperience.setProgress_title(progressTitle);
    modifyExperience.setProgressInMonths(String.valueOf(expMonth));

    editExperienceList.set(modifyingPos, modifyExperience);
  }

  public void setModifyingData(int position, Experience experience) {
    modifyingPos = position;
    modifyExperience = experience;
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {

    //components for general experience listing

    private CircularProgressBar expProgressBar;
    private TextView tvDesignationTitle;
    private TextView tvProgressTitle;
    private TextView tvProgressSubTitle;
    private ImageView ivEditExp;

    //components for designation listing in chipView

    private ChipView chipViewDesignations;
    private TextView mTvAddExp;

    //components for edit exp view

    private TextView tvRemove;
    private TextView tvKeep;
    private TextView tvExpTitle;
    private ImageView ivDeleteJob;
    private ExperienceView customProgressbar;

    public MyViewHolder(View itemView, int itemViewType) {
      super(itemView);
      init(itemView, itemViewType);
    }

    public void init(final View itemView, int viewType) {
      if (viewType == ExperienceTypes.TYPE_EXP_COMMON_LISTING) {
        expProgressBar = (CircularProgressBar) itemView.findViewById(R.id.expProgressBar);
        tvDesignationTitle = (TextView) itemView.findViewById(R.id.tvExpTitle);
        tvProgressTitle = (TextView) itemView.findViewById(R.id.tvProgressTitle);
        tvProgressSubTitle = (TextView) itemView.findViewById(R.id.tvProgressSubTitle);
        ivEditExp = (ImageView) itemView.findViewById(R.id.ivEditExp);
        expProgressBar.setGeneralStorekWidth();
        expProgressBar.setProgressColorPaint(
            ContextCompat.getColor(context, R.color.color_pink_progress));
        expProgressBar.setmBackgroundColorPaint(
            ContextCompat.getColor(context, R.color.color_grey_progress));
        expProgressBar.setMax(100);

        ivEditExp.setOnClickListener(new View.OnClickListener() {
          @Override public void onClick(View view) {
            if (designationSelection != null) {
              designationSelection.singleDesignationEdit(getLayoutPosition(),
                  editExperienceList.get(getLayoutPosition()));
            }
          }
        });
      } else if (viewType == ExperienceTypes.TYPE_EXP_EDIT_LISTING) {
        tvKeep = (TextView) itemView.findViewById(R.id.tvKeep);
        tvRemove = (TextView) itemView.findViewById(R.id.tvRemove);
        tvExpTitle = (TextView) itemView.findViewById(R.id.tvExpTitle);
        ivDeleteJob = (ImageView) itemView.findViewById(R.id.ivDeleteJob);
        customProgressbar = (ExperienceView) itemView.findViewById(R.id.customprogressbar);
        customProgressbar.setOnViewClickListener(EditExperienceAdapter.this);
        //tvKeep.setSelected(true);

        tvKeep.setOnClickListener(new View.OnClickListener() {
          @Override public void onClick(View view) {
            designationSelection.onKeepSettings(getLayoutPosition(),
                editExperienceList.get(getLayoutPosition()));
          }
        });

        tvRemove.setOnClickListener(new View.OnClickListener() {
          @Override public void onClick(View view) {
            designationSelection.onRemoveSettings(getLayoutPosition());
          }
        });

        ivDeleteJob.setOnClickListener(new View.OnClickListener() {
          @Override public void onClick(View view) {
            designationSelection.onDeleteExperience(getLayoutPosition());
          }
        });
        tvExpTitle.setOnClickListener(new View.OnClickListener() {
          @Override public void onClick(View view) {
            designationSelection.onEditExperienceTitle(getLayoutPosition());
          }
        });
      } else if (viewType == ExperienceTypes.TYPE_EXP_CHIP_VIEWS_LISTING) {
        mTvAddExp = (TextView) itemView.findViewById(R.id.tvAddExp);
        mTvAddExp.setOnClickListener(new View.OnClickListener() {
          @Override public void onClick(View v) {
            designationSelection.onDesignationClick();
          }
        });
        chipViewDesignations = (ChipView) itemView.findViewById(R.id.chipViewDesignations);
        chipViewDesignations.setChipBackgroundRes(R.drawable.round_grey_light_transparent);
        chipViewDesignations.setChipSidePadding(
            (int) context.getResources().getDimension(R.dimen._15sdp));
        chipViewDesignations.setChipPadding(
            (int) context.getResources().getDimension(R.dimen._7sdp));
        chipViewDesignations.setChipTextSize(
            context.getResources().getDimensionPixelSize(R.dimen._10sdp));
      }
    }

    private void updateChips() {
      List<Chip> chipList = new ArrayList<>();
      if (editExperienceList.size() > 1) {
        for (int i = 0; i < editExperienceList.size() - 1; i++) {
          String designationName = editExperienceList.get(i).getTitle();
          chipList.add(new Tag(designationName, i));
        }
      }
      //chipList.add(new Tag(context.getString(R.string.other), editExperienceList.size() - 1));
      chipViewDesignations.setChipList(chipList);
      /*chipViewDesignations.setOnChipClickListener(new OnChipClickListener() {
        @Override public void onChipClick(Chip chip) {
          if (chip.getPosition() == editExperienceList.size() - 1) {

          }
        }
      });*/
    }

    public void setData(Experience editExperience, int position) {
      if (position == editExperienceList.size() - 1
          && editExperience.getType() == ExperienceTypes.TYPE_EXP_CHIP_VIEWS_LISTING) {
        updateChips();
      } else if (editExperience.getType() == ExperienceTypes.TYPE_EXP_EDIT_LISTING) {
        tvExpTitle.setText(editExperience.getTitle());
        if (editExperience.getProgressInMonths() > 0) {
          customProgressbar.showInitialSelection(editExperience.getProgressInMonths());
        } else {
          customProgressbar.clearPosition();
        }
      } else {
        tvDesignationTitle.setText(editExperience.getTitle());
        String experienceTemp = editExperience.getExperience();
        String label;
        if (editExperience.getProgressInMonths() > 12) {
          label = context.getString(R.string.yearexp);
        } else {
          label = context.getString(R.string.monthexp);
        }
        tvProgressTitle.setText(experienceTemp);
        tvProgressSubTitle.setText(label);
        expProgressBar.setProgress((editExperience.getProgressInMonths() * 100) / 60);
      }
    }
  }

  @Override public int getItemViewType(int position) {
    Experience editExperience = editExperienceList.get(position);
    if (editExperience.getType() == ExperienceTypes.TYPE_EXP_COMMON_LISTING) {
      return ExperienceTypes.TYPE_EXP_COMMON_LISTING;
    } else if (editExperience.getType() == ExperienceTypes.TYPE_EXP_CHIP_VIEWS_LISTING) {
      return ExperienceTypes.TYPE_EXP_CHIP_VIEWS_LISTING;
    } else if (editExperience.getType() == ExperienceTypes.TYPE_EXP_EDIT_LISTING) {
      return ExperienceTypes.TYPE_EXP_EDIT_LISTING;
    }
    return ExperienceTypes.TYPE_EXP_COMMON_LISTING;
  }

  public interface DesignationSelection {
    void onDesignationClick();

    void singleDesignationEdit(int position, Experience experience);

    void onKeepSettings(int position, Experience experience);

    void onRemoveSettings(int position);

    void onDeleteExperience(int position);

    void onEditExperienceTitle(int position);
  }
}
