/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

/**
 * Created by jay shah on 25/7/16.
 */
public interface HomeView extends MediaView {

  void showMediaDialog();


}
