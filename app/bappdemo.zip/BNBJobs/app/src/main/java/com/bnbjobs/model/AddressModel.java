/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.android.gms.maps.model.LatLng;
import com.google.gson.annotations.SerializedName;

/**
 * @author Harsh
 * @version 1.0
 */

public class AddressModel {

  @SerializedName("geometry") private GeometryClass geometryClass;

  public GeometryClass getGeometryClass() {
    return geometryClass;
  }

  public void setGeometryClass(GeometryClass geometryClass) {
    this.geometryClass = geometryClass;
  }

  public class GeometryClass {

    @SerializedName("location") private LocationModel locationModel;

    public LocationModel getLocationModel() {
      return locationModel;
    }

    public class LocationModel {
      private double lat;
      private double lng;

      public double getLat() {
        return lat;
      }

      public void setLat(double lat) {
        this.lat = lat;
      }

      public double getLng() {
        return lng;
      }

      public void setLng(double lng) {
        this.lng = lng;
      }

      public LatLng getLatLng() {
        return new LatLng(lat, lng);
      }
    }
  }
}
