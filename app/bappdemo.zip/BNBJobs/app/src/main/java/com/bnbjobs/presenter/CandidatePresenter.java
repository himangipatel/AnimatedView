/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.support.v4.app.Fragment;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.CandidateContainer;
import com.bnbjobs.model.CandidateModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.CandidateView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class CandidatePresenter extends BasePresenter implements Presenter<CandidateView> {

  private static final int perPage = 10;
  private final String TAG = makeLogTag(CandidatePresenter.class);
  private CandidateView mCandidateView;
  private boolean loadMore;
  private int page;
  private Fragment fragment;

  @Override public void attachView(CandidateView view) {
    mCandidateView = view;
  }

  @Override public void detachView() {
    mCandidateView = null;
  }

  public void getCandidate() {
    mCandidateView.showProgress();
    HashMap<String, String> params = new HashMap<>(7);
    params.put("apiName", "getAllCandidates");
    if (loadMore) {
      params.put("page", String.valueOf(page));
    }
    params.put("perPage", String.valueOf(perPage));
    params.putAll(addDefaultParamsWitLat(params));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mCandidateView.hideProgress();
      }

      @Override public void onNext(String s) {
        mCandidateView.hideProgress();
        CandidateContainer candidateContainer = new Gson().fromJson(s, CandidateContainer.class);
        if (candidateContainer.isSuccess()) {
          page = candidateContainer.getCurrentPage() + 1;
          loadMore = candidateContainer.getTotalPage() != candidateContainer.getCurrentPage();
          setUpData(candidateContainer.getCandidateModelList());
        }
      }
    });
  }

  private void setUpData(List<CandidateModel> models) {
    Observable.just(models)
        .map(new Func1<List<CandidateModel>, List<CandidateModel>>() {
          @Override public List<CandidateModel> call(List<CandidateModel> candidateModels) {
            List<CandidateModel> mList = new ArrayList<>();
            for (CandidateModel model : candidateModels) {
              model.setAddress(getAddress(model.getuLat(), model.getuLng()));
              model.setDistance(getKm(Double.parseDouble(model.getDistance())));
              mList.add(model);
            }
            return mList;
          }
        })
        .subscribeOn(Schedulers.io())
        .compose(((BaseFragment) fragment).<List<CandidateModel>>bindUntilEvent(
            FragmentEvent.DESTROY_VIEW))
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<List<CandidateModel>>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            if (!isNotNull()) return;
            mCandidateView.hideProgress();
            LOGE(TAG, e.getMessage(), e);
          }

          @Override public void onNext(List<CandidateModel> candidateModels) {
            if (!isNotNull()) return;
            mCandidateView.hideProgress();
            mCandidateView.setAdapter(candidateModels);
          }
        });
  }

  private boolean isNotNull() {
    return mCandidateView != null;
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).<String>bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }

  @Override protected Context getBaseContext() {
    return mCandidateView.getContext();
  }
}
