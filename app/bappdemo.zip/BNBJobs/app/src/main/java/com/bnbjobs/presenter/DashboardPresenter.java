/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import com.bnbjobs.customui.looppager.RecyclerViewPager;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.DashboardContainer;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.DashboardView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.util.HashMap;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class DashboardPresenter extends BasePresenter implements Presenter<DashboardView> {

  private final String TAG = makeLogTag(DashboardPresenter.class);
  private DashboardView mDashboardView;
  private Fragment fragment;
  private RecyclerViewPager mRecyclerViewPager;
  // alpha factor for job vacancies
  private float scaleFactor = 0.94f;
  private float alphaFactor = 0.6f;

  @Override public void attachView(DashboardView view) {
    mDashboardView = view;
    mRecyclerViewPager = mDashboardView.getRecyclerViewPager();
  }

  @Override public void detachView() {
    mDashboardView = null;
  }

  @Override protected Context getBaseContext() {
    return mDashboardView.getContext();
  }

  public void getDashboard() {
    mDashboardView.showProgress();
    HashMap<String, String> params = new HashMap<>(8);
    params.put("apiName", "recruiterDashboard");
    params.putAll(addDefaultParamsWitLat(params));

    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mDashboardView.hideProgress();
      }

      @Override public void onNext(String s) {
        mDashboardView.hideProgress();
        DashboardContainer container = new Gson().fromJson(s, DashboardContainer.class);
        if (container.isSuccess()) {
          mDashboardView.setJobOffer(container.getDashboardData().getJobOfferDataList());
          mDashboardView.setCount(container.getDashboardData());
          mDashboardView.setUserDetail(container.getDashboardData().getUserModel());
          mDashboardView.setPagerAdapter();
          fetchAddress(container.getDashboardData().getUserModel().getLat(),
              container.getDashboardData().getUserModel().getLng());
        }
      }
    });
  }

  private void fetchAddress(final String lat, final String lng) {
    Observable.just(lat)
        .map(new Func1<String, String>() {
          @Override public String call(String s) {
            return getAddress(lat, lng);
          }
        })
        .compose(getBindEvent())
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
          }

          @Override public void onNext(String s) {
            mDashboardView.setAddress(s);
          }
        });
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }

  /**
   * set recyclerview settings
   */
  public void setRecyclerViewSettings() {
    mRecyclerViewPager.addOnScrollListener(new RecyclerView.OnScrollListener() {
      @Override public void onScrollStateChanged(RecyclerView recyclerView, int scrollState) {

      }

      @Override public void onScrolled(RecyclerView recyclerView, int i, int i2) {
        int childCount = mRecyclerViewPager.getChildCount();
        int width = mRecyclerViewPager.getChildAt(0).getWidth();
        //int padding = getResources().getDisplayMetrics().densityDpi;
        int padding = (mRecyclerViewPager.getWidth() - width) / 2;

        for (int j = 0; j < childCount; j++) {
          View v = recyclerView.getChildAt(j);
          float rate = 0;
          if (v.getLeft() <= padding) {
            if (v.getLeft() >= padding - v.getWidth()) {
              rate = (padding - v.getLeft()) * 1f / v.getWidth();
            } else {
              rate = 1;
            }
            v.setAlpha(1 - rate * (1 - alphaFactor));
            v.setScaleX(1 - rate * (1 - scaleFactor));
          } else {
            if (v.getLeft() <= recyclerView.getWidth() - padding) {
              rate = (recyclerView.getWidth() - padding - v.getLeft()) * 1f / v.getWidth();
            }
            v.setAlpha(alphaFactor + rate * (1 - alphaFactor));
            v.setScaleX(scaleFactor + rate * (1 - scaleFactor));
          }
        }
      }
    });

    // add on layout change listener
    mRecyclerViewPager.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
      @Override
      public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft,
          int oldTop, int oldRight, int oldBottom) {
        if (mRecyclerViewPager.getChildCount() < 3) {
          if (mRecyclerViewPager.getChildAt(1) != null) {
            if (mRecyclerViewPager.getCurrentPosition() == 0) {
              View v1 = mRecyclerViewPager.getChildAt(1);
              v1.setAlpha(alphaFactor);
              v1.setScaleX(scaleFactor);
            } else {
              View v1 = mRecyclerViewPager.getChildAt(0);
              v1.setAlpha(alphaFactor);
              v1.setScaleX(scaleFactor);
            }
          }
        } else {
          if (mRecyclerViewPager.getChildAt(0) != null) {
            View v0 = mRecyclerViewPager.getChildAt(0);
            v0.setAlpha(alphaFactor);
            v0.setScaleX(scaleFactor);
          }
          if (mRecyclerViewPager.getChildAt(2) != null) {
            View v2 = mRecyclerViewPager.getChildAt(2);
            v2.setAlpha(alphaFactor);
            v2.setScaleX(scaleFactor);
          }
        }
      }
    });
  }
}
