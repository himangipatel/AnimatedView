/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.utils;

import android.text.format.DateUtils;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * @author Harsh
 * @version 1.0
 */
public class TimeUtils {
    public static long getTimeInUTC(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeZone(TimeZone.getTimeZone("UTC"));
        calendar.set(year, month, day);
        return calendar.getTimeInMillis();


    }

    public static String getTimeInGMT(long timeStamp) {


        Calendar calendar = Calendar.getInstance();
        calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
        calendar.setTimeInMillis(timeStamp);

        int month = calendar.get(Calendar.MONTH);
        int year = calendar.get(Calendar.YEAR);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        String date = getGMTString(year, month + 1, day);
        return date;
    }

    public static String getGMTString(int year, int month, int day) {
        String strCurrentDate = String.valueOf(year) + " " + String.valueOf(month) + " " + String.valueOf(day);


        SimpleDateFormat format = new SimpleDateFormat("yyyy MM dd", Locale.ENGLISH);
        Date newDate = null;
        try {
            newDate = format.parse(strCurrentDate);

            format = new SimpleDateFormat("dd MMM yyyy");
            String date = format.format(newDate);
            return date;

        } catch (Exception e) {
            return "";
        }
    }

    public static String getTimeString(long then) {

        Date date = new Date(then);
        StringBuilder dateStr = new StringBuilder();

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        Calendar now = Calendar.getInstance();

        int days = daysBetween(calendar.getTime(), now.getTime());
        int minutes = hoursBetween(calendar.getTime(), now.getTime());
        int hours = minutes / 60;
        if (days == 0) {

            int second = minuteBetween(calendar.getTime(), now.getTime());
            if (minutes > 60) {
                if (hours >= 1 && hours <= 24) {
                    dateStr.append(hours).append("h");
                }
            } else {
                if (second <= 10) {
                    dateStr.append("Now");
                } else if (second > 10 && second <= 30) {
                    dateStr.append("few seconds ago");
                } else if (second > 30 && second <= 60) {
                    dateStr.append(second).append("s");
                } else if (second >= 60 && minutes <= 60) {
                    dateStr.append(minutes).append("m");
                }
            }
        } else if (hours > 24 && days <= 7) {
            dateStr.append(days).append("d");
        }/* else {
            dateStr.append(twtimeformat.format(date));
        }*/

        return dateStr.toString();
    }

    public static int minuteBetween(Date d1, Date d2) {
        return (int) ((d2.getTime() - d1.getTime()) / DateUtils.SECOND_IN_MILLIS);
    }

    public static int hoursBetween(Date d1, Date d2) {
        return (int) ((d2.getTime() - d1.getTime()) / DateUtils.MINUTE_IN_MILLIS);
    }

    public static int daysBetween(Date d1, Date d2) {
        return (int) ((d2.getTime() - d1.getTime()) / DateUtils.DAY_IN_MILLIS);
    }
}
