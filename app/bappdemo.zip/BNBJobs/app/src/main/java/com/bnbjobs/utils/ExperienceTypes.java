/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.utils;

/**
 * Created by jay shah on 6/9/16.
 */
public class ExperienceTypes {

    public static final int TYPE_EXP_COMMON_LISTING=1;
    public static final int TYPE_EXP_CHIP_VIEWS_LISTING=2;
    public static final int TYPE_EXP_EDIT_LISTING=3;
}
