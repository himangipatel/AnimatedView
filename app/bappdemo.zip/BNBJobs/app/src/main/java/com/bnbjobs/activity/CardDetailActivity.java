/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.adapter.BeautyAdpDate;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.interfaces.RecycleOnItemClickListner;
import com.bnbjobs.model.PaymentAction;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.BeautyCiphere;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.HelpCVVDialog;
import com.bnbjobs.utils.LocaleHelper;
import com.bnbjobs.utils.SearchNotAvailableDialog;
import com.bnbjobs.utils.Utils;
import com.trello.rxlifecycle.ActivityEvent;

import io.card.payment.CardIOActivity;
import io.card.payment.CreditCard;

import java.net.SocketTimeoutException;
import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import java.util.Locale;
import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;

import rx.Subscriber;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.getEuro;
import static com.bnbjobs.utils.Utils.hideKeyboard;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */
public class CardDetailActivity extends BaseActivity {

  private static final String TAG = makeLogTag(CardDetailActivity.class);
  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.imageCenterLogo) ImageView imageCenterLogo;
  @BindView(R.id.rightImage) TinTableImageView rightImage;
  @BindView(R.id.toolbar) Toolbar toolbar;
  @BindView(R.id.tvAmount) TextView tvAmount;
  @BindView(R.id.etCardName) EditText etCardName;
  @BindView(R.id.etCardNumber) EditText etCardNumber;
  @BindView(R.id.imgScanner) ImageView imgScanner;
  @BindView(R.id.tvMonth) TextView tvMonth;
  @BindView(R.id.tvYear) TextView tvYear;
  @BindView(R.id.imgQuestion) ImageView imgQuestion;
  @BindView(R.id.etCvv) EditText etCvv;
  @BindView(R.id.etCardHolderName) EditText etCardHolderName;
  @BindView(R.id.tvPayment) TextView tvPayment;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.tvCardSelected) TextView tvCardSelected;
  int prevPos = -1;
  private int ex_month = 0;
  private List<String> arrMonth = new ArrayList<>();
  private List<String> arrYear = new ArrayList<>();
  private List<String> arrCard = new ArrayList<>();
  private String[] cardList = {
      "Visa", "MasterCard", "Maestro", "Diners"
  };
  private String[] mangopayCardList = {
      "CB_VISA_MASTERCARD", "CB_VISA_MASTERCARD", "MAESTRO", "DINERS"
  };
  private int[] cardImg = {
      R.drawable.visa, R.drawable.mastercard, R.drawable.maestro, R.drawable.diner_club
  };
  private double height = 0, monthWidth, yearWidth = 0, cardwidth = 0;
  private BeautyAdpDate adapter;

  private String amount;
  private String planType;
  private String mangopayCard;
  private static final int MY_SCAN_REQUEST_CODE = 100;
  private PopupWindow popup;
  private RecycleOnItemClickListner listener = new RecycleOnItemClickListner() {
    @Override public void onItemClick(View view, int position) {
      if (popup != null) {
        popup.dismiss();
      }
      switch (view.getId()) {
        case R.id.tvMonth:
          ex_month = position;
          tvMonth.setText(arrMonth.get(position));
          break;
        case R.id.tvYear:
          tvYear.setText(arrYear.get(position));
          break;
        case R.id.tvCardSelected:
          tvCardSelected.setText(arrCard.get(position));
          tvCardSelected.setCompoundDrawablesWithIntrinsicBounds(cardImg[position], 0,
              R.drawable.down_arrow, 0);
          tvCardSelected.setCompoundDrawablePadding(
              (int) getResources().getDimension(R.dimen._10sdp));
          mangopayCard = mangopayCardList[position];
          if (prevPos != position && prevPos > 0) {
            etCardNumber.setText("");
          }
          prevPos = position;
          break;
      }
    }
  };

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_card_detail);
    ButterKnife.bind(this);
    tvTitle.setVisibility(View.VISIBLE);
    tvTitle.setText(R.string.payment);
    String[] months = new DateFormatSymbols().getMonths();
    arrMonth.addAll(Arrays.asList(months));
    setExpiryDateData();
    etCardNumber.addTextChangedListener(new cardTypeWatcher());
    if (getIntent() != null) {
      //paymentType = getIntent().getIntExtra(Constants.KEY_TYPE, 0);
      amount = getIntent().getStringExtra(Constants.KEY_TEXT);
      tvAmount.setText(String.format(Locale.getDefault(),"%s%s", amount, getEuro()));
      if (!isCandidate()) {
        planType = getIntent().getStringExtra(Constants.KEY_PLAN_TYPE);
      }
    }
  }

  private void setExpiryDateData() {
    arrCard.addAll(Arrays.asList(cardList));
    Calendar calendar = Calendar.getInstance();
    int year = calendar.get(Calendar.YEAR);
    for (int i = year; i <= year + 20; i++) {
      arrYear.add(String.valueOf(i));
    }
    height = (int) getResources().getDimension(R.dimen._35sdp) * 2;

    tvCardSelected.post(new Runnable() {
      @Override public void run() {
        if (tvCardSelected != null) {
          cardwidth = tvCardSelected.getWidth();
        }
      }
    });
    tvMonth.post(new Runnable() {
      @Override public void run() {
        if (tvMonth != null) {
          monthWidth = tvMonth.getWidth();
        }
      }
    });
    tvYear.post(new Runnable() {
      @Override public void run() {
        if (tvYear != null) {
          yearWidth = tvYear.getWidth();
        }
      }
    });
  }

  @OnClick({
      R.id.tvCardSelected, R.id.imgScanner, R.id.tvMonth, R.id.tvYear, R.id.imgQuestion,
      R.id.tvPayment, R.id.linearProgress
  }) void onClick(View view) {
    int id = view.getId();
    switch (id) {
      case R.id.tvCardSelected:
        adapter = new BeautyAdpDate(this, Arrays.asList(cardList), listener, (TextView) view);
        popupmenu((TextView) view, cardwidth, false);
        break;
      case R.id.imgScanner:
        onScanPress();
        break;
      case R.id.linearProgress:
        // do nothing..
        break;
      case R.id.tvMonth:
        hideKeyboard(this);
        adapter = new BeautyAdpDate(this, arrMonth, listener, (TextView) view);
        popupmenu((TextView) view, monthWidth, true);
        break;
      case R.id.tvYear:
        hideKeyboard(this);
        adapter = new BeautyAdpDate(this, arrYear, listener, (TextView) view);
        popupmenu((TextView) view, yearWidth, true);
        break;
      case R.id.imgQuestion:
        hideKeyboard(this);
        HelpCVVDialog helpCVVDialog = new HelpCVVDialog(this);
        helpCVVDialog.show();
        break;
      case R.id.tvPayment:
        hideKeyboard(this);
        apiCall();
        break;
    }
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    String resultStr;
    if (data != null && data.hasExtra(CardIOActivity.EXTRA_SCAN_RESULT)) {
      CreditCard scanResult = data.getParcelableExtra(CardIOActivity.EXTRA_SCAN_RESULT);
      // Never log a raw card number. Avoid displaying it, but if necessary use getFormattedCardNumber()
      boolean isValid = false;
      for (int k = 0; k < cardList.length; k++) {
        if (scanResult.getCardType().toString().equalsIgnoreCase(cardList[k])) {
          listener.onItemClick(tvCardSelected, k);
          isValid = true;
          break;
        }
      }
      if (isValid) {
        etCardNumber.setText(scanResult.getFormattedCardNumber() + "");
        if (scanResult.isExpiryValid()) {
          tvMonth.setText(arrMonth.get(scanResult.expiryMonth - 1));
          ex_month = scanResult.expiryMonth - 1;
          tvYear.setText(scanResult.expiryYear + "");
        }
        if (scanResult.cvv != null) {
          etCvv.setText(scanResult.cvv);
        }
        if (scanResult.cardholderName != null) {
          etCardHolderName.setText(scanResult.cardholderName);
        }
      } else {
        new SearchNotAvailableDialog(this, "Invalid Card!");
      }
    }
  }

  @Override protected void onResume() {
    super.onResume();
  }

  private void onScanPress() {
    // This method is set up as an onClick handler in the layout xml
    // e.g. android:onClick="onScanPress"
    Intent scanIntent = new Intent(this, CardIOActivity.class);
    // customize these values to suit your needs.
    scanIntent.putExtra(CardIOActivity.EXTRA_REQUIRE_EXPIRY, true); // default: false
    scanIntent.putExtra(CardIOActivity.EXTRA_REQUIRE_CVV, false); // default: false
    scanIntent.putExtra(CardIOActivity.EXTRA_REQUIRE_POSTAL_CODE, false); // default: false
    scanIntent.putExtra(CardIOActivity.EXTRA_RESTRICT_POSTAL_CODE_TO_NUMERIC_ONLY,
        false); // default: false
    scanIntent.putExtra(CardIOActivity.EXTRA_REQUIRE_CARDHOLDER_NAME, true); // default: false
    // hides the manual entry button
    // if set, developers should provide their own manual entry mechanism in the app
    scanIntent.putExtra(CardIOActivity.EXTRA_SUPPRESS_MANUAL_ENTRY, true); // default: false
    // matches the theme of your application
    scanIntent.putExtra(CardIOActivity.EXTRA_KEEP_APPLICATION_THEME, false); // default: false
    // hide the paypal logo
    scanIntent.putExtra(CardIOActivity.EXTRA_HIDE_CARDIO_LOGO, true);
    // MY_SCAN_REQUEST_CODE is arbitrary and is only used within this activity.
    startActivityForResult(scanIntent, MY_SCAN_REQUEST_CODE);
  }

  private void popupmenu(TextView edt, double width, boolean customAnchor) {
    popup = new PopupWindow(this);
    popup.setWidth((int) width);
    popup.setHeight((int) height);
    popup.setFocusable(true);
    popup.setBackgroundDrawable(new ColorDrawable());
    LinearLayout LL_Outer = new LinearLayout(this);
    LL_Outer.setOrientation(LinearLayout.VERTICAL); // set orientation
    LL_Outer.setBackground(
        ActivityCompat.getDrawable(this, R.drawable.rounded_birthdate)); // set background
    // set Layout_Width and Layout_Height
    LinearLayout.LayoutParams layoutForOuter =
        new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT);
    LL_Outer.setLayoutParams(layoutForOuter);
    RecyclerView recyclerview = new RecyclerView(this);
    RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);
    recyclerview.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
    recyclerview.setLayoutManager(mLayoutManager);
    recyclerview.setItemAnimator(new DefaultItemAnimator());
    recyclerview.setAdapter(adapter);
    LL_Outer.addView(recyclerview);
    popup.setContentView(LL_Outer);
    if (customAnchor) {
      popup.showAsDropDown(edt, 0, -200);
    } else {
      popup.showAsDropDown(edt);
    }
  }

  @OnClick(R.id.imageBack) void onBack() {
    onBackPressed();
  }

  private void apiCall() {
    Utils.hideKeyboard(this);
    if (isValidate()) {
      linearProgress.setVisibility(View.VISIBLE);
      HashMap<String, String> params = new HashMap<>();
      params.put("apiName", "premiumPlanPurchase");
      params.put("userId", getPrefs(this).getString(QuickstartPreferences.USER_ID, ""));
      params.put("accessToken", getPrefs(this).getString(QuickstartPreferences.ACCESS_TOKEN, ""));
      if (isCandidate()) {
        params.put("planType", "4");
        params.put("type", "1");
      } else {
        params.put("planType", planType);
        params.put("type", "2");
      }
      params.put("cardHolderName", Utils.getText(etCardHolderName));
      params.put("cardType", mangopayCard);
      params.put("cardDetail", setJsonObjectData());
      params.put("language", LocaleHelper.getLanguage(this));
      RestClient.getInstance(params)
          .compose(this.<String>bindUntilEvent(ActivityEvent.DESTROY))
          .subscribe(new Subscriber<String>() {
            @Override public void onCompleted() {
            }

            @Override public void onError(Throwable e) {
              LOGE(TAG, e.getMessage(), e);
              linearProgress.setVisibility(View.GONE);
              retryMethod(e);
            }

            @Override public void onNext(String s) {
              LOGI(TAG, "payment " + s);
              linearProgress.setVisibility(View.GONE);
              if (isResponseSuccess(s)) {
                EventBus.getDefault().post(new PaymentAction(true));
                finish();
              } else {
                try {
                  JSONObject object = new JSONObject(s);
                  Utils.showDialog(CardDetailActivity.this, getString(R.string.alert),
                      object.getString("message"), getString(R.string.ok),
                      new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface dialog, int which) {
                          dialog.dismiss();
                        }
                      }).show();
                } catch (JSONException e) {
                  e.printStackTrace();
                }
              }
            }
          });
    }
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(final Throwable e) {
    String error = "";
    if (e instanceof SocketTimeoutException) {
      error = getString(R.string.error_timeout);
    } else {
      error = getString(R.string.error_other);
    }
    Utils.showDialog(CardDetailActivity.this, getString(R.string.alert), error,
        getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            apiCall();
          }
        }).show();
  }

  private boolean isValidate() {
    if (isEmpty(Utils.getText(etCardName))) {
      showMessage(this, getString(R.string.enter_card_name));
      return false;
    } else if (isEmpty(Utils.getText(etCardNumber))) {
      showMessage(this, getString(R.string.enter_card_number));
      return false;
    } else if (isEmpty(Utils.getText(tvCardSelected))) {
      showMessage(this, getString(R.string.select_your_card));
      return false;
    } else if (isEmpty(Utils.getText(etCardHolderName))) {
      showMessage(this, getString(R.string.enter_card_holder));
      return false;
    } else if (isEmpty(Utils.getText(tvMonth))) {
      showMessage(this, getString(R.string.please_select_month));
      return false;
    } else if (isEmpty(Utils.getText(tvYear))) {
      showMessage(this, getString(R.string.please_select_year));
      return false;
    } else if (isEmpty(Utils.getText(etCvv))) {
      showMessage(this, getString(R.string.please_enter_cvv_number));
      return false;
    }
    return true;
  }

  private String setJsonObjectData() {
    try {
      String key = getPrefs(this).getString(QuickstartPreferences.USER_ID, "") + "|1|" + getPrefs(
          this).getString(QuickstartPreferences.CREATED_AT, "");
      String cardExpiry = String.format("%02d%02d", (ex_month + 1),
          Integer.parseInt(Utils.getText(tvYear).substring(2)));
      JSONObject jsonObject = new JSONObject();
      jsonObject.put("cardExpire", cardExpiry);
      jsonObject.put("cardCvv", Utils.getText(etCvv));
      jsonObject.put("cardNumber", Utils.getText(etCardNumber));
      return BeautyCiphere.encrypt(jsonObject.toString(), Utils.SHA1(key));
    } catch (Exception e) {
      e.printStackTrace();
      return "";
    }
  }

  private void setCardType(String cardNo) {
    if (Utils.isDinersCard(cardNo)) {
      prevPos = -1;
      listener.onItemClick(tvCardSelected, 3);
    } else if (Utils.isMasterCard(cardNo)) {
      prevPos = -1;
      listener.onItemClick(tvCardSelected, 1);
    } else if (Utils.isVisaCard(cardNo)) {
      prevPos = -1;
      listener.onItemClick(tvCardSelected, 0);
    } else if (Utils.isMaestroCard(cardNo)) {
      prevPos = -1;
      listener.onItemClick(tvCardSelected, 2);
    }
  }

  private class cardTypeWatcher implements TextWatcher {

    @Override public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
    }

    @Override public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
      if (charSequence.length() >= 1 && charSequence.length() <= 4) {
        setCardType(charSequence.toString());
      }
    }

    @Override public void afterTextChanged(Editable editable) {
    }
  }
}

