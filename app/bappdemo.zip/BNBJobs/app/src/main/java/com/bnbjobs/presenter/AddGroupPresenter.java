/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import com.bnbjobs.R;
import com.bnbjobs.model.GroupModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.RxUtil;
import com.bnbjobs.view.AddGroupView;
import com.google.gson.Gson;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import okhttp3.RequestBody;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.Utils.showDialog;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */
public class AddGroupPresenter extends BasePresenter implements Presenter<AddGroupView> {

  private AddGroupView mAddGroupView;
  private Subscription subscriber;

  @Override public void attachView(AddGroupView view) {
    this.mAddGroupView = view;
  }

  @Override public void detachView() {
    mAddGroupView = null;
    RxUtil.unsubscribe(subscriber);
  }

  public void addGroup(HashMap<String, RequestBody> params) {
    if(!hasNetworkConnectivity()){
      showMessage(getBaseContext(),getBaseContext().getString(R.string.check_internet));
      return;
    }

    params.putAll(addParamsBody(params));
    mAddGroupView.showProgress();
    RxUtil.unsubscribe(subscriber);
    subscriber = RestClient.getInstance()
        .apiCallImage(params)
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
          }

          @Override public void onError(Throwable e) {
            mAddGroupView.hideProgress();
            LOGI(TAG, Log.getStackTraceString(e));
          }

          @Override public void onNext(String s) {
            mAddGroupView.hideProgress();
            try {
              JSONObject object = new JSONObject(s);
              if(object.getBoolean("success")){
                GroupModel groupModel = new Gson().fromJson(object.getJSONObject("data").toString(),GroupModel.class);
                mAddGroupView.onSuccess(groupModel);

              }else{
                mAddGroupView.onError(object.getString("message"));
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  /**
   * get group details
   * @param gId group id
   */
  public void getGroupDetail(final String gId) {
    if (hasNetworkConnectivity()) {
      mAddGroupView.showProgress();
      HashMap<String, String> params = new HashMap<>();
      params.put("apiName", "group_details");
      params.put("group_id", gId);
      params.putAll(addParams(params));
      RxUtil.unsubscribe(subscriber);
      subscriber = RestClient.getInstance(params)
          .subscribe(new Subscriber<String>() {
            @Override public void onCompleted() {

            }

            @Override public void onError(Throwable e) {
              LOGE(TAG, e.getMessage(), e);
              mAddGroupView.hideProgress();
              String error;
              if (e instanceof SocketTimeoutException) {
                error = getBaseContext().getString(R.string.error_timeout);
              } else {
                error = getBaseContext().getString(R.string.error_other);
              }
              showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
                  getBaseContext().getString(R.string.retry),
                  new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                      dialog.dismiss();
                      getGroupDetail(gId);
                    }
                  }).show();
            }

            @Override public void onNext(String s) {
              mAddGroupView.hideProgress();
              try {
                JSONObject object = new JSONObject(s);
                if(object.getBoolean("success")){
                  JSONObject dateObject = object.getJSONObject("data");
                  GroupModel model = new Gson().fromJson(dateObject.toString(), GroupModel.class);
                  mAddGroupView.onSuccessDetail(model);
                }else{
                  mAddGroupView.onError(object.getString("message"));
                }
              } catch (JSONException e) {
                e.printStackTrace();
              }
            }
          });
    }
  }

  /**
   * showChangePhotoDialog
   * Show the dialog for photo selection options
   */
  public void showChangePhotoDialog() {
    imagePicker(new DialogInterface.OnClickListener() {
      @Override public void onClick(DialogInterface dialog, int which) {
        if (which == 0) {
          mAddGroupView.openCamera();
        } else if (which == 1) {
          mAddGroupView.openGallery();
        } else {
          mAddGroupView.setDefault();
        }
      }
    }, mAddGroupView.isImageSet()).show();
  }

  @Override protected Context getBaseContext() {
    return mAddGroupView.getContext();
  }
}
