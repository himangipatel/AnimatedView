/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

/**
 * @author Harsh
 * @version 1.0
 */
public class UpdateEvent {

  public boolean update;

  private GroupModel groupModel;
  public UpdateEvent(boolean update) {
    this.update = update;
  }

  public GroupModel getGroupModel() {
    return groupModel;
  }

  public void setGroupModel(GroupModel groupModel) {
    this.groupModel = groupModel;
  }
}
