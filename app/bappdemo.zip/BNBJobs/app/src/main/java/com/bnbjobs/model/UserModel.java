/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.bnbjobs.utils.LocaleHelper;
import com.google.gson.annotations.SerializedName;

/**
 * @author Harsh
 * @version 1.0
 */
public class UserModel implements Parcelable {

  public static final Creator<UserModel> CREATOR = new Creator<UserModel>() {
    @Override public UserModel createFromParcel(Parcel in) {
      UserModel userModel = new UserModel();
      userModel.readIn(in);
      return userModel;
    }

    @Override public UserModel[] newArray(int size) {
      return new UserModel[size];
    }
  };
  @SerializedName("u_id") private String id;
  @SerializedName("u_fname") private String fName;
  @SerializedName("u_lname") private String lName;
  @SerializedName("u_latitude") private String lat;
  @SerializedName("u_longitude") private String lng;
  @SerializedName("u_image_thumb_url") private String imageThumb;
  @SerializedName("u_banner_image_url") private String bannerImageUrl;
  @SerializedName("u_banner_image_thumb_url") private String bannerThumbUrl;
  @SerializedName("u_image_url") private String imageUrl;
  @SerializedName("u_email") private String u_email;
  @SerializedName("u_phone") private String u_phone;
  @SerializedName("ujp_status") private int ujpStatus;
  @SerializedName("u_company") private String u_company;
  @SerializedName("applyJobBtnFlag") private int applyJobBtnFlag;
  @SerializedName("d_title") private String d_title;
  @SerializedName("isPremiumplan") private boolean isPremiumplan;
  @SerializedName("d_title_1") private String dTitle1;
  @SerializedName("d_title_2") private String dTitle2;
  @SerializedName("d_title_3") private String dTitle3;
  @SerializedName("u_location") private String u_location;
  private String localLocation;
  private String distance;
  private boolean isSeletected;

  private void readIn(Parcel in) {
    id = in.readString();
    fName = in.readString();
    lName = in.readString();
    lat = in.readString();
    lng = in.readString();
    imageThumb = in.readString();
    bannerImageUrl = in.readString();
    bannerThumbUrl = in.readString();
    imageUrl = in.readString();
    u_email = in.readString();
    u_phone = in.readString();
    ujpStatus = in.readInt();
    u_company = in.readString();
    applyJobBtnFlag = in.readInt();
    d_title = in.readString();
    isPremiumplan = in.readByte() != 0;
    d_title = in.readString();
    dTitle1 = in.readString();
    dTitle2 = in.readString();
    dTitle3 = in.readString();
    u_location = in.readString();
    localLocation = in.readString();
    distance = in.readString();
    isSeletected = in.readByte() != 0;
  }

  @Override public void writeToParcel(Parcel dest, int flags) {
    dest.writeString(id);
    dest.writeString(fName);
    dest.writeString(lName);
    dest.writeString(lat);
    dest.writeString(lng);
    dest.writeString(imageThumb);
    dest.writeString(bannerImageUrl);
    dest.writeString(bannerThumbUrl);
    dest.writeString(imageUrl);
    dest.writeString(u_email);
    dest.writeString(u_phone);
    dest.writeInt(ujpStatus);
    dest.writeString(u_company);
    dest.writeInt(applyJobBtnFlag);
    dest.writeString(d_title);
    dest.writeByte((byte) (isPremiumplan ? 1 : 0));
    dest.writeString(dTitle1);
    dest.writeString(dTitle2);
    dest.writeString(dTitle3);
    dest.writeString(u_location);
    dest.writeString(localLocation);
    dest.writeString(distance);
    dest.writeByte((byte) (isSeletected ? 1 : 0));
  }

  public boolean isSeletected() {
    return isSeletected;
  }

  public void setSeletected(boolean seletected) {
    isSeletected = seletected;
  }

  public String getU_location() {
    return u_location;
  }

  public void setU_location(String u_location) {
    this.u_location = u_location;
  }

  public String getdTitle1() {
    return dTitle1;
  }

  public void setdTitle1(String dTitle1) {
    this.dTitle1 = dTitle1;
  }

  public String getdTitle2() {
    return dTitle2;
  }

  public void setdTitle2(String dTitle2) {
    this.dTitle2 = dTitle2;
  }

  public String getdTitle3() {
    return dTitle3;
  }

  public void setdTitle3(String dTitle3) {
    this.dTitle3 = dTitle3;
  }

  public String getTitle() {
    if (LocaleHelper.isFrench()) {
      return getdTitle2();
    } else if (LocaleHelper.isSpanish()) {
      return getdTitle3();
    } else {
      return getdTitle1();
    }
  }
  public String getDistance() {
    return distance;
  }

  public void setDistance(String distance) {
    this.distance = distance;
  }


  public void setD_title(String d_title) {
    this.d_title = d_title;
  }

  public String getBannerImageUrl() {
    return bannerImageUrl;
  }

  public void setBannerImageUrl(String bannerImageUrl) {
    this.bannerImageUrl = bannerImageUrl;
  }

  public String getBannerThumbUrl() {
    return bannerThumbUrl;
  }

  public void setBannerThumbUrl(String bannerThumbUrl) {
    this.bannerThumbUrl = bannerThumbUrl;
  }

  public int getUjpStatus() {
    return ujpStatus;
  }

  public void setUjpStatus(int ujpStatus) {
    this.ujpStatus = ujpStatus;
  }

  public int getApplyJobBtnFlag() {
    return applyJobBtnFlag;
  }

  public void setApplyJobBtnFlag(int applyJobBtnFlag) {
    this.applyJobBtnFlag = applyJobBtnFlag;
  }

  public String getU_email() {
    return u_email;
  }

  public void setU_email(String u_email) {
    this.u_email = u_email;
  }

  public String getU_phone() {
    return u_phone;
  }

  public void setU_phone(String u_phone) {
    this.u_phone = u_phone;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getfName() {
    return fName;
  }

  public void setfName(String fName) {
    this.fName = fName;
  }

  public String getlName() {
    return lName;
  }

  public void setlName(String lName) {
    this.lName = lName;
  }

  public String getLat() {
    return lat;
  }

  public void setLat(String lat) {
    this.lat = lat;
  }

  public String getLng() {
    return lng;
  }

  public void setLng(String lng) {
    this.lng = lng;
  }

  public String getImageThumb() {
    return imageThumb;
  }

  public void setImageThumb(String imageThumb) {
    this.imageThumb = imageThumb;
  }

  public String getImageUrl() {
    return imageUrl;
  }

  public void setImageUrl(String imageUrl) {
    this.imageUrl = imageUrl;
  }

  public String getLocalLocation() {
    return localLocation;
  }

  public void setLocalLocation(String localLocation) {
    this.localLocation = localLocation;
  }

  @Override public int describeContents() {
    return 0;
  }

  public boolean isPremiumplan() {
    return isPremiumplan;
  }

  public void setPremiumplan(boolean premiumplan) {
    isPremiumplan = premiumplan;
  }

  public String getU_company() {
    return u_company;
  }

  public void setU_company(String u_company) {
    this.u_company = u_company;
  }
}
