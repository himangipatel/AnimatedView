/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.CursorLoader;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.tour.TourActivity;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.trello.rxlifecycle.components.support.RxAppCompatActivity;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;

/**
 * @author Harsh
 * @version 1.0
 */

public abstract class BaseActivity extends RxAppCompatActivity {

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    if (!(this instanceof SplashActivity)
        && !(this instanceof PhoneNumberActivity)
        && !(this instanceof CountrySelectActivity)) {
      overridePendingTransition(R.anim.activity_open_translate, R.anim.activity_close_scale);
    }
  }

  @Override public void finish() {
    super.finish();
    if (doAnimation() && doAnimationCheck()) {
      overridePendingTransition(R.anim.activity_open_scale, R.anim.activity_close_translate);
    }
  }

  private boolean doAnimation() {
    return !(this instanceof HomeActivity)
        && !(this instanceof PhoneNumberActivity)
        && !(this instanceof CountrySelectActivity);
  }

  private boolean doAnimationCheck() {
    return !(this instanceof SplashActivity)
        && !(this instanceof TourActivity)
        && !(this instanceof LandingScreen);
  }

  protected boolean isCandidate() {
    return getPrefs(this).getString(QuickstartPreferences.USER_TYPE, "")
        .equalsIgnoreCase(Constants.CANDIDATE);
  }

  @Override protected void attachBaseContext(Context newBase) {
    super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
  }

  protected Drawable getDrawableObj(int res) {
    return ActivityCompat.getDrawable(this, res);
  }

  protected int getColorObj(int res) {
    return ActivityCompat.getColor(this, res);
  }

  public void setStatusBarColor() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      getWindow().setStatusBarColor(ActivityCompat.getColor(this, android.R.color.white));
      getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }
  }

  public void setStatusBarColorTheme() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      getWindow().setStatusBarColor(ActivityCompat.getColor(this, R.color.colorPrimary));
      getWindow().getDecorView().setSystemUiVisibility(-View.SYSTEM_UI_FLAG_VISIBLE);
    }
  }

  protected int getDate(String date, int field) {
    if (isEmpty(date)) {
      return -1;
    }
    Calendar calendar = Calendar.getInstance();
    DateFormat formatter = new SimpleDateFormat("MM, yyyy", Locale.getDefault());
    try {
      calendar.setTime(formatter.parse(date));
      return calendar.get(field);
    } catch (ParseException e) {
      e.printStackTrace();
    }
    return 0;
  }

  protected void setupUI(View view) {
    //Set up touch listener for non-text box views to hide keyboard.
    if (!(view instanceof EditText)) {
      view.setOnTouchListener(new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
          Utils.hideKeyboard(BaseActivity.this);
          return false;
        }
      });
    }
    //If a layout container, iterate over children and seed recursion.
    if (view instanceof ViewGroup) {
      for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
        View innerView = ((ViewGroup) view).getChildAt(i);
        setupUI(innerView);
      }
    }
  }

  protected void disableEnableControls(boolean enable, ViewGroup vg) {
    for (int i = 0; i < vg.getChildCount(); i++) {
      View child = vg.getChildAt(i);
      child.setEnabled(enable);
      if (child instanceof ViewGroup) {
        disableEnableControls(enable, (ViewGroup) child);
      }
    }
  }

  protected String getRealPathFromURI(Uri contentUri) {
    String[] proj = { MediaStore.Images.Media.DATA };
    CursorLoader cursorLoader =
        new CursorLoader(this, contentUri, proj, null, null, null);
    Cursor cursor = cursorLoader.loadInBackground();
    int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
    cursor.moveToFirst();
    return cursor.getString(column_index);
  }
}
