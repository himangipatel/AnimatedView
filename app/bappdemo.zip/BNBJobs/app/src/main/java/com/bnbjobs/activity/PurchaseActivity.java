/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.text.Html;
import android.text.Spannable;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.PaymentAction;
import com.bnbjobs.model.PurchaseModel;
import com.bnbjobs.presenter.PurchasePresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.view.PurchaseView;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.R.string.purchase_desc;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.Utils.getEuro;
import static com.bnbjobs.utils.Utils.getNumber;

/**
 * @author Harsh
 * @version 1.0
 */
public class PurchaseActivity extends BaseActivity implements PurchaseView {

  @BindView(R.id.imgClose) TinTableImageView imgClose;
  @BindView(R.id.tvHello) TextView tvHello;
  @BindView(R.id.tvAmountMonth) TextView tvAmountMonth;
  @BindView(R.id.tvPerMonth) TextView tvPerMonth;
  @BindView(R.id.linearMonth) LinearLayout linearMonth;
  @BindView(R.id.tvAmountYear) TextView tvAmountYear;
  @BindView(R.id.tvYear) TextView tvYear;
  @BindView(R.id.linearYear) LinearLayout linearYear;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;

  private PurchasePresenter presenter;
  private String monthAmount;
  private String yearAmount;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_purchase);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    presenter = new PurchasePresenter();
    presenter.attachView(this);
    presenter.getPurchasePlan();
    tvHello.setText(getString(purchase_desc,
        getPrefs(this).getString(QuickstartPreferences.USER_FNAME, "User")),
        TextView.BufferType.SPANNABLE);
    Spannable s = (Spannable) tvHello.getText();
    int start = s.length() - 6;
    int end = s.length();
    s.setSpan(new ForegroundColorSpan(ActivityCompat.getColor(this, R.color.theme_pink)), start,
        end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
    imgClose.setColorFilter(Color.WHITE);
    tvPerMonth.setText(Html.fromHtml(getEuro() + "<br><small>/mois</small>"));
    tvYear.setText(Html.fromHtml(getEuro() + "<br><small>/an</small>"));
  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void setData(PurchaseModel model) {
    monthAmount = model.getpMonthly();
    yearAmount = model.getpYearly();
    tvAmountMonth.setText(getNumber(model.getpMonthly()));
    tvAmountYear.setText(getNumber(model.getpYearly()));
  }

  @OnClick({ R.id.linearMonth, R.id.linearYear }) void onClick(View view) {
    if (isEmpty(monthAmount)) return;
    Intent intent = new Intent(this, CardDetailActivity.class);
    if (view.getId() == R.id.linearMonth) {
      intent.putExtra(Constants.KEY_TEXT, monthAmount);
      intent.putExtra(Constants.KEY_TYPE, 3);
    } else {
      intent.putExtra(Constants.KEY_TEXT, yearAmount);
      intent.putExtra(Constants.KEY_TYPE, 4);
    }
    startActivity(intent);
  }

  @OnClick(R.id.imgClose) void onClose() {
    finish();
  }

  @Override protected void onDestroy() {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe public void onEvent(PaymentAction action) {
    if (action.finish) {
      finish();
    }
  }
}
