/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import android.util.Log;
import io.realm.DynamicRealm;
import io.realm.FieldAttribute;
import io.realm.RealmMigration;
import io.realm.RealmSchema;

/**
 * @author Harsh
 * @version 1.0
 */
public class MyMigration implements RealmMigration {
  private static final String TAG = MyMigration.class.getSimpleName();

  @Override public void migrate(DynamicRealm realm, long oldVersion, long newVersion) {

    RealmSchema mRealmSchema = realm.getSchema();


    if (oldVersion == 0) {
      Log.d(TAG, "migrate: " + oldVersion + " new " + newVersion);
      mRealmSchema.create("CountryModel")
          .addField("name", String.class, FieldAttribute.REQUIRED)
          .addField("dialCode", String.class, FieldAttribute.REQUIRED)
          .addField("code", String.class, FieldAttribute.REQUIRED);
      oldVersion++;
    }
  }
}
