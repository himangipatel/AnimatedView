/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnCheckedChanged;
import butterknife.OnClick;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.GradientView;
import com.bnbjobs.presenter.RegisterPresenter;
import com.bnbjobs.services.DesignationService;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.view.RegisterView;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.ActivityUtils.launchActivity;

/**
 * @author Harsh
 * @version 1.0
 */
public class RegisterActivity extends BaseActivity implements RegisterView {

  @BindView(R.id.etFirstName) EditText etFirstName;
  @BindView(R.id.etLastName) EditText etLastName;
  @BindView(R.id.etEmailAddress) EditText etEmailAddress;
  @BindView(R.id.etPassword) EditText etPassword;
  @BindView(R.id.imageAgree) CheckBox imageAgree;
  @BindView(R.id.tvRegister) GradientView tvRegister;
  @BindView(R.id.tvLogIn) TextView tvLogIn;
  @BindView(R.id.relativeProgress) RelativeLayout relativeProgress;
  @BindView(R.id.etCompanyName) EditText etCompanyName;
  @BindView(R.id.rlCompany) RelativeLayout rlCompany;

  private RegisterPresenter presenter;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_register);
    ButterKnife.bind(this);
    if (!isCandidate()) {
      rlCompany.setVisibility(View.VISIBLE);
    }
    presenter = new RegisterPresenter();
    presenter.attachView(this);
    onCheckChange(false);
  }

  @Override protected void onDestroy() {
    presenter.detachView();
    super.onDestroy();
  }

  @OnClick(R.id.tvRegister) void onRegisterClick() {
    presenter.doRegister(etFirstName, etLastName, etEmailAddress, etPassword, etCompanyName);
  }

  @OnCheckedChanged(R.id.imageAgree) void onCheckChange(boolean isChecked) {
    tvRegister.setEnabled(isChecked);
  }

  @Override public void onRegister() {
    startService(new Intent(this, DesignationService.class));
    int status = getPrefs(getBaseContext()).getInt(QuickstartPreferences.USER_PHONE_VERIFIED, 0);
    if (status == 1) {
      launchActivity(this, InviteActivity.class, true);
    } else {
      Intent intent = new Intent(RegisterActivity.this, PhoneNumberActivity.class);
      intent.putExtra(Constants.KEY_VISIBLE_TYPE,"Register");
      startActivity(intent);
      finish();
    }
  }

  @Override public void showProgress() {
    relativeProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    relativeProgress.setVisibility(View.GONE);
  }

  @OnClick(R.id.imageBack) void onBack() {
    onBackPressed();
  }

  @OnClick(R.id.tvLogIn) void onLogin() {
    launchActivity(this, LoginActivity.class, true);
  }

  @OnClick(R.id.imageAgree) void onAgree() {
  }

  @Override public Context getContext() {
    return this;
  }
}
