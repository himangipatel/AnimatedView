/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.support.v4.app.Fragment;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.AnnounceView;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.util.HashMap;
import rx.Subscriber;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;

public class AnnouncePresenter extends BasePresenter implements Presenter<AnnounceView> {

  private AnnounceView mAnnounceView;
  private Fragment fragment;

  @Override protected Context getBaseContext() {
    return this.mAnnounceView.getContext();
  }

  @Override public void attachView(AnnounceView view) {
    this.mAnnounceView = view;
  }

  @Override public void detachView() {
    this.mAnnounceView = null;
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }

  public void deleteJobOffer(String jobOfferId, final int position) {
    mAnnounceView.showProgress();
    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "deleteJobOffer");
    params.put("jobOfferId", jobOfferId);
    params.putAll(addParams(params));
    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {
      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mAnnounceView.hideProgress();
      }

      @Override public void onNext(String s) {
        LOGI(TAG, "dashboard: " + s);
        mAnnounceView.hideProgress();
        mAnnounceView.deleteJobFromList(position);
      }
    });
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }
}