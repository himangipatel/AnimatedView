/*
 * Copyright (c) 2017 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.adapter.HomeAdapter;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.fragments.JobDetailFragment;
import com.bnbjobs.fragments.SearchFragment;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.CountryModel;
import com.bnbjobs.model.JobModel;
import com.bnbjobs.presenter.CountryJobPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.EndlessRecyclerViewScrollListener;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.CountryJobView;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.maps.model.LatLng;
import io.realm.Realm;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections4.IterableUtils;
import org.apache.commons.collections4.Predicate;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */
public class CountryJobFragment extends BaseFragment implements CountryJobView,ClickImpl<JobModel>{

  @BindView(R.id.tvCurrentLocation) TextView mTvCurrentLocation;
  @BindView(R.id.tvFilters) TextView mTvFilters;
  @BindView(R.id.rvOfferAround) RecyclerView mRvOfferAround;
  @BindView(R.id.rvCountryOffer) RecyclerView mRvCountryOffer;
  @BindView(R.id.linearProgress) LinearLayout mLinearProgress;
  @BindView(R.id.swipeRefresh) SwipeRefreshLayout mSwipeRefreshLayout;
  private Unbinder unbinder;

  private List<JobModel> mAroundJobList = new ArrayList<>();
  private List<JobModel> mCountryJobList = new ArrayList<>();

  private HomeAdapter mCountryJobAdapter;

  private EndlessRecyclerViewScrollListener mAroundListener;
  private EndlessRecyclerViewScrollListener mCountryJobListener;

  private CountryJobPresenter mCountryJobPresenter;
  private static final int PLACE_AUTOCOMPLETE_REQUEST_CODE = 1111;
  private boolean mOfferLoadMore;
  private boolean mCountryLoadMore;
  private LatLng mLatLng;
  private static final String TAG = makeLogTag(CountryJobFragment.class);
  private boolean isSet;
  private int mOfferCurrentPage;
  private int mJobCurrentPage;
  private String mCountryName;
  @Nullable @Override public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_country_job, container, false);
    unbinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    if(isEmpty(mCountryName)){
      setCurrentCountry();
    }else{
      mTvCurrentLocation.setText(mCountryName);
    }
    mRvOfferAround.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL,false));
    mAroundListener =  new EndlessRecyclerViewScrollListener((LinearLayoutManager) mRvOfferAround.getLayoutManager()) {
      @Override public void onLoadMore(int page, int totalItemsCount) {
        mAroundListener = this;
        if(mOfferLoadMore){
          mOfferLoadMore  = false;
          mCountryJobPresenter.getOfferAround(++mOfferCurrentPage);
        }
      }
    };

    mRvOfferAround.addOnScrollListener(mAroundListener);
    int height = getResources().getDimensionPixelOffset(R.dimen._200sdp) * 2;
    HomeAdapter aroundAdapter = new HomeAdapter(getActivity(), height, mAroundJobList, this);
    aroundAdapter.setIsFavorite(true);
    mRvOfferAround.setAdapter(aroundAdapter);

    mRvCountryOffer.setNestedScrollingEnabled(false);
    mRvCountryOffer.setLayoutManager(new LinearLayoutManager(getActivity()));
    mCountryJobListener = new EndlessRecyclerViewScrollListener((LinearLayoutManager) mRvCountryOffer.getLayoutManager()) {
      @Override public void onLoadMore(int page, int totalItemsCount) {
        mCountryJobListener = this;
        if(mCountryLoadMore){
          mCountryLoadMore = false;
          mCountryJobPresenter.getCountryOffer(++mJobCurrentPage);
        }
      }
    };
    mRvCountryOffer.addOnScrollListener(mCountryJobListener);
    mCountryJobAdapter= new HomeAdapter(getActivity(), height, mCountryJobList, CountryJobFragment.this);
    mRvCountryOffer.setAdapter(mCountryJobAdapter);

    if(mCountryJobPresenter == null){
      mCountryJobPresenter = new CountryJobPresenter();
      mCountryJobPresenter.attachView(this);
    }

    if(mAroundJobList.isEmpty()){
      mCountryJobPresenter.getOfferAround(1);
    }

    if(mCountryJobList.isEmpty()){
      mCountryJobPresenter.getCountryOffer(1);
    }

    mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
      @Override public void onRefresh() {
        mAroundListener.setLoading(false);
        mCountryJobListener.setLoading(false);
        callApi();
      }
    });

  }
  private void setCurrentCountry() {
    if(isSet)
      return;
    isSet = true;
    double lat = Double.parseDouble(getPrefs(getActivity()).getString(QuickstartPreferences.LAT,"0"));
    double lng = Double.parseDouble(getPrefs(getActivity()).getString(QuickstartPreferences.LNG,"0"));
    mLatLng = new LatLng(lat,lng);
    Realm mRealm = Realm.getDefaultInstance();
    String code = getPrefs(getActivity()).getString(QuickstartPreferences.COUNTRY_CODE, "FR").toUpperCase();
    CountryModel countryModel = mRealm.where(CountryModel.class).equalTo("code", code).findFirst();
    if (countryModel != null) {
      mCountryName = countryModel.getName();
      mTvCurrentLocation.setText(mCountryName);
    }
  }

  private void callApi(){
    mCountryJobPresenter.getOfferAround(1);
    mCountryJobPresenter.getCountryOffer(1);
  }

  @OnClick(R.id.tvCurrentLocation) void onCurrentLocation() {
    findPlace();
  }
  @OnClick(R.id.tvFilters) void onFilter() {
    SearchFragment fragment = new SearchFragment();
    fragment.setTargetFragment(this, 1000);
    addFragment(fragment, true);
  }

  private void findPlace() {
    try {
      Intent intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY).build(getActivity());
      startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
    } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
      LOGE(TAG, e.getMessage(), e);
    }
  }
  @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
      if (resultCode == Activity.RESULT_OK) {
        Place place = PlaceAutocomplete.getPlace(getActivity(), data);
        mLatLng = place.getLatLng();
        mCountryJobPresenter.getAddress(mLatLng);
      } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
        Status status = PlaceAutocomplete.getStatus(getActivity(), data);
        LOGI(TAG, status.getStatusMessage());
      } else if (resultCode == Activity.RESULT_CANCELED) {
        LOGI(TAG, "User cancel");
      }
    }
  }

  @Override public void onDestroyView() {
    super.onDestroyView();
    unbinder.unbind();
  }


  @Override public void showProgress() {
    mLinearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    mLinearProgress.setVisibility(View.GONE);
  }

  @Override public void onNearJobSuccess(BaseContainer<JobModel> jobSearchBaseContainer, boolean clear) {
    mSwipeRefreshLayout.setRefreshing(false);
    if(clear){
      mAroundJobList.clear();
    }
    if(jobSearchBaseContainer.isSuccess()){
      mOfferCurrentPage = jobSearchBaseContainer.getCurrentPage();
      mOfferLoadMore = jobSearchBaseContainer.getCurrentPage() < jobSearchBaseContainer.getTotalPages();
      mAroundJobList.addAll(jobSearchBaseContainer.getDataList());
      mRvOfferAround.getAdapter().notifyDataSetChanged();
    }else{
      onError(jobSearchBaseContainer.getMessage());
    }

  }

  @Override public void onCountryJobSuccess(BaseContainer<JobModel> countryJobList, boolean clear) {
    mSwipeRefreshLayout.setRefreshing(false);
    if(clear){
      mCountryJobList.clear();
    }
    if(countryJobList.isSuccess()){
      mJobCurrentPage = countryJobList.getCurrentPage();
      mCountryLoadMore = countryJobList.getCurrentPage() < countryJobList.getTotalPages();
      mCountryJobList.addAll(countryJobList.getDataList());
      mCountryJobAdapter.notifyDataSetChanged();
    }else{
      onError(countryJobList.getMessage());
    }
  }

  @Override public void onError(String msg) {
      showMessage(getActivity(),msg);
  }

  @Override public LatLng getLatLng() {
    return mLatLng;
  }

  @Override public String getCountryName() {
    return Utils.getText(mTvCurrentLocation);
  }

  @Override public void setCountry(String country) {
    mCountryName = country;
    mTvCurrentLocation.setText(mCountryName);
    callApi();
  }

  @Override public boolean isRefreshing() {
    return mSwipeRefreshLayout.isRefreshing();
  }

  @Override public void onClick(View view, JobModel model, int position) {
      Bundle bundle = new Bundle();
      bundle.putString(Constants.KEY_ID, model.getRpId());
      bundle.putInt(Constants.KEY_POSITION, position);
      JobDetailFragment fragment = new JobDetailFragment();
      fragment.setTargetFragment(this, 1111);
      fragment.setArguments(bundle);
      ((HomeActivity) getActivity()).switchFragment(fragment, true);
  }

  @Override public void updateList(final String offerId) {
    JobModel jobModel = IterableUtils.find(mAroundJobList, new Predicate<JobModel>() {
      @Override public boolean evaluate(JobModel object) {
        return offerId.equalsIgnoreCase(object.getRpId());
      }
    });
    if (jobModel != null) {
      jobModel.setApplyJobBtnFlag(2); // applied
    }
    JobModel jobModel2 = IterableUtils.find(mCountryJobList, new Predicate<JobModel>() {
      @Override public boolean evaluate(JobModel object) {
        return offerId.equalsIgnoreCase(object.getRpId());
      }
    });
    if (jobModel2 != null) {
      jobModel2.setApplyJobBtnFlag(2); // applied
    }
  }
}
