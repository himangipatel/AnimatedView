package com.bnbjobs.utils;

import android.app.DatePickerDialog;
import android.content.Context;
import android.widget.DatePicker;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by imobdev on 17/10/16.
 */
public class MyDatePicker {
    DatePickerDialog mDatePickerDialog;


    public interface onDateSet {
        public void onDate(DatePicker view, int year, int monthOfYear,
                           int dayOfMonth);
    }

    onDateSet mOnDateSet;

    public void setDateListener(onDateSet mOnDateSet) {
        this.mOnDateSet = mOnDateSet;
    }

    public MyDatePicker(Context ctx) {

        Calendar c = Calendar.getInstance();
        mDatePickerDialog = new DatePickerDialog(ctx, new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                mOnDateSet.onDate(view, year, monthOfYear, dayOfMonth);

            }
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        mDatePickerDialog.getDatePicker().setMaxDate(new Date().getTime());

    }

    public void show() {
        mDatePickerDialog.show();
    }

    public void cancel() {
        mDatePickerDialog.dismiss();
    }
}
