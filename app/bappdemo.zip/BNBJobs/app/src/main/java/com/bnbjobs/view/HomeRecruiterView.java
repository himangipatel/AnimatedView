/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.bnbjobs.model.CandidateModel;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public interface HomeRecruiterView extends MainView {

  void setAdapter(List<CandidateModel> candidateModels,boolean clear);

  void loadMore(boolean loadMore);

  void onError(String msg);

  void clearData();

  void setFavAdapter(List<CandidateModel> candidateModelList,boolean clear);

  void setLoadMore(boolean loadMore);

  String getOffset();

  void showSmallProgress(boolean show);
  void changeFavoriteStatus(CandidateModel candidateModel);
}
