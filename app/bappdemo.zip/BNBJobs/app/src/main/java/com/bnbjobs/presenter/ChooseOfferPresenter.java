/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.support.v4.app.Fragment;
import com.bnbjobs.model.PremiumContainer;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.ChooseOfferView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import com.trello.rxlifecycle.components.support.RxFragment;
import java.util.HashMap;
import rx.Subscriber;

import static com.bnbjobs.utils.LogUtils.LOGE;

/**
 * @author Harsh
 * @version 1.0
 */
public class ChooseOfferPresenter extends BasePresenter implements Presenter<ChooseOfferView> {

  private ChooseOfferView chooseOfferView;
  private Fragment fragment;

  @Override protected Context getBaseContext() {
    return chooseOfferView.getContext();
  }

  @Override public void attachView(ChooseOfferView view) {
    this.chooseOfferView = view;
  }

  @Override public void detachView() {
    this.chooseOfferView = null;
  }

  public void getPremiumPlanData() {
    chooseOfferView.showProgress();
    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "getPremiumPlans");
    params.put("type", "2");
    params.putAll(addParams(params));

    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        chooseOfferView.hideProgress();
      }

      @Override public void onNext(String s) {
        chooseOfferView.hideProgress();
        PremiumContainer premiumDataModel = new Gson().fromJson(s, PremiumContainer.class);
        if (premiumDataModel.isSuccess()) {
          chooseOfferView.setPremiumData(premiumDataModel.getPremiumDataModel());
        }
      }
    });
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((RxFragment) fragment).bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }
}
