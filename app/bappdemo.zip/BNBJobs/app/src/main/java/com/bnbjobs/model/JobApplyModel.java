/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.bnbjobs.utils.LocaleHelper;
import com.google.gson.annotations.SerializedName;

/**
 * @author Harsh
 * @version 1.0
 */
public class JobApplyModel {

  private String dTitle;
  @SerializedName("d_title_1") private String dTitle1;
  @SerializedName("d_title_2") private String dTitle2;
  @SerializedName("d_title_3") private String dTitle3;
  @SerializedName("rp_id") private String id;



  public void setdTitle(String dTitle) {
    this.dTitle = dTitle;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getdTitle1() {
    return dTitle1;
  }

  public void setdTitle1(String dTitle1) {
    this.dTitle1 = dTitle1;
  }

  public String getdTitle2() {
    return dTitle2;
  }

  public void setdTitle2(String dTitle2) {
    this.dTitle2 = dTitle2;
  }

  public String getdTitle3() {
    return dTitle3;
  }

  public void setdTitle3(String dTitle3) {
    this.dTitle3 = dTitle3;
  }

  public String getdTitle() {
    if (LocaleHelper.isFrench()) {
      return getdTitle2();
    } else if (LocaleHelper.isSpanish()) {
      return getdTitle3();
    } else {
      return getdTitle1();
    }
  }
}
