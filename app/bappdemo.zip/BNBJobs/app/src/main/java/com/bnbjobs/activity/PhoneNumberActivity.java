/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.GradientView;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.CountryModel;
import com.bnbjobs.model.PhoneNumberEvent;
import com.bnbjobs.presenter.PhoneNumberPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.PhoneNumberView;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.OnClickListener;
import com.orhanobut.dialogplus.ViewHolder;
import io.realm.Realm;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.ActivityUtils.launchActivity;
import static com.bnbjobs.utils.LogUtils.LOGI;

/**
 * @author Harsh
 * @version 1.0
 */
public class PhoneNumberActivity extends BaseActivity implements PhoneNumberView {

  @BindView(R.id.imageBack) TinTableImageView imageBack;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.tvCountryName) TextView tvCountryName;
  @BindView(R.id.tvCountryCode) TextView tvCountryCode;
  @BindView(R.id.linearCountry) LinearLayout linearCountry;
  @BindView(R.id.etPhoneNumber) EditText etPhoneNumber;
  @BindView(R.id.tvSendCode) GradientView tvSendCode;
  @BindView(R.id.relativeProgress) RelativeLayout relativeProgress;
  private static final String TAG = PhoneNumberActivity.class.getSimpleName();
  private PhoneNumberPresenter presenter;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_phone_number);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    presenter = new PhoneNumberPresenter();
    presenter.attachView(this);
    tvTitle.setVisibility(View.VISIBLE);
    tvTitle.setText(R.string.security);
    showDialog();
    setCurrentCountry();
    if (!getIntent().hasExtra(Constants.KEY_SHOW_BACK)) {
      imageBack.setVisibility(View.GONE);
    }
  }

  @OnClick(R.id.imageBack) void onBack() {
    onBackPressed();
  }

  @OnClick(R.id.linearCountry) void onCounty(View v) {
    Intent intent = new Intent(this, CountrySelectActivity.class);
    ActivityOptions options =
        ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.getWidth(), v.getHeight());
    startActivityForResult(intent, 1234, options.toBundle());
  }

  private void setCurrentCountry() {
    Realm mRealm = Realm.getDefaultInstance();
    String code = getPrefs(this).getString(QuickstartPreferences.COUNTRY_CODE, "FR").toUpperCase();
    LOGI(TAG, "here current country: " + code);
    CountryModel countryModel = mRealm
        .where(CountryModel.class)
        .equalTo("code", code).findFirst();
    if (countryModel != null) {
      tvCountryName.setText(countryModel.getName());
      tvCountryCode.setText(countryModel.getDialCode());
    }
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == Activity.RESULT_OK && requestCode == 1234) {
      CountryModel model = data.getParcelableExtra(Constants.KEY_OBJECT);
      tvCountryName.setText(model.getName());
      tvCountryCode.setText(model.getDialCode());
    }
  }

  @OnClick(R.id.tvSendCode) void onSendCode() {
    if (isEmpty(Utils.getText(etPhoneNumber))) {
      Utils.showMessage(this, getString(R.string.enter_phone_number));
    } else {
      Utils.hideKeyboard(etPhoneNumber, this);
      presenter.getOtp(Utils.getText(tvCountryCode) + Utils.getText(etPhoneNumber));
    }
  }

  private void showDialog() {
    DialogPlus dialog = DialogPlus.newDialog(this)
        .setContentHolder(new ViewHolder(R.layout.popup_verify_phone))
        .setOnClickListener(new OnClickListener() {
          @Override public void onClick(DialogPlus dialog, View view) {
            dialog.dismiss();
          }
        })
        .setCancelable(true)
        .setGravity(Gravity.CENTER)
        .setContentBackgroundResource(Color.TRANSPARENT)
        .create();
    dialog.show();
  }

  @Override public void onBackPressed() {
    if (getIntent().hasExtra(Constants.KEY_SHOW_BACK)) {
      super.onBackPressed();
    }
  }

  @Override public void showMessage(String msg) {
    Intent intent = new Intent(this, PhoneVerifyActivity.class);
    intent.putExtra(Constants.KEY_TEXT, msg);
    intent.putExtra(Constants.KEY_NUMBER,
        Utils.getText(tvCountryCode) + Utils.getText(etPhoneNumber));
    startActivity(intent);
  }

  @Override public void showVerified() {

  }

  @Override public Context getContext() {
    return this;
  }

  @Override public void showProgress() {
    relativeProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    relativeProgress.setVisibility(View.GONE);
  }

  @Override protected void onDestroy() {
    super.onDestroy();
    presenter.detachView();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe public void onEvent(PhoneNumberEvent event) {
    if (event.isCloseCurrentActivity()) {
      if (getIntent().hasExtra(Constants.KEY_VISIBLE_TYPE)) {
        launchActivity(this, InviteActivity.class, true);
      } else {
        finish();
      }
    }
  }
}
