/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.bnbjobs.R;
import com.bnbjobs.model.ImageModel;
import com.bnbjobs.utils.Constants;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import java.util.ArrayList;
import java.util.List;
import uk.co.senab.photoview.PhotoViewAttacher;

/**
 * @author Harsh
 * @version 1.0
 */

public class ImageActivity extends BaseActivity {

  /*@BindView(R.id.imageDisplay) ImageView imageDisplay;
  private PhotoViewAttacher attacher;*/

  @BindView(R.id.viewpager) ViewPager pager;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.detail_image_activity);
    ButterKnife.bind(this);

    ArrayList<ImageModel> mImageModel =
        (ArrayList<ImageModel>) getIntent().getSerializableExtra(Constants.KEY_LIST);

    pager.setAdapter(new MyPagerAdapter(this,mImageModel));
    pager.setCurrentItem(getIntent().getIntExtra(Constants.KEY_POSITION,0));
  }

  @Override public void onBackPressed() {
    super.onBackPressed();
    supportFinishAfterTransition();
  }

  private static class MyPagerAdapter extends PagerAdapter {

    private final List<ImageModel> imageModel;
    private Context context;

    MyPagerAdapter(Context context, List<ImageModel> imageModel) {
      this.imageModel = imageModel;
      this.context = context;
    }

    @Override public int getCount() {
      return imageModel.size();
    }

    @Override public void destroyItem(ViewGroup collection, int position, Object view) {
      collection.removeView((View) view);
    }

    @Override public Object instantiateItem(ViewGroup container, int position) {
      LayoutInflater inflater = LayoutInflater.from(context);
      ViewGroup layout = (ViewGroup) inflater.inflate(R.layout.activity_image, container, false);
      final ImageView imageDisplay = (ImageView) layout.findViewById(R.id.imageDisplay);
      container.addView(layout);
      Glide.with(context)
        .load(imageModel.get(position).getImageUrl())
        .asBitmap()
        .into(new SimpleTarget<Bitmap>() {
          @Override public void onResourceReady(Bitmap resource,GlideAnimation<? super Bitmap> glideAnimation) {
            imageDisplay.setImageBitmap(resource);
            new PhotoViewAttacher(imageDisplay);
          }
        });
      return layout;
    }

    @Override public boolean isViewFromObject(View view, Object object) {
      return view == object;
    }
  }
}
