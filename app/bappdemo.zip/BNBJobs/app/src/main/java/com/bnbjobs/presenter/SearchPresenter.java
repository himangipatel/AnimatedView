/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.support.v4.app.Fragment;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.model.DesignationContainer;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.SearchView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.ActivityEvent;
import java.util.HashMap;
import rx.Subscriber;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class SearchPresenter extends BasePresenter implements Presenter<SearchView> {

  private static final String TAG = makeLogTag(SearchPresenter.class);
  private SearchView mSearchView;
  private Fragment fragment;

  @Override public void attachView(SearchView view) {
    mSearchView = view;
  }

  @Override public void detachView() {
    mSearchView = null;
  }

  public void getDesignation() {
    mSearchView.showProgress();
    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "getAllDesignations");
    params.put("language", getLanguage());
    params.put("userId", getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_ID, ""));
    params.put("accessToken",
        getPrefs(getBaseContext()).getString(QuickstartPreferences.ACCESS_TOKEN, ""));
    RestClient.getInstance(params)
        .compose(((BaseActivity) getBaseContext()).<String>bindUntilEvent(ActivityEvent.STOP))
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            LOGE(TAG, e.getMessage(), e);
            if (mSearchView != null) {
              mSearchView.hideProgress();
            }
            //retryMethod(e, false, "");
          }

          @Override public void onNext(String s) {
            if (mSearchView != null) {
              mSearchView.hideProgress();
              DesignationContainer container = new Gson().fromJson(s, DesignationContainer.class);
              if (container.isSuccess()) {
                //mSearchView.setDesignation(container.getDesignationModelsList());
              }
            }
          }
        });
  }

  @Override protected Context getBaseContext() {
    return mSearchView.getContext();
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }
}
