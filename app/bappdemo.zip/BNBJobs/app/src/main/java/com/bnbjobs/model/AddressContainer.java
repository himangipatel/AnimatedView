/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */

public class AddressContainer {

  @SerializedName("results")
  private List<AddressModel> addressModels;

  public List<AddressModel> getAddressModels() {
    return addressModels;
  }

  public void setAddressModels(List<AddressModel> addressModels) {
    this.addressModels = addressModels;
  }
}
