/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.bnbjobs.utils.LocaleHelper;
import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class JobDetail implements Parcelable{

  @SerializedName("rp_id") private int id;
  @SerializedName("rp_recruiter_id") private int recruiterId;
  @SerializedName("rp_designation_id") private int designationId;
  @SerializedName("rp_contract_type") private int contractType;
  @SerializedName("rp_start_date") private String startDate;
  @SerializedName("rp_end_date") private String endDate;
  @SerializedName("rp_location") private String location;
  @SerializedName("rp_latitude") private String lat;
  @SerializedName("rp_longitude") private String lng;
  @SerializedName("rp_references") private String reference;
  @SerializedName("rp_description") private String description;
  @SerializedName("rp_salary") private String salary;
  @SerializedName("rp_created_at") private String createdAt;
  @SerializedName("rp_status") private int status;
  @SerializedName("u_id") private int uId;
  @SerializedName("u_fname") private String fName;
  @SerializedName("u_lname") private String lName;
  @SerializedName("u_email") private String email;
  @SerializedName("u_company") private String u_company;
  @SerializedName("u_latitude") private String uLat;
  @SerializedName("u_longitude") private String uLng;
  @SerializedName("d_title") private String dTitle;
  @SerializedName("profilePercentage") private int profilePercentage;
  @SerializedName("u_image_url") private String uImageUrl;
  @SerializedName("rp_video_url") private String videoUrl;
  @SerializedName("rp_images") private List<PhotoModel> mImageList;
  @SerializedName("applyJobBtnFlag") private int applyJobBtnFlag;
  @SerializedName("rp_experience") private String experience;
  @SerializedName("rp_experience_required") private int experienceRequired;
  @SerializedName("rp_profile_per") private String profileRequired;
  @SerializedName("rp_quality") private String quality;
  @SerializedName("rp_other_benefits") private String otherBenefits;
  private String d_title_1;
  private String d_title_2;
  private String d_title_3;
  private boolean favorite_flag;

  private void readIn(Parcel in) {
    id = in.readInt();
    recruiterId = in.readInt();
    designationId = in.readInt();
    contractType = in.readInt();
    startDate = in.readString();
    endDate = in.readString();
    location = in.readString();
    lat = in.readString();
    lng = in.readString();
    reference = in.readString();
    description = in.readString();
    salary = in.readString();
    createdAt = in.readString();
    status = in.readInt();
    uId = in.readInt();
    fName = in.readString();
    lName = in.readString();
    email = in.readString();
    u_company = in.readString();
    uLat = in.readString();
    uLng = in.readString();
    dTitle = in.readString();
    profilePercentage = in.readInt();
    uImageUrl = in.readString();
    videoUrl = in.readString();
    mImageList = in.readArrayList(PhotoModel.class.getClassLoader());
    applyJobBtnFlag = in.readInt();
    experience = in.readString();
    experienceRequired = in.readInt();
    profileRequired = in.readString();
    quality = in.readString();
    otherBenefits = in.readString();
    d_title_1 = in.readString();
    d_title_2 = in.readString();
    d_title_3 = in.readString();
    favorite_flag = in.readByte() != 0;

  }

  public static final Creator<JobDetail> CREATOR = new Creator<JobDetail>() {
    @Override public JobDetail createFromParcel(Parcel in) {
      JobDetail jobDetail = new JobDetail();
      jobDetail.readIn(in);
      return jobDetail;
    }

    @Override public JobDetail[] newArray(int size) {
      return new JobDetail[size];
    }
  };

  public int getExperienceRequired() {
    return experienceRequired;
  }

  public void setExperienceRequired(int experienceRequired) {
    this.experienceRequired = experienceRequired;
  }

  public String getProfileRequired() {
    return profileRequired;
  }

  public void setProfileRequired(String profileRequired) {
    this.profileRequired = profileRequired;
  }

  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }



  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getExperience() {
    return experience;
  }

  public void setExperience(String experience) {
    this.experience = experience;
  }

  public String getQuality() {
    return quality;
  }

  public void setQuality(String quality) {
    this.quality = quality;
  }

  public String getOtherBenefits() {
    return otherBenefits;
  }

  public void setOtherBenefits(String otherBenefits) {
    this.otherBenefits = otherBenefits;
  }

  public int getRecruiterId() {
    return recruiterId;
  }

  public void setRecruiterId(int recruiterId) {
    this.recruiterId = recruiterId;
  }

  public int getDesignationId() {
    return designationId;
  }

  public void setDesignationId(int designationId) {
    this.designationId = designationId;
  }

  public int getContractType() {
    return contractType;
  }

  public void setContractType(int contractType) {
    this.contractType = contractType;
  }

  public String getStartDate() {
    return startDate;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public String getLat() {
    return lat;
  }

  public void setLat(String lat) {
    this.lat = lat;
  }

  public String getLng() {
    return lng;
  }

  public void setLng(String lng) {
    this.lng = lng;
  }

  public String getReference() {
    return reference;
  }

  public void setReference(String reference) {
    this.reference = reference;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getSalary() {
    return salary;
  }

  public void setSalary(String salary) {
    this.salary = salary;
  }

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }

  public int getuId() {
    return uId;
  }

  public void setuId(int uId) {
    this.uId = uId;
  }

  public String getfName() {
    return fName;
  }

  public void setfName(String fName) {
    this.fName = fName;
  }

  public String getlName() {
    return lName;
  }

  public void setlName(String lName) {
    this.lName = lName;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getuLat() {
    return uLat;
  }

  public void setuLat(String uLat) {
    this.uLat = uLat;
  }

  public String getuLng() {
    return uLng;
  }

  public void setuLng(String uLng) {
    this.uLng = uLng;
  }

  public String getdTitle() {
    return dTitle;
  }
  public String getTitle() {
    if (LocaleHelper.isFrench()) {
      return getD_title_2();
    } else if (LocaleHelper.isSpanish()) {
      return getD_title_3();
    } else {
      return getD_title_1();
    }
  }

  public String getD_title_1() {
    return d_title_1;
  }

  public String getD_title_2() {
    return d_title_2;
  }

  public String getD_title_3() {
    return d_title_3;
  }

  public void setdTitle(String dTitle) {
    this.dTitle = dTitle;
  }

  public int getProfilePercentage() {
    return profilePercentage;
  }

  public void setProfilePercentage(int profilePercentage) {
    this.profilePercentage = profilePercentage;
  }

  public String getuImageUrl() {
    return uImageUrl;
  }

  public void setuImageUrl(String uImageUrl) {
    this.uImageUrl = uImageUrl;
  }

  public String getVideoUrl() {
    return videoUrl;
  }

  public void setVideoUrl(String videoUrl) {
    this.videoUrl = videoUrl;
  }

  public List<PhotoModel> getmImageList() {
    return mImageList;
  }

  public void setmImageList(List<PhotoModel> mImageList) {
    this.mImageList = mImageList;
  }

  public int getApplyJobBtnFlag() {
    return applyJobBtnFlag;
  }

  public void setApplyJobBtnFlag(int applyJobBtnFlag) {
    this.applyJobBtnFlag = applyJobBtnFlag;
  }

  public String getU_company() {
    return u_company;
  }

  public void setU_company(String u_company) {
    this.u_company = u_company;
  }

  public boolean isFavorite_flag() {
    return favorite_flag;
  }

  @Override public int describeContents() {
    return 0;
  }

  @Override public void writeToParcel(Parcel dest, int flags) {
    dest.writeInt(id);
    dest.writeInt(recruiterId);
    dest.writeInt(designationId);
    dest.writeInt(contractType);
    dest.writeString(startDate);
    dest.writeString(endDate);
    dest.writeString(location);
    dest.writeString(lat);
    dest.writeString(lng);
    dest.writeString(reference);
    dest.writeString(description);
    dest.writeString(salary);
    dest.writeString(createdAt);
    dest.writeInt(status);
    dest.writeInt(uId);
    dest.writeString(fName);
    dest.writeString(lName);
    dest.writeString(email);
    dest.writeString(u_company);
    dest.writeString(uLat);
    dest.writeString(uLng);
    dest.writeString(dTitle);
    dest.writeInt(profilePercentage);
    dest.writeString(uImageUrl);
    dest.writeString(videoUrl);
    dest.writeList(mImageList);
    dest.writeInt(applyJobBtnFlag);
    dest.writeString(experience);
    dest.writeInt(experienceRequired);
    dest.writeString(profileRequired);
    dest.writeString(quality);
    dest.writeString(otherBenefits);
    dest.writeString(d_title_1);
    dest.writeString(d_title_2);
    dest.writeString(d_title_3);
    dest.writeByte((byte) (favorite_flag ? 1 : 0));
  }
}


