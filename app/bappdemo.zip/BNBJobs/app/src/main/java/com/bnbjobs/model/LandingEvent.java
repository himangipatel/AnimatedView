/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

/**
 * @author Harsh
 * @version 1.0
 */
public class LandingEvent {
  public boolean isFinish;

  public LandingEvent(boolean isFinish) {
    this.isFinish = isFinish;
  }
}
