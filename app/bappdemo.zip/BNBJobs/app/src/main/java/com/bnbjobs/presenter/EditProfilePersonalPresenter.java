package com.bnbjobs.presenter;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;

import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.model.ProfileContainer;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.AeSimpleSHA1;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.EditPersonalProfileView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.ActivityEvent;
import com.trello.rxlifecycle.LifecycleTransformer;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;

import okhttp3.RequestBody;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * Created by imobdev on 17/10/16.
 */

public class EditProfilePersonalPresenter extends BasePresenter implements Presenter<EditPersonalProfileView> {

    private final static String TAG = makeLogTag(EditProfilePersonalPresenter.class);
    private EditPersonalProfileView mEditProfileView;
    private int descriptionLimit = 100;
    private String appendCharText;

    @Override
    protected Context getBaseContext() {
        return mEditProfileView.getContext();
    }


    @Override
    public void attachView(EditPersonalProfileView view) {
        mEditProfileView = view;
    }

    @Override
    public void detachView() {
        mEditProfileView = null;
    }

    public TextWatcher descriptionWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            if (s.toString().length() <= descriptionLimit) {
                mEditProfileView.setLengthView(String.valueOf(s.toString().length()), appendCharText);
            }
        }
    };

    public void getCandidateProfile() {
        appendCharText = " /" + descriptionLimit;

        mEditProfileView.showProgress();
        HashMap<String, String> params = new HashMap<>(4);
        params.put("apiName", "getPersonalProfile");
        addParams(params);
        RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
                mEditProfileView.hideProgress();
                LOGE(TAG, e.getMessage(), e);
            }

            @Override
            public void onNext(String s) {
                mEditProfileView.hideProgress();
                ProfileContainer container = new Gson().fromJson(s, ProfileContainer.class);
                if (container.isSuccess()) {
                    mEditProfileView.setPersonalData(container.getData());
                }
            }
        });
    }

    private LifecycleTransformer<String> getBindEvent() {
        return ((BaseActivity) getBaseContext()).bindUntilEvent(ActivityEvent.DESTROY);
    }

    private boolean isValid() {
        if (!Utils.isValidEmail(mEditProfileView.getEmail())) {
            showMessage(getBaseContext(), getString(R.string.enter_valid_email_address));
            return false;
        } else if (isEmpty(mEditProfileView.getFirstName())) {
            showMessage(getBaseContext(), getString(R.string.enter_valid_first_name));
            return false;
        } else if (isEmpty(mEditProfileView.getLastName())) {
            showMessage(getBaseContext(), getString(R.string.enter_valid_last_name));
            return false;
        } else if (isEmpty(mEditProfileView.getPhoneNumber())) {
            showMessage(getBaseContext(), getString(R.string.enter_your_phone_number));
            return false;
        } else if (isEmpty(mEditProfileView.getDesignation())) {
            showMessage(getBaseContext(), getString(R.string.enter_designation));
            return false;
        } else if (mEditProfileView.getGender() == 0) {
            showMessage(getBaseContext(), getString(R.string.enter_gender));
            return false;
        }
        return true;
    }

    public void updateProfile() {
        if (isValid()) {

            mEditProfileView.showProgress();
            HashMap<String, RequestBody> params = new HashMap<>(15);
            params.put("apiName", toRequestBody("updatePersonalProfile"));
            params.put("firstname", toRequestBody(mEditProfileView.getFirstName()));
            params.put("lastname", toRequestBody(mEditProfileView.getLastName()));
            params.put("email", toRequestBody(mEditProfileView.getEmail()));
            params.put("phone", toRequestBody(mEditProfileView.getPhoneNumber()));
            params.put("active_search", toRequestBody(mEditProfileView.getActiveSearch()));
            if (!isEmpty(mEditProfileView.getChangePassword())) {
                try {
                    params.put("password", toRequestBody(AeSimpleSHA1.SHA1(mEditProfileView.getChangePassword())));
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
            if(mEditProfileView.getDesignationId().length()>0)
            params.put("designationId", toRequestBody(mEditProfileView.getDesignationId()));
            if (!isEmpty(mEditProfileView.getDescription()))
                params.put("about_me", toRequestBody(mEditProfileView.getDescription()));
            params.put("gender", toRequestBody(String.valueOf(mEditProfileView.getGender())));
            if (!isEmpty(mEditProfileView.getBirthDate()))
                params.put("date_of_birth", toRequestBody(mEditProfileView.getBirthDateTimeStamp()));


            params.putAll(addParamsBody(params));
            RestClient.getInstance()
                    .apiCallImage(params)
                    .compose(getBindEvent())
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Subscriber<String>() {
                        @Override
                        public void onCompleted() {
                        }

                        @Override
                        public void onError(Throwable e) {
                            LOGE(TAG, e.getMessage(), e);
                            mEditProfileView.hideProgress();
                        }

                        @Override
                        public void onNext(String s) {
                            mEditProfileView.hideProgress();
                            try {
                                JSONObject object = new JSONObject(s);
                                ProfileContainer container = new Gson().fromJson(s, ProfileContainer.class);
                                if (container.isSuccess()) {
                                    JSONObject dataObject = object.getJSONObject("data");
                                    JSONObject userObject = dataObject.getJSONObject("userData");
                                    getPrefs(getBaseContext()).save(QuickstartPreferences.USER_PHONENUMBER,userObject.optString("u_phone", ""));
                                    mEditProfileView.onUpdated(container.getData());
                                }
                            } catch (JSONException e) {
                                LOGE(TAG, e.getMessage(), e);
                            }
                        }
                    });
        }
    }
}
