/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.activity.DesignationSelectActivity;
import com.bnbjobs.adapter.DesignationChildAdapter;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.DesignationDbModel;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.LogUtils;
import com.bnbjobs.utils.SimpleDividerItemDecoration;
import io.realm.Realm;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class DesignationChildFragment extends BaseFragment
    implements ClickImpl<DesignationDbModel> {

  @BindView(R.id.imgCancel) ImageView mImgCancel;
  @BindView(R.id.recyclerDesignation) RecyclerView mRecyclerDesignation;
  @BindView(R.id.tvDesignationTitle) TextView mTvDesignationTitle;
  @BindView(R.id.tvParentDesignation) TextView mTvParentDesignation;
  private List<DesignationDbModel> mList = new ArrayList<>();
  private DesignationChildAdapter mAdapter;
  private List<String> selectedIds;
  private Unbinder unbinder;
  private static final String TAG = LogUtils.makeLogTag(DesignationChildFragment.class);

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_designation_list, container, false);
    unbinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    if (!((DesignationSelectActivity) getActivity()).showCancel()) {
      mImgCancel.setVisibility(View.GONE);
    }
    mRecyclerDesignation.setLayoutManager(new LinearLayoutManager(getActivity()));
    mRecyclerDesignation.addItemDecoration(new SimpleDividerItemDecoration(getActivity()));
    selectedIds = ((DesignationSelectActivity) getActivity()).getArrayList();
    getData(getArguments().getInt(Constants.KEY_ID));
  }

  /**
   * show data as per id
   *
   * @param id id of designation field
   */
  private void getData(int id) {
    mTvParentDesignation.setText(getArguments().getString(Constants.KEY_TEXT));
    mList = DesignationDbModel.getDesignationList(id);
    mAdapter = new DesignationChildAdapter(getActivity(), mList, this);
    mAdapter.setSelectedIds(selectedIds);
    mRecyclerDesignation.setAdapter(mAdapter);
  }

  /**
   * @param view clicked view
   * @param object clicked object
   * @param position clicked position
   */
  @Override public void onClick(View view, DesignationDbModel object, int position) {
    if (selectedIds.contains(Integer.toString(object.getD_id()))) {
      selectedIds.remove(Integer.toString(object.getD_id()));
    } else {
      selectedIds.add(Integer.toString(object.getD_id()));
    }
    mAdapter.notifyItemChanged(position);
    if (((DesignationSelectActivity) getActivity()).isSingleChoice()) {
      ((DesignationSelectActivity) getActivity()).onFilter();
    }
  }

  @OnClick(R.id.tvParentDesignation) void onDesignationClick() {
    getFragmentManager().popBackStack();
  }

  @Override public void onDestroyView() {
    super.onDestroyView();
    unbinder.unbind();
  }

  @OnClick(R.id.imgCancel) void onCancel() {
    getActivity().finish();
  }
}
