/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.CountryModel;
import com.bnbjobs.utils.Constants;
import io.realm.Realm;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class CountrySelectActivity extends BaseActivity {


  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    LinearLayout mLinearLayout = new LinearLayout(this);
    mLinearLayout.setOrientation(LinearLayout.VERTICAL);
    View view = LayoutInflater.from(this).inflate(R.layout.header_layout, mLinearLayout, false);
    mLinearLayout.addView(view);
    mLinearLayout.setBackgroundColor(Color.WHITE);
    RecyclerView mRecyclerView = new RecyclerView(this);
    mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    mLinearLayout.addView(mRecyclerView);
    setContentView(mLinearLayout);
    Realm  mRealm = Realm.getDefaultInstance();
    List<CountryModel> mList = mRealm.where(CountryModel.class).findAll();
    mRecyclerView.setAdapter(new CountryAdapter(mList));
    ViewHolder mViewHolder = new ViewHolder(view);
    view.setBackgroundColor(ActivityCompat.getColor(this, R.color.colorPrimary));
    mViewHolder.tvTitle.setText(R.string.select_country);
    mViewHolder.tvTitle.setTextColor(Color.WHITE);
    mViewHolder.tvTitle.setVisibility(View.VISIBLE);
  }

  class CountryAdapter extends RecyclerView.Adapter<CountryAdapter.MyViewHolder> {

    private List<CountryModel> mCountryList;

    CountryAdapter(List<CountryModel> mCountryList) {
      this.mCountryList = mCountryList;
    }

    @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
      View view = LayoutInflater.from(parent.getContext())
          .inflate(R.layout.inflater_country_adapter, parent, false);
      return new MyViewHolder(view);
    }

    @Override public void onBindViewHolder(MyViewHolder holder, int position) {
      holder.bindData(mCountryList.get(position));
    }

    @Override public int getItemCount() {
      return mCountryList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
      @BindView(R.id.tvCountryName) TextView tvCountryName;
      @BindView(R.id.tvCountryCode) TextView tvCountryCode;

      public MyViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
      }

      void bindData(CountryModel countryModel) {
        tvCountryCode.setText(countryModel.getDialCode());
        tvCountryName.setText(countryModel.getName());
      }
      @OnClick(R.id.linearItem) void onItemClick(){
        Intent intent = new Intent();
        intent.putExtra(Constants.KEY_OBJECT, mCountryList.get(getLayoutPosition()));
        setResult(RESULT_OK, intent);
        finish();
      }

    }
  }

  static class ViewHolder {
    @BindView(R.id.imageBack) TinTableImageView imageBack;
    @BindView(R.id.tvTitle) TextView tvTitle;
    @BindView(R.id.imageCenterLogo) ImageView imageCenterLogo;
    @BindView(R.id.rightImage) TinTableImageView rightImage;
    @BindView(R.id.tvSkip) TextView tvSkip;
    @BindView(R.id.toolbar) Toolbar toolbar;

    ViewHolder(View view) {
      ButterKnife.bind(this, view);
    }
  }
}
