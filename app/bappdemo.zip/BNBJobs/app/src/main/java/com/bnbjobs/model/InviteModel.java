/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.bnbjobs.utils.Utils;

/**
 * @author Harsh
 * @version 1.0
 */
public class InviteModel {

  private String id;
  private String name;
  private String phoneNumber;
  private String photoId;
  private String address;
  private String comparePhoneNumber;
  private boolean isInvited;

  public String getComparePhoneNumber() {
    return comparePhoneNumber;
  }

  public void setComparePhoneNumber(String comparePhoneNumber) {
    this.comparePhoneNumber = comparePhoneNumber;
  }

  public boolean isInvited() {
    return isInvited;
  }

  public void setInvited(boolean invited) {
    isInvited = invited;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return Utils.capitalize(name);
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public String getPhotoId() {
    return photoId;
  }

  public void setPhotoId(String photoId) {
    this.photoId = photoId;
  }
}
