/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class NotificationContainer {
  private boolean success;
  private String message;
  @SerializedName("data") private List<NotificationModel> mNotificationModel;

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public List<NotificationModel> getmNotificationModel() {
    return mNotificationModel;
  }

  public void setmNotificationModel(List<NotificationModel> mNotificationModel) {
    this.mNotificationModel = mNotificationModel;
  }
}
