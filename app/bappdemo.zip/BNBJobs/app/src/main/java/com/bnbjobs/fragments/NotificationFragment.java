/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.adapter.NotificationAdapter;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.NotificationModel;
import com.bnbjobs.presenter.NotificationPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.SimpleDividerItemDecoration;
import com.bnbjobs.view.NotificationView;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class NotificationFragment extends BaseFragment
    implements NotificationView, ClickImpl<NotificationModel> {

  @BindView(R.id.recyclerView) RecyclerView recyclerView;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;

  private NotificationAdapter adapter;
  private Unbinder unbinder;
  private NotificationPresenter presenter;
  private List<NotificationModel> mNotificationModelList = new ArrayList<>();

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    presenter = new NotificationPresenter();
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_notification, container, false);
    unbinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
    presenter.attachView(this);
    presenter.setFragment(this);
    setTitle(getString(R.string.notification));
    if (adapter == null) {
      adapter = new NotificationAdapter(getActivity(), mNotificationModelList, this);
    }
    recyclerView.addItemDecoration(new SimpleDividerItemDecoration(getActivity()));
    recyclerView.setAdapter(adapter);
    if (mNotificationModelList.isEmpty()) {
      presenter.getNotification();
    }
  }

  @Override public void onResume() {
    super.onResume();
    resetToolbar();
    showLeftImage(false);
    showToolbar(true);
  }

  @Override public void onDestroyView() {
    super.onDestroyView();
    unbinder.unbind();
    presenter.detachView();
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void setData(List<NotificationModel> mNotificationModel) {
    mNotificationModelList.addAll(mNotificationModel);
    adapter.notifyDataSetChanged();
  }

  @Override public void onClick(View view, NotificationModel object, int position) {
    BestCandidateFragment mFragment = new BestCandidateFragment();
    Bundle bundle = new Bundle();
    bundle.putString(Constants.KEY_ID, Integer.toString(object.getOfferId()));
    mFragment.setArguments(bundle);
    addFragment(mFragment, true);
  }
}
