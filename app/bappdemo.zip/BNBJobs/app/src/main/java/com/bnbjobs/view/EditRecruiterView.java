/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.bnbjobs.model.UserModel;
import java.io.File;

/**
 * @author Harsh
 * @version 1.0
 */
public interface EditRecruiterView extends MainView {

  File getProfilePhoto();

  File getBannerImage();

  void openCamera(boolean banner);

  void openGallery(boolean banner);

  void showPhoto(String path);

  void showBannerPath(String path);

  void setDefault(boolean banner);

  boolean isImageSet();

  String getEmail();

  String getPassword();

  String getAddress();

  String getFirstName();

  String getLastName();

  String getPhoneNumber();

  String getCompanyName();

  void onUpdated(UserModel mData);
}
