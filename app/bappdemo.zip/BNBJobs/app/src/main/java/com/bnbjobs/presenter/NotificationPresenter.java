/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.app.Fragment;
import com.bnbjobs.R;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.NotificationContainer;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.NotificationView;
import com.google.gson.Gson;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import rx.Subscriber;

import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */
public class NotificationPresenter extends BasePresenter implements Presenter<NotificationView> {

  private static final String TAG = makeLogTag(NotificationPresenter.class);
  private NotificationView mNotificationView;
  private Fragment fragment;

  @Override public void attachView(NotificationView view) {
    mNotificationView = view;
  }

  @Override public void detachView() {
    mNotificationView = null;
  }

  @Override protected Context getBaseContext() {
    return mNotificationView.getContext();
  }

  public void getNotification() {
    mNotificationView.showProgress();
    HashMap<String, String> params = new HashMap<>(5);
    params.put("apiName", "getNotification");
    params.putAll(addParams(params));

    RestClient.getInstance(params).compose(getBindEvent()).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        LOGE(TAG, e.getMessage(), e);
        mNotificationView.hideProgress();
        retryMethod(e);
      }

      @Override public void onNext(String s) {
        mNotificationView.hideProgress();
        if (isResponseSuccess(s)) {
          NotificationContainer container = new Gson().fromJson(s, NotificationContainer.class);
          mNotificationView.setData(container.getmNotificationModel());
        }
      }
    });
  }

  /**
   * retry
   *
   * @param e throwable
   */
  private void retryMethod(final Throwable e) {
    String error = "";
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            getNotification();
          }
        }).show();
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).<String>bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  public void setFragment(Fragment fragment) {
    this.fragment = fragment;
  }
}
