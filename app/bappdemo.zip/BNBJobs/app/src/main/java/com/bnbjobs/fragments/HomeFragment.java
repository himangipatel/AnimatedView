/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnEditorAction;
import butterknife.OnTouch;
import butterknife.Unbinder;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.adapter.HomeAdapter;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.JobModel;
import com.bnbjobs.presenter.HomeFragmentPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.EndlessRecyclerViewScrollListener;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.HomeFragmentView;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import java.util.ArrayList;
import java.util.List;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;

/**
 * @author Harsh
 * @version 1.0
 */
public class HomeFragment extends BaseFragment implements HomeFragmentView, ClickImpl<Object> {

  private static final String TAG = makeLogTag(HomeFragment.class);
  private static final int REGULAR_TYPE = 1;
  private static final int PULL_TYPE = 2;
  private static final int SEARCH_TYPE = 3;
  @BindView(R.id.recyclerView) RecyclerView recyclerView;
  @BindView(R.id.imageFilter) ImageView imageFilter;
  @BindView(R.id.etSearch) EditText etSearch;
  @BindView(R.id.tvCurrentLocation) TextView tvCurrentLocation;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.swipeRefresh) SwipeRefreshLayout mSwipeRefresh;
  @BindView(R.id.tvNoRecord) TextView tvNoRecord;
  @BindView(R.id.linearFilter) LinearLayout linearFilter;
  @BindView(R.id.linearSearch) LinearLayout linearSearch;
  @BindView(R.id.tvDone) TextView tvDone;
  @BindView(R.id.cddCheck) CheckBox mCddCheck;
  @BindView(R.id.cdiCheck) CheckBox mCdiCheck;
  @BindView(R.id.interimCheck) CheckBox mInterimCheck;
  private HomeFragmentPresenter presenter;
  private Unbinder unbinder;
  private HomeAdapter adapter;
  private boolean loadMore;
  private List<JobModel> mJobModelList = new ArrayList<>();
  private int height = -1;
  private int PLACE_AUTOCOMPLETE_REQUEST_CODE = 1111;
  private EndlessRecyclerViewScrollListener listener;
  private boolean isFooterAdd;

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_home, container, false);
    unbinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    if (presenter == null) {
      presenter = new HomeFragmentPresenter();
    }
    presenter.attachView(this);
    presenter.setFragment(this);
    tvCurrentLocation.setText(
        getPrefs(getActivity()).getString(QuickstartPreferences.PLACE_NAME, ""));
    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
    recyclerView.setLayoutManager(linearLayoutManager);
    if (savedInstanceState == null) {
      presenter.setFilterString(getFilter());
    }
    // get height of recycler view and device item view into two equal part
    // and if fragment restore from backstack then it won't calculate again
    // we direct set adapter object to recyclerview
    if (height == -1) {
      recyclerView.post(new Runnable() {
        @Override public void run() {
          if (recyclerView != null) {
            height = recyclerView.getHeight();
            adapter = new HomeAdapter(getActivity(), height, mJobModelList, HomeFragment.this);
            recyclerView.setAdapter(adapter);
          }
        }
      });
    } else {
      if (adapter != null) {
        recyclerView.setAdapter(adapter);
      }
    }
    presenter.onSearch(etSearch);
    if (adapter == null || mJobModelList.size() < 1) {
      showProgress();
      presenter.getAllCandidates(REGULAR_TYPE);
    }
    mSwipeRefresh.setColorSchemeResources(R.color.colorPrimary, R.color.theme_blue,R.color.theme_pink, android.R.color.holo_orange_dark);
    mSwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
      @Override public void onRefresh() {
        onRefreshCall();
      }
    });
    recyclerView.setOnTouchListener(new View.OnTouchListener() {
      @Override public boolean onTouch(View v, MotionEvent event) {
        if (etSearch.hasFocus()) {
          clearFocus();
        }
        if (linearFilter.isShown()) {
          onFilter();
        }
        return false;
      }
    });
    etSearch.setOnFocusChangeListener(new View.OnFocusChangeListener() {
      @Override public void onFocusChange(View v, boolean hasFocus) {
        if (hasFocus) {
          if (linearFilter.isShown()) {
            onFilter();
          }
        }
      }
    });
    recyclerView.addOnScrollListener(new EndlessRecyclerViewScrollListener(linearLayoutManager) {
      @Override public void onLoadMore(int page, int totalItemsCount) {
        listener = this;
        if (loadMore) {
          isFooterAdd = true;
          mJobModelList.add(null);
          adapter.notifyItemInserted(mJobModelList.size() - 1);
          presenter.getAllCandidates(isEmpty(Utils.getText(etSearch)) ? REGULAR_TYPE : SEARCH_TYPE);
        }
      }
    });
  }

  private void onRefreshCall() {
    if (listener != null) {
      listener.setLoading(false);
    }
    presenter.resetRequest(PULL_TYPE);
  }

  private void clearFocus() {
    etSearch.clearFocus();
    InputMethodManager imm = (InputMethodManager) getActivity().getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.hideSoftInputFromWindow(etSearch.getWindowToken(), 0);
  }

  @Override public void onResume() {
    super.onResume();
    showToolbar(false);
  }

  @Override public void onPause() {
    super.onPause();
    if (linearFilter.isShown()) {
      onFilter();
    }
  }

  @OnClick(R.id.imageFilter) void onFilter() {
    if (!linearFilter.isShown()) {
      linearFilter.setVisibility(View.VISIBLE);
      linearFilter.animate()
          .translationYBy(linearFilter.getHeight())
          .setDuration(400)
          .translationY(0)
          .setListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
              super.onAnimationEnd(animation);
              linearFilter.setVisibility(View.VISIBLE);
            }
          })
          .start();
    } else {
      linearFilter.animate()
          .translationYBy(0)
          .setDuration(400)
          .translationY(-linearFilter.getHeight())
          .setListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
              super.onAnimationEnd(animation);
              if (linearFilter != null) {
                linearFilter.setVisibility(View.GONE);
              }
            }
          })
          .start();
    }
  }

  @OnTouch(R.id.linearFilter) boolean relativeFilter() {
    return true;
  }

  @OnClick(R.id.tvDone) void onDone() {
    if (linearFilter.isShown()) {
      onFilter();
    }
    presenter.setFilterString(getFilter());
    mSwipeRefresh.setRefreshing(true);
    onRefreshCall();
  }

  private String getFilter() {
    String filter = "";
    if (mCddCheck.isChecked()) {
      filter += "1,";
    }
    if (mCdiCheck.isChecked()) {
      filter += "2,";
    }
    if (mInterimCheck.isChecked()) {
      filter += "3";
    }
    if (filter.endsWith(",")) {
      return filter.substring(0, filter.length() - 1);
    }
    return filter;
  }

  @OnEditorAction(R.id.etSearch) boolean onSearchPress(TextView v, int actionId, KeyEvent event) {
    if (actionId == EditorInfo.IME_ACTION_SEARCH) {
      clearFocus();
      return true;
    }
    return false;
  }

  @Override public void onDestroyView() {
    presenter.detachView();
    unbinder.unbind();
    super.onDestroyView();
  }

  @OnClick(R.id.tvCurrentLocation) void onCurrentLocation() {
    findPlace();
  }

  private void findPlace() {
    try {
      Intent intent =
          new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY).build(getActivity());
      startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
    } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
      LOGE(TAG, e.getMessage(), e);
    }
  }

  @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
      if (resultCode == Activity.RESULT_OK) {
        Place place = PlaceAutocomplete.getPlace(getActivity(), data);
        tvCurrentLocation.setText(place.getName());
        getPrefs(getActivity()).save(QuickstartPreferences.PLACE_NAME,
            String.valueOf(place.getName()));
        getPrefs(getActivity()).save(QuickstartPreferences.LAT,
            String.valueOf(place.getLatLng().latitude));
        getPrefs(getActivity()).save(QuickstartPreferences.LNG,
            String.valueOf(place.getLatLng().longitude));
        if (listener != null) {
          listener.setLoading(false);
        }
        presenter.updateUserLocation();
      } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
        Status status = PlaceAutocomplete.getStatus(getActivity(), data);
        LOGI(TAG, status.getStatusMessage());
      } else if (resultCode == Activity.RESULT_CANCELED) {
        LOGI(TAG, "User cancel");
      }
    }
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public Context getContext() {
    return getActivity();
  }

  @Override public void setAdapter(List<JobModel> mJobModelList) {
    if (isFooterAdd) {
      isFooterAdd = false;
      this.mJobModelList.remove(this.mJobModelList.size() - 1);
      adapter.notifyItemRemoved(this.mJobModelList.size());
    }
    if (mSwipeRefresh.isRefreshing() || mJobModelList.size() < 1) {
      this.mJobModelList.clear();
      mSwipeRefresh.setRefreshing(false);
    }
    this.mJobModelList.addAll(mJobModelList);
    adapter.notifyDataSetChanged();
    if (adapter.getItemCount() > 0) {
      tvNoRecord.setVisibility(View.GONE);
    } else {
      tvNoRecord.setVisibility(View.VISIBLE);
    }
  }

  @Override public void loadMore(boolean loadMore) {
    this.loadMore = loadMore;
  }

  @Override public void onError() {
    if (mSwipeRefresh.isRefreshing()) {
      mSwipeRefresh.setRefreshing(false);
    }
  }

  @Override public void clearData() {
    mJobModelList.clear();
  }

  @Override public void onClick(View view, Object object, int position) {
    if (object instanceof JobModel) {
      JobModel model = (JobModel) object;
      Bundle bundle = new Bundle();
      bundle.putString(Constants.KEY_ID, model.getRpId());
      bundle.putInt(Constants.KEY_POSITION, position);
      JobDetailFragment fragment = new JobDetailFragment();
      fragment.setTargetFragment(this, 1111);
      fragment.setArguments(bundle);
      ((HomeActivity) getActivity()).switchFragment(fragment, true);
    }
  }
}
