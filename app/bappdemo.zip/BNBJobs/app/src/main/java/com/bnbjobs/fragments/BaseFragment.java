/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.activity.VerifyPhoneActivity;
import com.bnbjobs.utils.ActivityUtils;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Prefs;
import com.trello.rxlifecycle.components.support.RxFragment;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import static com.bnbjobs.main.AppClass.getPrefs;

/**
 * @author Harsh
 * @version 1.0
 */
public abstract class BaseFragment extends RxFragment {

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
  }

  public void setStatusBarColorTheme() {
    ((BaseActivity) getActivity()).setStatusBarColorTheme();
  }

  public void setStatusBarColorThemeLight() {
    ((BaseActivity) getActivity()).setStatusBarColor();
  }

  @Override public void onResume() {
    super.onResume();
    if (this instanceof HomeRecruiterFragment) {
      setStatusBarColorThemeLight();
    } else {
      setStatusBarColorTheme();
    }
  }

  protected boolean isCandidate() {
    return getPrefs(getActivity()).getString(QuickstartPreferences.USER_TYPE, "")
        .equalsIgnoreCase(Constants.CANDIDATE);
  }

  protected void changeToolbarColor(int color) {
    ((HomeActivity) getActivity()).changeToolBarColor(color);
  }

  protected void setRightImageColor(int color) {
    ((HomeActivity) getActivity()).setRightImageColor(color);
  }

  protected void setRightImage(int res) {
    ((HomeActivity) getActivity()).setRightImage(res);
  }

  protected void setBackImageColor(int color) {
    ((HomeActivity) getActivity()).setImageBackColor(color);
  }

  protected void showToolbar(boolean show) {
    ((HomeActivity) getActivity()).showHeader(show);
  }

  protected void showRightImage(boolean show) {
    ((HomeActivity) getActivity()).showRightImage(show);
  }

  protected void setTitle(String title) {
    ((HomeActivity) getActivity()).setToolbarTitle(title);
  }

  public void onBack(View view) {

  }

  public void onRight(View view) {
  }

  protected Toolbar getToolbar() {
    return ((HomeActivity) getActivity()).getToolbar();
  }

  public boolean onBackPressed() {
    return false;
  }

  /**
   * Checks if the device has network connectivity
   *
   * @return true if network is connected
   */
  protected boolean hasNetworkConnectivity() {
    ConnectivityManager connectivityManager = (ConnectivityManager) getActivity().getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
    NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
    return networkInfo != null && networkInfo.isConnectedOrConnecting();
  }

  protected String showDate(String date) {
    Long _sLong = Long.parseLong(date);
    DateTime _startDate = new DateTime(_sLong * 1000L);
    DateTimeFormatter formatter = DateTimeFormat.forPattern("dd MMMM yyyy");
    return formatter.print(_startDate);
  }

  public void addFragment(Fragment fragment, boolean addToBackStack) {
    ((HomeActivity) getActivity()).switchFragment(fragment, addToBackStack);
  }

  protected void setWhiteToolbar() {
    showRightImage(false);
    setBackImageColor(ActivityCompat.getColor(getActivity(), android.R.color.transparent));
    showToolbar(true);
    changeToolbarColor(Color.WHITE);
  }

  protected void setupUI(View view) {
    //Set up touch listener for non-text box views to hide keyboard.
    if (!(view instanceof EditText)) {
      view.setOnTouchListener(new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
          return false;
        }
      });
    }
    //If a layout container, iterate over children and seed recursion.
    if (view instanceof ViewGroup) {
      for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
        View innerView = ((ViewGroup) view).getChildAt(i);
        setupUI(innerView);
      }
    }
  }

  @Override public void onStop() {
    super.onStop();
    if (getActivity() instanceof HomeActivity) {
      resetToolbar();
    }
  }

  @Override public void onDestroyView() {
    super.onDestroyView();
  }

  protected void resetToolbar() {
    ((HomeActivity) getActivity()).resetToolbar();
  }

  protected void showLeftImage(boolean show) {
    ((HomeActivity) getActivity()).showLeftImage(show);
  }

  protected boolean checkPhoneVerified() {
    return getPrefs(getContext()).getInt(QuickstartPreferences.USER_PHONE_VERIFIED, 0) == 1;
  }

  protected void navigateToVerifyPhoneActivity() {
    ActivityUtils.launchActivity((Activity) getContext(), VerifyPhoneActivity.class, false);
  }

  protected void disableEnableControls(boolean enable, ViewGroup vg) {
    for (int i = 0; i < vg.getChildCount(); i++) {
      View child = vg.getChildAt(i);
      child.setEnabled(enable);
      if (child instanceof ViewGroup) {
        disableEnableControls(enable, (ViewGroup) child);
      }
    }
  }

  public void updateList(final String offerId) {

  }
  public static int getUserId(Context context){
    return Integer.parseInt(Prefs.with(context).getString(QuickstartPreferences.USER_ID,"0"));
  }
}
