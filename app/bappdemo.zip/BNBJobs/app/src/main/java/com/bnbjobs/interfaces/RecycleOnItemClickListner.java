/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.interfaces;

import android.view.View;

/**
 * Created by imobdev on 17/5/16.
 */
public interface RecycleOnItemClickListner {
  public void onItemClick(View view, int position);
}
