package com.bnbjobs.view;

import com.bnbjobs.model.ProfileData;

/**
 * Created by imobdev on 17/10/16.
 */

public interface EditPersonalProfileView extends MainView {
    void setPersonalData(ProfileData mData);

    int getGender();

    String getDescription();

    String getDesignationId();

    String getBirthDateTimeStamp();

    void setLengthView(String currentString, String totalString);

    String getEmail();

    String getBirthDate();


    String getFirstName();

    String getLastName();

    String getPhoneNumber();

    String getDesignation();

    String getChangePassword();
    String getActiveSearch();



    void onUpdated(ProfileData mData);

}
