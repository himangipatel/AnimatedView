/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.activity.InviteActivity;
import com.bnbjobs.customui.views.GradientView;
import com.bnbjobs.model.PhoneNumberEvent;
import com.bnbjobs.utils.Constants;
import java.util.Locale;
import org.greenrobot.eventbus.EventBus;

import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.ActivityUtils.launchActivity;
import static com.bnbjobs.utils.Utils.hasMarshmallow;

/**
 * @author imobdevtech
 * @version 1.0
 */
public class InviteFragment extends DialogFragment {

  @BindView(R.id.tvCandidate) GradientView tvCandidate;
  @BindView(R.id.tvSkip) TextView tvSkip;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.tvDescription) TextView tvDescription;
  @BindView(R.id.iv_invite) ImageView ivInvite;
  private Unbinder unbinder;

  private int inviteImageType;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setStyle(DialogFragment.STYLE_NO_TITLE, R.style.DialogTheme);
    inviteImageType = getArguments().getInt(Constants.KEY_DIALOG_TYPE);
  }

  @Nullable @Override public View onCreateView(LayoutInflater inflater, ViewGroup container,
      Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.popup_invite, container, false);
    unbinder = ButterKnife.bind(this, view);
    setData();
    return view;
  }

  @OnClick(R.id.tvCandidate) void onCandidate() {
    if (getPrefs(getActivity()).getBoolean(QuickstartPreferences.IS_NORMAL_USER, true)) {
      if (hasMarshmallow()) {
        ((InviteActivity) getActivity()).checkPermission();
      }
    }
    dismiss();
  }

  @OnClick(R.id.tvSkip) void onSkip() {
    if (inviteImageType == Constants.JOB_APPLIED_TYPE) {
      dismiss();
    } else if (inviteImageType == Constants.CANDIDATE_ACCEPT) {
      dismiss();
    } else if (inviteImageType == Constants.CANDIDATE_REJECT) {
      dismiss();
    } else if (inviteImageType == Constants.PHONE_VERIFIED) {
      EventBus.getDefault().post(new PhoneNumberEvent(true));
      dismiss();
      getActivity().finish();
    } else {
      launchActivity(getActivity(), HomeActivity.class, true);
    }
  }

  @Override public void onActivityCreated(Bundle savedInstanceState) {
    super.onActivityCreated(savedInstanceState);
    getDialog().setCancelable(false);
    final WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
    lp.copyFrom(getDialog().getWindow().getAttributes());
    lp.width = WindowManager.LayoutParams.MATCH_PARENT;
    lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
    lp.gravity = Gravity.CENTER;
    getDialog().getWindow().setAttributes(lp);
  }

  private void setData() {
    if (inviteImageType == Constants.JOB_APPLIED_TYPE) {
      tvCandidate.setVisibility(View.INVISIBLE);
      tvSkip.setText(getString(R.string.ok));
      tvTitle.setText(getString(R.string.congratulations));
      tvDescription.setText(getString(R.string.application_sent));
    } else if (inviteImageType == Constants.CANDIDATE_ACCEPT) {
      tvCandidate.setVisibility(View.INVISIBLE);
      tvSkip.setText(getString(R.string.ok));
      tvTitle.setText(getString(R.string.congratulations));
      tvDescription.setText(getString(R.string.accept_request));
    } else if (inviteImageType == Constants.CANDIDATE_REJECT) {
      tvCandidate.setVisibility(View.INVISIBLE);
      tvSkip.setText(getString(R.string.ok));
      tvTitle.setText(String.format(Locale.ENGLISH,"%s!", getString(R.string.refuse)));
      ivInvite.setImageResource(R.drawable.big_cross);
      tvDescription.setText(getString(R.string.reject_request));
    } else if (inviteImageType == Constants.PHONE_VERIFIED) {
      tvCandidate.setVisibility(View.INVISIBLE);
      tvSkip.setText(getString(R.string.perfect));
      tvTitle.setText(String.format(Locale.ENGLISH,"%s!", getString(R.string.merci)));
      tvDescription.setText(getString(R.string.verify_success));
    }
  }

  @Override public void onDestroyView() {
    unbinder.unbind();
    super.onDestroyView();
  }
}
