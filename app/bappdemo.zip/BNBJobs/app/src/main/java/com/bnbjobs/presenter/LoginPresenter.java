/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import com.bnbjobs.QuickstartPreferences;
import com.bnbjobs.R;
import com.bnbjobs.activity.LoginActivity;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.utils.AeSimpleSHA1;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.LoginView;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.trello.rxlifecycle.ActivityEvent;
import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Observer;

import static android.text.TextUtils.isEmpty;
import static com.bnbjobs.main.AppClass.getPrefs;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.getText;
import static com.bnbjobs.utils.Utils.hideKeyboard;
import static com.bnbjobs.utils.Utils.isResponseSuccess;
import static com.bnbjobs.utils.Utils.isValidEmail;
import static com.bnbjobs.utils.Utils.showDialog;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */

public class LoginPresenter extends BasePresenter implements Presenter<LoginView> {

  private static final String TAG = makeLogTag(LoginPresenter.class);
  private LoginView mLoginView;
  private EditText etUserName;
  private EditText etPassword;
  private CallbackManager callbackManager;
  private AccessToken accessToken;

  @Override public void attachView(LoginView view) {
    this.mLoginView = view;
    FacebookSdk.sdkInitialize(getContext().getApplicationContext());
    callbackManager = CallbackManager.Factory.create();
  }

  @Override public void detachView() {
    mLoginView = null;
  }

  public void doLogin(EditText etUserName, EditText etPassword) {
    this.etUserName = etUserName;
    this.etPassword = etPassword;
    if (checkValidation()) {
      hideKeyboard(getContext());
      if (hasNetworkConnectivity()) {
        mLoginView.showProgress();
        onLogin();
      } else {
        showNetworkError();
      }
    }
  }

  @Override protected Context getBaseContext() {
    return getContext();
  }

  public void onFbLogin() {
    LoginManager.getInstance()
        .logInWithReadPermissions(getContext(),
            Arrays.asList("public_profile", "email", "user_friends"));
    LoginManager.getInstance()
        .registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
          @Override public void onSuccess(LoginResult loginResult) {
            // App code
            LOGI(TAG, "onSuccess");
            LOGI(TAG, loginResult.getAccessToken() + "");
            accessToken = loginResult.getAccessToken();
            mLoginView.showProgress();
            getUserDetail();
          }

          @Override public void onCancel() {
            // App code
            LOGI(TAG, "onCancel");
          }

          @Override public void onError(FacebookException exception) {
            // App code
            if (exception.getMessage() != null) {
              showDialog(getContext(), getContext().getString(R.string.alert),
                  exception.getMessage(), getContext().getString(android.R.string.ok),
                  new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                      dialog.dismiss();
                    }
                  }).show();
            }
            LOGI(TAG, "exception");
            LOGE(TAG, Log.getStackTraceString(exception));
          }
        });
  }

  private void getUserDetail() {
    GraphRequest request =
        GraphRequest.newMeRequest(accessToken, new GraphRequest.GraphJSONObjectCallback() {
          @Override public void onCompleted(JSONObject object, GraphResponse response) {
            LOGI(TAG, object.toString());
            registerFbUser(object);
          }
        });
    Bundle parameters = new Bundle();
    parameters.putString("fields", "id,name,email,link");
    request.setParameters(parameters);
    request.executeAsync();
  }

  private void registerFbUser(JSONObject object) {
    HashMap<String, String> params = new HashMap<>(15);
    params.put("apiName", "register");
    String name = object.optString("name");
    List<String> names = Arrays.asList(name.split("\\s"));
    params.put("firstName", names.get(0));
    params.put("lastName", names.size() > 1 ? names.get(1) : "");
    params.put("email", object.optString("email"));
    params.put("latitude", getPrefs(getBaseContext()).getString(QuickstartPreferences.LAT, ""));
    params.put("longitude", getPrefs(getBaseContext()).getString(QuickstartPreferences.LNG, ""));
    params.put("userType",getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_TYPE, ""));
    params.put("location",getPrefs(getBaseContext()).getString(QuickstartPreferences.PLACE_NAME, ""));
    params.put("registerType", Constants.REG_FB);
    params.put("facebookId", object.optString("id"));
    params.putAll(addDefaultParams(params));
    LOGI(TAG, params.toString());
    RestClient.getInstance(params)
        .compose(getContext().<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Observer<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            mLoginView.hideProgress();
            LOGI(TAG, Log.getStackTraceString(e));
            retryMethod(e, true);
          }

          @Override public void onNext(String s) {
            mLoginView.hideProgress();
            try {
              JSONObject object = new JSONObject(s);
              if (isResponseSuccess(s)) {
                JSONObject userObject = object.getJSONObject("userData");
                getPrefs(getBaseContext()).save(QuickstartPreferences.IS_LOGIN, true);
                getPrefs(getBaseContext()).save(QuickstartPreferences.IS_NORMAL_USER, false);
                getPrefs(getBaseContext()).save(QuickstartPreferences.ACCESS_TOKEN,
                    object.getString("accessToken"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_ID,
                    userObject.getString("u_id"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.SHOW_DESIGNATION,
                    object.getBoolean("designationFlag"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.CREATED_AT,
                    userObject.getString("u_created_at"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_FNAME,
                    userObject.getString("u_fname"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_LNAME,
                    userObject.getString("u_lname"));
                showMessage(getContext(), "Login Successfully");
                mLoginView.onLogin();
              } else {
                showDialog(getContext(), getContext().getString(R.string.alert),
                    object.getString("message"), getContext().getString(android.R.string.ok),
                    new DialogInterface.OnClickListener() {
                      @Override public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                      }
                    }).show();
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  private void onLogin() {
    HashMap<String, String> params = new HashMap<>(10);
    params.put("apiName", "login");
    params.put("email", getText(etUserName));
    try {
      params.put("password", AeSimpleSHA1.SHA1(getText(etPassword)));
    } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
      e.printStackTrace();
    }
    params.put("latitude", getPrefs(getBaseContext()).getString(QuickstartPreferences.LAT, ""));
    params.put("longitude", getPrefs(getBaseContext()).getString(QuickstartPreferences.LNG, ""));
    params.put("location", getPrefs(getBaseContext()).getString(QuickstartPreferences.PLACE_NAME, ""));
    params.put("userType",getPrefs(getBaseContext()).getString(QuickstartPreferences.USER_TYPE, ""));
    params.putAll(addDefaultParams(params));
    LOGI(TAG, params.toString());
    RestClient.getInstance(params)
        .compose(getContext().<String>bindUntilEvent(ActivityEvent.DESTROY))
        .subscribe(new Observer<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            mLoginView.hideProgress();
            LOGE(TAG, Log.getStackTraceString(e));
            retryMethod(e, false);
          }

          @Override public void onNext(String s) {
            mLoginView.hideProgress();
            try {
              JSONObject object = new JSONObject(s);
              if (isResponseSuccess(s)) {
                showMessage(getContext(), "Login Successfully");
                getPrefs(getBaseContext()).save(QuickstartPreferences.ACCESS_TOKEN,
                    object.getString("accessToken"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.IS_LOGIN, true);
                JSONObject userObject = object.getJSONObject("userData");
                getPrefs(getBaseContext()).save(QuickstartPreferences.IS_NORMAL_USER, true);
                getPrefs(getBaseContext()).save(QuickstartPreferences.SHOW_DESIGNATION,
                    object.getBoolean("designationFlag"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_ID,
                    userObject.getString("u_id"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_FNAME,
                    userObject.getString("u_fname"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_LNAME,
                    userObject.getString("u_lname"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.CREATED_AT,
                    userObject.getString("u_created_at"));

                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_PHONENUMBER,
                    userObject.optString("u_phone", ""));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_PHONE_VERIFIED,
                    userObject.optInt("u_phone_verified"));
                getPrefs(getBaseContext()).save(QuickstartPreferences.USER_PHONE_TOKEN,
                    userObject.optString("u_phone_token", ""));
                mLoginView.onLogin();
              } else {
                showDialog(getContext(), getContext().getString(R.string.alert),
                    object.getString("message"), getContext().getString(android.R.string.ok),
                    new DialogInterface.OnClickListener() {
                      @Override public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                      }
                    }).show();
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
        });
  }

  /**
   * retry
   *
   * @param e throwable
   * @param isFbService check it is fbService retry or not
   */
  private void retryMethod(final Throwable e, final boolean isFbService) {
    String error = "";
    if (e instanceof SocketTimeoutException) {
      error = getBaseContext().getString(R.string.error_timeout);
    } else {
      error = getBaseContext().getString(R.string.error_other);
    }
    showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
        getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            if (isFbService) {
              getUserDetail();
            } else {
              onLogin();
            }
          }
        }).show();
  }

  private boolean checkValidation() {
    if (!isValidEmail(Utils.getText(etUserName))) {
      showMessage(getContext(), getContext().getString(R.string.enter_valid_email_address));
      return false;
    } else if (isEmpty(Utils.getText(etPassword))) {
      showMessage(getContext(), getContext().getString(R.string.enter_valid_password));
      return false;
    }
    return true;
  }

  private LoginActivity getContext() {
    return (LoginActivity) mLoginView.getContext();
  }

  public void setResult(int requestCode, int resultCode, Intent data) {
    callbackManager.onActivityResult(requestCode, resultCode, data);
  }
}
