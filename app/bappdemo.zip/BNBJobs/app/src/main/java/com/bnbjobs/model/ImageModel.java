/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

/**
 * @author Harsh
 * @version 1.0
 */
public class ImageModel implements Serializable {

  @SerializedName("upi_id") private int imageId;
  @SerializedName("upi_image") private String image;
  @SerializedName("upi_image_url") private String imageUrl;
  @SerializedName("upi_image_thumb_url") private String imageThumbUrl;

  private boolean isEdit = false;
  private boolean isVideo = false;

  public boolean isEdit() {
    return isEdit;
  }

  public void setEdit(boolean edit) {
    isEdit = edit;
  }

  public int getImageId() {
    return imageId;
  }

  public void setImageId(int imageId) {
    this.imageId = imageId;
  }

  public String getImage() {
    return image;
  }

  public void setImage(String image) {
    this.image = image;
  }

  public String getImageUrl() {
    return imageUrl;
  }

  public void setImageUrl(String imageUrl) {
    this.imageUrl = imageUrl;
  }

  public String getImageThumbUrl() {
    return imageThumbUrl;
  }

  public void setImageThumbUrl(String imageThumbUrl) {
    this.imageThumbUrl = imageThumbUrl;
  }

  public boolean isVideo() {
    return isVideo;
  }

  public void setVideo(boolean video) {
    isVideo = video;
  }
}

