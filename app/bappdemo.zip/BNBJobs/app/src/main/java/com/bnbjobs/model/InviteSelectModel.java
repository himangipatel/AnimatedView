/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author Harsh
 * @version 1.0
 */
public class InviteSelectModel implements Parcelable {
  private String uId;
  private boolean isSelected;
  private String imageUrl;

  private void readIn(Parcel in){
    uId = in.readString();
    isSelected = in.readByte() != 0;
    imageUrl = in.readString();
  }
  public static final Creator<InviteSelectModel> CREATOR = new Creator<InviteSelectModel>() {
    @Override public InviteSelectModel createFromParcel(Parcel in) {
      InviteSelectModel selectModel = new InviteSelectModel();
      selectModel.readIn(in);
      return selectModel;
    }

    @Override public InviteSelectModel[] newArray(int size) {
      return new InviteSelectModel[size];
    }
  };

  public String getuId() {
    return uId;
  }

  public void setuId(String uId) {
    this.uId = uId;
  }

  public boolean isSelected() {
    return isSelected;
  }

  public void setSelected(boolean selected) {
    isSelected = selected;
  }

  public String getImageUrl() {
    return imageUrl;
  }

  public void setImageUrl(String imageUrl) {
    this.imageUrl = imageUrl;
  }

  @Override public int describeContents() {
    return 0;
  }

  @Override public void writeToParcel(Parcel dest, int flags) {
    dest.writeString(uId);
    dest.writeByte((byte) (isSelected ? 1 : 0));
    dest.writeString(imageUrl);
  }
}
