/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.presenter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.app.Fragment;
import com.bnbjobs.R;
import com.bnbjobs.fragments.BaseFragment;
import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.MapModel;
import com.bnbjobs.rest.RestClient;
import com.bnbjobs.view.JobOfferMapView;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.trello.rxlifecycle.FragmentEvent;
import com.trello.rxlifecycle.LifecycleTransformer;
import java.lang.reflect.Type;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import rx.Subscriber;

import static com.bnbjobs.utils.Constants.FOR_ALL_CONTRACT;
import static com.bnbjobs.utils.Constants.PER_PAGE;
import static com.bnbjobs.utils.LogUtils.LOGE;
import static com.bnbjobs.utils.Utils.showDialog;

/**
 * @author Harsh
 * @version 1.0
 */

public class MapPresenter extends BasePresenter implements Presenter<JobOfferMapView>{

  private JobOfferMapView mMapView;
  private Fragment fragment;

  @Override protected Context getBaseContext() {
    return mMapView.getContext();
  }

  @Override public void attachView(JobOfferMapView view) {
    mMapView = view;
  }

  @Override public void detachView() {
    mMapView = null;
  }


  public void getJobList(final String lat, final String lng){
    HashMap<String,String> params = new HashMap<>();
    params.put("apiName","getAllJobOffersForMap");
    params.put("perPage", String.valueOf(PER_PAGE));
    params.put("contractType", FOR_ALL_CONTRACT);
    params.put("latitude", lat);
    params.put("longitude", lng);
    params.putAll(addParams(params));

    mMapView.showProgress();
    RestClient.getInstance(params).compose(getBindEvent())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            mMapView.hideProgress();
            LOGE(TAG, e.getMessage(), e);
            String error;
            if (e instanceof SocketTimeoutException) {
              error = getBaseContext().getString(R.string.error_timeout);
            } else {
              error = getBaseContext().getString(R.string.error_other);
            }
            showDialog(getBaseContext(), getBaseContext().getString(R.string.alert), error,
                getBaseContext().getString(R.string.retry), new DialogInterface.OnClickListener() {
                  @Override public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    getJobList(lat,lng);
                  }
                }).show();
          }

          @Override public void onNext(String s) {
            mMapView.hideProgress();
            GsonBuilder builder = new GsonBuilder();
            Type collectionType = new TypeToken<BaseContainer<MapModel>>() {
            }.getType();
            BaseContainer<MapModel> mapModelBaseContainer = builder.create().fromJson(s, collectionType);
            mMapView.setMarker(mapModelBaseContainer);
          }
        });
  }

  private LifecycleTransformer<String> getBindEvent() {
    return ((BaseFragment) fragment).bindUntilEvent(FragmentEvent.DESTROY_VIEW);
  }

  public void setFragment(Fragment fragment){
    this.fragment = fragment;
  }
}
