/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @author Harsh
 * @version 1.0
 */
public class FbFriends {

  @SerializedName("data") private List<FbFriendsList> mFbFriendsList;

  public List<FbFriendsList> getmFbFriendsList() {
    return mFbFriendsList;
  }

  public void setmFbFriendsList(List<FbFriendsList> mFbFriendsList) {
    this.mFbFriendsList = mFbFriendsList;
  }

  public class FbFriendsList {
    private String name;
    private String id;

    public String getName() {
      return name;
    }

    public void setName(String name) {
      this.name = name;
    }

    public String getId() {
      return id;
    }

    public void setId(String id) {
      this.id = id;
    }
  }
}
