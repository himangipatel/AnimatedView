/*
 * Copyright (c) 2017 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.view;

import com.bnbjobs.model.BaseContainer;
import com.bnbjobs.model.JobModel;
import com.google.android.gms.maps.model.LatLng;

/**
 * @author Harsh
 * @version 1.0
 */
public interface CountryJobView extends MainView {

  void onNearJobSuccess(BaseContainer<JobModel> jobSearchBaseContainer, boolean b);

  void onCountryJobSuccess(BaseContainer<JobModel> countryJobList, boolean clear);

  void onError(String msg);

  LatLng getLatLng();

  String getCountryName();

  void setCountry(String country);

  boolean isRefreshing();
}
