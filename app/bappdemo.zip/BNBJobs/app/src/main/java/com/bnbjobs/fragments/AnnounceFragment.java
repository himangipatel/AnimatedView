/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.activity.HomeActivity;
import com.bnbjobs.adapter.AnnounceAdapter;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.JobOfferData;
import com.bnbjobs.model.UpdateEvent;
import com.bnbjobs.presenter.AnnouncePresenter;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.AnnounceView;
import java.util.ArrayList;
import java.util.List;
import org.greenrobot.eventbus.EventBus;

/**
 * @author Harsh
 * @version 1.0
 */
public class AnnounceFragment extends BaseFragment
    implements ClickImpl<JobOfferData>, AnnounceView {

  @BindView(R.id.recyclerView) RecyclerView mRecyclerView;
  @BindView(R.id.tvNoRecord) TextView mTvNoRecord;
  @BindView(R.id.linearProgress) LinearLayout mLinearProgress;

  private AnnounceAdapter mAnnounceAdapter;
  private AnnouncePresenter presenter;
  private Unbinder unbinder;
  private List<JobOfferData> mJobOfferData = new ArrayList<>();

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_all_list, container, false);
    unbinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    presenter = new AnnouncePresenter();
    presenter.attachView(this);
    presenter.setFragment(this);
    mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
    getAnnounce();
  }

  private void getAnnounce() {
    mJobOfferData = ((ProfileRecruiterFragment) getParentFragment()).getJobOfferData();
    mAnnounceAdapter = new AnnounceAdapter(getActivity(), mJobOfferData, this);
    mRecyclerView.setAdapter(mAnnounceAdapter);
    if(mJobOfferData.isEmpty())
      mTvNoRecord.setVisibility(View.VISIBLE);
    else
      mTvNoRecord.setVisibility(View.GONE);
  }

  @Override public void onResume() {
    super.onResume();
    showToolbar(true);
    setTitle(getString(R.string.announces));
  }

  @Override public void onClick(View view, JobOfferData object, int position) {
    if (view.getId() == R.id.imgDelete) {
      showDelete(getActivity(), object.getOfferId(), position);
    } else {
      Fragment fragment = new OfferFragment();
      Bundle bundle = new Bundle();
      bundle.putSerializable(OfferFragment.ARG_JOBOFFER_MODEL, object);
      fragment.setArguments(bundle);
      ((HomeActivity) getActivity()).setSelectedTab(2);
      addFragment(fragment, true);
    }
  }

  private void showDelete(Context context, final int getOfferId, final int position) {
    Utils.showDialog(context, context.getString(R.string.delete),
        context.getString(R.string.delete_job), context.getString(R.string.yes),
        context.getString(R.string.no), new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            presenter.deleteJobOffer(Integer.toString(getOfferId), position);
          }
        }, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        }).show();
  }

  @Override public void onDestroyView() {
    super.onDestroyView();
    unbinder.unbind();
    presenter.detachView();
  }

  @Override public void deleteJobFromList(int position) {
    mJobOfferData.remove(position);
    mAnnounceAdapter.notifyItemRemoved(position);
    EventBus.getDefault().post(new UpdateEvent(true));
  }

  @Override public void showProgress() {
    mLinearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    mLinearProgress.setVisibility(View.GONE);
  }
}
