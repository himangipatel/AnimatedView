/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import com.bnbjobs.R;
import com.bnbjobs.activity.AddGroupActivity;
import com.bnbjobs.adapter.BaseRecyclerAdapter;
import com.bnbjobs.adapter.GroupListAdapter;
import com.bnbjobs.customui.views.TinTableImageView;
import com.bnbjobs.model.DeleteEvent;
import com.bnbjobs.model.GroupModel;
import com.bnbjobs.model.UpdateEvent;
import com.bnbjobs.presenter.GroupListPresenter;
import com.bnbjobs.utils.Constants;
import com.bnbjobs.utils.Utils;
import com.bnbjobs.view.GroupListView;
import com.kyleduo.switchbutton.SwitchButton;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections4.IterableUtils;
import org.apache.commons.collections4.Predicate;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import static com.bnbjobs.utils.LogUtils.LOGI;
import static com.bnbjobs.utils.LogUtils.makeLogTag;
import static com.bnbjobs.utils.Utils.showMessage;

/**
 * @author Harsh
 * @version 1.0
 */
public class GroupListFragment extends BaseFragment implements GroupListView {

  @BindView(R.id.etSearch) EditText etSearch;
  @BindView(R.id.linearSearch) LinearLayout linearSearch;
  @BindView(R.id.sb_default) SwitchButton sbDefault;
  @BindView(R.id.tvRadius) TextView tvRadius;
  @BindView(R.id.seekBar) SeekBar seekBar;
  @BindView(R.id.groupRecyclerView) RecyclerView groupRecyclerView;
  @BindView(R.id.ivAddGroup) TinTableImageView ivAddGroup;
  @BindView(R.id.linearProgress) LinearLayout linearProgress;
  @BindView(R.id.tvTodayError) TextView tvTodayError;
  @BindView(R.id.tvTitle) TextView tvTitle;
  @BindView(R.id.ivMyGroup) TinTableImageView ivMyGroup;
  @BindView(R.id.swipeRefresh) SwipeRefreshLayout swipeRefresh;

  private ArrayList<GroupModel> groupModels = new ArrayList<>();
  private Unbinder unbinder;
  private GroupListPresenter presenter;
  private GroupListAdapter adapter;
  private boolean isUserGroup;
  private boolean resume;
  private static final String TAG = makeLogTag(GroupListFragment.class);
  private boolean isDone;
  private UpdateEvent event;

  @Nullable @Override public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_list_group, container, false);
    unbinder = ButterKnife.bind(this, view);
    return view;
  }

  @Override public void onViewCreated(View view, Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    EventBus.getDefault().register(this);
    tvRadius.setText(Html.fromHtml(getString(R.string.view_profile_radius, "200")));
    groupRecyclerView.setNestedScrollingEnabled(false);
    groupRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
    ivMyGroup.updateTintColor();
    ivAddGroup.updateTintColor();
    if (adapter == null) {
      adapter = new GroupListAdapter(getActivity(), groupModels);
    }
    if (getArguments() != null) {
      isUserGroup = getArguments().getBoolean(Constants.KEY_SHOW, false);
    }

    if (presenter == null) {
      presenter = new GroupListPresenter();
      presenter.setFragment(this);
      presenter.attachView(this);
    }

    if (groupModels.isEmpty()) {
      if (isUserGroup) {
        groupModels.add(new GroupModel(true));
      }
      presenter.getGroupList(1);
    }
    adapter.setIsUserGroup(isUserGroup);
    groupRecyclerView.setAdapter(adapter);
    adapter.setRecycleOnItemClickListner(new BaseRecyclerAdapter.RecycleOnItemClickListener() {
      @Override public void onItemClick(View view, int position) {
        if (view.getId() == R.id.tvJoin) {
          //delete group
          if (groupModels.get(position).getuId() == getUserId(getActivity())) {
            presenter.deleteGroup(String.valueOf(groupModels.get(position).getgId()));
          }
        } else {
          if (isUserGroup) {
            // edit group
            Intent intent = new Intent(getActivity(), AddGroupActivity.class);
            if (!groupModels.get(position).isShowAdd()) {
              intent.putExtra(Constants.KEY_GROUP_ID, groupModels.get(position).getgId());
              intent.putExtra(Constants.KEY_EDIT, true);
            }
            startActivity(intent);
          } else {
            nextScreen(groupModels.get(position).getgId());
          }
        }
      }
    });

    swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
      @Override public void onRefresh() {
        presenter.getGroupList(1);
      }
    });
    tvTitle.setText(getString(R.string.the_groups));
    if (isUserGroup) {
      ivMyGroup.setVisibility(View.GONE);
      tvTitle.setText(R.string.my_groups);
      ivAddGroup.setVisibility(View.GONE);
      linearSearch.setVisibility(View.GONE);
    }

    etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
      @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_SEARCH) {
          Utils.hideKeyboard(etSearch, getContext());
          presenter.getGroupList(1);
          return true;
        }
        return false;
      }
    });
  }

  private void nextScreen(int gId) {
    Bundle bundle = new Bundle();
    bundle.putInt(Constants.KEY_ID, gId);
    GroupDetailFragment fragment = new GroupDetailFragment();
    fragment.setTargetFragment(GroupListFragment.this, 10001);
    fragment.setArguments(bundle);
    addFragment(fragment, true);
  }

  @Override public void onDestroyView() {
    EventBus.getDefault().unregister(this);
    presenter.detachView();
    unbinder.unbind();
    super.onDestroyView();
  }

  @Subscribe public void onEvent(final UpdateEvent event) {
    this.event = event;
    resume = event.update;
  }

  public void onEvent(final DeleteEvent event) {
    final GroupModel model = IterableUtils.find(groupModels, new Predicate<GroupModel>() {
      @Override public boolean evaluate(GroupModel object) {
        return event.getId() == object.getgId();
      }
    });
    if (model != null) {
      int pos = groupModels.indexOf(model);
      groupModels.remove(pos);
      adapter.notifyItemRemoved(pos);
    }
  }

  @Override public void onResume() {
    super.onResume();
    if (resume) {
      resume = false;
      showMyGroups();
    }
  }

  private void showMyGroups() {
    LOGI(TAG, "MyGroups");
    if (!isUserGroup) {
      Bundle bundle = new Bundle();
      bundle.putBoolean(Constants.KEY_SHOW, true);
      GroupListFragment fragment = new GroupListFragment();
      fragment.setArguments(bundle);
      addFragment(fragment, true);
    } else {
      if (event != null && event.getGroupModel() != null) {
        final GroupModel groupModel = event.getGroupModel();
        final GroupModel model = IterableUtils.find(groupModels, new Predicate<GroupModel>() {
          @Override public boolean evaluate(GroupModel object) {
            return groupModel.getgId() == object.getgId();
          }
        });
        if (model != null) {
          int pos = groupModels.indexOf(model);
          groupModels.set(pos, event.getGroupModel());
          adapter.notifyItemChanged(pos);
        } else {
          groupModels.add(event.getGroupModel());
          adapter.notifyDataSetChanged();
        }
        event = null;
      }
    }
  }

  @OnClick(R.id.ivAddGroup) void onAddGroup() {
    startActivity(new Intent(getActivity(), AddGroupActivity.class));
  }

  @OnClick(R.id.ivMyGroup) void onMyGroup() {
    showMyGroups();
  }

  @Override public void showProgress() {
    linearProgress.setVisibility(View.VISIBLE);
  }

  @Override public void hideProgress() {
    linearProgress.setVisibility(View.GONE);
  }

  @Override public void onSuccess(List<GroupModel> groupModelList, boolean clear) {
    swipeRefresh.setRefreshing(false);
    if (groupModelList.isEmpty()) {
      tvTodayError.setVisibility(View.VISIBLE);
      groupModels.clear();
    } else {
      tvTodayError.setVisibility(View.GONE);
      if (clear) {
        groupModels.clear();
        if (isUserGroup) {
          groupModels.add(new GroupModel(true));
        }
      }
      groupModels.addAll(groupModelList);
    }
    adapter.notifyDataSetChanged();
    if (getArguments() != null && !isDone && getArguments().getInt(Constants.KEY_GROUP_ID, 0) != 0) {
      isDone = true;
      nextScreen(getArguments().getInt(Constants.KEY_GROUP_ID));
    }
  }

  @Override public void onError(String message) {
    showMessage(getActivity(), message);
  }

  @Override public String getSearchString() {
    return Utils.getText(etSearch);
  }

  @Override public RecyclerView getRecyclerView() {
    return groupRecyclerView;
  }

  @Override public boolean isUserGroups() {
    return isUserGroup;
  }

  @Override public boolean isSwipeToRefresh() {
    return swipeRefresh.isRefreshing();
  }

  @Override public void onDeleteSuccess(final String groupId) {
    if (groupId != null) {
      final GroupModel model = IterableUtils.find(groupModels, new Predicate<GroupModel>() {
        @Override public boolean evaluate(GroupModel object) {
          return Integer.parseInt(groupId) == object.getgId();
        }
      });
      if (model != null) {
        int pos = groupModels.indexOf(model);
        groupModels.remove(pos);
        adapter.notifyItemRemoved(pos);
      }
    }
  }

  public void onJoinEvent(boolean isJoin, final int id) {
    final GroupModel model = IterableUtils.find(groupModels, new Predicate<GroupModel>() {
      @Override public boolean evaluate(GroupModel object) {
        return id == object.getgId();
      }
    });
    if (model != null) {
      model.setMember_flag(isJoin ? 1 : 0);
      int totalMember = model.getTotalMember();
      if (isJoin) {
        model.setTotalMember(totalMember + 1);
      } else {
        model.setTotalMember(totalMember - 1);
      }
      int pos = groupModels.indexOf(model);
      adapter.notifyItemChanged(pos);
    }
  }
}
