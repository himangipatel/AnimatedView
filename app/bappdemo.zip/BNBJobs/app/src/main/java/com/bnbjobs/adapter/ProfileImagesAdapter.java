/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.bnbjobs.R;
import com.bnbjobs.activity.BaseActivity;
import com.bnbjobs.activity.ImageActivity;
import com.bnbjobs.interfaces.ClickImpl;
import com.bnbjobs.model.ImageModel;
import com.bnbjobs.utils.Constants;
import com.bumptech.glide.Glide;
import java.io.Serializable;
import java.util.List;

import static com.bnbjobs.R.id.iv_profile_photos;
import static com.bnbjobs.R.id.rel_profile_photos;

/**
 * @author Harsh
 * @version 1.0
 */
public class ProfileImagesAdapter extends RecyclerView.Adapter<ProfileImagesAdapter.MyViewHolder> {

  private final Context mContext;
  private final List<ImageModel> imageModelList;
  private final ClickImpl<ImageModel> clickImpl;

  private boolean isEdit;
  private boolean isAddImage;

  public ProfileImagesAdapter(Context mContext, List<ImageModel> imageModelList,
      Fragment fragment) {
    this.mContext = mContext;
    this.imageModelList = imageModelList;
    this.clickImpl = (ClickImpl<ImageModel>) fragment;
  }

  public void setEdit(boolean isEdit) {
    this.isEdit = isEdit;
    notifyDataSetChanged();
  }

  @Override public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.photo_item_inflater, parent, false);
    return new MyViewHolder(view);
  }

  @Override public void onBindViewHolder(MyViewHolder holder, int position) {

    if (isEdit) {
      holder.linearRemove.setVisibility(View.VISIBLE);
    } else {
      holder.linearRemove.setVisibility(View.GONE);
    }

    if (isEdit && isAddImage && position == imageModelList.size()) {
      holder.linearRemove.setVisibility(View.GONE);
      holder.ivProfilePhotos.setImageResource(R.drawable.add_photo_placeholder);
    } else {
      if (isEdit) {
        holder.linearRemove.setVisibility(View.VISIBLE);
      } else {
        holder.linearRemove.setVisibility(View.GONE);
      }

      Glide.with(mContext)
          .load(imageModelList.get(position).getImageThumbUrl())
          .placeholder(R.drawable.small_placeholder)
          .dontAnimate()
          .fitCenter()
          .into(holder.ivProfilePhotos);
    }
  }

  /**
   * user can upload maximum 3 images
   *
   * @return item count
   */
  @Override public int getItemCount() {
    isAddImage = isEdit && imageModelList.size() < 3;
    if (isAddImage) {
      return imageModelList.size() + 1;
    } else {
      return imageModelList.size();
    }
  }

  public class MyViewHolder extends RecyclerView.ViewHolder {
    @BindView(iv_profile_photos) ImageView ivProfilePhotos;
    @BindView(R.id.imageRemove) ImageView imageRemove;
    @BindView(R.id.linearRemove) LinearLayout linearRemove;
    @BindView(rel_profile_photos) RelativeLayout relProfilePhotos;

    public MyViewHolder(View itemView) {
      super(itemView);
      ButterKnife.bind(this, itemView);
    }

    @OnClick({ R.id.imageRemove, R.id.iv_profile_photos }) void onItemClick(View view) {
      if (!isEdit && view.getId() == R.id.iv_profile_photos) {
        Intent mIntent = new Intent(mContext, ImageActivity.class);
        mIntent.putExtra(Constants.KEY_LIST, (Serializable) imageModelList);
        mIntent.putExtra(Constants.KEY_POSITION,getLayoutPosition());
        mIntent.putExtra(Constants.KEY_TYPE, imageModelList.get(getLayoutPosition()).getImageUrl());
        ActivityOptionsCompat options = ActivityOptionsCompat.
            makeSceneTransitionAnimation(((BaseActivity) mContext), ivProfilePhotos, "profile");
        mContext.startActivity(mIntent, options.toBundle());
      } else {
        if (view.getId() == R.id.imageRemove) {
          clickImpl.onClick(view, imageModelList.get(getLayoutPosition()), getLayoutPosition());
        } else {
          if (getLayoutPosition() == imageModelList.size()) {
            clickImpl.onClick(view, new ImageModel(), getLayoutPosition());
          }
        }
      }
    }
  }
}
