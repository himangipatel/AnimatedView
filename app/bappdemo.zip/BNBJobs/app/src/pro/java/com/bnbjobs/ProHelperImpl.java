package com.bnbjobs;

import com.bnbjobs.utils.ProHelper;

public class ProHelperImpl implements ProHelper {

    @Override
    public boolean isPro() {
        return true;
    }
}
