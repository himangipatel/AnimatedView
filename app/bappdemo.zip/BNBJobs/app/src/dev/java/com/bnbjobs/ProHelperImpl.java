/*
 * Copyright (c) 2016 - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential by BNBJobs
 */

package com.bnbjobs;

import com.bnbjobs.utils.ProHelper;
/**
 * @author Harsh
 * @version 1.0
 */
public class ProHelperImpl implements ProHelper {

    @Override
    public boolean isPro() {
        return false;
    }
}
