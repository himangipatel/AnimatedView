Proj**__**ect Description
 BNB job is the new mobile application for job search nearby.
 The application aims to simplify the recruitment process and make it more effective.
 It allows to apply more quickly and guarantee a response within 48 hours.

**_#Feature:_**
**Implementing Chat Functionality**


**_#Improvement_**
**its better to replace current `city` in home recruiter**