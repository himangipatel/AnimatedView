package com.recruitmentmatters.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;
import com.recruitmentmatters.constants.ApiParamEnum;

import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.BindView;

/**
 * Created by Sameer Jani on 3/4/17.
 */

public class ReferenceAdapter extends BaseRecyclerAdapter<ReferenceAdapter.DataObjectHolder, JSONObject> {
    private ArrayList<JSONObject> jsonArray = null;
    private Context context;

    public ReferenceAdapter(Context context, ArrayList jsonArray) {
        super(jsonArray);
        this.context = context;
        this.jsonArray = jsonArray;
    }


    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_reference_detail, parent, false);
        return new DataObjectHolder(view);
    }

    @Override
    public void onBindViewHolder(DataObjectHolder holder, int position) {
        JSONObject jsonReference = jsonArray.get(position);
        holder.tvContactNameValue.setText(jsonReference.optString(ApiParamEnum.CONTACT_NAME.getValue()));
        holder.tvCompanyNameValue.setText(jsonReference.optString(ApiParamEnum.COMPANY_NAME.getValue()));
        holder.tvPositionValue.setText(jsonReference.optString(ApiParamEnum.POSITION.getValue()));
        if(jsonReference.optString(ApiParamEnum.EMAIL.getValue()) != null
                && !jsonReference.optString(ApiParamEnum.EMAIL.getValue()).equalsIgnoreCase("")){
            holder.llEmail.setVisibility(View.VISIBLE);
            holder.tvEmailValue.setText(jsonReference.optString(ApiParamEnum.EMAIL.getValue()));
        }else {
            holder.llEmail.setVisibility(View.GONE);
        }
        if(jsonReference.optString(ApiParamEnum.TELEPHONE.getValue()) != null
                && !jsonReference.optString(ApiParamEnum.TELEPHONE.getValue()).equalsIgnoreCase("")){
            holder.llTelephone.setVisibility(View.VISIBLE);
            holder.tvTelephoneValue.setText(jsonReference.optString(ApiParamEnum.TELEPHONE.getValue()));
        }else {
            holder.llTelephone.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return jsonArray.size();
    }

    class DataObjectHolder extends BaseRecyclerAdapter.ViewHolder {
        @BindView(R.id.tvContactNameValue)
        TextView tvContactNameValue;
        @BindView(R.id.tvCompanyNameValue)
        TextView tvCompanyNameValue;
        @BindView(R.id.tvPositionValue)
        TextView tvPositionValue;
        @BindView(R.id.tvEmailValue)
        TextView tvEmailValue;
        @BindView(R.id.tvTelephoneValue)
        TextView tvTelephoneValue;
        @BindView(R.id.llEmail)
        LinearLayout llEmail;
        @BindView(R.id.llTelephone)
        LinearLayout llTelephone;

        DataObjectHolder(View itemView) {
            super(itemView);
            longClickableViews(itemView);
        }
    }
}
