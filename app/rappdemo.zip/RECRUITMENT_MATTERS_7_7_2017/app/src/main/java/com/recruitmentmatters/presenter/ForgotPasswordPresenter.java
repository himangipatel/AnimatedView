package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.validator.Validator;
import com.recruitmentmatters.views.ValidationErrorView;

import java.util.HashMap;

/**
 * Created by Darshna Desai on 3/4/17.
 */

public class ForgotPasswordPresenter extends BasePresenter<ValidationErrorView<Response>> {

    public void isValidData(HashMap<String, String> params) {
        ValidationErrorModel validationErrorModel = null;
        if ((validationErrorModel = (Validator.validateCandidateRefNo(params.get(ApiParamEnum.CANDIDATE_REF_NO.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateEmail(params.get(ApiParamEnum.EMAIL.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else {
            callForgotPasswordApi(params);
        }
    }

    private void callForgotPasswordApi(HashMap<String, String> params) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callForgotPasswordApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onSuccess(response);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }

}

