package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Sameer Jani on 13/4/17.
 */

public class JobPrefereedModel {

    @SerializedName("career_level")
    String career_level = "";
    @SerializedName("exp_year")
    String exp_year = "";
    @SerializedName("res_loc")
    String res_loc = "";
    @SerializedName("gender")
    String gender = "";
    @SerializedName("nationality")
    String nationality = "";
    @SerializedName("degree")
    String degree = "";

    public String getCareer_level() {
        return career_level;
    }

    public void setCareer_level(String career_level) {
        this.career_level = career_level;
    }

    public String getExp_year() {
        return exp_year;
    }

    public void setExp_year(String exp_year) {
        this.exp_year = exp_year;
    }

    public String getRes_loc() {
        return res_loc;
    }

    public void setRes_loc(String res_loc) {
        this.res_loc = res_loc;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }
}
