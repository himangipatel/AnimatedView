package com.recruitmentmatters.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseActivity;
import com.recruitmentmatters.utils.RMPrefs;

/**
 * Created by Darshna Desai on 23/3/17.
 */

public class SplashActivity extends BaseActivity {

    private static final int SPLASH_TIME = 2000;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        init();
    }

    private void init() {
        startSplashTimer();
    }

    private void startSplashTimer() {
        new CountDownTimer(SPLASH_TIME, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                if(RMPrefs.getInstance(SplashActivity.this).getUserDataModel() != null){
                    startActivity(MainActivity.class);
                }else{
                    startActivity(LoginActivity.class);
                }
            }
        }.start();
    }

    private void startActivity(Class activity) {
        Intent redirectIntent = new Intent(SplashActivity.this, activity);
        startActivity(redirectIntent);
        finish();
    }

}