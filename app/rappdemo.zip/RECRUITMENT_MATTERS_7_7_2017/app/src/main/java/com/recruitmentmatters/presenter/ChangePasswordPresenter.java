package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.validator.Validator;
import com.recruitmentmatters.views.ValidationErrorView;

import java.util.HashMap;

/**
 * Created by Darshna Desai on 10/4/17.
 */

public class ChangePasswordPresenter extends BasePresenter<ValidationErrorView<Response>> {

    public void isValidData(HashMap<String, Object> params) {
        ValidationErrorModel validationErrorModel = null;
        if ((validationErrorModel = (Validator.validateCurrentPassword(String.valueOf(params.get(ApiParamEnum.CURRENT_PASSWORD.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateNewPassword(String.valueOf(params.get(ApiParamEnum.NEW_PASSWORD.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateConfirmPassword(String.valueOf(params.get(ApiParamEnum.CONFIRM_PASSWORD.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validatePasswordConfirmPassword(String.valueOf(params.get(ApiParamEnum.NEW_PASSWORD.getValue()))
                , String.valueOf(params.get(ApiParamEnum.CONFIRM_PASSWORD.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        }else {
            callChangePasswordApi(params);
        }
    }

    private void callChangePasswordApi(HashMap<String, Object> params) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callChangePasswordApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressToolBar(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onSuccess(response);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressToolBar(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }

}
