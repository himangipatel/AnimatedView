package com.recruitmentmatters.views;

import com.recruitmentmatters.baseclasses.BaseView;
import com.recruitmentmatters.model.JobModel;

import java.util.ArrayList;

/**
 * Created by Darshna Desai on 11/4/17.
 */

public interface JobListingView<T> extends BaseView<T> {

    void onSuccessFavourite(String response, int position);

    void onFailureFavourite(String msg);

    void onMyApplicationJobSuccess(ArrayList<JobModel> jobModels);
}
