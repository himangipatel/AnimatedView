package com.recruitmentmatters.connection;

/**
 * Created by  Sameer Jani on 29/4/17.
 */

public class RestConstant {

    public static final String BASE_URL = "http://recruitmentmatters.co.zw/api/v1/";
}
