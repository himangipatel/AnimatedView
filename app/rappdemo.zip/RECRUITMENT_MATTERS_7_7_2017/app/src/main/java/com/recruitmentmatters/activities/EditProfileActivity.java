package com.recruitmentmatters.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseActivity;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.fragment.EmploymentFragment;
import com.recruitmentmatters.fragment.PersonalEducationFragment;
import com.recruitmentmatters.fragment.PersonalGeneralFragment;
import com.recruitmentmatters.fragment.PersonalLanguageSpokenFragment;
import com.recruitmentmatters.listeners.OnEditProfileListener;
import com.recruitmentmatters.model.LanguageModel;
import com.recruitmentmatters.model.ProfileEducationInfoModel;
import com.recruitmentmatters.model.ProfileGeneralInfoModel;
import com.recruitmentmatters.model.ViewProfileModel;
import com.recruitmentmatters.fragment.PersonalJobCategoryFragment;
import com.recruitmentmatters.fragment.PersonalJobTypeFragment;
import com.recruitmentmatters.fragment.ReferenceFragment;
import com.recruitmentmatters.model.ProfileJobCategoryModel;
import com.recruitmentmatters.model.ProfileJobTypeModel;
import com.recruitmentmatters.model.ProfileReferenceModel;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Sameer Jani on 5/4/17.
 */

public class EditProfileActivity extends BaseActivity implements OnEditProfileListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        ButterKnife.bind(this);
        initToolbar();
        init();
    }

    private void initToolbar() {
        tvToolbarTitle.setVisibility(View.VISIBLE);
    }

    private void init() {
        if (getIntent().hasExtra(AppConstants.SEND_DATA_EDIT_PROFILE) && getIntent().hasExtra(AppConstants.SEND_REQUEST_ID_EDIT_PROFILE)) {
            int requestedId = getIntent().getIntExtra(AppConstants.SEND_REQUEST_ID_EDIT_PROFILE, 0);
            Fragment fragment = null;
            switch (requestedId) {
                case AppConstants.GENERAL_FORM:
                    fragment = new PersonalGeneralFragment();
                    tvToolbarTitle.setText(R.string.title_general_profile);
                    break;
                case AppConstants.EDUCATION_FORM:
                    fragment = new PersonalEducationFragment();
                    tvToolbarTitle.setText(R.string.title_education_profile);
                    break;
                case AppConstants.EMPLOYMENT_FORM:
                    fragment = new EmploymentFragment();
                    tvToolbarTitle.setText(R.string.title_employment_profile);
                    break;
                case AppConstants.LANGUAGE_FORM:
                    fragment = new PersonalLanguageSpokenFragment();
                    tvToolbarTitle.setText(R.string.title_language_profile);
                    break;
                case AppConstants.JOB_CATEGORY_FORM:
                    fragment = new PersonalJobCategoryFragment();
                    tvToolbarTitle.setText(R.string.title_job_category_profile);
                    break;
                case AppConstants.JOB_TYPE_FORM:
                    fragment = new PersonalJobTypeFragment();
                    tvToolbarTitle.setText(R.string.title_job_type_profile);
                    break;
                case AppConstants.REFERENCES_FORM:
                    fragment = new ReferenceFragment();
                    tvToolbarTitle.setText(R.string.title_reference_profile);
                    break;
            }
            setFragment(fragment);
        }
    }

    private void setFragment(Fragment fragment) {
        if (fragment != null) {
            Bundle bundle = new Bundle();
            if (getIntent().getIntExtra(AppConstants.SEND_REQUEST_ID_EDIT_PROFILE, 0) == AppConstants.EMPLOYMENT_FORM) {
                bundle.putParcelableArrayList(AppConstants.SEND_DATA_EDIT_PROFILE, getIntent().getParcelableArrayListExtra(AppConstants.SEND_DATA_EDIT_PROFILE));
            } else if (fragment instanceof ReferenceFragment) {
                bundle.putParcelableArrayList(AppConstants.SEND_DATA_EDIT_PROFILE, getIntent().getParcelableArrayListExtra(AppConstants.SEND_DATA_EDIT_PROFILE));
            } else {
                bundle.putParcelable(AppConstants.SEND_DATA_EDIT_PROFILE, getIntent().getParcelableExtra(AppConstants.SEND_DATA_EDIT_PROFILE));
            }
            replaceFragment(fragment, false, bundle);
        }
    }

    private void replaceFragment(Fragment fragment, boolean addToBackStack, Bundle bundle) {

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, fragment, fragment.getClass().getSimpleName());
        if (addToBackStack) {
            fragmentTransaction.addToBackStack(fragment.getClass().getSimpleName());
        }
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        fragmentTransaction.commit();
    }

    @Override
    public void onEditProfileSuccess(Object profileData) {
        Intent intent = new Intent();
        if (profileData instanceof ProfileGeneralInfoModel) {
            intent.putExtra(AppConstants.SEND_DATA_EDIT_PROFILE, (ProfileGeneralInfoModel) profileData);
        } else if (profileData instanceof ProfileEducationInfoModel) {
            intent.putExtra(AppConstants.SEND_DATA_EDIT_PROFILE, (ProfileEducationInfoModel) profileData);
        } else if (getIntent().getIntExtra(AppConstants.SEND_REQUEST_ID_EDIT_PROFILE, 0) == AppConstants.EMPLOYMENT_FORM) {
            ViewProfileModel profileGeneralInfoModel = (ViewProfileModel) profileData;
            intent.putParcelableArrayListExtra(AppConstants.SEND_DATA_EDIT_PROFILE, profileGeneralInfoModel.getEmploymentData());
        } else if (profileData instanceof LanguageModel) {
            intent.putExtra(AppConstants.SEND_DATA_EDIT_PROFILE, (LanguageModel) profileData);
        } else if (profileData instanceof ProfileJobCategoryModel) {
            intent.putExtra(AppConstants.SEND_DATA_EDIT_PROFILE, (ProfileJobCategoryModel) profileData);
        } else if (profileData instanceof ProfileJobTypeModel) {
            intent.putExtra(AppConstants.SEND_DATA_EDIT_PROFILE, (ProfileJobTypeModel) profileData);
        } else if (getIntent().getIntExtra(AppConstants.SEND_REQUEST_ID_EDIT_PROFILE, 0) == AppConstants.REFERENCES_FORM) {
            intent.putExtra(AppConstants.SEND_DATA_EDIT_PROFILE, (ArrayList<ProfileReferenceModel>) profileData);
        }
        setResult(Activity.RESULT_OK, intent);
        finish();
    }


    @OnClick(R.id.ivToolbarLeft)
    public void onClick(View view) {
        finish();
    }

}
