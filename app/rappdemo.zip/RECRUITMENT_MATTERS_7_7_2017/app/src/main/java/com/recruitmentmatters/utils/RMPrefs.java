package com.recruitmentmatters.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.recruitmentmatters.model.LanguageModel;
import com.recruitmentmatters.model.ProfileEducationInfoModel;
import com.recruitmentmatters.model.ProfileJobCategoryModel;
import com.recruitmentmatters.model.ProfileJobTypeModel;
import com.recruitmentmatters.model.UserDataModel;
import com.recruitmentmatters.model.ViewProfileModel;

/**
 * Created by Sameer Jani on 1/4/17.
 */

public class RMPrefs {
    private final static String SP_NAME = "com.recruitmentmatters";
    private static RMPrefs rmPrefs = null;
    private SharedPreferences sharedPreferences = null;

    private RMPrefs(Context context) {
        sharedPreferences = context.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
    }

    public static RMPrefs getInstance(Context context) {
        return rmPrefs = (rmPrefs == null ? new RMPrefs(context) : rmPrefs);
    }

    public static void removeInstance() {
        rmPrefs = null;
    }

    public String getAccessToken() {
        return sharedPreferences.getString("access_token", "");
    }

    public void setAccessToken(String accessToken) {
        sharedPreferences.edit().putString("access_token", accessToken).apply();
    }

    public UserDataModel getUserDataModel() {
        return new Gson().fromJson(sharedPreferences.getString("userData", ""), UserDataModel.class);
    }

    public void setUserDataModel(UserDataModel userDataModel) {
        sharedPreferences.edit().putString("userData", new Gson().toJson(userDataModel)).apply();
    }


    public boolean isUserLogin() {
        return sharedPreferences.getBoolean("is_login", false);
    }

    public void setUserLogin(boolean isLogin) {
        sharedPreferences.edit().putBoolean("is_login", isLogin).apply();
    }

    /*Stored registration data in prefs*/
    public ProfileEducationInfoModel getEducationDataModel() {
        return new Gson().fromJson(sharedPreferences.getString("eduData", ""), ProfileEducationInfoModel.class);
    }

    public void setEducationDataModel(ProfileEducationInfoModel userDataModel) {
        sharedPreferences.edit().putString("eduData", new Gson().toJson(userDataModel)).apply();
    }

    public LanguageModel getLanguageModel() {
        return new Gson().fromJson(sharedPreferences.getString("lanData", ""), LanguageModel.class);
    }

    public void setLanguageModel(LanguageModel userDataModel) {
        sharedPreferences.edit().putString("lanData", new Gson().toJson(userDataModel)).apply();
    }

    public ProfileJobCategoryModel getJobCategoryModel() {
        return new Gson().fromJson(sharedPreferences.getString("catData", ""), ProfileJobCategoryModel.class);
    }

    public void setJobCategoryModel(ProfileJobCategoryModel userDataModel) {
        sharedPreferences.edit().putString("catData", new Gson().toJson(userDataModel)).apply();
    }

    public ProfileJobTypeModel getJobTypeModel() {
        return new Gson().fromJson(sharedPreferences.getString("jobTypeData", ""), ProfileJobTypeModel.class);
    }

    public void setJobTypeModel(ProfileJobTypeModel userDataModel) {
        sharedPreferences.edit().putString("jobTypeData", new Gson().toJson(userDataModel)).apply();
    }

    public ViewProfileModel getEmploymentModel() {
        return new Gson().fromJson(sharedPreferences.getString("empData", ""), ViewProfileModel.class);
    }

    public void setEmploymentModel(ViewProfileModel userDataModel) {
        sharedPreferences.edit().putString("empData", new Gson().toJson(userDataModel)).apply();
    }

    public ViewProfileModel getReferenceModel() {
        return new Gson().fromJson(sharedPreferences.getString("refData", ""), ViewProfileModel.class);
    }

    public void setReferenceModel(ViewProfileModel userDataModel) {
        sharedPreferences.edit().putString("refData", new Gson().toJson(userDataModel)).apply();
    }

    public void clearRegData(){
        sharedPreferences.edit().remove("eduData").apply();
        sharedPreferences.edit().remove("lanData").apply();
        sharedPreferences.edit().remove("catData").apply();
        sharedPreferences.edit().remove("jobTypeData").apply();
        sharedPreferences.edit().remove("empData").apply();
        sharedPreferences.edit().remove("refData").apply();
    }

    public void clearAllPrefs() {
        sharedPreferences.edit().clear().apply();
    }
}
