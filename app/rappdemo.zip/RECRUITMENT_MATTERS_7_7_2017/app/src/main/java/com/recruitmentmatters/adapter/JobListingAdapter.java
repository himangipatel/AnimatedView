package com.recruitmentmatters.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;
import com.recruitmentmatters.model.JobModel;

import java.text.DateFormatSymbols;
import java.util.ArrayList;

import butterknife.BindView;


/**
 * Created by Darshna Desai on 10/4/17.
 */

public class JobListingAdapter extends BaseRecyclerAdapter<JobListingAdapter.DataObjectHolder, JobModel> {
    private ArrayList<JobModel> jobModelArrayList = new ArrayList<>();
    private Context context;

    public JobListingAdapter(Context context, ArrayList<JobModel> jobModelArrayList) {
        super(jobModelArrayList);
        this.context = context;
        this.jobModelArrayList = jobModelArrayList;
    }

    @Override
    public JobListingAdapter.DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_job_listing, parent, false);
        return new JobListingAdapter.DataObjectHolder(view);
    }

    @Override
    public void onBindViewHolder(JobListingAdapter.DataObjectHolder holder, int position) {
        JobModel jobModel = jobModelArrayList.get(position);
        holder.tvDay.setText(jobModel.getJobDay());
        holder.tvMonth.setText(new DateFormatSymbols().getMonths()[Integer.parseInt(jobModel.getJobMonth()) - 1]);

        holder.tvJobTitle.setText(jobModel.getJobTitle());
        holder.tvJobLocation.setText(jobModel.getJobLocation());
        holder.tvJobSummery.setText(jobModel.getJobSummary());
        holder.tvJobCategories.setText(jobModel.getJobCategory());
        holder.tvJobSalary.setText(jobModel.getJobSalary());
        if (jobModel.isJobFav()) {
            holder.ivFavourite.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.favorite_selected));
        } else {
            holder.ivFavourite.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.favorite_unselected_grey));
        }
    }

    public void setHotJobListFavourite(String jobId, boolean isJobFav) {
        if (!jobId.isEmpty()) {
            for (int countJobs = 0; countJobs < jobModelArrayList.size(); countJobs++) {
                JobModel jobModel = jobModelArrayList.get(countJobs);
                if (jobModel.getJobId().equalsIgnoreCase(jobId)) {
                    jobModel.setJobFav(isJobFav);
                    notifyDataSetChanged();
                    return;
                }
            }
        }
    }

    public void removeJob(int position) {
        jobModelArrayList.remove(position);
        notifyDataSetChanged();
    }

    public void clearAll() {
        jobModelArrayList.clear();
        notifyDataSetChanged();
    }

    public void appendAll(ArrayList<JobModel> arrayList) {
        jobModelArrayList.addAll(arrayList);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return jobModelArrayList.size();
    }

    public JobModel getData(int position) {
        return jobModelArrayList.get(position);
    }

    public void setData(ArrayList<JobModel> data) {
        jobModelArrayList.addAll(data);
    }

    public void setData(JobModel jobModel, int pos) {
        jobModelArrayList.set(pos, jobModel);
        notifyDataSetChanged();
    }

    class DataObjectHolder extends BaseRecyclerAdapter.ViewHolder {

        @BindView(R.id.tvDay)
        TextView tvDay;
        @BindView(R.id.tvMonth)
        TextView tvMonth;
        @BindView(R.id.tvJobTitle)
        TextView tvJobTitle;
        @BindView(R.id.tvJobLocation)
        TextView tvJobLocation;
        @BindView(R.id.tvJobSummery)
        TextView tvJobSummery;
        @BindView(R.id.tvJobCategories)
        TextView tvJobCategories;
        @BindView(R.id.tvJobSalary)
        TextView tvJobSalary;
        @BindView(R.id.ivFavourite)
        ImageView ivFavourite;

        DataObjectHolder(View itemView) {
            super(itemView);
            clickableViews(ivFavourite);
            clickableViews(itemView);
        }
    }
}

