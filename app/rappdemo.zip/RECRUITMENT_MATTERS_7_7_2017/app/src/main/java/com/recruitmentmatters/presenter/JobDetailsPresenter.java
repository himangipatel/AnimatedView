package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.JobDetailResponse;
import com.recruitmentmatters.model.JobModel;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.views.JobDetailsView;

import java.util.HashMap;

/**
 * Created by Sameer Jani on 13/4/17.
 */

public class JobDetailsPresenter extends BasePresenter<JobDetailsView<JobModel>> {

    public void callJobDetailApi(HashMap<String, String> params) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callJobDetailsApi(params, new InterActorCallback<JobDetailResponse>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(JobDetailResponse response) {
                    if (response.isStatus()) {
                        getView().onSuccess(response.getJobModel());
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        } else {
            getView().onFailure(null);
        }
    }


    public void callJobApplyApi(HashMap<String, String> params) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callJobApplyApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onJobApplySuccess(response.getMessage());
                    } else {
                        getView().onJobApplyFail(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }

    public void callFavouriteJobsApi(HashMap<String, String> params) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callFavouriteJobsApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onSuccessFavourite(response.getMessage());
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        } else {
            getView().onFailure(null);
        }
    }
}
