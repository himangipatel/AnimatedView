package com.recruitmentmatters.customview;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class DialogChooseView extends Dialog {
    private View view;
    private Animation slide_down_anim, slide_up_anim;

    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;

    @BindView(R.id.txt_Cancel)
    TextView tvCancel;

    @BindView(R.id.dialog)
    View dialog;


    public interface OnDialogItemChoose {
        void onItemChoose(Dialog dialog, int position);
    }

    private OnDialogItemChoose mOnDialogChooseListener;

    public DialogChooseView(Context context, List<String> items,
                            OnDialogItemChoose mOnDialogChooseListener) {
        super(context, R.style.ThemeDialogCustomBottom);
        init(context, items, mOnDialogChooseListener);
    }

    @SuppressLint("InflateParams")
    private void init(Context context, List<String> items,
                      OnDialogItemChoose mOnDialogChooseListener) {
        this.mOnDialogChooseListener = mOnDialogChooseListener;
        LayoutInflater inflater =
                (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.dialog_chooser, null);
        ButterKnife.bind(this, view);

        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        OptionDialogAdapter adapter = new OptionDialogAdapter(context, items);
        adapter.setRecycleOnItemEventListener(mRecycleOnItemClickListener);
        recyclerView.setAdapter(adapter);
        initAnimation();
        setContentView(view);
        setCancelable(true);
        visible_option_menu();
        Window window = getWindow();
        if (window != null) {
            window.setGravity(Gravity.BOTTOM);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(window.getAttributes());
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            window.setAttributes(lp);
        }
    }

    private BaseRecyclerAdapter.RecycleOnItemEventListener mRecycleOnItemClickListener =
            new BaseRecyclerAdapter.RecycleOnItemEventListener() {
                @Override
                public void onItemClick(View view, int position) {
                    if (mOnDialogChooseListener != null) {
                        mOnDialogChooseListener.onItemChoose(DialogChooseView.this, position);
                    }
                }

                @Override
                public void onItemLongPress(View view, int position) {

                }
            };

    @Override
    public void onBackPressed() {
        hide_option_menu();
    }

    private void initAnimation() {
        slide_down_anim = AnimationUtils.loadAnimation(getContext(), R.anim.slide_down);
        slide_down_anim.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        DialogChooseView.this.dismiss();
                    }
                }, 0);
            }
        });
        slide_up_anim = AnimationUtils.loadAnimation(getContext(), R.anim.slide_up);
    }

    public void hide_option_menu() {
        dialog.startAnimation(slide_down_anim);
    }

    public void visible_option_menu() {
        if (!isShowing()) {
            show();
            dialog.setVisibility(View.VISIBLE);
            dialog.startAnimation(slide_up_anim);
        }
    }

    @Override
    public void dismiss() {
        super.dismiss();
    }

    @OnClick({R.id.txt_Cancel})
    public void onCancel(View view) {
        hide_option_menu();
    }

    public static void setOnDialog() {

    }
}
