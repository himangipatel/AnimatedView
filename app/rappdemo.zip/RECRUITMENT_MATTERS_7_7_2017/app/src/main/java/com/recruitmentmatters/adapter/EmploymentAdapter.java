package com.recruitmentmatters.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;
import com.recruitmentmatters.constants.ApiParamEnum;

import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.BindView;

/**
 * Created by Sameer Jani on 3/4/17.
 */

public class EmploymentAdapter extends BaseRecyclerAdapter<EmploymentAdapter.DataObjectHolder, JSONObject> {
    private ArrayList<JSONObject> jsonArray = null;
    private Context context;

    public EmploymentAdapter(Context context, ArrayList jsonArray) {
        super(jsonArray);
        this.context = context;
        this.jsonArray = jsonArray;
    }


    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_employer_detail, parent, false);
        return new DataObjectHolder(view);
    }

    @Override
    public void onBindViewHolder(DataObjectHolder holder, int position) {
        JSONObject jsonEmployer = jsonArray.get(position);
        holder.tvEmployerValue.setText(jsonEmployer.optString(ApiParamEnum.EMPLOYER.getValue()));
        holder.tvPositionValue.setText(jsonEmployer.optString(ApiParamEnum.POSITION.getValue()));
        holder.tvWorkDurationValue.setText(jsonEmployer.optString(ApiParamEnum.START_DATE.getValue()) + "-" + jsonEmployer.optString(ApiParamEnum.END_DATE.getValue()));
        holder.tvSkillsValue.setText(jsonEmployer.optString(ApiParamEnum.KEY_SKILLS.getValue()));
        if(jsonEmployer.optString(ApiParamEnum.END_DATE.getValue()).equalsIgnoreCase(context.getResources().getString(R.string.title_present))){
            holder.tvEmployerValue.setText(jsonEmployer.optString(ApiParamEnum.EMPLOYER.getValue()) + context.getResources().getString(R.string.title_current_position));
        }
    }

    @Override
    public int getItemCount() {
        return jsonArray.size();
    }

    class DataObjectHolder extends BaseRecyclerAdapter.ViewHolder {
        @BindView(R.id.tvEmployerValue)
        TextView tvEmployerValue;
        @BindView(R.id.tvPositionValue)
        TextView tvPositionValue;
        @BindView(R.id.tvWorkDurationValue)
        TextView tvWorkDurationValue;
        @BindView(R.id.tvSkillsValue)
        TextView tvSkillsValue;

        DataObjectHolder(View itemView) {
            super(itemView);
            longClickableViews(itemView);
        }
    }
}
