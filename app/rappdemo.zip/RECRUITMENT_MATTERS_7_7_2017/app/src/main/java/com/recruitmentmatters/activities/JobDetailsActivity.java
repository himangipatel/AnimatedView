package com.recruitmentmatters.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.MVPActivity;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.customview.CustomDialog;
import com.recruitmentmatters.customview.JobQuestionsDialog;
import com.recruitmentmatters.model.JobModel;
import com.recruitmentmatters.model.UserDataModel;
import com.recruitmentmatters.presenter.JobDetailsPresenter;
import com.recruitmentmatters.tagview.Tag;
import com.recruitmentmatters.tagview.TagView;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;
import com.recruitmentmatters.views.JobDetailsView;

import java.text.DateFormatSymbols;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnCheckedChanged;
import butterknife.OnClick;

/**
 * Created by Sameer Jani on 11/4/17.
 */

public class JobDetailsActivity extends MVPActivity<JobDetailsPresenter, JobDetailsView<JobModel>> implements JobDetailsView<JobModel>, View.OnClickListener {

    @BindView(R.id.main_collapsing)
    CollapsingToolbarLayout collapsingToolbarLayout;
    @BindView(R.id.main_appbar)
    AppBarLayout appBarLayout;
    @BindView(R.id.llDate)
    LinearLayout llDate;
    @BindView(R.id.main_toolbar)
    Toolbar toolbar;
    @BindView(R.id.rbJobDetails)
    RadioButton rbJobDetails;
    @BindView(R.id.rbJobDescription)
    RadioButton rbJobDescription;
    @BindView(R.id.llJobDetails)
    LinearLayout llJobDetails;
    @BindView(R.id.llJobDescriptions)
    LinearLayout llJobDescriptions;

    @BindView(R.id.tvDay)
    TextView tvDay;
    @BindView(R.id.tvMonth)
    TextView tvMonth;
    @BindView(R.id.tvJobTitleValue)
    TextView tvJobTitleValue;
    @BindView(R.id.tvJobLocationValue)
    TextView tvJobLocationValue;
    @BindView(R.id.tvJobCategoryValue)
    TextView tvJobCategoryValue;
    @BindView(R.id.tvJobExpectedSalaryValue)
    TextView tvJobExpectedSalaryValue;

    //Job Details
    @BindView(R.id.tvJobIdValue)
    TextView tvJobIdValue;
    @BindView(R.id.tvJobLocationsValue)
    TextView tvJobLocationsValue;
    @BindView(R.id.tvJobCompanyTypeValue)
    TextView tvJobCompanyTypeValue;
    @BindView(R.id.tvJobRoleValue)
    TextView tvJobRoleValue;
    @BindView(R.id.tvJobJoiningDateValue)
    TextView tvJobJoiningDateValue;
    @BindView(R.id.tvJobEmploymentTypeValue)
    TextView tvJobEmploymentTypeValue;
    @BindView(R.id.tvJobCareerLevelValue)
    TextView tvJobCareerLevelValue;
    @BindView(R.id.tvJobYearOfExperianceValue)
    TextView tvJobYearOfExperianceValue;
    @BindView(R.id.tvJobResidenceLocationValue)
    TextView tvJobResidenceLocationValue;
    @BindView(R.id.tvJobGenderValue)
    TextView tvJobGenderValue;
    @BindView(R.id.tvJobNationalityValue)
    TextView tvJobNationalityValue;
    @BindView(R.id.tvJobDegreeValue)
    TextView tvJobDegreeValue;


    @BindView(R.id.llJobQuestions)
    LinearLayout llJobQuestions;

    @BindView(R.id.llDynamicQue)
    LinearLayout llDynamicQue;

    @BindView(R.id.tvApply)
    TextView tvApply;


    //Job Description
    @BindView(R.id.tvJobDescriptionValue)
    TextView tvJobDescriptionValue;
    @BindView(R.id.tvJobKeySkillValue)
    TextView tvJobKeySkillValue;
    @BindView(R.id.tvExperianceValue)
    TextView tvExperianceValue;
    @BindView(R.id.tvQualificationValue)
    TextView tvQualificationValue;
    @BindView(R.id.tvAdditionalRequirments)
    TextView tvAdditionalRequirments;
    @BindView(R.id.gridAdditionalRequirments)
    TagView gridAdditionalRequirments;

    @BindView(R.id.nestedScroll)
    NestedScrollView nestedScroll;
    @BindView(R.id.tvNoData)
    TextView tvNoData;

    View view;
    ImageView ivBack;
    ImageView ivFavourite;
    private JobModel jobModel = null;
    private String jobId = "";
    private int jobDetailPosition;
    private boolean isMyApplication = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_details);
        init();
    }

    private void init() {
        ButterKnife.bind(this);
        view = LayoutInflater.from(this).inflate(R.layout.toolbar_transparent, null, false);
        ivBack = ButterKnife.findById(view, R.id.ivToolbarLeft);
        ivFavourite = ButterKnife.findById(view, R.id.ivToolbarRight);
        initToolbar();
        llJobDetails.setVisibility(View.VISIBLE);
        rbJobDetails.setChecked(true);
        if (getIntent().hasExtra(AppConstants.SEND_JOB_DETAILS_POSITION)) {
            jobDetailPosition = getIntent().getIntExtra(AppConstants.SEND_JOB_DETAILS_POSITION, -1);
        }
        if (getIntent().hasExtra(ApiParamEnum.JOB_ID.getValue())) {
            callJobDetailsApi(getIntent().getStringExtra(ApiParamEnum.JOB_ID.getValue()));
        }
        if (getIntent().hasExtra(AppConstants.SEND_IS_MY_APPLICATION_JOB_DETAILS) && getIntent().getBooleanExtra(AppConstants.SEND_IS_MY_APPLICATION_JOB_DETAILS, false)) {
            tvApply.setVisibility(View.GONE);
            llJobQuestions.setVisibility(View.VISIBLE);
            isMyApplication = true;
        }
    }

    @NonNull
    @Override
    public JobDetailsPresenter createPresenter() {
        return new JobDetailsPresenter();
    }

    @NonNull
    @Override
    public JobDetailsView attachView() {
        return this;
    }

    private void initToolbar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setCustomView(view);
        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (collapsingToolbarLayout.getHeight() + verticalOffset < 2 * ViewCompat.getMinimumHeight(collapsingToolbarLayout)) {
                    llDate.animate().alpha(0).scaleX(0f).scaleY(0f).setDuration(200);
                } else {
                    llDate.animate().alpha(1).scaleX(1.0f).scaleY(1.0f).setDuration(200);
                }
            }
        });
        ivBack.setOnClickListener(this);
        ivFavourite.setOnClickListener(this);
    }

    @OnCheckedChanged({R.id.rbJobDescription, R.id.rbJobDetails})
    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
        if (rbJobDetails.isChecked()) {
            llJobDetails.setVisibility(View.VISIBLE);
            llJobDescriptions.setVisibility(View.GONE);
        } else {
            llJobDetails.setVisibility(View.GONE);
            llJobDescriptions.setVisibility(View.VISIBLE);
        }
    }

    private void callJobDetailsApi(String jobId) {
        UserDataModel user = RMPrefs.getInstance(getActivity()).getUserDataModel();
        HashMap<String, String> params = new HashMap<>();
        //if (user != null && isMyApplication) {
        if (user != null) {
            params.put(ApiParamEnum.USER_ID.getValue(), user.getUser_id());
        }
        params.put(ApiParamEnum.JOB_ID.getValue(), jobId);
        getPresenter().callJobDetailApi(params);
    }

    @OnClick({R.id.tvApply})
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivToolbarLeft:
                finish();
                break;
            case R.id.ivToolbarRight:
                callFavouriteJob();
                break;
            case R.id.tvApply:
                UserDataModel userDataModel = RMPrefs.getInstance(this).getUserDataModel();
                if (userDataModel != null) {
                    if (jobModel.getJobQuestionsData() != null && jobModel.getJobQuestionsData().size() > 0) {
                        showQuestionsDialog();
                    } else {
                        callApplyJob("");
                    }
                } else {
                    showLoginDialog();
                }
                break;
        }
    }

    @Override
    public void finish() {
        Intent returnedIntent = new Intent();
        returnedIntent.putExtra(AppConstants.RETURNED_JOB_DETAIL, jobModel);
        returnedIntent.putExtra(AppConstants.SEND_JOB_DETAILS_POSITION, jobDetailPosition);
        setResult(Activity.RESULT_OK, returnedIntent);
        super.finish();
    }

    private void callFavouriteJob() {
        if (jobModel != null) {
            HashMap<String, String> params = new HashMap<>();
            UserDataModel user = RMPrefs.getInstance(getActivity()).getUserDataModel();
            if (user != null) {
                params.put(ApiParamEnum.USER_ID.getValue(), user.getUser_id());
                params.put(ApiParamEnum.ACCESS_TOKEN.getValue(), RMPrefs.getInstance(getActivity()).getAccessToken());
                params.put(ApiParamEnum.PERSONAL_ID.getValue(), user.getUser_personal_id());
                params.put(ApiParamEnum.JOB_ID.getValue(), jobModel.getJobId());
                params.put(ApiParamEnum.IS_FAVOURITE.getValue(), jobModel.isJobFav() ? "2" : "1");
                getPresenter().callFavouriteJobsApi(params);
            } else {
                AppUtils.showToast(JobDetailsActivity.this, getResources().getString(R.string.msg_login_to_favourite));
            }
        }
    }

    private void showQuestionsDialog() {
        final JobQuestionsDialog dialog = new JobQuestionsDialog(JobDetailsActivity.this, jobModel.getJobQuestionsData()) {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.tvPositive:
                        String data = getData();
                        callApplyJob(data);
                        dismiss();
                        break;
                    case R.id.tvNegative:
                        dismiss();
                        break;
                }
            }
        };
        dialog.show();
    }

    private void callApplyJob(String answers) {
        UserDataModel userDataModel = RMPrefs.getInstance(this).getUserDataModel();
        if (userDataModel != null && jobId != null) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put(ApiParamEnum.CANDIDATE_REF_NO.getValue(), userDataModel.getUser_candidate_ref_number());
            hashMap.put(ApiParamEnum.JOB_ID.getValue(), jobId);
            if (!answers.equalsIgnoreCase("")) {
                List<String> items = Arrays.asList(answers.split("\\s*,\\s*"));
                for (int i = 0; i < items.size(); i++) {
                    hashMap.put(ApiParamEnum.QUESTION.getValue() + (i + 1), items.get(i));
                }
            }
            getPresenter().callJobApplyApi(hashMap);
        }
    }

    private void showLoginDialog() {
        final CustomDialog dialog = new CustomDialog(JobDetailsActivity.this,
                getResources().getString(R.string.title_login_reg), getResources().getString(R.string.msg_login_to_apply),
                getResources().getString(android.R.string.ok)
                , getResources().getString(android.R.string.cancel)) {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.tvPositive:
                        Intent redirectIntent = new Intent(JobDetailsActivity.this, LoginActivity.class);
                        redirectIntent.putExtra(AppConstants.EXTRA_FROM_APPLY_JOB, true);
                        startActivityForResult(redirectIntent, AppConstants.LOGIN_TO_APPLY_JOB);
                        dismiss();
                        break;
                    case R.id.tvNegative:
                        dismiss();
                        break;
                }
            }
        };
        dialog.show();
    }

    private void setDetails(JobModel jobModel) {
        tvDay.setText(jobModel.getJobDay());
        tvMonth.setText(DateFormatSymbols.getInstance().getShortMonths()[Integer.parseInt(jobModel.getJobMonth()) - 1]);
        tvJobTitleValue.setText(jobModel.getJobTitle());
        tvJobLocationValue.setText(jobModel.getJobLocation());
        tvJobCategoryValue.setText(jobModel.getJobCategory());
        tvJobExpectedSalaryValue.setText(jobModel.getJobSalary());
        ivFavourite.setImageResource(jobModel.isJobFav() ? R.drawable.favorite_selected : R.drawable.favorite_unselected_grey);
        jobId = jobModel.getJobId();
        setJobDetails(jobModel);
        setJobDescription(jobModel);
    }

    private void setJobDetails(JobModel jobModel) {
        tvJobIdValue.setText(jobModel.getJob_details().getJob().getJob_id());
        tvJobLocationsValue.setText(jobModel.getJob_details().getJob().getJob_location());
        tvJobCompanyTypeValue.setText(jobModel.getJob_details().getJob().getJob_company_name());
        tvJobRoleValue.setText(jobModel.getJob_details().getJob().getJob_role());
        tvJobJoiningDateValue.setText(jobModel.getJob_details().getJob().getJob_join_date());
        tvJobEmploymentTypeValue.setText(jobModel.getJob_details().getJob().getJob_emp_type());
        tvJobCareerLevelValue.setText(jobModel.getJob_details().getPrefereed().getCareer_level());
        tvJobYearOfExperianceValue.setText(jobModel.getJob_details().getPrefereed().getExp_year());
        tvJobResidenceLocationValue.setText(jobModel.getJob_details().getPrefereed().getRes_loc());
        tvJobGenderValue.setText(jobModel.getJob_details().getPrefereed().getGender());
        tvJobNationalityValue.setText(jobModel.getJob_details().getPrefereed().getNationality());
        tvJobDegreeValue.setText(jobModel.getJob_details().getPrefereed().getDegree());

        if (jobModel.getJobQuestionsData() != null && jobModel.getJobQuestionsData().size() > 0) {

            if (llJobQuestions.getVisibility() == View.VISIBLE) {
                for (int i = 0; i < jobModel.getJobQuestionsData().size(); i++) {
                    LinearLayout rowTextView = (LinearLayout) getLayoutInflater().inflate(R.layout.partial_dynamic_tv, null);

                    TextView tv = (TextView) rowTextView.findViewById(R.id.tvTitleQuestion);
                    tv.setText(jobModel.getJobQuestionsData().get(i).getQue());

                    TextView tvAnswer = (TextView) rowTextView.findViewById(R.id.tvAnswer);
                    if (jobModel.getJobQuestionsData().get(i).getQue_ans().equalsIgnoreCase("1")) {
                        tvAnswer.setText(getString(R.string.title_your_ans) + getString(R.string.yes));
                    } else {
                        tvAnswer.setText(getString(R.string.title_your_ans) + getString(R.string.no));
                    }
                    llDynamicQue.addView(rowTextView);
                }
            }
        } else {
            llJobQuestions.setVisibility(View.GONE);
        }
    }

    private void setJobDescription(JobModel jobModel) {
        tvJobDescriptionValue.setText(jobModel.getJobDescriptionModel().getDec());
        tvJobKeySkillValue.setText(jobModel.getJobDescriptionModel().getKey_skills());
        tvExperianceValue.setText(jobModel.getJobDescriptionModel().getJobRequiredSkills().getExp());
        tvQualificationValue.setText(jobModel.getJobDescriptionModel().getJobRequiredSkills().getQualifications());
        String[] requirements = jobModel.getJobDescriptionModel().getAdd_require().split(",");
        if (requirements.length >= 0 && !requirements[0].equalsIgnoreCase("")) {
           /* gridAdditionalRequirments.getLayoutParams().width = AppUtils.getScreenWidth(getActivity());
            gridAdditionalRequirments.setTags(requirements);*/

            gridAdditionalRequirments.removeAllTags();
            for (int i = 0; i < requirements.length; i++) {
                Tag tag = new Tag(requirements[i]);
                tag.background = ContextCompat.getDrawable(getActivity(), R.drawable.tag_shape);
                tag.isDeletable = false;
                tag.setTagTextColor(R.color.themeGray);
                gridAdditionalRequirments.addTag(tag);
            }

            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    gridAdditionalRequirments.getLayoutParams().height = LinearLayout.LayoutParams.WRAP_CONTENT;
                    gridAdditionalRequirments.requestLayout();
                }
            }, 100);
            tvAdditionalRequirments.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onSuccess(JobModel response) {
        if (response != null) {
            jobModel = response;
            showHideNoData(View.GONE, View.VISIBLE);
            setDetails(response);
        }
    }

    @Override
    public void onFailure(String message) {
        if (message != null) AppUtils.showToast(this, message);
        showHideNoData(View.VISIBLE, View.GONE);
    }

    private void showHideNoData(int noDataVisible, int dataVisible) {
        tvNoData.setVisibility(noDataVisible);
        nestedScroll.setVisibility(dataVisible);
        llDate.setVisibility(dataVisible);
    }

    @Override
    public void onJobApplySuccess(String message) {
        AppUtils.showToast(this, message);
    }

    @Override
    public void onJobApplyFail(String message) {
        AppUtils.showToast(this, message);
    }

    @Override
    public void onSuccessFavourite(String message) {
        AppUtils.showToast(this, message);
        jobModel.setJobFav(!jobModel.isJobFav());
        ivFavourite.setImageResource(jobModel.isJobFav() ? R.drawable.favorite_selected : R.drawable.favorite_unselected_grey);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == AppConstants.LOGIN_TO_APPLY_JOB && data != null) {
            if (data.hasExtra(AppConstants.EXTRA_LOGIN_SUCCESS)
                    && data.getBooleanExtra(AppConstants.EXTRA_LOGIN_SUCCESS, false)) {
                if (jobModel.getJobQuestionsData() != null && jobModel.getJobQuestionsData().size() > 0) {
                    showQuestionsDialog();
                } else {
                    callApplyJob("");
                }
            }
        }
    }
}
