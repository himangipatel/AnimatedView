package com.recruitmentmatters.listeners;

/**
 * Created by Sameer Jani on 5/4/17.
 */

public interface OnEditProfileListener {
    public void onEditProfileSuccess(Object profileData);
}
