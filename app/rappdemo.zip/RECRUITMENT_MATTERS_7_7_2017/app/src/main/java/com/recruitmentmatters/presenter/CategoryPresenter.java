package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.baseclasses.BaseView;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.CategoryResponse;

/**
 * Created by Darshna Desai on 12/4/17.
 */

public class CategoryPresenter extends BasePresenter<BaseView> {

    public void callGetCategoryApi(String url) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callGetAllCategoriesApi(url, new InterActorCallback<CategoryResponse>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(CategoryResponse response) {
                    if (response.isStatus()) {
                        getView().onSuccess(response);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }
                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }
}