package com.recruitmentmatters.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.recruitmentmatters.R;
import com.recruitmentmatters.adapter.ReferenceAdapter;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.constants.RegisterForm;
import com.recruitmentmatters.customview.CustomDialog;
import com.recruitmentmatters.customview.CustomRecycleview;
import com.recruitmentmatters.listeners.OnEditProfileListener;
import com.recruitmentmatters.listeners.OnNextPressedListener;
import com.recruitmentmatters.model.ProfileReferenceModel;
import com.recruitmentmatters.model.ViewProfileModel;
import com.recruitmentmatters.presenter.ReferencePresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.views.ReferenceView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Sameer Jani on 28/3/17.
 */

public class ReferenceFragment extends MVPFragment<ReferencePresenter, ReferenceView<HashMap<String, Object>>> implements ReferenceView<HashMap<String, Object>> {


    @BindView(R.id.rvReferenceDetailsContainer)
    CustomRecycleview rvReferenceDetailsContainer;
    @BindView(R.id.etContactName)
    EditText etContactName;
    @BindView(R.id.etCompanyName)
    EditText etCompanyName;
    @BindView(R.id.etPosition)
    EditText etPosition;
    @BindView(R.id.etEmail)
    EditText etEmail;
    @BindView(R.id.etTelephone)
    EditText etTelephone;
    @BindView(R.id.tvAddRef)
    TextView tvAddRef;
    @BindView(R.id.llAddReference)
    LinearLayout llAddReference;
    @BindView(R.id.tvSubmit)
    TextView tvSubmit;

    @BindView(R.id.rlPersonalTitleBar)
    RelativeLayout rlPersonalTitleBar;
    @BindView(R.id.tvFormTitle)
    TextView tvFormTitle;
    @BindView(R.id.ivFormBack)
    ImageView ivFormBack;

    OnNextPressedListener onNextPressedListener = null;
    OnEditProfileListener onEditProfileListener = null;

    private boolean isEditable = false;
    private ArrayList<JSONObject> referenceList = new ArrayList<>();
    private ArrayList<ProfileReferenceModel> referenceModels = new ArrayList<>();
    private int intEventPos;
    private ReferenceAdapter adapter;
    private BaseRecyclerAdapter.RecycleOnItemEventListener mRecycleviewEventListener = new BaseRecyclerAdapter.RecycleOnItemEventListener() {
        @Override
        public void onItemClick(View view, int position) {
            AppUtils.hideKeyboard(getActivity());
        }

        @Override
        public void onItemLongPress(View view, int position) {
            AppUtils.hideKeyboard(getActivity());
            switch (view.getId()) {
                case R.id.llReferenceMain:
                    if (!isEditable) {
                        intEventPos = position;
                        askForEditOrDelete(position);
                    }
                    break;
            }
        }
    };

    public ReferenceFragment() {
    }

    private void askForEditOrDelete(final int position) {
        final CustomDialog dialog = new CustomDialog(getActivity(),
                getResources().getString(R.string.dialog_title_reference)
                , getResources().getString(R.string.dialog_msg_reference)
                , getResources().getString(R.string.edit)
                , getResources().getString(R.string.delete)) {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.tvPositive:
                        dismiss();
                        llAddReference.setVisibility(View.VISIBLE);
                        setData(position);
                        break;
                    case R.id.tvNegative:
                        dismiss();
                        tvAddRef.setVisibility(View.VISIBLE);
                        askForDeleteConfirmation(position);
                        break;
                }
            }
        };
        dialog.show();
        dialog.setCancelable(true);
    }

    private void setData(int pos) {
        isEditable = true;
        tvAddRef.setVisibility(View.VISIBLE);
        tvAddRef.setText(R.string.action_edit_reference);
        JSONObject jsonEmployer = referenceList.get(pos);
        etContactName.setText(jsonEmployer.optString(ApiParamEnum.CONTACT_NAME.getValue()));
        etCompanyName.setText(jsonEmployer.optString(ApiParamEnum.COMPANY_NAME.getValue()));
        etPosition.setText(jsonEmployer.optString(ApiParamEnum.POSITION.getValue()));
        etEmail.setText(jsonEmployer.optString(ApiParamEnum.EMAIL.getValue()));
        etTelephone.setText(jsonEmployer.optString(ApiParamEnum.TELEPHONE.getValue()));
    }

    private void askForDeleteConfirmation(final int pos) {
        final CustomDialog dialog = new CustomDialog(getActivity(),
                getResources().getString(R.string.dialog_title_reference)
                , getResources().getString(R.string.dialog_msg_confirm_reference_delete)
                , getResources().getString(R.string.yes)
                , getResources().getString(R.string.no)) {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.tvPositive:
                        dismiss();
                        referenceList.remove(pos);
                        adapter.notifyDataSetChanged();
                        if (adapter.getItemCount() == 0) {
                            tvSubmit.setEnabled(false);
                            tvSubmit.setAlpha(0.7f);
                        }
                        llAddReference.setVisibility(View.VISIBLE);
                        AppUtils.showToast(getActivity(), getResources().getString(R.string.msg_delete_reference));
                        break;
                    case R.id.tvNegative:
                        dismiss();
                        break;
                }
            }
        };
        dialog.show();
    }

    @NonNull
    @Override
    public ReferencePresenter createPresenter() {
        return new ReferencePresenter();
    }

    @NonNull
    @Override
    public ReferenceView attachView() {
        return this;
    }

    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.partial_reg_references, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        rvReferenceDetailsContainer.setLayoutManager(new LinearLayoutManager(getActivity()));
        //tvEmpRefTitle = ButterKnife.findById(view, R.id.tvEmpRefTitle);
        if (getActivity() instanceof OnNextPressedListener)
            onNextPressedListener = (OnNextPressedListener) getActivity();
        if (getActivity() instanceof OnEditProfileListener)
            onEditProfileListener = (OnEditProfileListener) getActivity();
        initFormTitleBar();
        setDataFromPrefs();
        checkForEdit();
    }

    private void initFormTitleBar() {
        ivFormBack.setVisibility(View.VISIBLE);
        tvFormTitle.setText(R.string.title_references);
    }

    private void setDataFromPrefs() {
        if(RMPrefs.getInstance(getActivity()).getReferenceModel() != null) {
            referenceModels = RMPrefs.getInstance(getActivity()).getReferenceModel().getReferenceData();
            if (referenceModels != null) {
                setReferenceData();
            }
        }
    }

    private void checkForEdit() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            referenceModels = bundle.getParcelableArrayList(AppConstants.SEND_DATA_EDIT_PROFILE);
            if (referenceModels != null) {
                tvSubmit.setText(getResources().getString(R.string.update));
                rlPersonalTitleBar.setVisibility(View.GONE);
                setReferenceData();
            }
        }
    }

    private void setReferenceData() {
        for (int i = 0; i < referenceModels.size(); i++) {
            JSONObject object = referenceModels.get(i).toJSONObject();
            referenceList.add(object);
        }
        addReferenceDetail();
        if (referenceModels.size() >= 2) {
            llAddReference.setVisibility(View.GONE);
        }
    }

    @OnClick({R.id.tvSubmit, R.id.tvAddRef, R.id.ivFormBack})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvSubmit:
                askForConfirmation();
                break;
            case R.id.tvAddRef:
                addReference();
                break;
            case R.id.ivFormBack:
                if (onNextPressedListener != null) {
                    saveDataInPrefs();
                    onNextPressedListener.onPreviousClicked();
                }
                break;
        }
    }

    public void saveDataInPrefs() {
        ViewProfileModel model = new ViewProfileModel();
        ArrayList<ProfileReferenceModel> referenceModels =  new ArrayList<>();
        for(int i = 0; i < referenceList.size(); i++){
            ProfileReferenceModel referenceModel = new ProfileReferenceModel();
            try {
                referenceModel.setRefName(String.valueOf(referenceList.get(i).get(ApiParamEnum.CONTACT_NAME.getValue())));
                referenceModel.setRefCompanyName(String.valueOf(referenceList.get(i).get(ApiParamEnum.COMPANY_NAME.getValue())));
                referenceModel.setRefEmail(String.valueOf(referenceList.get(i).get(ApiParamEnum.EMAIL.getValue())));
                referenceModel.setRefPhone(String.valueOf(referenceList.get(i).get(ApiParamEnum.TELEPHONE.getValue())));
                referenceModel.setRefPosition(String.valueOf(referenceList.get(i).get(ApiParamEnum.POSITION.getValue())));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            referenceModels.add(referenceModel);
        }
        model.setReferenceData(referenceModels);
        RMPrefs.getInstance(getActivity()).setReferenceModel(model);
    }

    private void askForConfirmation() {
        final CustomDialog dialog = new CustomDialog(getActivity(),
                getResources().getString(R.string.dialog_title_reference)
                , getResources().getString(R.string.dialog_reference_confirmation)
                , getResources().getString(R.string.action_continue)
                , getResources().getString(R.string.cancel)) {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.tvPositive:
                        addReferenceDetails();
                        dismiss();
                        break;
                    case R.id.tvNegative:
                        dismiss();
                        break;
                }
            }
        };
        dialog.show();
    }

    private void addReferenceDetails() {
        AppUtils.hideKeyboard(getActivity());
        if (referenceModels != null) {
            getPresenter().addReferenceDetails(referenceList, AppUtils.getCommonParams(getActivity(), new HashMap<String, Object>()));
        } else {
            getPresenter().addReferenceDetails(referenceList, null);
        }
    }

    private void addReference() {
        AppUtils.hideKeyboard(getActivity());
        HashMap<String, Object> hmReference = new HashMap<>();
        hmReference.put(ApiParamEnum.CONTACT_NAME.getValue(), AppUtils.getText(etContactName));
        hmReference.put(ApiParamEnum.COMPANY_NAME.getValue(), AppUtils.getText(etCompanyName));
        hmReference.put(ApiParamEnum.POSITION.getValue(), AppUtils.getText(etPosition));
        hmReference.put(ApiParamEnum.EMAIL.getValue(), AppUtils.getText(etEmail));
        hmReference.put(ApiParamEnum.TELEPHONE.getValue(), AppUtils.getText(etTelephone));
        getPresenter().isValidate(hmReference);
    }

    @Override
    public void onReferenceAdded(JSONObject jsonReferenceDetails) {
        if (isEditable && intEventPos < referenceList.size()) {
            referenceList.set(intEventPos, jsonReferenceDetails);
        } else {
            referenceList.add(jsonReferenceDetails);
        }
        if(isEditable){
            AppUtils.showToast(getActivity(), getResources().getString(R.string.msg_edit_reference));
        }else{
            AppUtils.showToast(getActivity(), getResources().getString(R.string.msg_add_reference));
        }
        isEditable = false;
        tvAddRef.setText(R.string.action_add_reference);
        if (referenceList.size() == 2) {
            tvAddRef.setVisibility(View.GONE);
            llAddReference.setVisibility(View.GONE);
        }
        addReferenceDetail();
    }

    private void addReferenceDetail() {
        if (adapter == null) {
            adapter = new ReferenceAdapter(getActivity(), referenceList);
            rvReferenceDetailsContainer.setAdapter(adapter);
            adapter.setRecycleOnItemEventListener(mRecycleviewEventListener);
        } else {
            adapter.notifyDataSetChanged();
        }
        if (adapter.getItemCount() > 0) {
            tvSubmit.setEnabled(true);
            tvSubmit.setAlpha(1.0f);
        }
        clearForm();
    }

    @Override
    public void onValidationError(ValidationErrorModel validationErrorModel) {
        AppUtils.showToast(getActivity(), validationErrorModel.getMsg());
        switch (validationErrorModel.getError()) {
            case CONTACT_NAME:
                AppUtils.requestEdittextFocus(getActivity(), etContactName);
                break;
            case COMPANY_NAME:
                AppUtils.requestEdittextFocus(getActivity(), etCompanyName);
                break;
            case POSITION:
                AppUtils.requestEdittextFocus(getActivity(), etPosition);
                break;
            case EMAIL:
                AppUtils.requestEdittextFocus(getActivity(), etEmail);
                break;
            case TELEPHONE:
                AppUtils.requestEdittextFocus(getActivity(), etTelephone);
                break;
        }
    }

    @Override
    public void onSuccess(HashMap<String, Object> response) {
        if (response != null && response.size() > 0) {
            if (onNextPressedListener != null) {
                onNextPressedListener.onNextPressed(RegisterForm.REGISTER_ALL_FORM_COMPLETED, response);
            } else if (onEditProfileListener != null) {
                referenceModels.clear();
                for (int i = 0; i < referenceList.size(); i++) {
                    Gson gson = new Gson();
                    String jsonString = "";
                    try {
                        jsonString = String.valueOf(referenceList.get(i));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (jsonString != null && !jsonString.equalsIgnoreCase("")) {
                        ProfileReferenceModel profileReferenceModel = gson.fromJson(jsonString, ProfileReferenceModel.class);
                        referenceModels.add(profileReferenceModel);
                    }
                }
                onEditProfileListener.onEditProfileSuccess(referenceModels);
            }
        }
    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
    }

    private void clearForm() {
        etContactName.setText("");
        etPosition.setText("");
        etCompanyName.setText("");
        etEmail.setText("");
        etTelephone.setText("");
        etContactName.requestFocus();
        etContactName.setCursorVisible(true);
    }
}
