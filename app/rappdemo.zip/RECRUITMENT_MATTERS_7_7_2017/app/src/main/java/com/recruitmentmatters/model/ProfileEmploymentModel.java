package com.recruitmentmatters.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;
import com.recruitmentmatters.constants.ApiParamEnum;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Darshna Desai on 5/4/17.
 */

public class ProfileEmploymentModel implements Parcelable {

    public static final Creator<ProfileEmploymentModel> CREATOR = new Creator<ProfileEmploymentModel>() {
        @Override
        public ProfileEmploymentModel createFromParcel(Parcel in) {
            return new ProfileEmploymentModel(in);
        }

        @Override
        public ProfileEmploymentModel[] newArray(int size) {
            return new ProfileEmploymentModel[size];
        }
    };
    @SerializedName(value = "emp_company", alternate = "employer")
    String empCompany;
    @SerializedName(value = "emp_position", alternate = "position")
    String empPosition;
    @SerializedName(value = "emp_start_date", alternate = "start_date")
    String empStartDate;
    @SerializedName(value = "emp_end_date", alternate = "end_date")
    String empEndDate;
    @SerializedName(value = "emp_key_skills", alternate = "key_skills")
    String empKeySkills;

    public ProfileEmploymentModel() {

    }

    protected ProfileEmploymentModel(Parcel in) {
        empCompany = in.readString();
        empPosition = in.readString();
        empStartDate = in.readString();
        empEndDate = in.readString();
        empKeySkills = in.readString();
    }

    public JSONObject toJSONObject() {
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject();
            jsonObject.put(ApiParamEnum.EMPLOYER.getValue(), getEmpCompany());
            jsonObject.put(ApiParamEnum.POSITION.getValue(), getEmpPosition());
            jsonObject.put(ApiParamEnum.START_DATE.getValue(), getEmpStartDate());
            jsonObject.put(ApiParamEnum.END_DATE.getValue(), getEmpEndDate());
            jsonObject.put(ApiParamEnum.KEY_SKILLS.getValue(), getEmpKeySkills());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    public String getEmpCompany() {
        return empCompany;
    }

    public void setEmpCompany(String empCompany) {
        this.empCompany = empCompany;
    }

    public String getEmpPosition() {
        return empPosition;
    }

    public void setEmpPosition(String empPosition) {
        this.empPosition = empPosition;
    }

    public String getEmpStartDate() {
        return empStartDate;
    }

    public void setEmpStartDate(String empStartDate) {
        this.empStartDate = empStartDate;
    }

    public String getEmpEndDate() {
        return empEndDate;
    }

    public void setEmpEndDate(String empEndDate) {
        this.empEndDate = empEndDate;
    }

    public String getEmpKeySkills() {
        return empKeySkills;
    }

    public void setEmpKeySkills(String empKeySkills) {
        this.empKeySkills = empKeySkills;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(empCompany);
        parcel.writeString(empPosition);
        parcel.writeString(empStartDate);
        parcel.writeString(empEndDate);
        parcel.writeString(empKeySkills);
    }
}
