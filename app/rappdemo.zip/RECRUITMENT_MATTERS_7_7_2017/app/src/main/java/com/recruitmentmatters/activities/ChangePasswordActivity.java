package com.recruitmentmatters.activities;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.MVPActivity;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.presenter.ChangePasswordPresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.views.ValidationErrorView;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Darshna Desai on 10/4/17.
 */

public class ChangePasswordActivity extends MVPActivity<ChangePasswordPresenter, ValidationErrorView<Response>> implements ValidationErrorView<Response> {

    @BindView(R.id.tvUpdate)
    TextView tvUpdate;

    @BindView(R.id.etCurrentPassword)
    EditText etCurrentPassword;
    @BindView(R.id.etNewPassword)
    EditText etNewPassword;
    @BindView(R.id.etConfirmPassword)
    EditText etConfirmPassword;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        init();
    }

    @NonNull
    @Override
    public ChangePasswordPresenter createPresenter() {
        return new ChangePasswordPresenter();
    }

    @NonNull
    @Override
    public ValidationErrorView<Response> attachView() {
        return this;
    }

    private void init() {
        ButterKnife.bind(this);
        initToolbar();
    }

    private void initToolbar() {
        tvToolbarTitle.setText(getResources().getString(R.string.toolbar_change_password));
    }

    @OnClick({R.id.tvUpdate, R.id.ivToolbarLeft})
    public void onClick(View view) {
        AppUtils.hideKeyboard(this);
        switch (view.getId()) {
            case R.id.tvUpdate:
                callChangePasswordApi();
                break;
            case R.id.ivToolbarLeft:
                finish();
                break;
        }
    }

    private void callChangePasswordApi() {
        tvUpdate.setEnabled(false);
        HashMap<String, Object> params = new HashMap<>();
        params.put(ApiParamEnum.CURRENT_PASSWORD.getValue(), AppUtils.getText(etCurrentPassword));
        params.put(ApiParamEnum.NEW_PASSWORD.getValue(), AppUtils.getText(etNewPassword));
        params.put(ApiParamEnum.CONFIRM_PASSWORD.getValue(), AppUtils.getText(etConfirmPassword));
        params = AppUtils.getCommonParams(ChangePasswordActivity.this, params);
        getPresenter().isValidData(params);
    }

    @Override
    public void onValidationError(ValidationErrorModel validationErrorModel) {
        tvUpdate.setEnabled(true);
        AppUtils.showToast(getActivity(), validationErrorModel.getMsg());
        switch (validationErrorModel.getError()) {
            case CURRENT_PASSWORD:
                AppUtils.requestEdittextFocus(ChangePasswordActivity.this, etCurrentPassword);
                break;
            case PASSWORD:
                AppUtils.requestEdittextFocus(ChangePasswordActivity.this, etNewPassword);
                break;
            case CONFIRM_PASSWORD:
                AppUtils.requestEdittextFocus(ChangePasswordActivity.this, etConfirmPassword);
                break;
        }
    }

    @Override
    public void onFailure(String message) {
        tvUpdate.setEnabled(true);
        AppUtils.showToast(getActivity(), message);
    }

    @Override
    public void onSuccess(Response response) {
        tvUpdate.setEnabled(true);
        AppUtils.showToast(getActivity(), response.getMessage());
        finish();
    }
}
