package com.recruitmentmatters.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.model.LanguageModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;

public class LanguageAdapter extends BaseAdapter {

    private Context context;
    private List<LanguageModel> languageModels;
    private LayoutInflater inflater;
    private LanguageSelectListener languageSelectListener = null;

    public LanguageAdapter(Context context, ArrayList<LanguageModel> list, LanguageSelectListener languageSelectListener) {
        this.context = context;
        languageModels = list;
        inflater = inflater.from(this.context);
        this.languageSelectListener = languageSelectListener;
    }

    @Override
    public int getCount() {
        return languageModels.size();
    }

    @Override
    public Object getItem(int i) {
        return languageModels.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        Holder holder = null;
        if (view == null) {
            view = inflater.inflate(R.layout.item_language_spoken, viewGroup, false);
            holder = new Holder(view);
            view.setTag(holder);
        } else {
            holder = (Holder) view.getTag();
        }
        LanguageModel languageModel = languageModels.get(i);
        if (languageModel.isSelected()) {
            holder.ivLanguageSelection.setImageResource(R.drawable.tick_selected);
        } else {
            holder.ivLanguageSelection.setImageResource(R.drawable.tick_unselected);
        }
        if (languageModel.getLanguageName().equalsIgnoreCase("Other") && languageModel.isSelected()) {
            languageSelectListener.onOtherLanguageSelected(true);
        } else if (languageModel.getLanguageName().equalsIgnoreCase("Other") && !languageModel.isSelected()) {
            languageSelectListener.onOtherLanguageSelected(false);
        }
        holder.tvLanguageName.setText(languageModel.getLanguageName());
        holder.tvLanguageName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                languageSelectListener.onLanguageSelect(i);
            }
        });

        holder.ivLanguageSelection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                languageSelectListener.onLanguageSelect(i);
            }
        });
        return view;
    }

    public static interface LanguageSelectListener {
        void onLanguageSelect(int pos);

        void onOtherLanguageSelected(boolean isSelected);
    }

    public static class Holder {

        ImageView ivLanguageSelection;
        TextView tvLanguageName;

        public Holder(View v) {
            ivLanguageSelection = ButterKnife.findById(v, R.id.ivLanguageSelection);
            tvLanguageName = ButterKnife.findById(v, R.id.tvLanguageName);
        }
    }
}
