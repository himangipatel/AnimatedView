package com.recruitmentmatters.constants;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by Darshna Desai on 6/3/17.
 */

public class DemoIntDef {

    //Validation error code constants
    public static final int EMAIL = 0;
    public static final int PHONE = 1;
    public static final int PASSWORD = 2;

    @IntDef({EMAIL, PHONE, PASSWORD})
     /* Tell the compiler not to store annotation data in the .class file */
    @Retention(RetentionPolicy.SOURCE)
    public @interface ValidationErrorCode {
    }


    @ValidationErrorCode
    private int mCode;

    @ValidationErrorCode
    public int getValidationErrorCode() {
        return mCode;
    }

    public void setValidationErrorCode(@ValidationErrorCode int code) {
        mCode = code;
    }

}
