package com.recruitmentmatters.views;

import org.json.JSONObject;

/**
 * Created by Sameer Jani on 3/4/17.
 */

public interface ReferenceView<T> extends ValidationErrorView<T> {
    void onReferenceAdded(JSONObject jsonReferenceDetails);
}
