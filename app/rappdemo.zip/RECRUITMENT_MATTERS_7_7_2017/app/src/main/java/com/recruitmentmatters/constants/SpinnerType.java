package com.recruitmentmatters.constants;

/**
 * Created by Sameer Jani on 29/3/17.
 */

public enum SpinnerType {
    GENDER, COUNTRY, DRIVING_LICENCE, CATEGORY, AVAILABLE, UNIVERSITY_LOCATION
}
