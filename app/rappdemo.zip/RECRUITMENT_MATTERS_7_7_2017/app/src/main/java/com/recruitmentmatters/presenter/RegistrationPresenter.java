package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.baseclasses.BaseView;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.Response;

import java.util.HashMap;

/**
 * Created by Sameer Jani on 4/4/17.
 */

public class RegistrationPresenter extends BasePresenter<BaseView<String>> {

    public void callRegistrationApi(HashMap<String, Object> params) {
        if (hasInternet()) {//If no internet it will show toast automatically.

            addSubscription(getAppInteractor().callRegistrationApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onSuccess(response.getMessage());
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }
}
