package com.recruitmentmatters.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Sameer Jani on 4/4/17.
 */

public class CategoryModel implements Parcelable {
    public static final Creator<CategoryModel> CREATOR = new Creator<CategoryModel>() {
        @Override
        public CategoryModel createFromParcel(Parcel in) {
            return new CategoryModel(in);
        }

        @Override
        public CategoryModel[] newArray(int size) {
            return new CategoryModel[size];
        }
    };
    @SerializedName(value = "cat_id", alternate = "location_id")
    String cat_id = "";
    @SerializedName(value = "cat_name", alternate = "location_name")
    String cat_name = "";
    @SerializedName("count")
    String count = "";

    protected CategoryModel(Parcel in) {
        cat_id = in.readString();
        cat_name = in.readString();
        count = in.readString();
    }

    public String getCat_id() {
        return cat_id;
    }

    public void setCat_id(String cat_id) {
        this.cat_id = cat_id;
    }

    public String getCat_name() {
        return cat_name;
    }

    public void setCat_name(String cat_name) {
        this.cat_name = cat_name;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(cat_id);
        parcel.writeString(cat_name);
        parcel.writeString(count);
    }
}
