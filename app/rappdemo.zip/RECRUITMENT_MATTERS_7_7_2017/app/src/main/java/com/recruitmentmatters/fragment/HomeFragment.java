package com.recruitmentmatters.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.activities.AdvanceSearchActivity;
import com.recruitmentmatters.activities.JobDetailsActivity;
import com.recruitmentmatters.activities.MainActivity;
import com.recruitmentmatters.adapter.JobListingAdapter;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.customview.EndlessRecyclerViewScrollListener;
import com.recruitmentmatters.model.JobListResponse;
import com.recruitmentmatters.model.JobModel;
import com.recruitmentmatters.model.UserDataModel;
import com.recruitmentmatters.presenter.JobListingPresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;
import com.recruitmentmatters.views.JobListingView;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Darshna Desai on 24/3/17.
 */

public class HomeFragment extends MVPFragment<JobListingPresenter, JobListingView<JobListResponse>> implements JobListingView<JobListResponse> {

    @BindView(R.id.commonRecyclerView)
    RecyclerView commonRecyclerView;
    @BindView(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    @BindView(R.id.tvNoJobs)
    TextView tvNoJobs;
    @BindView(R.id.ivSearch)
    ImageView ivSearch;

    private JobListingAdapter adapter;
    private ArrayList<JobModel> jobModelArrayList = new ArrayList<>();
    private int totalRecords = 0;
    private boolean isMyApplication = false;

    private boolean isPullToRefresh = false;
    private boolean isLoadMore = false;
    SwipeRefreshLayout.OnRefreshListener mOnRefreshListener = new SwipeRefreshLayout.OnRefreshListener() {
        @Override
        public void onRefresh() {
            swipeRefreshLayout.setRefreshing(true);
            callGetJobsApi(true, false);
        }
    };
    private EndlessRecyclerViewScrollListener endlessRecyclerViewScrollListener;
    private BaseRecyclerAdapter.RecycleOnItemEventListener mRecycleviewEventListener = new BaseRecyclerAdapter.RecycleOnItemEventListener() {
        @Override
        public void onItemClick(View view, int position) {
            switch (view.getId()) {
                case R.id.ivFavourite:
                    callFavouriteJobApi(((JobListingAdapter) commonRecyclerView.getAdapter()).getData(position), position);
                    break;
                default:
                    Intent redirectIntent = new Intent(getContext(), JobDetailsActivity.class);
                    redirectIntent.putExtra(ApiParamEnum.JOB_ID.getValue(),
                            ((JobListingAdapter) commonRecyclerView.getAdapter()).getData(position).getJobId());
                    redirectIntent.putExtra(AppConstants.SEND_JOB_DETAILS_POSITION,
                            position);
                    redirectIntent.putExtra(AppConstants.SEND_IS_MY_APPLICATION_JOB_DETAILS,
                            isMyApplication);
                    startActivityForResult(redirectIntent, AppConstants.SEND_JOB_DETAILS);
            }
        }

        @Override
        public void onItemLongPress(View view, int position) {
        }
    };

    @NonNull
    @Override
    public JobListingPresenter createPresenter() {
        return new JobListingPresenter();
    }

    @NonNull
    @Override
    public JobListingView attachView() {
        return this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.app_recyclerview, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        init(view, savedInstanceState);
    }

    private void init(View v, Bundle savedInstanceState) {
        swipeRefreshLayout.setOnRefreshListener(mOnRefreshListener);
        commonRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        setAdapterData();
        if (getArguments() != null && getArguments().getString(AppConstants.SEND_FOR_MY_APPLICATION_SCREEN) != null) {//For Application Screen
            isMyApplication = true;
            swipeRefreshLayout.setEnabled(false);
            callGetMyApplicationJobsApi();
        } else {//For home screen
            ivSearch.setVisibility(View.VISIBLE);
            callGetJobsApi(false, false);
        }
    }

    private void callGetMyApplicationJobsApi() {
        UserDataModel userDataModel = RMPrefs.getInstance(getActivity()).getUserDataModel();
        String accessToken = RMPrefs.getInstance(getActivity()).getAccessToken();
        if (userDataModel != null && accessToken != null) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put(ApiParamEnum.USER_ID.getValue(), userDataModel.getUser_id());
            hashMap.put(ApiParamEnum.PERSONAL_ID.getValue(), userDataModel.getUser_personal_id());
            hashMap.put(ApiParamEnum.ACCESS_TOKEN.getValue(), accessToken);
            getPresenter().callGetMyApplicationJobsListApi(hashMap);
        }
    }

    private void setAdapterData() {
        adapter = new JobListingAdapter(getActivity(), jobModelArrayList);
        commonRecyclerView.setAdapter(adapter);
        endlessRecyclerViewScrollListener =
                new EndlessRecyclerViewScrollListener((LinearLayoutManager) commonRecyclerView.getLayoutManager()) {
                    @Override
                    public void onLoadMore(int page, int totalItemsCount) {
                        if(totalRecords != jobModelArrayList.size()) {
                            endlessRecyclerViewScrollListener.setLoading(true);
                            callGetJobsApi(false, true);
                        }
                    }
                }.setVisibleThreshold(10);
        commonRecyclerView.addOnScrollListener(endlessRecyclerViewScrollListener);
        adapter.setRecycleOnItemEventListener(mRecycleviewEventListener);
    }

    private void callFavouriteJobApi(JobModel jobModel, int position) {
        HashMap<String, String> params = new HashMap<>();
        UserDataModel user = RMPrefs.getInstance(getActivity()).getUserDataModel();
        if (user != null) {
            params.put(ApiParamEnum.USER_ID.getValue(), user.getUser_id());
            params.put(ApiParamEnum.ACCESS_TOKEN.getValue(), RMPrefs.getInstance(getActivity()).getAccessToken());
            params.put(ApiParamEnum.PERSONAL_ID.getValue(), user.getUser_personal_id());
            params.put(ApiParamEnum.JOB_ID.getValue(), jobModel.getJobId());
            params.put(ApiParamEnum.IS_FAVOURITE.getValue(), jobModel.isJobFav() ? "2" : "1");
            getPresenter().callFavouriteJobsApi(params, position);
        }else{
            AppUtils.showToast(getActivity(), getResources().getString(R.string.msg_login_to_favourite));
        }
    }

    private void callGetJobsApi(boolean isPullToRefresh, boolean isLoadMore) {
        this.isPullToRefresh = isPullToRefresh;
        this.isLoadMore = isLoadMore;
        HashMap<String, String> params = new HashMap<>();
        UserDataModel user = RMPrefs.getInstance(getActivity()).getUserDataModel();
        if (user != null) {
            params.put(ApiParamEnum.USER_ID.getValue(), user.getUser_id());
        }
        Bundle bundle = getArguments();
        if (bundle != null) {
            ivSearch.setVisibility(View.GONE);
            params.put(ApiParamEnum.SEARCH_WORD.getValue(), bundle.getString(ApiParamEnum.SEARCH_WORD.getValue(), ""));
            params.put(ApiParamEnum.CAT_ID.getValue(), bundle.getString(ApiParamEnum.CAT_ID.getValue(), ""));
            params.put(ApiParamEnum.LOCATION_NAME.getValue(), bundle.getString(ApiParamEnum.LOCATION_NAME.getValue(), ""));
            params.put(ApiParamEnum.LOCATION_ID.getValue(), bundle.getString(ApiParamEnum.LOCATION_ID.getValue(), ""));
        }
        getPresenter().callGetJobsApi(params, isPullToRefresh, isLoadMore);
    }

    @Override
    public void onSuccess(JobListResponse response) {
        swipeRefreshLayout.setRefreshing(false);
        if (endlessRecyclerViewScrollListener != null)
            endlessRecyclerViewScrollListener.setLoading(false);

        if (response != null && !response.getJobData().isEmpty()) {
            tvNoJobs.setVisibility(View.GONE);
            totalRecords = response.getTotalRecord();
            if (isPullToRefresh && commonRecyclerView.getAdapter() != null && commonRecyclerView.getAdapter().getItemCount() > 0) {
                ((JobListingAdapter) commonRecyclerView.getAdapter()).clearAll();
                ((JobListingAdapter) commonRecyclerView.getAdapter()).appendAll(response.getJobData());
            } else if (commonRecyclerView.getAdapter() != null && commonRecyclerView.getAdapter().getItemCount() > 0) {
                ((JobListingAdapter) commonRecyclerView.getAdapter()).appendAll(response.getJobData());
            } else {
                jobModelArrayList = response.getJobData();
                adapter.setData(jobModelArrayList);
                adapter.notifyDataSetChanged();
            }
        }else if (!isLoadMore && !isPullToRefresh && jobModelArrayList.size() <= 0) {
                tvNoJobs.setVisibility(View.VISIBLE);
        }

        isPullToRefresh = false;
        isLoadMore = false;
    }

    @Override
    public void onFailure(String message) {

        if (!isLoadMore && !isPullToRefresh) {
            tvNoJobs.setVisibility(View.VISIBLE);
        }
        if (swipeRefreshLayout != null && swipeRefreshLayout.isRefreshing())
            swipeRefreshLayout.setRefreshing(false);
        if (endlessRecyclerViewScrollListener != null)
            endlessRecyclerViewScrollListener.setLoading(false);
        if (message != null) {
            AppUtils.showToast(getActivity(), message);
        }

        isLoadMore = false;
        isPullToRefresh = false;
    }

    @Override
    public void onSuccessFavourite(String response, int pos) {
        AppUtils.showToast(getActivity(), response);
        ((JobListingAdapter) commonRecyclerView.getAdapter()).getData(pos).setJobFav(!((JobListingAdapter) commonRecyclerView.getAdapter()).getData(pos).isJobFav());
        commonRecyclerView.getAdapter().notifyDataSetChanged();
    }

    @Override
    public void onFailureFavourite(String msg) {
        AppUtils.showToast(getActivity(), msg);
    }

    @Override
    public void onMyApplicationJobSuccess(ArrayList<JobModel> jobModels) {
        if (jobModels == null || jobModels.isEmpty()) {
            tvNoJobs.setVisibility(View.VISIBLE);
            return;
        }
        commonRecyclerView.setAdapter(new JobListingAdapter(getActivity(), jobModels).setRecycleOnItemEventListener(mRecycleviewEventListener));
    }

    @OnClick({R.id.ivSearch})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivSearch:
                startActivity(new Intent(getActivity(), AdvanceSearchActivity.class));
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AppConstants.SEND_JOB_DETAILS && resultCode == Activity.RESULT_OK && data != null) {
            if (commonRecyclerView.getAdapter() != null) {
                int pos = data.getIntExtra(AppConstants.SEND_JOB_DETAILS_POSITION, -1);
                JobModel jobModel = data.getParcelableExtra(AppConstants.RETURNED_JOB_DETAIL);
                if (pos >= 0 && jobModel != null) {
                    if (getActivity() instanceof MainActivity && !isMyApplication) {
                        ((JobListingAdapter) commonRecyclerView.getAdapter()).setHotJobListFavourite(jobModel.getJobId(), jobModel.isJobFav());
                    } else {
                        ((JobListingAdapter) commonRecyclerView.getAdapter()).setData(jobModel, pos);
                    }
                }
            }
        }
    }
}
