package com.recruitmentmatters.listeners;

import com.recruitmentmatters.constants.RegisterForm;

import java.util.HashMap;

/**
 * Created by Sameer Jani on 28/3/17.
 */

public interface OnNextPressedListener {
    void onNextPressed(RegisterForm registerForm, HashMap<String, Object> saveObjectData);

    void onPreviousClicked();
}
