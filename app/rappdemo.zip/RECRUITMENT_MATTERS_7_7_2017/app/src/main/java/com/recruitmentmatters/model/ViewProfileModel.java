package com.recruitmentmatters.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Darshna Desai on 5/4/17.
 */

public class ViewProfileModel implements Parcelable {

    public static final Creator<ViewProfileModel> CREATOR = new Creator<ViewProfileModel>() {
        @Override
        public ViewProfileModel createFromParcel(Parcel in) {
            return new ViewProfileModel(in);
        }

        @Override
        public ViewProfileModel[] newArray(int size) {
            return new ViewProfileModel[size];
        }
    };
    @SerializedName("general_info")
    ProfileGeneralInfoModel generalInfoModel;
    @SerializedName("edu_info")
    ProfileEducationInfoModel educationInfoModel;
    @SerializedName("languages")
    LanguageModel languageModel;
    @SerializedName("job_category_info")
    ProfileJobCategoryModel jobCategoryModel;
    @SerializedName("job_type")
    ProfileJobTypeModel jobTypeModel;
    @SerializedName("employment_info")
    ArrayList<ProfileEmploymentModel> employmentData;
    @SerializedName("ref_info")
    ArrayList<ProfileReferenceModel> referenceData;

    public ViewProfileModel(){}

    protected ViewProfileModel(Parcel in) {
        generalInfoModel = in.readParcelable(ProfileGeneralInfoModel.class.getClassLoader());
        educationInfoModel = in.readParcelable(ProfileEducationInfoModel.class.getClassLoader());
    }

    public ProfileGeneralInfoModel getGeneralInfoModel() {
        return generalInfoModel;
    }

    public void setGeneralInfoModel(ProfileGeneralInfoModel generalInfoModel) {
        this.generalInfoModel = generalInfoModel;
    }

    public ProfileEducationInfoModel getEducationInfoModel() {
        return educationInfoModel;
    }

    public void setEducationInfoModel(ProfileEducationInfoModel educationInfoModel) {
        this.educationInfoModel = educationInfoModel;
    }

    public LanguageModel getLanguageModel() {
        return languageModel;
    }

    public void setLanguageModel(LanguageModel languageModel) {
        this.languageModel = languageModel;
    }

    public ProfileJobCategoryModel getJobCategoryModel() {
        return jobCategoryModel;
    }

    public void setJobCategoryModel(ProfileJobCategoryModel jobCategoryModel) {
        this.jobCategoryModel = jobCategoryModel;
    }

    public ProfileJobTypeModel getJobTypeModel() {
        return jobTypeModel;
    }

    public void setJobTypeModel(ProfileJobTypeModel jobTypeModel) {
        this.jobTypeModel = jobTypeModel;
    }

    public ArrayList<ProfileEmploymentModel> getEmploymentData() {
        return employmentData;
    }

    public void setEmploymentData(ArrayList<ProfileEmploymentModel> employmentData) {
        this.employmentData = employmentData;
    }

    public ArrayList<ProfileReferenceModel> getReferenceData() {
        return referenceData;
    }

    public void setReferenceData(ArrayList<ProfileReferenceModel> referenceData) {
        this.referenceData = referenceData;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(generalInfoModel, i);
        parcel.writeParcelable(educationInfoModel, i);
    }
}
