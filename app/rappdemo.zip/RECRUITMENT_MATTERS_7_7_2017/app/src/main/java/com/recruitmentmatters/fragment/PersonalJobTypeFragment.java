package com.recruitmentmatters.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.constants.RegisterForm;
import com.recruitmentmatters.listeners.OnEditProfileListener;
import com.recruitmentmatters.listeners.OnNextPressedListener;
import com.recruitmentmatters.model.ProfileJobTypeModel;
import com.recruitmentmatters.presenter.PersonalJobTypePresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.views.ValidationErrorView;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnCheckedChanged;
import butterknife.OnClick;

/**
 * Created by Sameer Jani on 28/3/17.
 */

public class PersonalJobTypeFragment extends MVPFragment<PersonalJobTypePresenter, ValidationErrorView<HashMap<String, Object>>> implements ValidationErrorView<HashMap<String, Object>> {

    @BindView(R.id.cbTemporary)
    CheckBox cbTemporary;
    @BindView(R.id.cbPermanent)
    CheckBox cbPermanent;
    @BindView(R.id.cbInterim)
    CheckBox cbIterim;
    @BindView(R.id.tvInterim)
    TextView tvInterim;
    @BindView(R.id.etCurrentSalary)
    EditText etCurrentSalary;
    @BindView(R.id.etExpectedSalary)
    EditText etExpectedSalary;
    @BindView(R.id.etNoticePeriod)
    EditText etNoticePeriod;
    @BindView(R.id.tvNext)
    TextView tvNext;
    @BindView(R.id.tvTopHeader)
    RelativeLayout tvTopHeader;

    RelativeLayout rlPersonalTitleBar;
    TextView tvFormTitle;
    ImageView ivFormBack;

    OnNextPressedListener onNextPressedListener = null;
    OnEditProfileListener onEditProfileListener = null;

    private ProfileJobTypeModel profileJobTypeModel = null;

    public PersonalJobTypeFragment() {
    }


    @NonNull
    @Override
    public PersonalJobTypePresenter createPresenter() {
        return new PersonalJobTypePresenter();
    }

    @NonNull
    @Override
    public ValidationErrorView<HashMap<String, Object>> attachView() {
        return this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.partial_reg_job_type, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        rlPersonalTitleBar = ButterKnife.findById(view, R.id.rlPersonalTitleBar);
        ivFormBack = ButterKnife.findById(view, R.id.ivFormBack);
        tvFormTitle = ButterKnife.findById(view, R.id.tvFormTitle);
        if (getActivity() instanceof OnNextPressedListener)
            onNextPressedListener = (OnNextPressedListener) getActivity();
        if (getActivity() instanceof OnEditProfileListener)
            onEditProfileListener = (OnEditProfileListener) getActivity();
        initFormTitleBar();
        setDataFromPrefs();
        checkForEdit();
    }

    private void initFormTitleBar() {
        ivFormBack.setVisibility(View.VISIBLE);
        tvFormTitle.setText(R.string.title_job_type);
        tvInterim.setText(getResources().getString(R.string.title_interim) + " " + getResources().getString(R.string.msg_interim));
    }

    private void setDataFromPrefs() {
        profileJobTypeModel = RMPrefs.getInstance(getActivity()).getJobTypeModel();
        if (profileJobTypeModel != null) {
            setData();
        }
    }

    private void checkForEdit() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            if (bundle.getParcelable(AppConstants.SEND_DATA_EDIT_PROFILE) != null) {
                profileJobTypeModel = bundle.getParcelable(AppConstants.SEND_DATA_EDIT_PROFILE);
                tvTopHeader.setVisibility(View.GONE);
                tvNext.setText(R.string.update);
                setData();
            }
        }
    }

    private void setData() {
        etCurrentSalary.setText(profileJobTypeModel.getCurrentSalary());
        etExpectedSalary.setText(profileJobTypeModel.getExpectedSalary());
        etNoticePeriod.setText(profileJobTypeModel.getNoticePeriod());
        String[] jobType = profileJobTypeModel.getJobType().split("/");
        for (int i = 0; i < jobType.length; i++) {
            if (jobType[i].equalsIgnoreCase(getString(R.string.title_temporary))) {
                cbTemporary.setChecked(true);
            } else if (jobType[i].equalsIgnoreCase(getString(R.string.title_permanent))) {
                cbPermanent.setChecked(true);
            } else if (jobType[i].equalsIgnoreCase(getString(R.string.title_interim))) {
                cbIterim.setChecked(true);
            }
        }
    }

    @OnCheckedChanged({R.id.cbTemporary, R.id.cbPermanent, R.id.cbInterim})
    public void onCheckChanged(CompoundButton compoundButton, boolean b) {
        compoundButton.setButtonDrawable(compoundButton.isChecked() ? R.drawable.tick_selected : R.drawable.tick_unselected);
    }

    @OnClick({R.id.tvNext, R.id.ivFormBack})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvNext:
                addJobType();
                break;

            case R.id.ivFormBack:
                if (onNextPressedListener != null) {
                    saveDataInPrefs();
                    onNextPressedListener.onPreviousClicked();
                }
                break;
        }
    }

    public void saveDataInPrefs() {
        ProfileJobTypeModel model = new ProfileJobTypeModel();
        model.setJobType(getJobType());
        model.setCurrentSalary(AppUtils.getText(etCurrentSalary));
        model.setExpectedSalary(AppUtils.getText(etExpectedSalary));
        model.setNoticePeriod(AppUtils.getText(etNoticePeriod));
        RMPrefs.getInstance(getActivity()).setJobTypeModel(model);
    }

    private void addJobType() {
        AppUtils.hideKeyboard(getActivity());
        String strJobType = getJobType();
        HashMap<String, Object> hmJobType = new HashMap<>();
        hmJobType.put(ApiParamEnum.JOB_TYPE.getValue(), strJobType);
        hmJobType.put(ApiParamEnum.CURRENT_SALARY.getValue(), AppUtils.getText(etCurrentSalary));
        hmJobType.put(ApiParamEnum.EXPECTED_SALARY.getValue(), AppUtils.getText(etExpectedSalary));
        hmJobType.put(ApiParamEnum.NOTICE_PERIOD.getValue(), AppUtils.getText(etNoticePeriod));
        if (profileJobTypeModel != null) {
            hmJobType = AppUtils.getCommonParams(getActivity(), hmJobType);
        }
        getPresenter().isValidate(hmJobType, onNextPressedListener == null);

    }

    private String getJobType() {
        String strJobType = "";
        if (cbTemporary.isChecked()) {
            strJobType = getString(R.string.title_temporary);
        }
        if (cbPermanent.isChecked()) {
            if (strJobType.length() > 0) {
                strJobType = strJobType + "/" + getString(R.string.title_permanent);
            } else {
                strJobType = getString(R.string.title_permanent);
            }
        }
        if (cbIterim.isChecked()) {
            if (strJobType.length() > 0) {
                strJobType = strJobType + "/" + getString(R.string.title_interim);
            } else {
                strJobType = getString(R.string.title_interim);
            }
        }
        return strJobType;
    }

    @Override
    public void onValidationError(ValidationErrorModel validationErrorModel) {
        AppUtils.showToast(getActivity(), validationErrorModel.getMsg());
        switch (validationErrorModel.getError()) {
            case CURRRENT_SALARY:
                AppUtils.requestEdittextFocus(getActivity(), etCurrentSalary);
                break;
            case EXPECTED_SALARY:
                AppUtils.requestEdittextFocus(getActivity(), etExpectedSalary);
                break;
        }
    }

    @Override
    public void onSuccess(HashMap<String, Object> response) {
        if (response != null && response.size() > 0) {
            if (onNextPressedListener != null) {
                onNextPressedListener.onNextPressed(RegisterForm.EMPLOYMENT_DETAIL, response);
            } else if (onEditProfileListener != null) {
                profileJobTypeModel.setCurrentSalary(AppUtils.getText(etCurrentSalary));
                profileJobTypeModel.setExpectedSalary(AppUtils.getText(etExpectedSalary));
                profileJobTypeModel.setNoticePeriod(AppUtils.getText(etNoticePeriod));
                profileJobTypeModel.setJobType(String.valueOf(response.get(ApiParamEnum.JOB_TYPE.getValue())));
                onEditProfileListener.onEditProfileSuccess(profileJobTypeModel);
            }
        }
    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
    }
}
