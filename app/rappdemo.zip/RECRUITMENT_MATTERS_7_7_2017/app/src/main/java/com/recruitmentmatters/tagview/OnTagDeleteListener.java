package com.recruitmentmatters.tagview;

/**
 * listener for tag delete
 */
public interface OnTagDeleteListener {
    void onTagDeleted(int position, Tag tag);
}