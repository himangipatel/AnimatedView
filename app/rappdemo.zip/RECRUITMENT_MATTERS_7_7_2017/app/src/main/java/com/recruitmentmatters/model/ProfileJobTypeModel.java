package com.recruitmentmatters.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Darshna Desai on 5/4/17.
 */

public class ProfileJobTypeModel implements Parcelable{

    @SerializedName("job_type")
    String jobType;
    @SerializedName("current_salary")
    String currentSalary;
    @SerializedName("expected_salary")
    String expectedSalary;
    @SerializedName("notice_period")
    String noticePeriod;

    protected ProfileJobTypeModel(Parcel in) {
        jobType = in.readString();
        currentSalary = in.readString();
        expectedSalary = in.readString();
        noticePeriod = in.readString();
    }

    public static final Creator<ProfileJobTypeModel> CREATOR = new Creator<ProfileJobTypeModel>() {
        @Override
        public ProfileJobTypeModel createFromParcel(Parcel in) {
            return new ProfileJobTypeModel(in);
        }

        @Override
        public ProfileJobTypeModel[] newArray(int size) {
            return new ProfileJobTypeModel[size];
        }
    };

    public ProfileJobTypeModel(){}

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public String getCurrentSalary() {
        return currentSalary;
    }

    public void setCurrentSalary(String currentSalary) {
        this.currentSalary = currentSalary;
    }

    public String getExpectedSalary() {
        return expectedSalary;
    }

    public void setExpectedSalary(String expectedSalary) {
        this.expectedSalary = expectedSalary;
    }

    public String getNoticePeriod() {
        return noticePeriod;
    }

    public void setNoticePeriod(String noticePeriod) {
        this.noticePeriod = noticePeriod;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(jobType);
        parcel.writeString(currentSalary);
        parcel.writeString(expectedSalary);
        parcel.writeString(noticePeriod);
    }
}
