package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Sameer Jani on 13/4/17.
 */

public class JobDetailsModel {

    @SerializedName("job")
    JobDetailsJobModel job;
    @SerializedName("prefereed")
    JobPrefereedModel prefereed;

    public JobDetailsJobModel getJob() {
        return job;
    }

    public void setJob(JobDetailsJobModel job) {
        this.job = job;
    }

    public JobPrefereedModel getPrefereed() {
        return prefereed;
    }

    public void setPrefereed(JobPrefereedModel prefereed) {
        this.prefereed = prefereed;
    }
}
