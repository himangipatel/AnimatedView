package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Sameer Jani on 19/4/17.
 */

public class MyApplicationResponse extends Response {

    @SerializedName("job_data")
    ArrayList<JobModel> jobModels;

    public ArrayList<JobModel> getJobModels() {
        return jobModels;
    }

    public void setJobModels(ArrayList<JobModel> jobModels) {
        this.jobModels = jobModels;
    }
}
