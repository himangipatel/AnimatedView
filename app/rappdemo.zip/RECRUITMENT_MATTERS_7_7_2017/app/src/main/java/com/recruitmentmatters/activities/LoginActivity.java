package com.recruitmentmatters.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.MVPActivity;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.model.LoginResponse;
import com.recruitmentmatters.presenter.LoginPresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.views.ValidationErrorView;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Darshna Desai on 23/3/17.
 */

public class LoginActivity extends MVPActivity<LoginPresenter, ValidationErrorView<LoginResponse>> implements ValidationErrorView<LoginResponse> {

    @BindView(R.id.tvLogin)
    TextView tvLogin;
    @BindView(R.id.tvForgotPassword)
    TextView tvForgotPassword;
    @BindView(R.id.tvCreateNow)
    TextView tvCreateNow;
    @BindView(R.id.etCandidateNo)
    EditText etCandidateNo;
    @BindView(R.id.etPassword)
    EditText etPassword;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        init();
    }

    @NonNull
    @Override
    public LoginPresenter createPresenter() {
        return new LoginPresenter();
    }

    @NonNull
    @Override
    public ValidationErrorView<LoginResponse> attachView() {
        return this;
    }

    private void init() {
        ButterKnife.bind(this);
        initToolbar();
    }

    private void initToolbar() {
        if(!(getIntent().hasExtra(AppConstants.EXTRA_FROM_MENU)
                && getIntent().getBooleanExtra(AppConstants.EXTRA_FROM_MENU, false))
                && !(getIntent().hasExtra(AppConstants.EXTRA_FROM_APPLY_JOB)
                && getIntent().getBooleanExtra(AppConstants.EXTRA_FROM_APPLY_JOB, false)) ) {
            setTvToolbarRightVisibility(View.VISIBLE, getResources().getString(R.string.action_skip));
        }
        ivToolbarLeft.setVisibility(View.GONE);
        tvToolbarTitle.setVisibility(View.GONE);
    }

    @OnClick({R.id.tvLogin, R.id.tvForgotPassword, R.id.tvCreateNow, R.id.tvToolbarRight})
    public void onClick(View view) {
        AppUtils.hideKeyboard(this);
        switch (view.getId()) {
            case R.id.tvLogin:
                callLoginApi();
                break;
            case R.id.tvForgotPassword:
                startActivity(new Intent(this, ForgotPasswordActivity.class));
                break;
            case R.id.tvCreateNow:
                startActivity(new Intent(this, RegistrationActivity.class));
                break;
            case R.id.tvToolbarRight:
                startActivity(new Intent(this, MainActivity.class));
                finish();
                break;
        }
    }

    private void callLoginApi() {
        HashMap<String, String> params = new HashMap<>();
        params.put(ApiParamEnum.CANDIDATE_REF_NO.getValue(), AppUtils.getText(etCandidateNo)); //224051
        params.put(ApiParamEnum.PASSWORD.getValue(), AppUtils.getText(etPassword));
        params.put(ApiParamEnum.DEVICE_TYPE.getValue(), String.valueOf(AppConstants.DEVICE_TYPE));
        getPresenter().isValidData(params);
    }

    @Override
    public void onValidationError(ValidationErrorModel validationErrorModel) {
        AppUtils.showToast(getActivity(), validationErrorModel.getMsg());
        switch (validationErrorModel.getError()) {
            case CANDIDATE_REF_NO:
                AppUtils.requestEdittextFocus(LoginActivity.this, etCandidateNo);
                break;
            case PASSWORD:
                AppUtils.requestEdittextFocus(LoginActivity.this, etPassword);
                break;
        }
    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
    }

    @Override
    public void onSuccess(LoginResponse response) {
        AppUtils.showToast(getActivity(), response.getMessage());
        setDataInPrefs(response);

        if((getIntent().hasExtra(AppConstants.EXTRA_FROM_APPLY_JOB)
                && getIntent().getBooleanExtra(AppConstants.EXTRA_FROM_APPLY_JOB, false))){
            Intent intent = new Intent();
            intent.putExtra(AppConstants.EXTRA_LOGIN_SUCCESS, true);
            setResult(Activity.RESULT_OK, intent);
        }else if(!(getIntent().hasExtra(AppConstants.EXTRA_FROM_MENU)
                && getIntent().getBooleanExtra(AppConstants.EXTRA_FROM_MENU, false))){
            startActivity(new Intent(this, MainActivity.class));
        }

        finish();
    }

    private void setDataInPrefs(LoginResponse response) {
        RMPrefs.getInstance(this).setUserDataModel(response.getUserDataModel());
        RMPrefs.getInstance(this).setAccessToken(response.getAccess_token());
        RMPrefs.getInstance(this).setUserLogin(true);
    }
}
