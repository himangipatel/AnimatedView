package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.JobListResponse;
import com.recruitmentmatters.model.MyApplicationResponse;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.views.JobListingView;

import java.util.HashMap;

/**
 * Created by Darshna Desai on 11/4/17.
 */

public class JobListingPresenter extends BasePresenter<JobListingView<JobListResponse>> {

    private static final int PER_PAGE = 10;
    private int PAGE = 1;

    public void callGetJobsApi(HashMap<String, String> params, final boolean isPullToRefresh, final boolean isLoadMore) {

        if (hasInternet()) {

            if (isPullToRefresh) {
                PAGE = 1;
            } else if(isLoadMore) {
                PAGE = PAGE + 1;
            }

            params.put(ApiParamEnum.PER_PAGE.getValue(), String.valueOf(PER_PAGE));
            params.put(ApiParamEnum.PAGE.getValue(), String.valueOf(PAGE));

            addSubscription(getAppInteractor().callGetJobsApi(params, new InterActorCallback<JobListResponse>() {
                @Override
                public void onStart() {
                    if(!isPullToRefresh && !isLoadMore) {
                        getView().showProgressDialog(true);
                    }
                }

                @Override
                public void onResponse(JobListResponse response) {
                    if (response.isStatus()) {
                        getView().onSuccess(response);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    if(!isPullToRefresh && !isLoadMore){
                        getView().onFailure(message);
                    }
                }
            }));
        } else {
            getView().onFailure(null);
        }
    }

    public void callFavouriteJobsApi(HashMap<String, String> params, final int position) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callFavouriteJobsApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressToolBar(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onSuccessFavourite(response.getMessage(), position);
                    } else {
                        getView().onFailureFavourite(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressToolBar(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailureFavourite(message);
                }
            }));
        }
    }

    public void callGetMyApplicationJobsListApi(HashMap<String, String> params) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callGetMyApplicationJobsListApi(params, new InterActorCallback<MyApplicationResponse>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(MyApplicationResponse response) {
                    if (response.isStatus()) {
                        getView().onMyApplicationJobSuccess(response.getJobModels());
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }
}

