package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.JobListResponse;
import com.recruitmentmatters.model.JobModel;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.views.JobFavouriteView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Sameer Jani on 18/4/17.
 */

public class JobFavouritePresenter extends BasePresenter<JobFavouriteView<ArrayList<JobModel>>> {

    public void callGetFavouriteJobsListApi(HashMap<String, String> params) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callGetFavouriteJobsListApi(params, new InterActorCallback<JobListResponse>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(JobListResponse response) {
                    if (response.isStatus()) {
                        getView().onSuccess(response.getJobData());
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        } else {
            getView().onFailure(null);
        }
    }

    public void callFavouriteJobsApi(HashMap<String, String> params, final int position) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callFavouriteJobsApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onFavouriteJobSucess(response.getMessage(), position);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        } else {
            getView().onFailure(null);
        }
    }
}
