package com.recruitmentmatters.views;

import com.recruitmentmatters.baseclasses.BaseView;
import com.recruitmentmatters.validator.ValidationErrorModel;

/**
 * Created by imobdev on 31/3/17.
 */

public interface ValidationErrorView<T> extends BaseView<T>{
    void onValidationError(ValidationErrorModel validationErrorModel);
}
