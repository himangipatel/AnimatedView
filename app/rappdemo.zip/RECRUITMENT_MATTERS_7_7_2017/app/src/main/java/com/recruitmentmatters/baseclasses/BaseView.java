package com.recruitmentmatters.baseclasses;

import android.app.Activity;

/**
 * Created by Darshna Desai on 6/3/17.
 */

public interface BaseView<T> {
    boolean hasInternet();

    void showProgressDialog(boolean show);

    void showProgressToolBar(boolean show);

    void onSuccess(T response);

    void onFailure(String message);

    void onAuthenticationFailure(String message);

    Activity getActivity();
}