package com.recruitmentmatters.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.model.CountryModel;

import java.util.ArrayList;

/**
 * Created by Darshna Desai on 2/5/17.
 */

public class SpinnerCustomAdapter  extends BaseAdapter {

    private Context context;
    private ArrayList<CountryModel> arrData;

    public SpinnerCustomAdapter(Context mContext, ArrayList<CountryModel> arrData) {
        this.context = mContext;
        this.arrData = arrData;
    }

    @Override
    public int getCount() {
        return arrData.size();
    }

    @Override
    public Object getItem(int i) {
        return arrData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        TextView tvSpinnerView = (TextView) LayoutInflater.from(context).inflate(R.layout.item_spinner_view, viewGroup, false);

        tvSpinnerView.setHint(R.string.hint_sp_uni_location);

        if (i == 0) {
            tvSpinnerView.setText("");
        } else {
            tvSpinnerView.setText(arrData.get(i).getCountry_name());
        }
        return tvSpinnerView;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        TextView tvSpinnerDropDown = (TextView) LayoutInflater.from(context).inflate(R.layout.item_spinner_dropdown_view, parent, false);
        tvSpinnerDropDown.setText(arrData.get(position).getCountry_name());
        return tvSpinnerDropDown;
    }
}