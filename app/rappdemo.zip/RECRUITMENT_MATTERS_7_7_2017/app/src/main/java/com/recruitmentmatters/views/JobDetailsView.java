package com.recruitmentmatters.views;

import com.recruitmentmatters.baseclasses.BaseView;

/**
 * Created by Sameer Jani on 15/4/17.
 */

public interface JobDetailsView<T> extends BaseView<T> {
    public void onJobApplySuccess(String message);

    public void onJobApplyFail(String message);

    public void onSuccessFavourite(String message);
}
