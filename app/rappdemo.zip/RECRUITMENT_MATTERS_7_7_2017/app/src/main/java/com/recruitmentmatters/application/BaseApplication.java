package com.recruitmentmatters.application;

import android.app.Application;

import com.crittercism.app.Crittercism;
import com.recruitmentmatters.R;
import com.recruitmentmatters.constants.AppConstants;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

/**
 * Created by Darshna Desai on 6/3/17.
 */

public class BaseApplication extends Application {

    private static BaseApplication baseApplication = null;

    public static BaseApplication getBaseApplication() {
        return baseApplication;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        baseApplication = this;

        /*Initialization for Crittercism (Crash analytics)*/
        Crittercism.initialize(getApplicationContext(), AppConstants.CRITICISM_ID);

        /*Initialization for Calligraphy for setting custom fonts in application*/
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/segoeuisl.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build()
        );
    }
}