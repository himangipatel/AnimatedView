package com.recruitmentmatters.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.adapter.LanguageAdapter;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.constants.RegisterForm;
import com.recruitmentmatters.listeners.OnEditProfileListener;
import com.recruitmentmatters.listeners.OnNextPressedListener;
import com.recruitmentmatters.model.LanguageModel;
import com.recruitmentmatters.model.UserDataModel;
import com.recruitmentmatters.presenter.PersonalLanguageSpokenPresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.views.ValidationErrorView;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Sameer Jani on 28/3/17.
 */

public class PersonalLanguageSpokenFragment extends MVPFragment<PersonalLanguageSpokenPresenter, ValidationErrorView<HashMap<String, Object>>> implements ValidationErrorView<HashMap<String, Object>>, LanguageAdapter.LanguageSelectListener {


    RelativeLayout rlPersonalTitleBar;
    TextView tvFormTitle;
    ImageView ivFormBack;

    @BindView(R.id.gvLanguages)
    GridView gvLanguages;
    @BindView(R.id.etOtherLanguage)
    EditText etOtherLanguage;

    @BindView(R.id.tvNext)
    TextView tvNext;
    @BindView(R.id.formTitlebar)
    View formTitlebar;

    private OnNextPressedListener onNextPressedListener = null;
    private ArrayList<LanguageModel> languageModels = new ArrayList<>();
    private LanguageModel languageModel = null;
    private LanguageAdapter languageAdapter = null;
    private OnEditProfileListener onEditProfileListener;

    public PersonalLanguageSpokenFragment() {
    }


    @NonNull
    @Override
    public PersonalLanguageSpokenPresenter createPresenter() {
        return new PersonalLanguageSpokenPresenter();
    }

    @NonNull
    @Override
    public ValidationErrorView attachView() {
        return this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.partial_reg_language_spoken, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        rlPersonalTitleBar = ButterKnife.findById(view, R.id.rlPersonalTitleBar);
        ivFormBack = ButterKnife.findById(view, R.id.ivFormBack);
        tvFormTitle = ButterKnife.findById(view, R.id.tvFormTitle);
        if (getActivity() instanceof OnNextPressedListener)
            onNextPressedListener = (OnNextPressedListener) getActivity();
        if (getActivity() instanceof OnEditProfileListener)
            onEditProfileListener = (OnEditProfileListener) getActivity();
        initFormTitleBar();
        initForm();
        setDataFromPrefs();
        checkForEdit();
    }

    private void setDataFromPrefs() {
        languageModel = RMPrefs.getInstance(getActivity()).getLanguageModel();
        if (languageModel != null) {
            setData();
        }
    }

    private void checkForEdit() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            if (bundle.getParcelable(AppConstants.SEND_DATA_EDIT_PROFILE) != null) {
                languageModel = bundle.getParcelable(AppConstants.SEND_DATA_EDIT_PROFILE);
                formTitlebar.setVisibility(View.GONE);
                tvNext.setText(R.string.update);
                setData();
            }
        }
    }

    private void setData() {
        String[] languages = languageModel.getLanguageName().split("/");
        String otherLanguages = "";
        for (int langCount = 0; langCount < languageModels.size(); langCount++) {
            for (int selectLangCount = 0; selectLangCount < languages.length; selectLangCount++) {
                if (languages[selectLangCount].equalsIgnoreCase(languageModels.get(langCount).getLanguageName())) {
                    languageModels.get(langCount).setSelected(true);
                }
            }
        }
        checkForOtherLanguage(languages);
        languageAdapter.notifyDataSetChanged();
    }

    private void checkForOtherLanguage(String[] languages) {
        String otherLanguages = "";
        for (int i = 0; i < languages.length; i++) {
            boolean isNotOtherLanguage = false;
            for (LanguageModel languageModel : languageModels) {
                if (languageModel.getLanguageName().equalsIgnoreCase(languages[i])) {
                    isNotOtherLanguage = true;
                    break;
                }
            }
            if (!isNotOtherLanguage) {
                if (otherLanguages.length() > 0) {
                    otherLanguages = otherLanguages + "/" + languages[i];
                } else {
                    otherLanguages = languages[i];
                }
            }
        }
        if (otherLanguages.length() > 0) {
            languageModels.get(languageModels.size() - 1).setSelected(true);
            etOtherLanguage.setVisibility(View.VISIBLE);
            etOtherLanguage.setText(otherLanguages);
        }
    }

    private void initForm() {

        String[] strArrLanguages = getResources().getStringArray(R.array.language_arrays);
        if (languageModels.size() == 0) {
            for (String language : strArrLanguages) {
                LanguageModel languageModel = new LanguageModel();
                languageModel.setLanguageName(language);
                languageModel.setSelected(false);
                languageModels.add(languageModel);
            }
        }
        languageAdapter = new LanguageAdapter(getActivity(), languageModels, this);
        gvLanguages.setAdapter(languageAdapter);
    }

    private void initFormTitleBar() {
        ivFormBack.setVisibility(View.VISIBLE);
        tvFormTitle.setText(R.string.title_language_spoken);
    }

    @OnClick({R.id.tvNext, R.id.ivFormBack})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvNext:
                addPersonalSpokenLanguageDetails();
                break;

            case R.id.ivFormBack:
                if (onNextPressedListener != null) {
                    saveDataInPrefs();
                    onNextPressedListener.onPreviousClicked();
                }
                break;
        }
    }

    public void saveDataInPrefs() {
        LanguageModel model = new LanguageModel();
        String language = getPresenter().getAllSelectedLanguage(languageModels
                , (etOtherLanguage.getVisibility() == View.VISIBLE) ? AppUtils.getText(etOtherLanguage) : "");
        model.setLanguageName(language);

        RMPrefs.getInstance(getActivity()).setLanguageModel(model);
    }

    private void addPersonalSpokenLanguageDetails() {
        HashMap<String, Object> hmPersonalSpokenLanguageDetials = new HashMap<>();
        hmPersonalSpokenLanguageDetials.put(ApiParamEnum.LANGUAGES_SPOKEN.getValue(), languageModels);
        if (languageModel != null) {
            UserDataModel userDataModel = RMPrefs.getInstance(getActivity()).getUserDataModel();
            String accessToken = RMPrefs.getInstance(getActivity()).getAccessToken();
            if (userDataModel != null) {
                hmPersonalSpokenLanguageDetials.put(ApiParamEnum.ACCESS_TOKEN.getValue(), accessToken);
                hmPersonalSpokenLanguageDetials.put(ApiParamEnum.USER_ID.getValue(), userDataModel.getUser_id());
                hmPersonalSpokenLanguageDetials.put(ApiParamEnum.PERSONAL_ID.getValue(), userDataModel.getUser_personal_id());
            }
        }
        getPresenter().isValidate(hmPersonalSpokenLanguageDetials, (etOtherLanguage.getVisibility() == View.VISIBLE) ? AppUtils.getText(etOtherLanguage) : "", onNextPressedListener == null);
    }

    @Override
    public void onLanguageSelect(int pos) {
        languageModels.get(pos).setSelected(languageModels.get(pos).isSelected() ? false : true);
        languageAdapter.notifyDataSetChanged();
    }

    @Override
    public void onOtherLanguageSelected(boolean isSelected) {
        etOtherLanguage.setVisibility(isSelected ? View.VISIBLE : View.INVISIBLE);
    }

    @Override
    public void onSuccess(HashMap<String, Object> savedObject) {
        if (savedObject != null) {
            if (onNextPressedListener != null)
                onNextPressedListener.onNextPressed(RegisterForm.PERSONAL_JOB_CATEGORY, savedObject);
            else if (onEditProfileListener != null) {
                languageModel.setLanguageName(String.valueOf(savedObject.get(ApiParamEnum.LANGUAGES_SPOKEN.getValue())));
                onEditProfileListener.onEditProfileSuccess(languageModel);
            }
        }
    }


    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
    }

    @Override
    public void onValidationError(ValidationErrorModel validationErrorModel) {
        AppUtils.showToast(getActivity(), validationErrorModel.getMsg());
    }
}
