package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Darshna Desai on 11/4/17.
 */

public class JobListResponse extends Response{

    @SerializedName("job_data")
    ArrayList<JobModel> jobData;

    @SerializedName("total_records")
    int totalRecord;

    public ArrayList<JobModel> getJobData() {
        return jobData;
    }

    public void setJobData(ArrayList<JobModel> jobData) {
        this.jobData = jobData;
    }

    public int getTotalRecord() {
        return totalRecord;
    }

    public void setTotalRecord(int totalRecord) {
        this.totalRecord = totalRecord;
    }
}
