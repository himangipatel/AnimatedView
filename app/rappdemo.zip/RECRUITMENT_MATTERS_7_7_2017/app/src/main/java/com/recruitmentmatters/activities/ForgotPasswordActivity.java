package com.recruitmentmatters.activities;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.EditText;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.MVPActivity;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.presenter.ForgotPasswordPresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.views.ValidationErrorView;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Darshna Desai on 24/3/17.
 */

public class ForgotPasswordActivity extends MVPActivity<ForgotPasswordPresenter, ValidationErrorView<Response>> implements ValidationErrorView<Response> {


    @BindView(R.id.etCandidateNo)
    EditText etCandidateNo;
    @BindView(R.id.etEmail)
    EditText etEmail;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        init();
    }

    @NonNull
    @Override
    public ForgotPasswordPresenter createPresenter() {
        return new ForgotPasswordPresenter();
    }

    @NonNull
    @Override
    public ValidationErrorView<Response> attachView() {
        return this;
    }

    private void init() {
        ButterKnife.bind(this);
        initToolbar();
    }

    private void initToolbar() {
        tvToolbarTitle.setText(getResources().getString(R.string.toolbar_forgot_password));
    }

    @OnClick({R.id.ivToolbarLeft, R.id.tvReset})
    public void onClick(View view) {
        AppUtils.hideKeyboard(this);
        switch (view.getId()) {
            case R.id.tvReset:
                callForgotPasswordApi();
                break;
            case R.id.ivToolbarLeft:
                finish();
                break;
        }
    }

    private void callForgotPasswordApi() {

        HashMap<String, String> params = new HashMap<>();
        params.put(ApiParamEnum.CANDIDATE_REF_NO.getValue(), AppUtils.getText(etCandidateNo));
        params.put(ApiParamEnum.EMAIL.getValue(), AppUtils.getText(etEmail));
        getPresenter().isValidData(params);
    }

    @Override
    public void onValidationError(ValidationErrorModel validationErrorModel) {
        AppUtils.showToast(getActivity(), validationErrorModel.getMsg());
        switch (validationErrorModel.getError()) {
            case CANDIDATE_REF_NO:
                AppUtils.requestEdittextFocus(ForgotPasswordActivity.this, etCandidateNo);
                break;
            case EMAIL:
                AppUtils.requestEdittextFocus(ForgotPasswordActivity.this, etEmail);
                break;
        }
    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
    }

    @Override
    public void onSuccess(Response response) {
        AppUtils.showToast(getActivity(), response.getMessage());
        finish();
    }

}
