package com.recruitmentmatters.customview;


import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.utils.AppUtils;


/**
 * Created by Darshna Desai on 23/3/17.
 */

public abstract class CustomDialog extends Dialog implements View.OnClickListener {

    private String strPositive, strNegative, strTitle, strMessage;
    private TextView tvPositive, tvNegative, tvTitle, tvMessage, tvSend;
    private EditText etName, etEmail, etWebsite, etQuery;
    private LinearLayout llBtns, llCustomDialog, llQueryDialog;
    private boolean isQueryDialog = false;

    public CustomDialog(Context context, String strTitle, String strMessage, String strPositive, String strNegative) {
        super(context);
        this.strPositive = strPositive;
        this.strNegative = strNegative;
        this.strTitle = strTitle;
        this.strMessage = strMessage;
    }

    public CustomDialog(Context context, String strPositive) {
        super(context);
        this.strPositive = strPositive;
        isQueryDialog = true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (!isQueryDialog) {
            setCancelable(false);
            setContentView(R.layout.app_dialog_custom);
            tvPositive = (TextView) findViewById(R.id.tvPositive);
            tvNegative = (TextView) findViewById(R.id.tvNegative);
            tvTitle = (TextView) findViewById(R.id.tvTitle);
            tvMessage = (TextView) findViewById(R.id.tvMessage);
            llBtns = (LinearLayout) findViewById(R.id.llBtns);
            setText();
            tvNegative.setOnClickListener(this);
            tvPositive.setOnClickListener(this);
        } else {
            setCancelable(true);
            setContentView(R.layout.dialog_view_send_message);
            getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            etName = (EditText) findViewById(R.id.etName);
            etEmail = (EditText) findViewById(R.id.etEmail);
            etWebsite = (EditText) findViewById(R.id.etWebsite);
            etQuery = (EditText) findViewById(R.id.etQuery);
            tvSend = (TextView) findViewById(R.id.tvSend);
            tvSend.setOnClickListener(this);
        }
    }

    public String getName() {
        return AppUtils.getText(etName);
    }

    public String getEmail() {
        return AppUtils.getText(etEmail);
    }

    public String getWebsite() {
        return AppUtils.getText(etWebsite);
    }

    public String getQuery() {
        return AppUtils.getText(etQuery);
    }

    private void setText() {
        if (strPositive != null) {
            tvPositive.setText(strPositive);
        }
        if (strNegative != null && !strNegative.equalsIgnoreCase("")) {
            tvNegative.setText(strNegative);
        }else{
            tvNegative.setVisibility(View.GONE);
            llBtns.setWeightSum(1);
        }
        if (strTitle != null) {
            tvTitle.setText(strTitle);
        }
        if (strMessage != null){
            tvMessage.setText(strMessage);
        }
    }

}
