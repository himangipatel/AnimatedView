package com.recruitmentmatters.tagview;

/**
 * listener for tag delete
 */
public interface OnTagClickListener {
    void onTagClick(int position, Tag tag);
}