package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Sameer Jani on 13/4/17.
 */

public class JobRequiredSkills {

    @SerializedName("exp")
    String exp = "";
    @SerializedName("qualifications")
    String qualifications;

    public String getExp() {
        return exp;
    }

    public void setExp(String exp) {
        this.exp = exp;
    }

    public String getQualifications() {
        return qualifications;
    }

    public void setQualifications(String qualifications) {
        this.qualifications = qualifications;
    }
}
