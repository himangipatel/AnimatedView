package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Sameer Jani on 13/4/17.
 */

public class JobDescriptionModel {
    @SerializedName("dec")
    String dec = "";
    @SerializedName("key_skills")
    String key_skills = "";
    @SerializedName("add_require")
    String add_require = "";
    @SerializedName("req_skills")
    JobRequiredSkills jobRequiredSkills;

    public String getDec() {
        return dec;
    }

    public void setDec(String dec) {
        this.dec = dec;
    }

    public String getKey_skills() {
        return key_skills;
    }

    public void setKey_skills(String key_skills) {
        this.key_skills = key_skills;
    }

    public String getAdd_require() {
        return add_require;
    }

    public void setAdd_require(String add_require) {
        this.add_require = add_require;
    }

    public JobRequiredSkills getJobRequiredSkills() {
        return jobRequiredSkills;
    }

    public void setJobRequiredSkills(JobRequiredSkills jobRequiredSkills) {
        this.jobRequiredSkills = jobRequiredSkills;
    }


}
