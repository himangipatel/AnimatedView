package com.recruitmentmatters.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;
import com.recruitmentmatters.model.ProfileReferenceModel;

import java.util.ArrayList;

import butterknife.BindView;

/**
 * Created by Darshna Desai on 5/4/17.
 */

public class ProfileReferenceAdapter extends BaseRecyclerAdapter<ProfileReferenceAdapter.DataObjectHolder, ProfileReferenceModel> {
    private ArrayList<ProfileReferenceModel> referenceModels = null;
    private Context context;

    public ProfileReferenceAdapter(Context context, ArrayList<ProfileReferenceModel> referenceModels) {
        super(referenceModels);
        this.context = context;
        this.referenceModels = referenceModels;
    }

    @Override
    public ProfileReferenceAdapter.DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_profile_reference, parent, false);
        return new ProfileReferenceAdapter.DataObjectHolder(view);
    }

    @Override
    public void onBindViewHolder(ProfileReferenceAdapter.DataObjectHolder holder, int position) {
        ProfileReferenceModel model = referenceModels.get(position);
        holder.tvContactName.setText(model.getRefName());
        holder.tvCompanyName.setText(model.getRefCompanyName());
        holder.tvPosition.setText(model.getRefPosition());
        if(model.getRefEmail() != null && !model.getRefEmail().equalsIgnoreCase("")) {
            holder.tvEmail.setVisibility(View.VISIBLE);
            holder.tvEmail.setText(model.getRefEmail());
        }else{
            holder.tvEmail.setVisibility(View.GONE);
        }
        if(model.getRefPhone() != null && !model.getRefPhone().equalsIgnoreCase("")) {
            holder.tvTelephone.setVisibility(View.VISIBLE);
            holder.tvTelephone.setText(model.getRefPhone());
        }else{
            holder.tvTelephone.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return referenceModels.size();
    }

    class DataObjectHolder extends BaseRecyclerAdapter.ViewHolder {
        @BindView(R.id.tvContactName)
        TextView tvContactName;
        @BindView(R.id.tvCompanyName)
        TextView tvCompanyName;
        @BindView(R.id.tvPosition)
        TextView tvPosition;
        @BindView(R.id.tvEmail)
        TextView tvEmail;
        @BindView(R.id.tvTelephone)
        TextView tvTelephone;

        DataObjectHolder(View itemView) {
            super(itemView);
        }
    }
}

