package com.recruitmentmatters.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.activities.CategoryLocationActivity;
import com.recruitmentmatters.activities.JobsActivity;
import com.recruitmentmatters.baseclasses.BaseView;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.model.CategoryModel;
import com.recruitmentmatters.presenter.CategoryPresenter;
import com.recruitmentmatters.utils.AppUtils;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Darshna Desai on 12/4/17.
 */

public class AdvanceSearchFragment extends MVPFragment<CategoryPresenter, BaseView> implements BaseView {

    @BindView(R.id.tvCategory)
    TextView tvCategory;

    @BindView(R.id.tvLocation)
    TextView tvLocation;

    @BindView(R.id.etSearch)
    EditText etSearch;

    @BindView(R.id.tvSearch)
    TextView tvSearch;

    @BindView(R.id.tvReset)
    TextView tvReset;

    private String categoryId = "";
    private String locationName = "";

    @NonNull
    @Override
    public CategoryPresenter createPresenter() {
        return new CategoryPresenter();
    }

    @NonNull
    @Override
    public BaseView attachView() {
        return this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_advance_search, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        init(view, savedInstanceState);
    }

    private void init(View v, Bundle savedInstanceState) {
    }

    @OnClick({R.id.tvSearch, R.id.tvCategory, R.id.tvLocation, R.id.tvReset})
    public void onClick(View view) {
        Intent intent = null;
        switch (view.getId()) {
            case R.id.tvSearch:
                intent = new Intent(getContext(), JobsActivity.class);
                intent.putExtra(ApiParamEnum.SEARCH_WORD.getValue(), AppUtils.getText(etSearch));
                intent.putExtra(ApiParamEnum.CAT_ID.getValue(), categoryId);
                intent.putExtra(ApiParamEnum.LOCATION_NAME.getValue(), locationName);
                intent.putExtra(AppConstants.IS_ADVANCE_SEARCH, true);
                startActivity(intent);
                break;
            case R.id.tvCategory:
                intent = new Intent(getContext(), CategoryLocationActivity.class);
                intent.putExtra(ApiParamEnum.CATEGORY_NAME.getValue(), ApiParamEnum.CATEGORY_NAME.getValue());
                startActivityForResult(intent, AppConstants.CATEGORY_LIST);
                break;
            case R.id.tvLocation:
                intent = new Intent(getContext(), CategoryLocationActivity.class);
                intent.putExtra(ApiParamEnum.LOCATION_NAME.getValue(), ApiParamEnum.LOCATION_NAME.getValue());
                startActivityForResult(intent, AppConstants.LOCATION_LIST);
                break;
            case R.id.tvReset:
                tvCategory.setText("");
                tvCategory.setHint(getResources().getString(R.string.toolbar_categories));
                categoryId = "";
                locationName = "";
                tvLocation.setText("");
                tvLocation.setHint(getResources().getString(R.string.toolbar_location));
                etSearch.setText("");
                break;
        }
    }

    @Override
    public void onSuccess(Object response) {

    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AppConstants.CATEGORY_LIST && resultCode == Activity.RESULT_OK && data != null) {
            CategoryModel categoryModel = data.getParcelableExtra(ApiParamEnum.CATEGORY_NAME.getValue());
            if (categoryModel != null) {
                tvCategory.setText(categoryModel.getCat_name());
                categoryId = categoryModel.getCat_id();
            }
        } else if (requestCode == AppConstants.LOCATION_LIST && resultCode == Activity.RESULT_OK && data != null) {
            locationName = data.getStringExtra(ApiParamEnum.LOCATION_NAME.getValue());
            tvLocation.setText(locationName);
        }
    }
}
