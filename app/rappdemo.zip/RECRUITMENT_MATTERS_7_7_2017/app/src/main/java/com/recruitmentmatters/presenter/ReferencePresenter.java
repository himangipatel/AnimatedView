package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.validator.Validator;
import com.recruitmentmatters.views.ReferenceView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Sameer Jani on 01/04/17.
 */

public class ReferencePresenter extends BasePresenter<ReferenceView<HashMap<String, Object>>> {

    public void isValidate(HashMap<String, Object> hashMap) {
        ValidationErrorModel validationErrorModel = null;
        if ((validationErrorModel = Validator.validateContactName(String.valueOf(hashMap.get(ApiParamEnum.CONTACT_NAME.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validateCompanyName(String.valueOf(hashMap.get(ApiParamEnum.COMPANY_NAME.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validatePosition(String.valueOf(hashMap.get(ApiParamEnum.POSITION.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validateEmailPattern(String.valueOf(hashMap.get(ApiParamEnum.EMAIL.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validateTelephonePattern(String.valueOf(hashMap.get(ApiParamEnum.TELEPHONE.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else {
            addReference(hashMap);
        }
    }

    private void addReference(HashMap<String, Object> hashMap) {
        JSONObject jsonReference = new JSONObject();
        try {
            jsonReference.putOpt(ApiParamEnum.CONTACT_NAME.getValue(), String.valueOf(hashMap.get(ApiParamEnum.CONTACT_NAME.getValue())));
            jsonReference.putOpt(ApiParamEnum.COMPANY_NAME.getValue(), String.valueOf(hashMap.get(ApiParamEnum.COMPANY_NAME.getValue())));
            jsonReference.putOpt(ApiParamEnum.POSITION.getValue(), String.valueOf(hashMap.get(ApiParamEnum.POSITION.getValue())));
            jsonReference.putOpt(ApiParamEnum.EMAIL.getValue(), String.valueOf(hashMap.get(ApiParamEnum.EMAIL.getValue())));
            jsonReference.putOpt(ApiParamEnum.TELEPHONE.getValue(), String.valueOf(hashMap.get(ApiParamEnum.TELEPHONE.getValue())));
            getView().onReferenceAdded(jsonReference);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void addReferenceDetails(ArrayList<JSONObject> listReference, HashMap<String, Object> commonParams) {
        ValidationErrorModel validationErrorModel = null;
        if ((validationErrorModel = Validator.validateReferences(listReference)) != null) {
            getView().onValidationError(validationErrorModel);
        } else {
            JSONArray jsonArray = new JSONArray();
            for (JSONObject jsonObject : listReference) {
                jsonArray.put(jsonObject);
            }
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put(ApiParamEnum.REFERENCES.getValue(), jsonArray.toString());

            if(commonParams != null && commonParams.size()>0){
                hashMap.putAll(commonParams);
                callEditReferenceApi(hashMap);
            }else{
                getView().onSuccess(hashMap);
            }
        }
    }

    private void callEditReferenceApi(final HashMap<String, Object> hashMap) {
            if (hasInternet()) {
                addSubscription(getAppInteractor().callEditReferenceApi(hashMap, new InterActorCallback<Response>() {
                    @Override
                    public void onStart() {
                        getView().showProgressDialog(true);
                    }

                    @Override
                    public void onResponse(Response response) {
                        if (response.isStatus()) {
                            getView().onSuccess(hashMap);
                        } else {
                            getView().onFailure(response.getMessage());
                        }
                    }

                    @Override
                    public void onFinish() {
                        getView().showProgressDialog(false);
                    }

                    @Override
                    public void onError(String message) {
                        getView().onFailure(message);
                    }
                }));
            }
    }
}
