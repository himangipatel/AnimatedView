package com.recruitmentmatters.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.constants.SpinnerType;

/**
 * Created by Sameer Jani on 29/3/17.
 */

public class SpinnerAdapter extends BaseAdapter {

    private Context context;
    private String[] arrData;
    private SpinnerType spinnerType;

    public SpinnerAdapter(Context mContext, String[] arrData, SpinnerType spinnerType) {
        this.context = mContext;
        this.arrData = arrData;
        this.spinnerType = spinnerType;
    }

    @Override
    public int getCount() {
        return arrData.length;
    }

    @Override
    public Object getItem(int i) {
        return arrData[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        TextView tvSpinnerView = (TextView) LayoutInflater.from(context).inflate(R.layout.item_spinner_view, viewGroup, false);
        if (spinnerType == SpinnerType.GENDER) {
            tvSpinnerView.setHint(R.string.hint_sp_gender);
        } else if (spinnerType == SpinnerType.COUNTRY) {
            tvSpinnerView.setHint(R.string.hint_sp_country);
        } else if (spinnerType == SpinnerType.DRIVING_LICENCE) {
            tvSpinnerView.setHint(R.string.hint_sp_driving_licence);
        } else if (spinnerType == SpinnerType.CATEGORY) {
            tvSpinnerView.setHint(R.string.hint_select_category);
        } else if (spinnerType == SpinnerType.AVAILABLE) {
            tvSpinnerView.setHint(R.string.hint_sp_available);
        } else if(spinnerType == SpinnerType.UNIVERSITY_LOCATION) {
            tvSpinnerView.setHint(R.string.hint_sp_uni_location);
        }
        if (i == 0) {
            tvSpinnerView.setText("");
        } else {
            tvSpinnerView.setText(arrData[i]);
        }
        return tvSpinnerView;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        TextView tvSpinnerDropDown = (TextView) LayoutInflater.from(context).inflate(R.layout.item_spinner_dropdown_view, parent, false);
        tvSpinnerDropDown.setText(arrData[position]);
        return tvSpinnerDropDown;
    }
}
