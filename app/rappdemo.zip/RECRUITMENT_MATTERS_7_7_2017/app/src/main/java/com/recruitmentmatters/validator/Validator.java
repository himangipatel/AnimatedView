package com.recruitmentmatters.validator;

import android.content.Context;
import android.util.Patterns;
import android.widget.EditText;
import android.widget.Toast;

import com.recruitmentmatters.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * Created by Darshna Desai on 6/3/17.
 */

public class Validator {

    public static final String EMAIL_PATTERN = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
            "\\@" +
            "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
            "(" +
            "\\." +
            "[a-zA-Z]{2,8}" +
            ")+";

    public static final String WEBSITE_PATTERN = "^(http:\\/\\/|https:\\/\\/)?(www.)?([a-zA-Z0-9]+).[a-zA-Z0-9]*.[a-z]{3}.?([a-z]+)?$";
    public static final String PHONE_PATTERN = "^[+0-9][0-9]*$";
    //6-len alpha-numeric pattern with optional special characters
    public static final String PASSWORD_PATTERN = "^.*(?=.{6,20})(?=.*\\d)(?=.*[a-zA-Z])(^[a-zA-Z0-9._@!&$*%+-:/><#]+$)";
    public static Toast toast = null;

    /* User Validation */
    public static ValidationErrorModel generateError(int msg, ValidationError error) {
        return new ValidationErrorModel(msg, error);
    }

    public static ValidationErrorModel validateCandidateRefNo(String number) {
        return isBlank(number) ? new ValidationErrorModel(R.string.blank_candidate_ref_no, ValidationError.CANDIDATE_REF_NO) : null;
    }

    public static ValidationErrorModel validateFirstName(String firstName) {
        return isBlank(firstName) ? new ValidationErrorModel(R.string.blank_fname, ValidationError.FIRST_NAME) : null;
    }

    public static ValidationErrorModel validateName(String name) {
        return isBlank(name) ? new ValidationErrorModel(R.string.blank_name, ValidationError.NAME) : null;
    }

    public static ValidationErrorModel validateHelpText(String helpText) {
        return isBlank(helpText) ? new ValidationErrorModel(R.string.blank_helptext, ValidationError.HELP_TEXT) : null;
    }

    /*public static ValidationErrorModel validateWebsite(String website) {
        return isBlank(website) ?
                new ValidationErrorModel(R.string.blank_website, ValidationError.WEBSITE)
                : !Pattern.compile(WEBSITE_PATTERN).matcher(website).matches()
                ? new ValidationErrorModel(R.string.invalid_website, ValidationError.WEBSITE)
                : null;
    }*/

    public static ValidationErrorModel validateWebsite(String website) {
        return isBlank(website) ?
                new ValidationErrorModel(R.string.blank_website, ValidationError.WEBSITE)
                : !Patterns.WEB_URL.matcher(website).matches()
                ? new ValidationErrorModel(R.string.invalid_website, ValidationError.WEBSITE)
                : null;
    }

    public static ValidationErrorModel validateLastName(String firstName) {
        return isBlank(firstName) ? new ValidationErrorModel(R.string.blank_lname, ValidationError.LAST_NAME) : null;
    }

    public static ValidationErrorModel validateCityName(String cityName) {
        return isBlank(cityName) ? new ValidationErrorModel(R.string.blank_city, ValidationError.CITY_NAME) : null;
    }

    public static ValidationErrorModel validateCountryName(String countryName, String countryHint) {
        return isBlank(countryName) ? new ValidationErrorModel(R.string.blank_country, ValidationError.COUNTRY_NAME)
                : ((countryName.equalsIgnoreCase(countryHint))
                ? new ValidationErrorModel(R.string.blank_country, ValidationError.COUNTRY_NAME) : null);
    }

    public static ValidationErrorModel validatePassword(String password) {
        return isBlank(password) ?
                new ValidationErrorModel(R.string.blank_password, ValidationError.PASSWORD)
               /* : !Pattern.compile(PASSWORD_PATTERN).matcher(password).matches()
                ? new ValidationErrorModel(R.string.invalid_password, ValidationError.PASSWORD)
               */ : null;
    }

    public static ValidationErrorModel validateCurrentPassword(String current_password) {
        return isBlank(current_password) ?
                new ValidationErrorModel(R.string.blank_current_password, ValidationError.CURRENT_PASSWORD)
               : null;
    }

    public static ValidationErrorModel validateNewPassword(String new_password) {
        return isBlank(new_password) ?
                new ValidationErrorModel(R.string.blank_new_password, ValidationError.PASSWORD)
                : null;
    }

    public static ValidationErrorModel validateConfirmPassword(String password) {
        return isBlank(password) ?
                new ValidationErrorModel(R.string.blank_confirm_password, ValidationError.CONFIRM_PASSWORD)
               : null;
    }

    public static ValidationErrorModel validatePasswordConfirmPassword(String password, String confirm_password) {
        return !(password.equalsIgnoreCase(confirm_password)) ?
                new ValidationErrorModel(R.string.invalid_confirm_password, ValidationError.CONFIRM_PASSWORD)
                : null;
    }

    public static ValidationErrorModel validateGender(int gender) {
        return gender == 0 ? new ValidationErrorModel(R.string.blank_gender, ValidationError.GENDER) : null;
    }

    public static ValidationErrorModel validateDrivingLicence(String drivingLicence) {
        return isBlank(drivingLicence) ? new ValidationErrorModel(R.string.blank_driver_license, ValidationError.DRIVING_LICENCE) : null;
    }

    public static ValidationErrorModel validateDateOfBirth(String dob) {
        return isBlank(dob) ? new ValidationErrorModel(R.string.blank_dob, ValidationError.DOB) : null;
    }

    public static ValidationErrorModel validateEmail(String email) {
        return isBlank(email) ?
                new ValidationErrorModel(R.string.blank_email, ValidationError.EMAIL)
                : !Pattern.compile(EMAIL_PATTERN).matcher(email).matches()
                ? new ValidationErrorModel(R.string.invalid_email, ValidationError.EMAIL)
                : null;
    }

    public static ValidationErrorModel validateEmailPattern(String email) {
        if(isBlank(email)){
            return null;
        }
        return !Pattern.compile(EMAIL_PATTERN).matcher(email).matches()
                ? new ValidationErrorModel(R.string.invalid_email, ValidationError.EMAIL)
                : null;
    }

    public static ValidationErrorModel validateCellphone(String phone) {
        return isBlank(phone) ?
                new ValidationErrorModel(R.string.blank_cellphone, ValidationError.CELLPHONE)
                : ((!(phone.length() >= 10 && phone.length() <= 15))
                ? new ValidationErrorModel(R.string.invalid_cellphone, ValidationError.CELLPHONE) : null);
    }

    public static ValidationErrorModel validateSpokenLanguage(String spokenLanguages) {
        return isBlank(spokenLanguages)
                ? new ValidationErrorModel(R.string.blank_language, ValidationError.SPOKEN_LANGUAGE)
                : ((spokenLanguages.equalsIgnoreCase(" "))
                ? new ValidationErrorModel(R.string.invalid_language, ValidationError.SPOKEN_LANGUAGE)
                : null);
    }

    public static ValidationErrorModel validateJobType(String jobTypes) {
        return isBlank(jobTypes)
                ? new ValidationErrorModel(R.string.blank_job_type, ValidationError.JOB_TYPE)
                : ((jobTypes.equalsIgnoreCase(" "))
                ? new ValidationErrorModel(R.string.invalid_job_type, ValidationError.JOB_TYPE)
                : null);
    }

    public static ValidationErrorModel validateCurrentSalary(String currentSalary) {
        return isBlank(currentSalary) ? new ValidationErrorModel(R.string.blank_current_salary, ValidationError.CURRRENT_SALARY) : null;
    }

    public static ValidationErrorModel validateExpectedSalary(String expectedSalary) {
        return isBlank(expectedSalary) ? new ValidationErrorModel(R.string.blank_expected_salary, ValidationError.EXPECTED_SALARY) : null;
    }

    public static ValidationErrorModel validateTelephone(String phone) {
        return isBlank(phone) ?
                new ValidationErrorModel(R.string.blank_telephone, ValidationError.TELEPHONE)
                : ((!(phone.length() >= 6 && phone.length() <= 15))
                ? new ValidationErrorModel(R.string.invalid_telephone, ValidationError.TELEPHONE) : null);
    }

    public static ValidationErrorModel validateTelephonePattern(String phone) {
        if(isBlank(phone)){
            return null;
        }
        return ((!(phone.length() >= 6 && phone.length() <= 15))
                ? new ValidationErrorModel(R.string.invalid_telephone, ValidationError.TELEPHONE) : null);
    }

    public static ValidationErrorModel validateQualification(String qualification) {
        return isBlank(qualification) ? new ValidationErrorModel(R.string.blank_qualification, ValidationError.QUALIFICATION) : null;
    }

    public static ValidationErrorModel validateCategoryName(String categoryName, String categoryHint) {
        return isBlank(categoryName) ? new ValidationErrorModel(R.string.blank_category_name, ValidationError.CATEGORY_NAME)
                : ((categoryName.equalsIgnoreCase(categoryHint))
                ? new ValidationErrorModel(R.string.blank_category_name, ValidationError.CATEGORY_NAME) : null);
    }

    public static ValidationErrorModel validateIndustriesWorked(String industriedWorked) {
        return isBlank(industriedWorked) ? new ValidationErrorModel(R.string.blank_industries_worked, ValidationError.INDUSTRIES_WORKED) : null;
    }

    public static ValidationErrorModel validateSkills(String skills) {
        return isBlank(skills) ? new ValidationErrorModel(R.string.blank_skill, ValidationError.SKILLS) : null;
    }

    public static ValidationErrorModel validateAvailability(String availability, String availabilityHint) {
        return isBlank(availability) ? new ValidationErrorModel(R.string.blank_availability, ValidationError.AVAILABILITY)
                : ((availability.equalsIgnoreCase(availabilityHint))
                ? new ValidationErrorModel(R.string.blank_availability, ValidationError.AVAILABILITY) : null);
    }

    public static ValidationErrorModel validateEmployer(String employer) {
        return isBlank(employer) ? new ValidationErrorModel(R.string.blank_employer, ValidationError.EMPLOYER) : null;
    }

    public static ValidationErrorModel validatePosition(String position) {
        return isBlank(position) ? new ValidationErrorModel(R.string.blank_position, ValidationError.POSITION) : null;
    }

    public static ValidationErrorModel validateStartDate(String startDate) {
        return isBlank(startDate) ? new ValidationErrorModel(R.string.blank_start_date, ValidationError.START_DATE) : null;
    }

    public static ValidationErrorModel validateEndDate(String endDate) {
        return isBlank(endDate) ? new ValidationErrorModel(R.string.blank_end_date, ValidationError.END_DATE) : null;
    }

    public static ValidationErrorModel validateDuration(long startDate, long endDate) {
        return startDate > endDate ? new ValidationErrorModel(R.string.invalid_duration, ValidationError.DURATION) : null;
    }

    public static ValidationErrorModel validateEmployers(ArrayList<JSONObject> jsonEmployers) {
        return (jsonEmployers == null || jsonEmployers.isEmpty()) ? new ValidationErrorModel(R.string.blank_employments, ValidationError.EMPLOYMENTS) : null;
    }

    public static ValidationErrorModel validateContactName(String contactName) {
        return isBlank(contactName) ? new ValidationErrorModel(R.string.blank_contact_name, ValidationError.CONTACT_NAME) : null;
    }

    public static ValidationErrorModel validateCompanyName(String companyName) {
        return isBlank(companyName) ? new ValidationErrorModel(R.string.blank_company_name, ValidationError.COMPANY_NAME) : null;
    }

    public static ValidationErrorModel validateReferences(ArrayList<JSONObject> jsonReferences) {
        return (jsonReferences == null || jsonReferences.isEmpty()) ? new ValidationErrorModel(R.string.blank_reference, ValidationError.EMPLOYMENTS) : null;
    }

    public static boolean isBlank(String text) {
        if (text == null || text.trim().length() == 0)
            return true;

        return false;
    }

    public static boolean isBlank(EditText editText) {
        if (editText.getText() == null || editText.getText().toString().trim().length() == 0)
            return true;

        return false;
    }

    public static String validateData(Context context, String str, String strKey) {
        if (isBlank(str)) {
            return context.getResources().getString(R.string.invalid) + strKey;
        }
        return "";
    }

    public static boolean validateNumber(String strNumber, int min, int max) {
        if (strNumber.length() >= min && strNumber.length() <= max) {
            return true;
        }
        return false;
    }
}
