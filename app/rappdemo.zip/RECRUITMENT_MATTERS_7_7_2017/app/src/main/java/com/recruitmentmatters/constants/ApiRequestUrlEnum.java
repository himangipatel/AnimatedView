package com.recruitmentmatters.constants;

/**
 * Created by Darshna Desai on 31/3/17.
 */

public enum ApiRequestUrlEnum {

    USER_LOGIN("login"),
    USER_FORGOT_PASSWORD("forgot_password"),
    USER_LOGOUT("logout"),
    GET_ALL_COUNTRIES("get_all_countries"),
    GET_ALL_CATEGORIES("get_all_categories"),
    REGISTER("register"),
    VIEW_PROFILE("get_user_profile"),
    EDIT_GENERAL_PROFILE("edit_user_profile_general"),
    EDIT_EDUCATION_PROFILE("edit_user_profile_edu"),
    EDIT_EMPLOYMENT_PROFILE("edit_user_profile_employment"),
    EDIT_LANGUAGE_PROFILE("edit_user_profile_language"),
    EDIT_JOB_CATEGORY("edit_user_profile_jobcategory"),
    EDIT_JOB_TYPE("edit_user_profile_jobtype"),
    EDIT_REFERENCE("edit_user_profile_ref"),
    USER_CHANGE_PASSWORD("change_password"),
    USER_UPLOAD_PROFILE("upload_image"),
    GET_ALL_JOBS("get_jobs"),
    GET_JOB_DETAILS("get_job_detail"),
    APPLY_JOB("apply_job"),
    FAVOURITE_JOB("favourite_job"),
    GET_FAVOURITE_JOB("get_favourite_job"),
    GET_MY_APPLICATIONS("get_my_applications"),
    CONTACT_US_VIEW("contact_us_view"),
    SEND_MESSAGE("send_msg"),
    GET_ALL_LOCATIONS("get_all_locations"),
    GET_ALL_FILER_LOCATIONS("get_all_filter_location"),
    USER_UPLOAD_CV("upload_cv"),
    GET_ALL_UNI_LOCATION("get_all_uni_location");


    private String value;

    ApiRequestUrlEnum(String value) {
        this.value = AppConstants.API_BASE_URL + value;
    }

    public String getValue() {
        return value;
    }
}