package com.recruitmentmatters.views;

/**
 * Created by Sameer Jani on 29/3/17.
 */

public interface PersonalJobCategoryView<T> extends ValidationErrorView<T> {
    public void onCategoryList(String[] categoryList);
}
