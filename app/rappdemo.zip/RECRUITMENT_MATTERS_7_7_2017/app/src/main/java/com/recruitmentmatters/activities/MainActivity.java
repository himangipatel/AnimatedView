package com.recruitmentmatters.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.text.Layout;
import android.text.SpannableString;
import android.text.style.AlignmentSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.baseclasses.BaseView;
import com.recruitmentmatters.baseclasses.MVPActivity;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.customview.CircleImageView;
import com.recruitmentmatters.customview.CustomDialog;
import com.recruitmentmatters.fragment.AdvanceSearchFragment;
import com.recruitmentmatters.fragment.CategoryFragment;
import com.recruitmentmatters.fragment.ContactUsFragment;
import com.recruitmentmatters.fragment.FavouriteJobsFragment;
import com.recruitmentmatters.fragment.HomeFragment;
import com.recruitmentmatters.fragment.LocationFragment;
import com.recruitmentmatters.fragment.MyProfileFragment;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.model.UserDataModel;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends MVPActivity<BasePresenter<BaseView<Response>>, BaseView<Response>>
        implements BaseView<Response>, NavigationView.OnNavigationItemSelectedListener {

    @BindView(R.id.drawer_layout)
    DrawerLayout drawerLayout;
    @BindView(R.id.navView)
    NavigationView navigationView;
    TextView tvUserName, tvCandidateNo;
    CircleImageView ivUserProfile;
    @BindView(R.id.container)
    FrameLayout container;

    private boolean doubleBackToExitPressedOnce;
    private boolean isMyApplicationFragment = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }

    @NonNull
    @Override
    public BasePresenter createPresenter() {
        return new BasePresenter() {
        };
    }

    @NonNull
    @Override
    public BaseView<Response> attachView() {
        return this;
    }

    private void init() {
        ButterKnife.bind(this);
        initHeaderLayout();
        setupMenu();
    }

    private void initHeaderLayout() {
        View headerLayout = navigationView.inflateHeaderView(R.layout.partial_navigation_header);
        ivUserProfile = ButterKnife.findById(headerLayout, R.id.ivUserProfile);
        tvUserName = ButterKnife.findById(headerLayout, R.id.tvUserName);
        tvCandidateNo = ButterKnife.findById(headerLayout, R.id.tvCandidateNo);

        headerLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (RMPrefs.getInstance(MainActivity.this).isUserLogin()) {
                    tvToolbarTitle.setVisibility(View.GONE);
                    setHeaderTextColor(R.color.themeRed);
                    setFragment(new MyProfileFragment());
                } else {
                    Intent redirectIntent = new Intent(MainActivity.this, LoginActivity.class);
                    redirectIntent.putExtra(AppConstants.EXTRA_FROM_MENU, true);
                    startActivity(redirectIntent);
                }
                drawerLayout.closeDrawer(GravityCompat.START);

                navigationView.post(new Runnable() {
                    @Override
                    public void run() {
                        navigationView.setCheckedItem(R.id.navDummy);
                    }
                });
            }
        });
    }

    private void setHeaderTextColor(int color) {
        tvUserName.setTextColor(ContextCompat.getColor(MainActivity.this, color));
        tvCandidateNo.setTextColor(ContextCompat.getColor(MainActivity.this, color));
    }


    private void setupMenu() {
        tvToolbarTitle.setText(getResources().getString(R.string.toolbar_home));
        ivToolbarLeft.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.menu));
        navigationView.setNavigationItemSelectedListener(this);

        // Get menu from navigationView
        Menu menu = navigationView.getMenu();
        String[] menu_items = getResources().getStringArray(R.array.menu_item_with_login);
        /*Set all the elements of the menu with center alignment*/
        for (int i = 0; i < menu_items.length; i++) {
            MenuItem item = menu.getItem(i);
            SpannableString s = new SpannableString(menu_items[i]);
            s.setSpan(new AlignmentSpan.Standard(Layout.Alignment.ALIGN_CENTER), 0, s.length(), 0);
            item.setTitle(s);
        }
        setupMenuOptions(menu);

        setHeaderData();
        replaceFragment(new HomeFragment(), false, null);
    }

    private void setupMenuOptions(Menu menu) {
        if (!RMPrefs.getInstance(MainActivity.this).isUserLogin()) {
            menu.findItem(R.id.navFavorites).setVisible(false);
            menu.findItem(R.id.navMyApplication).setVisible(false);
            menu.findItem(R.id.navLogout).setVisible(false);
        } else {
            menu.findItem(R.id.navFavorites).setVisible(true);
            menu.findItem(R.id.navMyApplication).setVisible(true);
            menu.findItem(R.id.navLogout).setVisible(true);
        }
    }

    private void setHeaderData() {
        UserDataModel user = RMPrefs.getInstance(this).getUserDataModel();
        if (user != null) {
            tvUserName.setText(user.getUser_first_name().concat(" ").concat(user.getUser_last_name()));
            tvCandidateNo.setText("#".concat(user.getUser_candidate_ref_number()));
            Glide.with(getActivity()).load(AppConstants.IMAGE_BASE_URL + user.getUser_id() + "/" + user.getImage_url())
                    .asBitmap().centerCrop().placeholder(R.drawable.profile_icon).into(ivUserProfile);
        }
    }

    private void replaceFragment(Fragment fragment, boolean addToBackStack, Bundle bundle) {

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, fragment, fragment.getClass().getSimpleName());
        if (addToBackStack) {
            fragmentTransaction.addToBackStack(fragment.getClass().getSimpleName());
        }
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        fragmentTransaction.commit();
    }

    @OnClick({R.id.ivToolbarLeft, R.id.ivToolbarRight, R.id.tvToolbarRight})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivToolbarLeft:
                AppUtils.hideKeyboard(this);
                drawerLayout.openDrawer(GravityCompat.START);
                setHeaderData();
                break;
            default:
                break;
        }
    }

    private Fragment getCurrentFragment() {
        return getSupportFragmentManager().findFragmentById(R.id.container);
    }

    public void popFragment() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.popBackStackImmediate();
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        Fragment fragment = null;
        setHeaderTextColor(android.R.color.white);
        switch (item.getItemId()) {
            case R.id.navHome:
                tvToolbarTitle.setVisibility(View.VISIBLE);
                tvToolbarTitle.setText(getResources().getString(R.string.toolbar_home));
                isMyApplicationFragment = false;
                fragment = new HomeFragment();
                break;
            case R.id.navAdvanceSearch:
                tvToolbarTitle.setVisibility(View.VISIBLE);
                tvToolbarTitle.setText(getResources().getString(R.string.toolbar_advance_search));
                isMyApplicationFragment = false;
                fragment = new AdvanceSearchFragment();
                break;
            case R.id.navCategories:
                tvToolbarTitle.setVisibility(View.VISIBLE);
                tvToolbarTitle.setText(getResources().getString(R.string.toolbar_categories));
                isMyApplicationFragment = false;
                fragment = new CategoryFragment();
                break;
            case R.id.navLocation:
                tvToolbarTitle.setVisibility(View.VISIBLE);
                tvToolbarTitle.setText(getResources().getString(R.string.toolbar_location));
                isMyApplicationFragment = false;
                fragment = new LocationFragment();
                break;

            case R.id.navFavorites:
                tvToolbarTitle.setVisibility(View.VISIBLE);
                tvToolbarTitle.setText(getResources().getString(R.string.toolbar_favourite));
                isMyApplicationFragment = false;
                fragment = new FavouriteJobsFragment();
                break;

            case R.id.navMyApplication:
                tvToolbarTitle.setVisibility(View.VISIBLE);
                tvToolbarTitle.setText(getResources().getString(R.string.toolbar_applications));
                isMyApplicationFragment = true;
                fragment = new HomeFragment();
                Bundle bundle = new Bundle();
                bundle.putString(AppConstants.SEND_FOR_MY_APPLICATION_SCREEN, AppConstants.SEND_FOR_MY_APPLICATION_SCREEN);
                fragment.setArguments(bundle);
                break;

            case R.id.navContactUs:
                tvToolbarTitle.setVisibility(View.VISIBLE);
                tvToolbarTitle.setText(getResources().getString(R.string.toolbar_contact_us));
                isMyApplicationFragment = false;
                fragment = new ContactUsFragment();
                break;

            case R.id.navLogout:
                showLogoutDialog();
                navigationView.post(new Runnable() {
                    @Override
                    public void run() {
                        navigationView.setCheckedItem(R.id.navDummy);
                    }
                });
                break;
        }
        setFragment(fragment);
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void setFragment(Fragment fragment) {
        if (fragment != null) {
            Fragment currentFragment = getCurrentFragment();
            if (!currentFragment.getClass()
                    .getSimpleName()
                    .equalsIgnoreCase(fragment.getClass().getSimpleName())) {
                getSupportFragmentManager().popBackStackImmediate(0,
                        FragmentManager.POP_BACK_STACK_INCLUSIVE);
                replaceFragment(fragment, false, null);
                return;
            }
            if (currentFragment instanceof HomeFragment && currentFragment.getArguments() != null && fragment.getArguments() == null) {
                replaceFragment(fragment, false, null);
            } else if (currentFragment instanceof HomeFragment && currentFragment.getArguments() == null && fragment.getArguments() != null) {
                replaceFragment(fragment, false, null);
            }
        }
    }

    private void showLogoutDialog() {
        final CustomDialog dialog = new CustomDialog(MainActivity.this,
                getResources().getString(R.string.title_logout), getResources().getString(R.string.are_you_sure_you_want_to_logout),
                getResources().getString(R.string.yes)
                , getResources().getString(R.string.no)) {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.tvPositive:
                        callLogoutApi();
                        dismiss();
                        break;
                    case R.id.tvNegative:
                        dismiss();
                        break;
                }
            }
        };
        dialog.show();
    }

    private void callLogoutApi() {
        UserDataModel user = RMPrefs.getInstance(MainActivity.this).getUserDataModel();
        if (user != null) {
            HashMap<String, String> params = new HashMap<>();
            params.put(ApiParamEnum.USER_ID.getValue(), user.getUser_id());
            params.put(ApiParamEnum.ACCESS_TOKEN.getValue(), RMPrefs.getInstance(MainActivity.this).getAccessToken());
            params.put(ApiParamEnum.DEVICE_TYPE.getValue(), String.valueOf(AppConstants.DEVICE_TYPE));
            getPresenter().callLogoutApi(params);
        }
    }

    @Override
    public void onSuccess(Response response) {
        logoutUser(response.getMessage());
    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
    }

    public void hideToolbar() {
        setToolbarVisibility(View.GONE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setupMenuOptions(navigationView.getMenu());
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.container);
            if (fragment instanceof HomeFragment && !isMyApplicationFragment) {
                if (doubleBackToExitPressedOnce) {
                    super.onBackPressed();
                    return;
                }
                this.doubleBackToExitPressedOnce = true;
                AppUtils.showToast(MainActivity.this, getString(R.string.back_message));

                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        doubleBackToExitPressedOnce = false;
                    }
                }, 2000);
            } else {
                if (fragment instanceof ContactUsFragment && ((ContactUsFragment) fragment).wvContactUs.canGoBack()) {
                    ((ContactUsFragment) fragment).wvContactUs.goBack();
                } else {
                    tvToolbarTitle.setVisibility(View.VISIBLE);
                    tvToolbarTitle.setText(getResources().getString(R.string.toolbar_home));
                    navigationView.setCheckedItem(R.id.navHome);
                    setHeaderTextColor(android.R.color.white);
                    setFragment(new HomeFragment());
                }
            }
        }
    }
}