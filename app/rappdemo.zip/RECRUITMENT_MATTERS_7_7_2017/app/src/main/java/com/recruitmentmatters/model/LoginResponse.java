package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Sameer Jani on 01/04/17.
 */

public class LoginResponse extends Response {
    @SerializedName("access_token")
    String access_token;
    String userName;
    @SerializedName("userData")
    UserDataModel userDataModel;

    public String getAccess_token() {
        return access_token;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public UserDataModel getUserDataModel() {
        return userDataModel;
    }

    public void setUserDataModel(UserDataModel userDataModel) {
        this.userDataModel = userDataModel;
    }
}
