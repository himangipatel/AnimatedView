package com.recruitmentmatters.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Sameer Jani on 28/3/17.
 */

public class ProfileEducationInfoModel implements Parcelable {

    @SerializedName("edu_high_school")
    String highschool = "";
    @SerializedName("edu_university")
    String university = "";
    @SerializedName("edu_degree")
    String degree = "";
    @SerializedName("edu_qualification")
    String qualificationDetail ="";
    @SerializedName("edu_uni_location")
    String universityLocation = "";

    public ProfileEducationInfoModel(){}

    public String getHighschool() {
        return highschool;
    }

    public void setHighschool(String highschool) {
        this.highschool = highschool;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getQualificationDetail() {
        return qualificationDetail;
    }

    public void setQualificationDetail(String qualificationDetail) {
        this.qualificationDetail = qualificationDetail;
    }

    public String getUniversityLocation() {
        return universityLocation;
    }

    public void setUniversityLocation(String universityLocation) {
        this.universityLocation = universityLocation;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.highschool);
        dest.writeString(this.university);
        dest.writeString(this.degree);
        dest.writeString(this.qualificationDetail);
        dest.writeString(this.universityLocation);
    }

    protected ProfileEducationInfoModel(Parcel in) {
        this.highschool = in.readString();
        this.university = in.readString();
        this.degree = in.readString();
        this.qualificationDetail = in.readString();
        this.universityLocation = in.readString();
    }

    public static final Creator<ProfileEducationInfoModel> CREATOR = new Creator<ProfileEducationInfoModel>() {
        @Override
        public ProfileEducationInfoModel createFromParcel(Parcel source) {
            return new ProfileEducationInfoModel(source);
        }

        @Override
        public ProfileEducationInfoModel[] newArray(int size) {
            return new ProfileEducationInfoModel[size];
        }
    };
}

