package com.recruitmentmatters.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;
import com.recruitmentmatters.model.ProfileEmploymentModel;

import java.util.ArrayList;

import butterknife.BindView;

/**
 * Created by Darshna Desai on 5/4/17.
 */

public class ProfileEmploymentAdapter extends BaseRecyclerAdapter<ProfileEmploymentAdapter.DataObjectHolder, ProfileEmploymentModel> {
    private ArrayList<ProfileEmploymentModel> employmentModels = null;
    private Context context;

    public ProfileEmploymentAdapter(Context context, ArrayList<ProfileEmploymentModel> employmentModels) {
        super(employmentModels);
        this.context = context;
        this.employmentModels = employmentModels;
    }

    @Override
    public ProfileEmploymentAdapter.DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_profile_employment, parent, false);
        return new ProfileEmploymentAdapter.DataObjectHolder(view);
    }

    @Override
    public void onBindViewHolder(ProfileEmploymentAdapter.DataObjectHolder holder, int position) {
        ProfileEmploymentModel model = employmentModels.get(position);
        holder.tvEmployer.setText(model.getEmpCompany());
        holder.tvPosition.setText(model.getEmpPosition());
        holder.tvWorkDuration.setText(model.getEmpStartDate() + "-" + model.getEmpEndDate());
        if(model.getEmpEndDate().equalsIgnoreCase(context.getResources().getString(R.string.title_present))){
            holder.tvEmployer.setText(model.getEmpCompany() + context.getResources().getString(R.string.title_current_position));
        }
    }

    @Override
    public int getItemCount() {
        return employmentModels.size();
    }

    class DataObjectHolder extends BaseRecyclerAdapter.ViewHolder {
        @BindView(R.id.tvEmployer)
        TextView tvEmployer;
        @BindView(R.id.tvPosition)
        TextView tvPosition;
        @BindView(R.id.tvWorkDuration)
        TextView tvWorkDuration;

        DataObjectHolder(View itemView) {
            super(itemView);
        }
    }
}
