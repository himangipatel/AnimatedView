package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.validator.Validator;
import com.recruitmentmatters.views.EmploymentView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Sameer Jani on 01/04/17.
 */

public class EmploymentPresenter extends BasePresenter<EmploymentView<HashMap<String, Object>>> {


    public void isValidate(HashMap<String, Object> hashMap, boolean isPresentSelected) {
        ValidationErrorModel validationErrorModel = null;
        if ((validationErrorModel = Validator.validateEmployer(String.valueOf(hashMap.get(ApiParamEnum.EMPLOYER.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validatePosition(String.valueOf(hashMap.get(ApiParamEnum.POSITION.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validateStartDate(String.valueOf(hashMap.get(ApiParamEnum.START_DATE.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validateEndDate(String.valueOf(hashMap.get(ApiParamEnum.END_DATE.getValue())))) != null && !isPresentSelected) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validateDuration(
                Long.parseLong(String.valueOf(hashMap.get(ApiParamEnum.START_DATE_DURATION.getValue())))
                , Long.parseLong(String.valueOf(hashMap.get(ApiParamEnum.END_DATE_DURATION.getValue()))))) != null
                && !isPresentSelected) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validateSkills(String.valueOf(hashMap.get(ApiParamEnum.KEY_SKILLS.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else {
            addEmployer(hashMap);
        }
    }

    private void callEditEmploymentApi(final HashMap<String, Object> params) {
        if (hasInternet()) {//If no internet it will show toast automatically.

            addSubscription(getAppInteractor().callEditEmploymentProfileApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onSuccess(params);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }

    private void addEmployer(HashMap<String, Object> hashMap) {
        JSONObject jsonEmployer = new JSONObject();
        try {
            jsonEmployer.putOpt(ApiParamEnum.EMPLOYER.getValue(), String.valueOf(hashMap.get(ApiParamEnum.EMPLOYER.getValue())));
            jsonEmployer.putOpt(ApiParamEnum.POSITION.getValue(), String.valueOf(hashMap.get(ApiParamEnum.POSITION.getValue())));
            jsonEmployer.putOpt(ApiParamEnum.START_DATE.getValue(), String.valueOf(hashMap.get(ApiParamEnum.START_DATE.getValue())));
            jsonEmployer.putOpt(ApiParamEnum.END_DATE.getValue(), String.valueOf(hashMap.get(ApiParamEnum.END_DATE.getValue())));
            jsonEmployer.putOpt(ApiParamEnum.KEY_SKILLS.getValue(), String.valueOf(hashMap.get(ApiParamEnum.KEY_SKILLS.getValue())));
            getView().onEmployerAdded(jsonEmployer);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void addEmployerDetails(ArrayList<JSONObject> listEmployer, boolean isEdit, HashMap<String, Object> hmDetails) {
        ValidationErrorModel validationErrorModel = null;
        if ((validationErrorModel = Validator.validateEmployers(listEmployer)) != null) {
            getView().onValidationError(validationErrorModel);
        } else {
            JSONArray jsonArray = new JSONArray();
            for (JSONObject jsonObject : listEmployer) {
                jsonArray.put(jsonObject);
            }
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put(ApiParamEnum.EMPLOYMENTS.getValue(), jsonArray.toString());
            if (isEdit) {
                hashMap.putAll(hmDetails);
                callEditEmploymentApi(hashMap);
            } else {
                getView().onSuccess(hashMap);
            }
        }
    }
}
