package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.LanguageModel;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.validator.Validator;
import com.recruitmentmatters.views.ValidationErrorView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Sameer Jani on 29/3/17.
 */

public class PersonalLanguageSpokenPresenter extends BasePresenter<ValidationErrorView<HashMap<String, Object>>> {

    public void isValidate(HashMap<String, Object> hashMap, String otherLangauge, boolean isEdit) {
        ArrayList<LanguageModel> alLanguages = (ArrayList<LanguageModel>) hashMap.get(ApiParamEnum.LANGUAGES_SPOKEN.getValue());
        ValidationErrorModel validationErrorModel = null;
        if (alLanguages != null && alLanguages.size() > 0) {
            String language = getAllSelectedLanguage(alLanguages, otherLangauge);
            if ((validationErrorModel = Validator.validateSpokenLanguage(language)) != null) {
                getView().onValidationError(validationErrorModel);
            } else {
                if (isEdit) {
                    hashMap.put(ApiParamEnum.LANGUAGES_SPOKEN.getValue(), language);
                    callEditLanguageProfile(hashMap);
                } else {
                    hashMap.clear();
                    hashMap.put(ApiParamEnum.LANGUAGES_SPOKEN.getValue(), language);
                    getView().onSuccess(hashMap);
                }
            }
        } else if ((validationErrorModel = Validator.validateSpokenLanguage(otherLangauge)) != null) {
            getView().onValidationError(validationErrorModel);
        } else {
            if (isEdit) {
                hashMap.put(ApiParamEnum.LANGUAGES_SPOKEN.getValue(), otherLangauge);
                callEditLanguageProfile(hashMap);
                return;
            } else {
                hashMap.put(ApiParamEnum.LANGUAGES_SPOKEN.getValue(), otherLangauge);
                getView().onSuccess(hashMap);
            }
        }
    }


    private void callEditLanguageProfile(final HashMap<String, Object> params) {
        if (hasInternet()) {//If no internet it will show toast automatically.

            addSubscription(getAppInteractor().callEditLanguageProfileApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onSuccess(params);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }

    public String getAllSelectedLanguage(ArrayList<LanguageModel> alLanguageModel, String strOtherLanguage) {
        String strLanguageSpokens = "";
        for (LanguageModel languageModel : alLanguageModel) {
            if (languageModel.isSelected() && !languageModel.getLanguageName().equalsIgnoreCase("Other")) {
                strLanguageSpokens = strLanguageSpokens.length() > 0 ? strLanguageSpokens + "/" + languageModel.getLanguageName() : languageModel.getLanguageName();
            }
        }
        if (!strOtherLanguage.isEmpty()) {
            strLanguageSpokens = strLanguageSpokens.length() > 0 ? strLanguageSpokens + "/" + strOtherLanguage : strOtherLanguage;
        }
        return strLanguageSpokens;
    }
}
