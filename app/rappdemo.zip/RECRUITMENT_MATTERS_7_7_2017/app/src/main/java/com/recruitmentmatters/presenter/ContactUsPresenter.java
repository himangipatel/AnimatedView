package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.customview.CustomDialog;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.ContactUsResponse;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.validator.Validator;
import com.recruitmentmatters.views.ContactUsView;

import java.util.HashMap;

/**
 * Created by Sameer Jani on 20/4/17.
 */

public class ContactUsPresenter extends BasePresenter<ContactUsView<String>> {
    public void callContactUsApi() {
        if (hasInternet()) {//If no internet it will show toast automatically.

            addSubscription(getAppInteractor().callContactUsApi(new InterActorCallback<ContactUsResponse>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onResponse(ContactUsResponse response) {
                    if (response.isStatus()) {
                        getView().onSuccess(response.getUrl());
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }

    public void isValidate(HashMap<String, String> params, CustomDialog customDialog) {
        ValidationErrorModel validationErrorModel = null;
        if ((validationErrorModel = (Validator.validateName(String.valueOf(params.get(ApiParamEnum.NAME.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateEmail(String.valueOf(params.get(ApiParamEnum.EMAIL.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } /*else if ((validationErrorModel = (Validator.validateWebsite(String.valueOf(params.get(ApiParamEnum.WEBSITE.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        }*/ else if ((validationErrorModel = (Validator.validateHelpText(String.valueOf(params.get(ApiParamEnum.HELP_TEXT.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else {
            callSendMessageApi(params, customDialog);
        }
    }

    private void callSendMessageApi(HashMap<String, String> params, final CustomDialog customDialog) {

        if (hasInternet()) {
            addSubscription(getAppInteractor().callSendMessageApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onMessageSendSuccess(response.getMessage(), customDialog);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        } else {
            getView().onFailure(null);
        }
    }
}
