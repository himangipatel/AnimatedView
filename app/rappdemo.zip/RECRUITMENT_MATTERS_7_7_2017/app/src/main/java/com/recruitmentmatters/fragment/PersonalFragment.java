package com.recruitmentmatters.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseFragment;
import com.recruitmentmatters.utils.AppUtils;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Darshna Desai on 28/3/17.
 */

public class PersonalFragment extends BaseFragment {

    @BindView(R.id.tvNext)
    TextView tvNext;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_personal, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
    }

    @OnClick({R.id.tvNext})
    public void onClick(View view) {
        AppUtils.hideKeyboard(getActivity());
        switch (view.getId()) {
            case R.id.tvReset:
                //callForgotPasswordApi();
                break;
        }
    }


}
