package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.CountryResponse;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.validator.Validator;
import com.recruitmentmatters.views.PersonalEducationView;

import java.util.HashMap;

/**
 * Created by Sameer Jani on 29/3/17.
 */

public class PersonalEducationPresenter extends BasePresenter<PersonalEducationView<HashMap<String, Object>>> {

    public void isValidate(HashMap<String, Object> hashMap, boolean isEdit) {
        ValidationErrorModel validationErrorModel = null;
        if ((validationErrorModel = Validator.validateQualification(String.valueOf(hashMap.get(ApiParamEnum.QUALIFICATION.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else {
            if (isEdit) {
                callEditEducationProfile(hashMap);
            } else {
                getView().onSuccess(hashMap);
            }
        }
    }

    private void callEditEducationProfile(final HashMap<String, Object> params) {
        if (hasInternet()) {//If no internet it will show toast automatically.

            addSubscription(getAppInteractor().callEditEducationProfile(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onSuccess(params);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }

    public void callUniversityLocationApi() {
        if (hasInternet()) {//If no internet it will show toast automatically.

            addSubscription(getAppInteractor().callUniversityLocationApi(new InterActorCallback<CountryResponse>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(CountryResponse response) {
                    if (response.isStatus()) {
                        getView().onLocationList(response);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }
}
