package com.recruitmentmatters.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.activities.JobsActivity;
import com.recruitmentmatters.adapter.CategoryLocationAdapter;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;
import com.recruitmentmatters.baseclasses.BaseView;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.ApiRequestUrlEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.customview.CustomSwipeRefreshLayout;
import com.recruitmentmatters.model.CategoryResponse;
import com.recruitmentmatters.presenter.CategoryPresenter;
import com.recruitmentmatters.utils.AppUtils;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Darshna Desai on 12/4/17.
 */

public class LocationFragment extends MVPFragment<CategoryPresenter, BaseView> implements BaseView, BaseRecyclerAdapter.RecycleOnItemEventListener {

    @BindView(R.id.commonRecyclerView)
    RecyclerView commonRecyclerView;
    @BindView(R.id.swipeRefreshLayout)
    CustomSwipeRefreshLayout swipeRefreshLayout;
    @BindView(R.id.tvNoJobs)
    TextView tvNoData;

    boolean isFromAdvanceSearch = false;

    @NonNull
    @Override
    public CategoryPresenter createPresenter() {
        return new CategoryPresenter();
    }

    @NonNull
    @Override
    public BaseView attachView() {
        return this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.app_recyclerview, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        init(view, savedInstanceState);
        swipeRefreshLayout.setEnabled(false);
    }

    private void init(View v, Bundle savedInstanceState) {
        commonRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        callGetJobsApi();
    }

    private void callGetJobsApi() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            isFromAdvanceSearch = bundle.getBoolean(AppConstants.SEND_IS_FROM_ADVANCE_SEARCH);
        }
        if(isFromAdvanceSearch){
            getPresenter().callGetCategoryApi(ApiRequestUrlEnum.GET_ALL_FILER_LOCATIONS.getValue());
        }else {
            getPresenter().callGetCategoryApi(ApiRequestUrlEnum.GET_ALL_LOCATIONS.getValue());
        }
    }

    @Override
    public void onSuccess(Object response) {
        if (((CategoryResponse) response).getCategory_data() != null) {
            tvNoData.setVisibility(View.GONE);

            CategoryLocationAdapter adapter = new CategoryLocationAdapter(getActivity()
                    , ((CategoryResponse) response).getCategory_data(), isFromAdvanceSearch);
            commonRecyclerView.setAdapter(adapter);
            adapter.setRecycleOnItemEventListener(this);
        }
    }

    @Override
    public void onFailure(String message) {
        tvNoData.setVisibility(View.VISIBLE);
        AppUtils.showToast(getActivity(), message);
    }

    @Override
    public void onItemClick(View view, int position) {
        if (getActivity().getIntent().hasExtra(ApiParamEnum.LOCATION_NAME.getValue())) {
            Intent returnIntent = new Intent();
            returnIntent.putExtra(ApiParamEnum.LOCATION_NAME.getValue(), ((CategoryLocationAdapter) commonRecyclerView.getAdapter()).getData(position).getCat_name());
            getActivity().setResult(Activity.RESULT_OK, returnIntent);
            getActivity().finish();
        } else {
            Intent redirectJobsActivityIntent = new Intent(getActivity(), JobsActivity.class);
            redirectJobsActivityIntent.putExtra(ApiParamEnum.LOCATION_NAME.getValue(), ((CategoryLocationAdapter) commonRecyclerView.getAdapter()).getData(position).getCat_name());
            redirectJobsActivityIntent.putExtra(ApiParamEnum.LOCATION_ID.getValue(), ((CategoryLocationAdapter) commonRecyclerView.getAdapter()).getData(position).getCat_id());
            startActivity(redirectJobsActivityIntent);
        }
    }

    @Override
    public void onItemLongPress(View view, int position) {

    }
}

