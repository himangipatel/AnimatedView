package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Sameer Jani on 01/04/17.
 */

public class CategoryResponse extends Response {
    @SerializedName(value = "category_data", alternate = "location_data")
    ArrayList<CategoryModel> category_data;

    public ArrayList<CategoryModel> getCategory_data() {
        return category_data;
    }

    public void setCategory_data(ArrayList<CategoryModel> category_data) {
        this.category_data = category_data;
    }
}
