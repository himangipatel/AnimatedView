package com.recruitmentmatters.baseclasses;

import com.recruitmentmatters.interacter.AppInteractor;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.Response;

import java.util.HashMap;

import rx.Subscription;
import rx.subscriptions.CompositeSubscription;

;

/**
 * Created  on 22/8/16.
 */

public abstract class BasePresenter<V extends BaseView> {
    protected AppInteractor appInteractor;
    private V view;
    private CompositeSubscription subscription = new CompositeSubscription();

    final void attachView(V view) {
        this.view = view;
    }

    final void detachView() {
        this.view = null;
        if (subscription != null) {
            subscription.clear();
        }

    }

    public V getView() {
        return view;
    }

    public boolean hasInternet() {
        return view.hasInternet();
    }

    public boolean isViewAttached() {
        return view != null;
    }

    public void checkViewAttached() {
        if (!isViewAttached()) throw new MvpViewNotAttachedException();
    }



    public static class MvpViewNotAttachedException extends RuntimeException {
        public MvpViewNotAttachedException() {
            super("Please call Presenter.attachView(MvpView) before requesting data to the Presenter");
        }
    }

    protected void addSubscription(Subscription s) {
        subscription.add(s);
    }

    //This method is for adding subscription with key
    protected void addSubscription(Subscription subscription, String key, boolean removePrevious) {
        /*if (removePrevious && subscriptionHashMap.containsKey(key)) {
            Subscription foundSubscription = subscriptionHashMap.get(key);
            if (foundSubscription != null && !foundSubscription.isUnsubscribed()) {
                foundSubscription.unsubscribe();
                subscriptionHashMap.remove(key);
            }
        }
        subscriptionHashMap.put(key, subscription);*/
    }

    protected final AppInteractor getAppInteractor() {
        if (appInteractor == null) {
            appInteractor = new AppInteractor();
        }
        return appInteractor;
    }

    public void callLogoutApi(HashMap<String, String> logoutParams) {
        new AppInteractor().callLogoutApi(logoutParams, new InterActorCallback<Response>() {
            @Override
            public void onStart() {
                getView().showProgressDialog(true);
            }

            @Override
            public void onResponse(Response response) {
                if (response.isStatus()) {
                    if(response.isAuthentication()) getView().onSuccess(response);
                    else getView().onAuthenticationFailure(response.getMessage());
                } else {
                    getView().onFailure(response.getMessage());
                }
            }

            @Override
            public void onFinish() {
                getView().showProgressDialog(false);
            }

            @Override
            public void onError(String message) {
                getView().onFailure(message);
            }
        });
    }
}
