package com.recruitmentmatters.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.adapter.SpinnerAdapter;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.constants.RegisterForm;
import com.recruitmentmatters.constants.SpinnerType;
import com.recruitmentmatters.listeners.OnEditProfileListener;
import com.recruitmentmatters.listeners.OnNextPressedListener;
import com.recruitmentmatters.model.ProfileJobCategoryModel;
import com.recruitmentmatters.presenter.PersonalJobCategoryPresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.views.PersonalJobCategoryView;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnFocusChange;
import butterknife.OnTouch;

/**
 * Created by Sameer Jani on 28/3/17.
 */

public class PersonalJobCategoryFragment extends MVPFragment<PersonalJobCategoryPresenter, PersonalJobCategoryView<HashMap<String, Object>>> implements PersonalJobCategoryView<HashMap<String, Object>> {

    @BindView(R.id.spCategory)
    Spinner spCategory;
    @BindView(R.id.etIndustries)
    EditText etIndustries;
    @BindView(R.id.etSkills)
    EditText etSkills;
    @BindView(R.id.spAvailability)
    Spinner spAvailability;
    @BindView(R.id.tvNext)
    TextView tvNext;
    @BindView(R.id.tvTopHeader)
    RelativeLayout tvTopHeader;

    RelativeLayout rlPersonalTitleBar;
    TextView tvFormTitle;
    ImageView ivFormBack;

    private OnNextPressedListener onNextPressedListener = null;
    private OnEditProfileListener onEditProfileListener = null;
    private String[] categoryList = null;

    private ProfileJobCategoryModel profileJobCategoryModel = null;


    public PersonalJobCategoryFragment() {
    }


    @NonNull
    @Override
    public PersonalJobCategoryPresenter createPresenter() {
        return new PersonalJobCategoryPresenter();
    }

    @NonNull
    @Override
    public PersonalJobCategoryView attachView() {
        return this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.partial_reg_job_category, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
    }

    private void init(View view) {
        ButterKnife.bind(this, view);
        rlPersonalTitleBar = ButterKnife.findById(view, R.id.rlPersonalTitleBar);
        ivFormBack = ButterKnife.findById(view, R.id.ivFormBack);
        tvFormTitle = ButterKnife.findById(view, R.id.tvFormTitle);
        if (getActivity() instanceof OnNextPressedListener)
            onNextPressedListener = (OnNextPressedListener) getActivity();
        if (getActivity() instanceof OnEditProfileListener)
            onEditProfileListener = (OnEditProfileListener) getActivity();
        initFormTitleBar();
        initForm();
        setDataFromPrefs();
        checkForEdit();
    }

    private void initFormTitleBar() {
        ivFormBack.setVisibility(View.VISIBLE);
        tvFormTitle.setText(R.string.title_job_category);
    }

    private void initForm() {

        String[] availableList = getResources().getStringArray(R.array.available_arrays);
        spAvailability.setAdapter(new SpinnerAdapter(getActivity(), availableList, SpinnerType.AVAILABLE));

        if (categoryList != null && categoryList.length > 1) {
            spCategory.setAdapter(new SpinnerAdapter(getActivity(), categoryList, SpinnerType.CATEGORY));
            if (profileJobCategoryModel != null) {
                setCategory(profileJobCategoryModel.getJobCategory());
            }
            return;
        }
        categoryList = new String[]{getString(R.string.hint_select_category)};
        spCategory.setAdapter(new SpinnerAdapter(getActivity(), categoryList, SpinnerType.CATEGORY));
        getPresenter().onCategoryList();
    }

    private void setDataFromPrefs() {
        profileJobCategoryModel = RMPrefs.getInstance(getActivity()).getJobCategoryModel();
        if (profileJobCategoryModel != null) {
            setData();
        }
    }

    private void checkForEdit() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            if(bundle.getParcelable(AppConstants.SEND_DATA_EDIT_PROFILE) != null) {
                profileJobCategoryModel = bundle.getParcelable(AppConstants.SEND_DATA_EDIT_PROFILE);
                tvTopHeader.setVisibility(View.GONE);
                tvNext.setText(R.string.update);
                setData();
            }
        }
    }

    private void setData() {
        etIndustries.setText(profileJobCategoryModel.getJobIndustries());
        etSkills.setText(profileJobCategoryModel.getJobSkills());
        setAvailability(profileJobCategoryModel.getJobAvailability());
    }

    private void setCategory(String category) {
        for (int i = 0; i < spCategory.getAdapter().getCount(); i++) {
            if (category.equalsIgnoreCase(String.valueOf(spCategory.getAdapter().getItem(i)))) {
                spCategory.setSelection(i);
            }
        }
    }

    private void setAvailability(String jobAvailability) {
        for (int i = 0; i < spAvailability.getAdapter().getCount(); i++) {
            if (jobAvailability.equalsIgnoreCase(String.valueOf(spAvailability.getAdapter().getItem(i)))) {
                spAvailability.setSelection(i);
            }
        }
    }

    @OnClick({R.id.tvNext, R.id.ivFormBack})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvNext:
                addJobCategoryDetails();
                break;

            case R.id.ivFormBack:
                if (onNextPressedListener != null) {
                    saveDataInPrefs();
                    onNextPressedListener.onPreviousClicked();
                }
                break;
        }
    }

    public void saveDataInPrefs() {
        ProfileJobCategoryModel model = new ProfileJobCategoryModel();
        model.setJobCategory(String.valueOf(spCategory.getSelectedItem()));
        model.setJobIndustries(AppUtils.getText(etIndustries));
        model.setJobSkills(AppUtils.getText(etSkills));
        model.setJobAvailability(String.valueOf(spAvailability.getSelectedItem()));
        RMPrefs.getInstance(getActivity()).setJobCategoryModel(model);
    }

    @OnFocusChange({R.id.spCategory, R.id.spAvailability})
    public void onFocusChange(View view, boolean focused) {
        if (focused) {
            AppUtils.hideKeyboard(getActivity());
        }
    }

    private void addJobCategoryDetails() {
        AppUtils.hideKeyboard(getActivity());
        HashMap<String, Object> hmPersonalJobCategoryDetails = new HashMap<>();
        hmPersonalJobCategoryDetails.put(ApiParamEnum.CATEGORY_NAME.getValue(), spCategory.getSelectedItem());
        hmPersonalJobCategoryDetails.put(ApiParamEnum.INDUSTRIES_WORKED.getValue(), AppUtils.getText(etIndustries));
        hmPersonalJobCategoryDetails.put(ApiParamEnum.SKILLS.getValue(), AppUtils.getText(etSkills));
        hmPersonalJobCategoryDetails.put(ApiParamEnum.AVAILABILITY.getValue(), spAvailability.getSelectedItem());

        if (profileJobCategoryModel != null) {
            hmPersonalJobCategoryDetails = AppUtils.getCommonParams(getActivity(), hmPersonalJobCategoryDetails);
        }

        getPresenter().isValidate(hmPersonalJobCategoryDetails, onNextPressedListener == null,
                getResources().getString(R.string.hint_select_category), getResources().getString(R.string.hint_sp_available));
    }

    @Override
    public void onValidationError(ValidationErrorModel validationErrorModel) {
        AppUtils.showToast(getActivity(), validationErrorModel.getMsg());
        switch (validationErrorModel.getError()) {
            case SKILLS:
                AppUtils.requestEdittextFocus(getActivity(), etSkills);
                break;
            case INDUSTRIES_WORKED:
                AppUtils.requestEdittextFocus(getActivity(), etIndustries);
                break;
        }
    }

    @Override
    public void onSuccess(HashMap<String, Object> response) {
        if (response != null && response.size() > 0) {
            if (onNextPressedListener != null) {
                onNextPressedListener.onNextPressed(RegisterForm.PERSONAL_JOB_TYPE, response);
            } else if (onEditProfileListener != null) {
                profileJobCategoryModel.setJobIndustries(AppUtils.getText(etIndustries));
                profileJobCategoryModel.setJobSkills(AppUtils.getText(etSkills));
                profileJobCategoryModel.setJobCategory(String.valueOf(response.get(ApiParamEnum.CATEGORY_NAME.getValue())));
                profileJobCategoryModel.setJobAvailability(String.valueOf(response.get(ApiParamEnum.AVAILABILITY.getValue())));
                onEditProfileListener.onEditProfileSuccess(profileJobCategoryModel);
            }
        }
    }

    @OnTouch({R.id.spCategory, R.id.spAvailability})
    public boolean onTouch(View view, MotionEvent motionEvent) {
        AppUtils.hideKeyboard(getActivity());
        if (view.getId() == R.id.spCategory) {
            if (spCategory.getAdapter() == null || spCategory.getAdapter().getCount() <= 1) {
                getPresenter().onCategoryList();
            }
        }
        return false;
    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
    }

    @Override
    public void onCategoryList(String[] categoryList) {
        this.categoryList = categoryList;
        spCategory.setAdapter(new SpinnerAdapter(getActivity(), categoryList, SpinnerType.CATEGORY));
        if (profileJobCategoryModel != null) {
            setCategory(profileJobCategoryModel.getJobCategory());
        }
    }

}
