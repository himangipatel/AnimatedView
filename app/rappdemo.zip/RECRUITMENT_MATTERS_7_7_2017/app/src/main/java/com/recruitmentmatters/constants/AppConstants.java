package com.recruitmentmatters.constants;

/**
 * Created by Darshna Desai on 23/3/17.
 */

public class AppConstants {

    public static final String API_BASE_URL = "http://recruitmentmatters.co.zw/api/v1/";
    public static final String IMAGE_BASE_URL = "http://recruitmentmatters.co.zw/uploads/users/";/*BASE URL/userid/image_url*/
    public static final String CV_BASE_URL = "http://recruitmentmatters.co.zw/uploads/";

    public static final int DEVICE_TYPE = 2;

    public static final String CRITICISM_ID = "998e504e0f47401598e547c2536fb2cf00555300";

    public static final String SEND_DATA_EDIT_PROFILE = "sendDataEditProfile";
    public static final String SEND_REQUEST_ID_EDIT_PROFILE = "sendRequestIdEditProfile";
    public static final String SEND_IS_FROM_ADVANCE_SEARCH = "isFromAdvanceSearch";

    public static final String IS_ADVANCE_SEARCH = "isAdvancedSearch";
    public static final String SEND_JOB_DETAILS_POSITION = "sendJobDetailsPosition";
    public static final String RETURNED_JOB_DETAIL = "returnedUpdatedJobDetails";
    public static final String SEND_IS_MY_APPLICATION_JOB_DETAILS = "sendIsMyApplicationJobDetails";
    public static final String SEND_FOR_MY_APPLICATION_SCREEN = "sendForMyApplicationScreen";

    public static final String EXTRA_FROM_MENU = "from_menu";
    public static final String EXTRA_FROM_APPLY_JOB= "from_apply_job";
    public static final String EXTRA_LOGIN_SUCCESS= "is_login";


    public static final String FAVOURITE = "1";
    public static final String UNFAVOURITE = "2";

    public static final int GENERAL_FORM = 100;
    public static final int EDUCATION_FORM = 101;
    public static final int EMPLOYMENT_FORM = 102;
    public static final int LANGUAGE_FORM = 103;
    public static final int JOB_CATEGORY_FORM = 104;
    public static final int JOB_TYPE_FORM = 105;
    public static final int REFERENCES_FORM = 106;

    public static final int CATEGORY_LIST = 107;
    public static final int LOCATION_LIST = 108;

    public static final int SEND_JOB_DETAILS = 109;
    public static final int SELECT_FILE = 110;

    public static final int PERMISSION_READ_STORAGE = 111;
    public static final int PERMISSION_WRITE_STORAGE = 112;

    public static final int LOGIN_TO_APPLY_JOB = 113;

}
