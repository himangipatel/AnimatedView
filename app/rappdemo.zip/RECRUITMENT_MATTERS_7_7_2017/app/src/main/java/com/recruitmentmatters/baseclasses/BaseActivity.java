package com.recruitmentmatters.baseclasses;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.activities.LoginActivity;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;

import butterknife.BindView;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;


public class BaseActivity extends AppCompatActivity {


    @Nullable
    @BindView(R.id.toolbar)
    public Toolbar toolbar;
    @Nullable
    @BindView(R.id.rlToolbar)
    public RelativeLayout rlToolbar;
    @Nullable
    @BindView(R.id.ivToolbarLeft)
    public ImageView ivToolbarLeft;
    @Nullable
    @BindView(R.id.tvToolbarTitle)
    public TextView tvToolbarTitle;
    @Nullable
    @BindView(R.id.ivToolbarRight)
    public ImageView ivToolbarRight;
    @Nullable
    @BindView(R.id.tvToolbarRight)
    public TextView tvToolbarRight;
    @Nullable
    @BindView(R.id.progressToolbar)
    public ProgressBar progressToolbar;

    private Dialog progressDialog;

    private LifeCycleCallBackManager lifeCycleCallBackManager;

    public void setLifeCycleCallBackManager(LifeCycleCallBackManager lifeCycleCallBackManager) {
        this.lifeCycleCallBackManager = lifeCycleCallBackManager;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (lifeCycleCallBackManager != null) {
            lifeCycleCallBackManager.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (lifeCycleCallBackManager != null) {
            lifeCycleCallBackManager.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setSupportActionBar(toolbar);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.themeGray));
        }
    }


    //hide or show toolbar
    public void setToolbarVisibility(int visibility) {
        toolbar.setVisibility(visibility);
    }

    public void setTvToolbarRightVisibility(int visibility, String textRight) {
        tvToolbarRight.setVisibility(visibility);
        tvToolbarRight.setText(textRight);
    }

    public void showProgressDialog(boolean show) {
        //Show Progress bar here
        if (show) {
            showProgressDialog();
        } else {
            hideProgressDialog();
        }
    }

    public void showProgressToolBar(boolean show) {
        if (show) {
            progressToolbar.setVisibility(View.VISIBLE);
        } else {
            progressToolbar.setVisibility(View.GONE);
        }
    }



    public void onAuthenticationFailure(String msg) {
        logoutUser(msg);
    }


    /**
     * Common function to redirect the user to login screen, when the user logs out
     */
    public void logoutUser(String msg) {
        AppUtils.showToast(this, msg);
        RMPrefs.getInstance(this).clearAllPrefs();
        Intent redirectIntent = new Intent(this, LoginActivity.class);
        redirectIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(redirectIntent);
    }

    /**
     * show progress bar
     */
    protected final void showProgressDialog() {
        if (progressDialog == null) {
            progressDialog = new Dialog(this);
        } else {
            return;
        }
        View view = LayoutInflater.from(this).inflate(R.layout.app_loading_dialog, null, false);

        ImageView imageView1 = (ImageView) view.findViewById(R.id.imageView2);
        Animation a1 = AnimationUtils.loadAnimation(this, R.anim.progress_anim);
        a1.setDuration(1500);
        imageView1.startAnimation(a1);

        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(view);
        Window window = progressDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(ContextCompat.getDrawable(this, android.R.color.transparent));
        }
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
    }

    /**
     * hide progress bar
     */
    protected final void hideProgressDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
            progressDialog = null;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public Activity getActivity() {
        return this;
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}