package com.recruitmentmatters.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.recruitmentmatters.fragment.EmploymentFragment;
import com.recruitmentmatters.fragment.PersonalFragment;
import com.recruitmentmatters.fragment.ReferenceFragment;

/**
 * Created by Darshna Desai on 28/3/17.
 */

public class RegistrationPagerAdapter extends FragmentStatePagerAdapter {

    int mNumOfTabs;

    public RegistrationPagerAdapter(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                PersonalFragment tab1 = new PersonalFragment();
                return tab1;
            case 1:
                EmploymentFragment tab2 = new EmploymentFragment();
                return tab2;
            case 2:
                ReferenceFragment tab3 = new ReferenceFragment();
                return tab3;
            default:
                PersonalFragment tabDefault = new PersonalFragment();
                return tabDefault;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}
