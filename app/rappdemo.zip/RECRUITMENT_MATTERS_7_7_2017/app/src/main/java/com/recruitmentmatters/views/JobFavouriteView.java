package com.recruitmentmatters.views;

import com.recruitmentmatters.baseclasses.BaseView;

/**
 * Created by Sameer Jani on 19/4/17.
 */

public interface JobFavouriteView<T> extends BaseView<T> {
    void onFavouriteJobSucess(String message,int pos);
}
