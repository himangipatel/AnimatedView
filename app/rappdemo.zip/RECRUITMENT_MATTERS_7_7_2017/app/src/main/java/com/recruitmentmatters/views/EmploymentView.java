package com.recruitmentmatters.views;

import org.json.JSONObject;

/**
 * Created by Sameer Jani on 3/4/17.
 */

public interface EmploymentView<T> extends ValidationErrorView<T> {
    void onEmployerAdded(JSONObject jsonEmploymentDetails);
}
