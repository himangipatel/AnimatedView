package com.recruitmentmatters.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Darshna Desai on 11/4/17.
 */

public class JobModel implements Parcelable {
    public static final Creator<JobModel> CREATOR = new Creator<JobModel>() {
        @Override
        public JobModel createFromParcel(Parcel in) {
            return new JobModel(in);
        }

        @Override
        public JobModel[] newArray(int size) {
            return new JobModel[size];
        }
    };
    @SerializedName("job_id")
    String jobId;

    @SerializedName("job_day")
    String jobDay;

    @SerializedName("job_month")
    String jobMonth;

    @SerializedName("job_title")
    String jobTitle;

    @SerializedName("job_summary")
    String jobSummary;

    @SerializedName(value = "job_description", alternate = "job_decription")
    String jobDesc;

    @SerializedName("job_category")
    String jobCategory;

    @SerializedName("job_location")
    String jobLocation;

    @SerializedName("job_salary")
    String jobSalary;

    @SerializedName("job_is_fav")
    boolean jobFav;

    @SerializedName("job_details")
    JobDetailsModel job_details;

    @SerializedName("description")
    JobDescriptionModel jobDescriptionModel;

    @SerializedName("job_questions")
    ArrayList<JobQuestions> jobQuestionsData;

    protected JobModel(Parcel in) {
        jobId = in.readString();
        jobDay = in.readString();
        jobMonth = in.readString();
        jobTitle = in.readString();
        jobSummary = in.readString();
        jobDesc = in.readString();
        jobCategory = in.readString();
        jobLocation = in.readString();
        jobSalary = in.readString();
        jobFav = in.readByte() != 0;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getJobDay() {
        return jobDay;
    }

    public void setJobDay(String jobDay) {
        this.jobDay = jobDay;
    }

    public String getJobMonth() {
        return jobMonth;
    }

    public void setJobMonth(String jobMonth) {
        this.jobMonth = jobMonth;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getJobSummary() {
        return jobSummary;
    }

    public void setJobSummary(String jobSummary) {
        this.jobSummary = jobSummary;
    }

    public String getJobDesc() {
        return jobDesc;
    }

    public void setJobDesc(String jobDesc) {
        this.jobDesc = jobDesc;
    }

    public String getJobCategory() {
        return jobCategory;
    }

    public void setJobCategory(String jobCategory) {
        this.jobCategory = jobCategory;
    }

    public String getJobLocation() {
        return jobLocation;
    }

    public void setJobLocation(String jobLocation) {
        this.jobLocation = jobLocation;
    }

    public String getJobSalary() {
        return jobSalary;
    }

    public void setJobSalary(String jobSalary) {
        this.jobSalary = jobSalary;
    }

    public boolean isJobFav() {
        return jobFav;
    }

    public void setJobFav(boolean jobFav) {
        this.jobFav = jobFav;
    }

    public JobDetailsModel getJob_details() {
        return job_details;
    }

    public void setJob_details(JobDetailsModel job_details) {
        this.job_details = job_details;
    }

    public JobDescriptionModel getJobDescriptionModel() {
        return jobDescriptionModel;
    }

    public void setJobDescriptionModel(JobDescriptionModel jobDescriptionModel) {
        this.jobDescriptionModel = jobDescriptionModel;
    }

    public ArrayList<JobQuestions> getJobQuestionsData() {
        return jobQuestionsData;
    }

    public void setJobQuestionsData(ArrayList<JobQuestions> jobQuestionsData) {
        this.jobQuestionsData = jobQuestionsData;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(jobId);
        parcel.writeString(jobDay);
        parcel.writeString(jobMonth);
        parcel.writeString(jobTitle);
        parcel.writeString(jobSummary);
        parcel.writeString(jobDesc);
        parcel.writeString(jobCategory);
        parcel.writeString(jobLocation);
        parcel.writeString(jobSalary);
        parcel.writeByte((byte) (jobFav ? 1 : 0));
    }
}
