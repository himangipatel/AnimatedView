package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Sameer Jani on 13/4/17.
 */

public class JobDetailsJobModel {
    @SerializedName("job_id")
    String job_id = "";
    @SerializedName("job_location")
    String job_location = "";
    @SerializedName("job_company_name")
    String job_company_name = "";
    @SerializedName("job_role")
    String job_role = "";
    @SerializedName("job_join_date")
    String job_join_date = "";
    @SerializedName("job_emp_type")
    String job_emp_type = "";
    @SerializedName("job_month_salary")
    String job_month_salary = "";

    public String getJob_id() {
        return job_id;
    }

    public void setJob_id(String job_id) {
        this.job_id = job_id;
    }

    public String getJob_location() {
        return job_location;
    }

    public void setJob_location(String job_location) {
        this.job_location = job_location;
    }

    public String getJob_company_name() {
        return job_company_name;
    }

    public void setJob_company_name(String job_company_name) {
        this.job_company_name = job_company_name;
    }

    public String getJob_role() {
        return job_role;
    }

    public void setJob_role(String job_role) {
        this.job_role = job_role;
    }

    public String getJob_join_date() {
        return job_join_date;
    }

    public void setJob_join_date(String job_join_date) {
        this.job_join_date = job_join_date;
    }

    public String getJob_emp_type() {
        return job_emp_type;
    }

    public void setJob_emp_type(String job_emp_type) {
        this.job_emp_type = job_emp_type;
    }

    public String getJob_month_salary() {
        return job_month_salary;
    }

    public void setJob_month_salary(String job_month_salary) {
        this.job_month_salary = job_month_salary;
    }
}
