package com.recruitmentmatters.presenter;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.ApiRequestUrlEnum;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.CategoryModel;
import com.recruitmentmatters.model.CategoryResponse;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.validator.Validator;
import com.recruitmentmatters.views.PersonalJobCategoryView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Sameer Jani on 01/04/17.
 */

public class PersonalJobCategoryPresenter extends BasePresenter<PersonalJobCategoryView<HashMap<String, Object>>> {
    public void isValidate(HashMap<String, Object> hashMap, boolean isEdit, String categoryHint, String availabilityHint) {
        ValidationErrorModel validationErrorModel = null;
        if ((validationErrorModel = Validator.validateCategoryName(String.valueOf(hashMap.get(ApiParamEnum.CATEGORY_NAME.getValue())), categoryHint)) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validateIndustriesWorked(String.valueOf(hashMap.get(ApiParamEnum.INDUSTRIES_WORKED.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validateSkills(String.valueOf(hashMap.get(ApiParamEnum.SKILLS.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validateAvailability(String.valueOf(hashMap.get(ApiParamEnum.AVAILABILITY.getValue())), availabilityHint)) != null) {
            getView().onValidationError(validationErrorModel);
        } else {
            if(isEdit){
                callEditJobCategoryApi(hashMap);
            }else {
                getView().onSuccess(hashMap);
            }
        }
    }

    public void onCategoryList() {
        if (hasInternet()) {//If no internet it will show toast automatically.

            addSubscription(getAppInteractor().callGetAllCategoriesApi(ApiRequestUrlEnum.GET_ALL_CATEGORIES.getValue(),
                    new InterActorCallback<CategoryResponse>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(CategoryResponse response) {
                    if (response.isStatus()) {
                        ArrayList<CategoryModel> categoryModels = response.getCategory_data();
                        String[] categoryList = new String[categoryModels.size() + 1];
                        categoryList[0] = getView().getActivity().getString(R.string.hint_select_category);
                        int count = 1;
                        for (CategoryModel categoryModel : categoryModels) {
                            categoryList[count] = categoryModel.getCat_name();
                            count++;
                        }
                        getView().onCategoryList(categoryList);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }

    private void callEditJobCategoryApi(final HashMap<String, Object> params) {
        if (hasInternet()) {//If no internet it will show toast automatically.

            addSubscription(getAppInteractor().callEditJobCategoryApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onSuccess(params);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }
}
