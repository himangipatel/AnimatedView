package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Darshna Desai on 8/5/17.
 */

public class JobQuestions {

    @SerializedName("que_id")
    private int que_id;
    @SerializedName("que")
    private String que;
    @SerializedName("que_ans")
    private String que_ans;

    public int getQue_id() {
        return que_id;
    }

    public void setQue_id(int que_id) {
        this.que_id = que_id;
    }

    public String getQue() {
        return que;
    }

    public void setQue(String que) {
        this.que = que;
    }

    public String getQue_ans() {
        return que_ans;
    }

    public void setQue_ans(String que_ans) {
        this.que_ans = que_ans;
    }
}
