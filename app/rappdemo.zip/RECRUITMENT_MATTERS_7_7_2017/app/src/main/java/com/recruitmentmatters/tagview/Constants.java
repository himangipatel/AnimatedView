package com.recruitmentmatters.tagview;

import android.graphics.Color;

import com.recruitmentmatters.R;

class Constants {
    // the dimens unit is dp or sp, not px
    public static final float DEFAULT_LINE_MARGIN = 5;
    public static final float DEFAULT_TAG_MARGIN = 6;
    public static final float DEFAULT_TAG_TEXT_MARGIN_LEFT = 12f;

    public static final float DEFAULT_TAG_TEXT_MARGIN_RIGHT = 12f;

    public static final float DEFAULT_TAG_TEXT_PADDING_LEFT = 12f;
    public static final float DEFAULT_TAG_TEXT_PADDING_TOP = 5;
    public static final float DEFAULT_TAG_TEXT_PADDING_RIGHT = 12;
    public static final float DEFAULT_TAG_TEXT_PADDING_BOTTOM = 6;
    public static final float LAYOUT_WIDTH_OFFSET = 1;
    public static final float DEFAULT_TAG_TEXT_SIZE = 15f;
    public static final float DEFAULT_TAG_DELETE_INDICATOR_SIZE = 14f;
    public static final float DEFAULT_TAG_LAYOUT_BORDER_SIZE = 0f;
    public static final float DEFAULT_TAG_RADIUS = 100;
    public static final int DEFAULT_TAG_LAYOUT_COLOR = Color.parseColor("#00BFFF");
    public static final int DEFAULT_TAG_LAYOUT_COLOR_PRESS = Color.parseColor("#88363636");
    public static final int DEFAULT_TAG_TEXT_COLOR = Color.parseColor("#ffffff");
    public static final int DEFAULT_TAG_DELETE_INDICATOR_COLOR = Color.parseColor("#ffffff");
    public static final int DEFAULT_TAG_LAYOUT_BORDER_COLOR = Color.parseColor("#ffffff");
    public static final int DEFAULT_TAG_DELETE_ICON = R.drawable.cross_recipients_icon;
    public static final boolean DEFAULT_TAG_IS_DELETABLE = false;
    public static boolean DEBUG = true;
}
