package com.recruitmentmatters.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Sameer Jani on 30/3/17.
 */

public class ProfileJobCategoryModel implements Parcelable {

    public static final Creator<ProfileJobCategoryModel> CREATOR = new Creator<ProfileJobCategoryModel>() {
        @Override
        public ProfileJobCategoryModel createFromParcel(Parcel in) {
            return new ProfileJobCategoryModel(in);
        }

        @Override
        public ProfileJobCategoryModel[] newArray(int size) {
            return new ProfileJobCategoryModel[size];
        }
    };
    @SerializedName("main_category")
    String jobCategory = "";
    @SerializedName("industries_worked")
    String jobIndustries = "";
    @SerializedName("skills")
    String jobSkills = "";
    @SerializedName("availability")
    String jobAvailability = "";

    protected ProfileJobCategoryModel(Parcel in) {
        jobCategory = in.readString();
        jobIndustries = in.readString();
        jobSkills = in.readString();
        jobAvailability = in.readString();
    }

    public ProfileJobCategoryModel() {
    }

    public String getJobCategory() {
        return jobCategory;
    }

    public void setJobCategory(String jobCategory) {
        this.jobCategory = jobCategory;
    }

    public String getJobIndustries() {
        return jobIndustries;
    }

    public void setJobIndustries(String jobIndustries) {
        this.jobIndustries = jobIndustries;
    }

    public String getJobSkills() {
        return jobSkills;
    }

    public void setJobSkills(String jobSkills) {
        this.jobSkills = jobSkills;
    }

    public String getJobAvailability() {
        return jobAvailability;
    }

    public void setJobAvailability(String jobAvailability) {
        this.jobAvailability = jobAvailability;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(jobCategory);
        parcel.writeString(jobIndustries);
        parcel.writeString(jobSkills);
        parcel.writeString(jobAvailability);
    }
}
