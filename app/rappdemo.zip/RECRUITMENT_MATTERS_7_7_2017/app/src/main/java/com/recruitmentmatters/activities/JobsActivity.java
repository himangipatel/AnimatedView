package com.recruitmentmatters.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseActivity;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.fragment.HomeFragment;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Sameer Jani on 15/4/17.
 */

public class JobsActivity extends BaseActivity {

    @BindView(R.id.tvJobType)
    TextView tvJobType;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common);
        ButterKnife.bind(this);
        initJobs();
    }

    private void initJobs() {
        tvToolbarTitle.setText(getResources().getString(R.string.toolbar_jobs));
        Fragment fragment = new HomeFragment();
        Bundle bundle = null;
        if (getIntent().hasExtra(ApiParamEnum.SEARCH_WORD.getValue())) {
            bundle = new Bundle();
            bundle.putString(ApiParamEnum.SEARCH_WORD.getValue(), getIntent().getStringExtra(ApiParamEnum.SEARCH_WORD.getValue()));
        }
        if (getIntent().hasExtra(ApiParamEnum.CAT_ID.getValue())) {
            if (bundle == null)
                bundle = new Bundle();
            bundle.putString(ApiParamEnum.CAT_ID.getValue(), getIntent().getStringExtra(ApiParamEnum.CAT_ID.getValue()));
            if (getIntent().hasExtra(ApiParamEnum.CATEGORY_NAME.getValue()) && !getIntent().hasExtra(AppConstants.IS_ADVANCE_SEARCH)) {
                tvJobType.setVisibility(View.VISIBLE);
                tvJobType.setText(getIntent().getStringExtra(ApiParamEnum.CATEGORY_NAME.getValue()));
            }
        }
        if (getIntent().hasExtra(ApiParamEnum.LOCATION_NAME.getValue())) {
            if (bundle == null)
                bundle = new Bundle();
            if (getIntent().hasExtra(ApiParamEnum.LOCATION_NAME.getValue()) && !getIntent().hasExtra(AppConstants.IS_ADVANCE_SEARCH)) {
                tvJobType.setVisibility(View.VISIBLE);
                tvJobType.setText(getIntent().getStringExtra(ApiParamEnum.LOCATION_NAME.getValue()));
                bundle.putString(ApiParamEnum.LOCATION_NAME.getValue(), "");
                bundle.putString(ApiParamEnum.LOCATION_ID.getValue(), getIntent().getStringExtra(ApiParamEnum.LOCATION_ID.getValue()));
            }else{
                bundle.putString(ApiParamEnum.LOCATION_NAME.getValue(),getIntent().getStringExtra(ApiParamEnum.LOCATION_NAME.getValue()));
            }
        }
        replaceFragment(fragment, false, bundle);
    }

    private void replaceFragment(Fragment fragment, boolean addToBackStack, Bundle bundle) {

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, fragment, fragment.getClass().getSimpleName());
        if (addToBackStack) {
            fragmentTransaction.addToBackStack(fragment.getClass().getSimpleName());
        }
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        fragmentTransaction.commit();
    }

    @OnClick({R.id.ivToolbarLeft})
    public void onClick(View view) {
        finish();
    }
}
