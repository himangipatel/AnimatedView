package com.recruitmentmatters.presenter;

import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.validator.Validator;
import com.recruitmentmatters.views.ValidationErrorView;

import java.util.HashMap;

/**
 * Created by Sameer Jani on 01/04/17.
 */

public class PersonalJobTypePresenter extends BasePresenter<ValidationErrorView<HashMap<String, Object>>> {

    public void isValidate(HashMap<String, Object> hashMap, boolean isEdit) {
        ValidationErrorModel validationErrorModel = null;
        if ((validationErrorModel = Validator.validateJobType(String.valueOf(hashMap.get(ApiParamEnum.JOB_TYPE.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validateCurrentSalary(String.valueOf(hashMap.get(ApiParamEnum.CURRENT_SALARY.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = Validator.validateExpectedSalary(String.valueOf(hashMap.get(ApiParamEnum.EXPECTED_SALARY.getValue())))) != null) {
            getView().onValidationError(validationErrorModel);
        } else {
            if(isEdit){
                callEditJobTypeApi(hashMap);
            }else {
                getView().onSuccess(hashMap);
            }
        }
    }

    private void callEditJobTypeApi(final HashMap<String, Object> params) {
        if (hasInternet()) {
            addSubscription(getAppInteractor().callEditJobTypeApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onSuccess(params);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }
}
