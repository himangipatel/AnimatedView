package com.recruitmentmatters.fragment;

import android.annotation.TargetApi;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.customview.CustomDialog;
import com.recruitmentmatters.presenter.ContactUsPresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.views.ContactUsView;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Sameer Jani on 20/4/17.
 */

public class ContactUsFragment extends MVPFragment<ContactUsPresenter, ContactUsView<String>> implements ContactUsView<String> {

    @BindView(R.id.wvContactUs)
    public WebView wvContactUs;
    @BindView(R.id.pbLoader)
    ProgressBar pbLoader;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.contact_us_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        init();
    }

    private void init() {
        getPresenter().callContactUsApi();
    }

    @Override
    public void onSuccess(String response) {
        wvContactUs.loadUrl(response);

        wvContactUs.getSettings().setJavaScriptEnabled(true);
        wvContactUs.getSettings().setSupportZoom(false);
        wvContactUs.getSettings().setBuiltInZoomControls(false);
        wvContactUs.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pbLoader.setVisibility(View.GONE);
            }

            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if(url != null) {
                    if (url.startsWith("tel:")) {
                        initiateCall(url);
                        return true;
                    } else if (url.startsWith("mailto:")) {
                        //sendEmail(url.substring(7));
                        sendEmail(url);
                        view.reload();
                        return true;
                    }
                }
                return false;
            }

            @TargetApi(Build.VERSION_CODES.N)
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if(url != null) {
                    if (url.startsWith("tel:")) {
                        initiateCall(url);
                        return true;
                    } else if (url.startsWith("mailto:")) {
                        sendEmail(url);
                        view.reload();
                        return true;
                    }
                }
                return false;
            }

        });
    }

    private void initiateCall(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
            startActivity(intent);
        }catch (ActivityNotFoundException e){
            AppUtils.showToast(getActivity(), getResources().getString(R.string.msg_activity_not_found));
        }
    }

    private void sendEmail(String url) {
        try {
            // MailTo mt = MailTo.parse(url);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.putExtra(Intent.EXTRA_EMAIL, url);
            /*intent.putExtra(Intent.EXTRA_EMAIL, new String[] { mt.getTo() });
            intent.putExtra(Intent.EXTRA_TEXT, mt.getBody());
            intent.putExtra(Intent.EXTRA_SUBJECT, mt.getSubject());*/
            //intent.putExtra(Intent.EXTRA_CC, cc);
            intent.setType("message/rfc822");
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            AppUtils.showToast(getActivity(), getResources().getString(R.string.msg_activity_not_found));
        }
    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
        pbLoader.setVisibility(View.GONE);
    }

    @NonNull
    @Override
    public ContactUsPresenter createPresenter() {
        return new ContactUsPresenter();
    }

    @NonNull
    @Override
    public ContactUsView attachView() {
        return this;
    }

    @OnClick({R.id.tvSendUsMessage})
    public void onClick(View view) {
        CustomDialog customDialog = new CustomDialog(getActivity(), getResources().getString(R.string.action_send)) {
            @Override
            public void onClick(View view) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(ApiParamEnum.NAME.getValue(), getName());
                hashMap.put(ApiParamEnum.EMAIL.getValue(), getEmail());
                hashMap.put(ApiParamEnum.WEBSITE.getValue(), getWebsite());
                hashMap.put(ApiParamEnum.HELP_TEXT.getValue(), getQuery());
                getPresenter().isValidate(hashMap, this);
            }
        };
        customDialog.show();
    }

    @Override
    public void onMessageSendSuccess(String message, CustomDialog customDialog) {
        if (customDialog != null && customDialog.isShowing()) {
            customDialog.dismiss();
        }
        AppUtils.showToast(getActivity(), message);
    }

    @Override
    public void onValidationError(ValidationErrorModel validationErrorModel) {
        AppUtils.showToast(getActivity(), validationErrorModel.getMsg());
    }

}
