package com.recruitmentmatters.customview;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;

import java.util.List;

import butterknife.BindView;

/**
 * Created by  bhoomika on 21/12/16.
 */
public class OptionDialogAdapter
        extends BaseRecyclerAdapter<OptionDialogAdapter.ViewHolder, String> {

    private List<String> items;

    private Drawable roundedTopLeftRight, roundedBottomLeftRight, solidWhite;

    public OptionDialogAdapter(Context activity, List<String> data) {
        super(data);
        this.items = data;
        roundedTopLeftRight =
                ContextCompat.getDrawable(activity, R.drawable.rounded_white_left_right_top);
        roundedBottomLeftRight =
                ContextCompat.getDrawable(activity, R.drawable.rounded_white_left_right_bottom);
        solidWhite = ContextCompat.getDrawable(activity, R.drawable.solid_white);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_option_dialog, parent, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.tvItem.setText(getItem(position));
        if (position == 0) {
            holder.tvItem.setBackground(roundedTopLeftRight);
        } else if (position == items.size() - 1) {
            holder.tvItem.setBackground(roundedBottomLeftRight);
        } else {
            holder.tvItem.setBackground(solidWhite);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class ViewHolder extends BaseRecyclerAdapter.ViewHolder {
        @BindView(R.id.tvItem)
        TextView tvItem;
        View rootView;

        ViewHolder(View itemView) {
            super(itemView);
            this.rootView = itemView;
            clickableViews(rootView);
        }
    }
}
