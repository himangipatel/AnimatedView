package com.recruitmentmatters.views;

import com.recruitmentmatters.baseclasses.BaseView;
import com.recruitmentmatters.model.Response;

import java.io.File;

/**
 * Created by Darshna Desai on 11/4/17.
 */

public interface MyProfileView<T> extends BaseView<T> {
    void onProfilePicUploaded(Response response);
    void showPicProgress(boolean show);
    void onCVUploaded(Response response);
    void onCVDownloaded(File file);
    void onCVDownloadFailure(int message);

}