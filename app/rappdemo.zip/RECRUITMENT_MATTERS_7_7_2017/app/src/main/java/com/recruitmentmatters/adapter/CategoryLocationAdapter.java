package com.recruitmentmatters.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;
import com.recruitmentmatters.model.CategoryModel;

import java.util.ArrayList;

import butterknife.BindView;

/**
 * Created by Darshna Desai on 12/4/17.
 */

public class CategoryLocationAdapter extends BaseRecyclerAdapter<CategoryLocationAdapter.DataObjectHolder, CategoryModel> {
    private ArrayList<CategoryModel> categoryModelArrayList = null;
    private Context context;
    private boolean isFromAdvanceSearch;

    public CategoryLocationAdapter(Context context, ArrayList<CategoryModel> categoryModelArrayList, boolean isFromAdvanceSearch) {
        super(categoryModelArrayList);
        this.context = context;
        this.categoryModelArrayList = categoryModelArrayList;
        this.isFromAdvanceSearch = isFromAdvanceSearch;
    }

    @Override
    public CategoryLocationAdapter.DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category_location_listing, parent, false);
        return new CategoryLocationAdapter.DataObjectHolder(view);
    }

    @Override
    public void onBindViewHolder(CategoryLocationAdapter.DataObjectHolder holder, int position) {
        CategoryModel categoryModel = categoryModelArrayList.get(position);
        holder.tvName.setText(categoryModel.getCat_name());
        if(!isFromAdvanceSearch) holder.tvCount.setText(categoryModel.getCount());
        else holder.tvCount.setVisibility(View.GONE);
    }

    public CategoryModel getData(int position) {
        return categoryModelArrayList.get(position);
    }

    @Override
    public int getItemCount() {
        return categoryModelArrayList.size();
    }

    class DataObjectHolder extends BaseRecyclerAdapter.ViewHolder {

        @BindView(R.id.tvName)
        TextView tvName;
        @BindView(R.id.tvCount)
        TextView tvCount;

        DataObjectHolder(View itemView) {
            super(itemView);
            clickableViews(itemView);
        }
    }
}

