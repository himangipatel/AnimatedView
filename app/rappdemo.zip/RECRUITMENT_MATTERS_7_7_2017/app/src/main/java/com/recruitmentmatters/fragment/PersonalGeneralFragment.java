package com.recruitmentmatters.fragment;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.adapter.SpinnerAdapter;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.constants.RegisterForm;
import com.recruitmentmatters.constants.SpinnerType;
import com.recruitmentmatters.listeners.OnEditProfileListener;
import com.recruitmentmatters.listeners.OnNextPressedListener;
import com.recruitmentmatters.model.ProfileGeneralInfoModel;
import com.recruitmentmatters.model.UserDataModel;
import com.recruitmentmatters.presenter.PersonalGeneralPresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.views.PersonalGeneralView;

import java.util.Calendar;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnFocusChange;
import butterknife.OnItemSelected;
import butterknife.OnTouch;

/**
 * Created by Sameer Jani on 28/3/17.
 */

public class PersonalGeneralFragment extends MVPFragment<PersonalGeneralPresenter, PersonalGeneralView<HashMap<String, Object>>> implements PersonalGeneralView<HashMap<String, Object>> {

    @BindView(R.id.etFirstName)
    EditText etFirstName;
    @BindView(R.id.etLastName)
    EditText etLastName;
    @BindView(R.id.spGender)
    Spinner spGender;
    @BindView(R.id.spDriverLicence)
    Spinner spDriverLicence;
    @BindView(R.id.viewLicenceLine)
    View viewLicenceLine;
    @BindView(R.id.tvDob)
    TextView tvDob;
    @BindView(R.id.etEmail)
    EditText etEmail;
    @BindView(R.id.etTelephone)
    EditText etTelephone;
    @BindView(R.id.etCellphone)
    EditText etCellphone;
    @BindView(R.id.etSkypeId)
    EditText etSkypeId;
    @BindView(R.id.etAddress1)
    EditText etAddress1;
    @BindView(R.id.etAddress2)
    EditText etAddress2;
    @BindView(R.id.llDriverLicenceType)
    LinearLayout llDriverLicenceType;
    @BindView(R.id.cbMotorBike)
    CheckBox cbMotorBike;
    @BindView(R.id.cbLightVehicle)
    CheckBox cbLightVehicle;
    @BindView(R.id.cbHeavyDuty)
    CheckBox cbHeavyDuty;
    @BindView(R.id.cbOtherVehicle)
    CheckBox cbOtherVehicle;
    @BindView(R.id.spCountry)
    Spinner spCountry;
    @BindView(R.id.etCity)
    EditText etCity;
    @BindView(R.id.etOtherCountry)
    EditText etOtherCountry;
    @BindView(R.id.tvNext)
    TextView tvNext;
    @BindView(R.id.formTitlebar)
    View formTitlebar;

    RelativeLayout rlPersonalTitleBar;
    TextView tvFormTitle;
    ImageView ivFormBack;
    Calendar calendar = Calendar.getInstance();
    long lngDOB = 0;
    OnNextPressedListener onNextPressedListener = null;
    OnEditProfileListener onEditProfileListener = null;
    private ProfileGeneralInfoModel profileGeneralInfoModel = null;
    private String[] countryList = null;
    private int selected_years = 0, selected_months = 0, selected_days = 0;

    public PersonalGeneralFragment() {
    }

    @NonNull
    @Override
    public PersonalGeneralPresenter createPresenter() {
        return new PersonalGeneralPresenter();
    }

    @NonNull
    @Override
    public PersonalGeneralView attachView() {
        return this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.partial_reg_general, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
        checkForEdit();
    }

    private void checkForEdit() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            profileGeneralInfoModel = bundle.getParcelable(AppConstants.SEND_DATA_EDIT_PROFILE);
            if (profileGeneralInfoModel != null) {
                setData();
            }
        }
    }

    private void setData() {
        formTitlebar.setVisibility(View.GONE);
        spDriverLicence.setVisibility(View.GONE);
        viewLicenceLine.setVisibility(View.GONE);
        tvNext.setText(R.string.update);
        etFirstName.setText(profileGeneralInfoModel.getUserFirstName());
        etLastName.setText(profileGeneralInfoModel.getUserLastName());
        if (profileGeneralInfoModel.getUserGender() != null && !profileGeneralInfoModel.getUserGender().equalsIgnoreCase(""))
            spGender.setSelection(Integer.parseInt(profileGeneralInfoModel.getUserGender()));
        tvDob.setText(profileGeneralInfoModel.getUserDob());
        etEmail.setText(profileGeneralInfoModel.getUserEmail());
        etTelephone.setText(profileGeneralInfoModel.getUserTelephone());
        etCellphone.setText(profileGeneralInfoModel.getUserMobile());
        etSkypeId.setText(profileGeneralInfoModel.getUserSkypeId());
        etAddress1.setText(profileGeneralInfoModel.getUserAddressLine1());
        etAddress2.setText(profileGeneralInfoModel.getUserAddressLine2());
        etCity.setText(profileGeneralInfoModel.getUserCity());
        setCountry(profileGeneralInfoModel.getUserCountry());
    }

    private void setCountry(String country) {
        boolean isCountryFound = false;
        for (int i = 0; i < spCountry.getAdapter().getCount(); i++) {
            if (country.equalsIgnoreCase(String.valueOf(spCountry.getAdapter().getItem(i)))) {
                spCountry.setSelection(i);
                isCountryFound = true;
            }
        }
        if (!isCountryFound) {
            spCountry.setSelection(spCountry.getAdapter().getCount() - 1);
            etOtherCountry.setVisibility(View.VISIBLE);
            etOtherCountry.setText(country);
        }
    }

    private void init(View view) {
        ButterKnife.bind(this, view);
        rlPersonalTitleBar = ButterKnife.findById(view, R.id.rlPersonalTitleBar);
        ivFormBack = ButterKnife.findById(view, R.id.ivFormBack);
        tvFormTitle = ButterKnife.findById(view, R.id.tvFormTitle);
        if (getActivity() instanceof OnNextPressedListener)
            onNextPressedListener = (OnNextPressedListener) getActivity();
        if (getActivity() instanceof OnEditProfileListener)
            onEditProfileListener = (OnEditProfileListener) getActivity();
        initFormTitleBar();
        initForm();
    }

    private void initFormTitleBar() {
        ivFormBack.setVisibility(View.GONE);
        tvFormTitle.setText(R.string.title_general);
    }

    private void initForm() {
        String[] driverList = getResources().getStringArray(R.array.driving_licence_arrays);
        spDriverLicence.setAdapter(new SpinnerAdapter(getActivity(), driverList, SpinnerType.DRIVING_LICENCE));
        spDriverLicence.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String isYes = String.valueOf(adapterView.getItemAtPosition(i));
                if (isYes.equalsIgnoreCase(getString(R.string.str_yes))) {
                    llDriverLicenceType.setVisibility(View.VISIBLE);
                    llDriverLicenceType.refreshDrawableState();
                } else {
                    llDriverLicenceType.setVisibility(View.GONE);
                    llDriverLicenceType.refreshDrawableState();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        String[] genderList = getResources().getStringArray(R.array.gender_arrays);
        spGender.setAdapter(new SpinnerAdapter(getActivity(), genderList, SpinnerType.GENDER));

        if (selected_years > 0 && selected_days > 0) {
            calendar.set(Calendar.YEAR, selected_years);
            calendar.set(Calendar.MONTH, selected_months);
            calendar.set(Calendar.DAY_OF_MONTH, selected_days);
            lngDOB = calendar.getTimeInMillis();
            tvDob.setText(selected_years + "-" + (selected_months + 1) + "-" + selected_days);
        }

        if (countryList != null && countryList.length > 1) {
            spCountry.setAdapter(new SpinnerAdapter(getActivity(), countryList, SpinnerType.COUNTRY));
            if (profileGeneralInfoModel != null) {
                setCountry(profileGeneralInfoModel.getUserCountry());
            } else {
                setCountry(getResources().getString(R.string.default_country));
            }
            return;
        }
        countryList = new String[]{getString(R.string.hint_country)};
        spCountry.setAdapter(new SpinnerAdapter(getActivity(), countryList, SpinnerType.COUNTRY));
        getPresenter().onCountryList();
    }

    @OnFocusChange({R.id.spGender, R.id.spDriverLicence, R.id.spCountry})
    public void onFocusChanged(View view, boolean focused) {
        if (focused)
            AppUtils.hideKeyboard(getActivity());
    }

    @OnClick({R.id.tvNext, R.id.tvDob})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvNext:
                addPersonalGeneralDetails();
                break;

            case R.id.tvDob:
                showDatePickerDialog();
                break;
        }
    }

    private void addPersonalGeneralDetails() {
        AppUtils.hideKeyboard(getActivity());
        HashMap<String, Object> hmPersonalGeneralDetails = new HashMap<>();
        hmPersonalGeneralDetails.put(ApiParamEnum.FIRST_NAME.getValue(), AppUtils.getText(etFirstName));
        hmPersonalGeneralDetails.put(ApiParamEnum.LAST_NAME.getValue(), AppUtils.getText(etLastName));
        hmPersonalGeneralDetails.put(ApiParamEnum.EMAIL.getValue(), AppUtils.getText(etEmail));
        hmPersonalGeneralDetails.put(ApiParamEnum.GENDER.getValue(), spGender.getSelectedItemPosition());
        if (spDriverLicence.getSelectedItemPosition() == 1) {
            hmPersonalGeneralDetails.put(ApiParamEnum.DRIVER_LICENSE.getValue(), "No");
        } else if (spDriverLicence.getSelectedItemPosition() == 2) {
            String strDrivingTypes = "";
            if (cbMotorBike.isChecked()) {
                if (strDrivingTypes.length() > 0) {
                    strDrivingTypes = strDrivingTypes + ",motorbike";
                } else {
                    strDrivingTypes = "motorbike";
                }
            }
            if (cbHeavyDuty.isChecked()) {
                if (strDrivingTypes.length() > 0) {
                    strDrivingTypes = strDrivingTypes + ",heavy";
                } else {
                    strDrivingTypes = "heavy";
                }
            }
            if (cbLightVehicle.isChecked()) {
                if (strDrivingTypes.length() > 0) {
                    strDrivingTypes = strDrivingTypes + ",light";
                } else {
                    strDrivingTypes = "light";
                }
            }
            if (cbOtherVehicle.isChecked()) {
                if (strDrivingTypes.length() > 0) {
                    strDrivingTypes = strDrivingTypes + ",other";
                } else {
                    strDrivingTypes = "other";
                }
            }
            hmPersonalGeneralDetails.put(ApiParamEnum.DRIVER_LICENSE.getValue(), strDrivingTypes);
        } else {
            hmPersonalGeneralDetails.put(ApiParamEnum.DRIVER_LICENSE.getValue(), "");
        }
        hmPersonalGeneralDetails.put(ApiParamEnum.DOB.getValue(), AppUtils.getText(tvDob));
        hmPersonalGeneralDetails.put(ApiParamEnum.TELEPHONE.getValue(), AppUtils.getText(etTelephone));
        hmPersonalGeneralDetails.put(ApiParamEnum.CELLPHONE.getValue(), AppUtils.getText(etCellphone));
        hmPersonalGeneralDetails.put(ApiParamEnum.SKYPE_ID.getValue(), AppUtils.getText(etSkypeId));
        hmPersonalGeneralDetails.put(ApiParamEnum.ADDRESS_LINE1.getValue(), AppUtils.getText(etAddress1));
        hmPersonalGeneralDetails.put(ApiParamEnum.ADDRESS_LINE2.getValue(), AppUtils.getText(etAddress2));
        hmPersonalGeneralDetails.put(ApiParamEnum.CITY_NAME.getValue(), AppUtils.getText(etCity));
        hmPersonalGeneralDetails.put(ApiParamEnum.COUNTRY_NAME.getValue(), ((etOtherCountry.getVisibility() == View.VISIBLE) ? AppUtils.getText(etOtherCountry) : String.valueOf(spCountry.getSelectedItem())));
        if (profileGeneralInfoModel != null) {
            UserDataModel userDataModel = RMPrefs.getInstance(getActivity()).getUserDataModel();
            String accessToken = RMPrefs.getInstance(getActivity()).getAccessToken();
            if (userDataModel != null) {
                hmPersonalGeneralDetails.put(ApiParamEnum.ACCESS_TOKEN.getValue(), accessToken);
                hmPersonalGeneralDetails.put(ApiParamEnum.USER_ID.getValue(), userDataModel.getUser_id());
                hmPersonalGeneralDetails.put(ApiParamEnum.PERSONAL_ID.getValue(), userDataModel.getUser_personal_id());
            }
        }
        getPresenter().isValidate(hmPersonalGeneralDetails, profileGeneralInfoModel != null, getResources().getString(R.string.hint_country));
    }

    private void showDatePickerDialog() {
        DatePickerDialog mDatePicker = new DatePickerDialog(
                getActivity(), R.style.DatePickerDialogTheme, new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker datepicker,
                                  int selected_year, int selected_month, int selected_day) {
                calendar.set(Calendar.YEAR, selected_year);
                calendar.set(Calendar.MONTH, selected_month);
                calendar.set(Calendar.DAY_OF_MONTH, selected_day);
                lngDOB = calendar.getTimeInMillis();
                selected_years = selected_year;
                selected_months = selected_month;
                selected_days = selected_day;
                tvDob.setText(selected_year + "-" + (selected_month + 1) + "-" + selected_day);
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        mDatePicker.setTitle(getString(R.string.select_date));
        mDatePicker.getDatePicker().setMaxDate(System.currentTimeMillis());
        mDatePicker.show();
    }

    @OnItemSelected(R.id.spCountry)
    void onItemSelected(int position) {
        String selected_language = String.valueOf(spCountry.getAdapter().getItem(position));
        etOtherCountry.setVisibility(selected_language.equalsIgnoreCase("Other") ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onSuccess(HashMap<String, Object> hashMap) {

        if (hashMap != null && hashMap.size() > 0) {
            if (onNextPressedListener != null) {
                onNextPressedListener.onNextPressed(RegisterForm.PERSONAL_EDUCATION, hashMap);
            } else if (onEditProfileListener != null) {
                profileGeneralInfoModel.setUserFirstName(AppUtils.getText(etFirstName));
                profileGeneralInfoModel.setUserLastName(AppUtils.getText(etLastName));
                profileGeneralInfoModel.setUserGender(String.valueOf(spGender.getSelectedItemPosition()));
                profileGeneralInfoModel.setUserDob(AppUtils.getText(tvDob));
                profileGeneralInfoModel.setUserEmail(AppUtils.getText(etEmail));
                profileGeneralInfoModel.setUserMobile(AppUtils.getText(etCellphone));
                profileGeneralInfoModel.setUserTelephone(AppUtils.getText(etTelephone));
                profileGeneralInfoModel.setUserSkypeId(AppUtils.getText(etSkypeId));
                profileGeneralInfoModel.setUserAddressLine1(AppUtils.getText(etAddress1));
                profileGeneralInfoModel.setUserAddressLine2(AppUtils.getText(etAddress2));
                profileGeneralInfoModel.setUserCity(String.valueOf(hashMap.get(ApiParamEnum.CITY_NAME.getValue())));
                profileGeneralInfoModel.setUserCountry(String.valueOf(hashMap.get(ApiParamEnum.COUNTRY_NAME.getValue())));
                onEditProfileListener.onEditProfileSuccess(profileGeneralInfoModel);
            }
        }
    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
    }


    @OnTouch({R.id.spCountry, R.id.spDriverLicence, R.id.spGender, R.id.cbOtherVehicle, R.id.cbHeavyDuty, R.id.cbLightVehicle, R.id.cbMotorBike, R.id.tvDob, R.id.tvNext})
    public boolean onTouch(View view, MotionEvent motionEvent) {
        AppUtils.hideKeyboard(getActivity());
        if (view.getId() == R.id.spCountry) {
            if (spCountry.getAdapter() == null || spCountry.getAdapter().getCount() <= 1) {
                getPresenter().onCountryList();
            }
        }
        return false;
    }

    @Override
    public void onValidationError(ValidationErrorModel validationErrorModel) {
        AppUtils.showToast(getActivity(), validationErrorModel.getMsg());
        switch (validationErrorModel.getError()) {
            case FIRST_NAME:
                AppUtils.requestEdittextFocus(getActivity(), etFirstName);
                break;
            case LAST_NAME:
                AppUtils.requestEdittextFocus(getActivity(), etLastName);
                break;
            case CELLPHONE:
                AppUtils.requestEdittextFocus(getActivity(), etCellphone);
                break;
            case EMAIL:
                AppUtils.requestEdittextFocus(getActivity(), etEmail);
                break;
            case TELEPHONE:
                AppUtils.requestEdittextFocus(getActivity(), etTelephone);
                break;
            case CITY_NAME:
                AppUtils.requestEdittextFocus(getActivity(), etCity);
                break;
        }
    }

    @Override
    public void onCountryList(String[] countryList) {
        this.countryList = countryList;
        spCountry.setAdapter(new SpinnerAdapter(getActivity(), countryList, SpinnerType.COUNTRY));
        if (profileGeneralInfoModel != null) {
            setCountry(profileGeneralInfoModel.getUserCountry());
        } else {
            setCountry(getResources().getString(R.string.default_country));
        }
    }
}
