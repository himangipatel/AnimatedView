package com.recruitmentmatters.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Sameer Jani on 28/3/17.
 */

public class ProfileGeneralInfoModel implements Parcelable {

    @SerializedName("user_first_name")
    String userFirstName = "";

    @SerializedName("user_last_name")
    String userLastName = "";

    @SerializedName("user_email")
    String userEmail = "";

    @SerializedName("user_dob")
    String userDob = "";

    @SerializedName("user_addline1")
    String userAddressLine1 = "";

    @SerializedName("user_addline2")
    String userAddressLine2 = "";

    @SerializedName("user_city")
    String userCity = "";

    @SerializedName("user_country")
    String userCountry = "";

    @SerializedName("user_gender")
    String userGender = "";

    @SerializedName("user_mobile_no")
    String userMobile = "";

    @SerializedName("user_telephone_no")
    String userTelephone = "";

    @SerializedName("user_skype_id")
    String userSkypeId = "";

    @SerializedName("image_url")
    String userImage = "";

    @SerializedName("cv_url")
    String userCv = "";

    public String getUserFirstName() {
        return userFirstName;
    }

    public void setUserFirstName(String userFirstName) {
        this.userFirstName = userFirstName;
    }

    public String getUserLastName() {
        return userLastName;
    }

    public void setUserLastName(String userLastName) {
        this.userLastName = userLastName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserDob() {
        return userDob;
    }

    public void setUserDob(String userDob) {
        this.userDob = userDob;
    }

    public String getUserAddressLine1() {
        return userAddressLine1;
    }

    public void setUserAddressLine1(String userAddressLine1) {
        this.userAddressLine1 = userAddressLine1;
    }

    public String getUserAddressLine2() {
        return userAddressLine2;
    }

    public void setUserAddressLine2(String userAddressLine2) {
        this.userAddressLine2 = userAddressLine2;
    }

    public String getUserCity() {
        return userCity;
    }

    public void setUserCity(String userCity) {
        this.userCity = userCity;
    }

    public String getUserCountry() {
        return userCountry;
    }

    public void setUserCountry(String userCountry) {
        this.userCountry = userCountry;
    }

    public String getUserGender() {
        return userGender;
    }

    public void setUserGender(String userGender) {
        this.userGender = userGender;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserTelephone() {
        return userTelephone;
    }

    public void setUserTelephone(String userTelephone) {
        this.userTelephone = userTelephone;
    }

    public String getUserSkypeId() {
        return userSkypeId;
    }

    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }

    public void setUserSkypeId(String userSkypeId) {
        this.userSkypeId = userSkypeId;
    }

    public String getUserCv() {
        return userCv;
    }

    public void setUserCv(String userCv) {
        this.userCv = userCv;
    }

    public ProfileGeneralInfoModel() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.userFirstName);
        dest.writeString(this.userLastName);
        dest.writeString(this.userEmail);
        dest.writeString(this.userDob);
        dest.writeString(this.userAddressLine1);
        dest.writeString(this.userAddressLine2);
        dest.writeString(this.userCity);
        dest.writeString(this.userCountry);
        dest.writeString(this.userGender);
        dest.writeString(this.userMobile);
        dest.writeString(this.userTelephone);
        dest.writeString(this.userSkypeId);
        dest.writeString(this.userImage);
        dest.writeString(this.userCv);
    }

    protected ProfileGeneralInfoModel(Parcel in) {
        this.userFirstName = in.readString();
        this.userLastName = in.readString();
        this.userEmail = in.readString();
        this.userDob = in.readString();
        this.userAddressLine1 = in.readString();
        this.userAddressLine2 = in.readString();
        this.userCity = in.readString();
        this.userCountry = in.readString();
        this.userGender = in.readString();
        this.userMobile = in.readString();
        this.userTelephone = in.readString();
        this.userSkypeId = in.readString();
        this.userImage = in.readString();
        this.userCv = in.readString();
    }

    public static final Creator<ProfileGeneralInfoModel> CREATOR = new Creator<ProfileGeneralInfoModel>() {
        @Override
        public ProfileGeneralInfoModel createFromParcel(Parcel source) {
            return new ProfileGeneralInfoModel(source);
        }

        @Override
        public ProfileGeneralInfoModel[] newArray(int size) {
            return new ProfileGeneralInfoModel[size];
        }
    };
}
