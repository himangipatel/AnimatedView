package com.recruitmentmatters.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;
import com.recruitmentmatters.constants.ApiParamEnum;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Darshna Desai on 5/4/17.
 */

public class ProfileReferenceModel implements Parcelable {

    public static final Creator<ProfileReferenceModel> CREATOR = new Creator<ProfileReferenceModel>() {
        @Override
        public ProfileReferenceModel createFromParcel(Parcel in) {
            return new ProfileReferenceModel(in);
        }

        @Override
        public ProfileReferenceModel[] newArray(int size) {
            return new ProfileReferenceModel[size];
        }
    };
     @SerializedName(value = "ref_name", alternate = "contact_name")
    String refName;
    @SerializedName(value = "ref_company_name", alternate = "company_name")
    String refCompanyName;
    @SerializedName(value = "ref_position", alternate = "position")
    String refPosition;
    @SerializedName(value = "ref_email", alternate = "email")
    String refEmail;
    @SerializedName(value = "ref_phone_no", alternate = "telephone")
    String refPhone;

    protected ProfileReferenceModel(Parcel in) {
        refName = in.readString();
        refCompanyName = in.readString();
        refPosition = in.readString();
        refEmail = in.readString();
        refPhone = in.readString();
    }

    public ProfileReferenceModel(){}

    public String getRefName() {
        return refName;
    }

    public void setRefName(String refName) {
        this.refName = refName;
    }

    public String getRefCompanyName() {
        return refCompanyName;
    }

    public void setRefCompanyName(String refCompanyName) {
        this.refCompanyName = refCompanyName;
    }

    public String getRefPosition() {
        return refPosition;
    }

    public void setRefPosition(String refPosition) {
        this.refPosition = refPosition;
    }

    public String getRefEmail() {
        return refEmail;
    }

    public void setRefEmail(String refEmail) {
        this.refEmail = refEmail;
    }

    public String getRefPhone() {
        return refPhone;
    }

    public void setRefPhone(String refPhone) {
        this.refPhone = refPhone;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(refName);
        parcel.writeString(refCompanyName);
        parcel.writeString(refPosition);
        parcel.writeString(refEmail);
        parcel.writeString(refPhone);
    }

    public JSONObject toJSONObject() {
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject();
            jsonObject.put(ApiParamEnum.CONTACT_NAME.getValue(), getRefName());
            jsonObject.put(ApiParamEnum.COMPANY_NAME.getValue(), getRefCompanyName());
            jsonObject.put(ApiParamEnum.POSITION.getValue(), getRefPosition());
            jsonObject.put(ApiParamEnum.EMAIL.getValue(), getRefEmail());
            jsonObject.put(ApiParamEnum.TELEPHONE.getValue(), getRefPhone());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }
}
