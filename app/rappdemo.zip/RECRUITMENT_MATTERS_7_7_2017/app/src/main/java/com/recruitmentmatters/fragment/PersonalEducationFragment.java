package com.recruitmentmatters.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.adapter.SpinnerCustomAdapter;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.constants.RegisterForm;
import com.recruitmentmatters.listeners.OnEditProfileListener;
import com.recruitmentmatters.listeners.OnNextPressedListener;
import com.recruitmentmatters.model.CountryModel;
import com.recruitmentmatters.model.CountryResponse;
import com.recruitmentmatters.model.ProfileEducationInfoModel;
import com.recruitmentmatters.model.UserDataModel;
import com.recruitmentmatters.presenter.PersonalEducationPresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.views.PersonalEducationView;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnTouch;

/**
 * Created by Sameer Jani on 28/3/17.
 */

public class PersonalEducationFragment extends MVPFragment<PersonalEducationPresenter, PersonalEducationView<HashMap<String, Object>>> implements PersonalEducationView<HashMap<String, Object>> {

    RelativeLayout rlPersonalTitleBar;
    TextView tvFormTitle;
    ImageView ivFormBack;
    OnNextPressedListener onNextPressedListener = null;

    @BindView(R.id.etHighSchool)
    EditText etHighSchool;
    @BindView(R.id.etUniversity)
    EditText etUniversity;
    @BindView(R.id.spLocation)
    Spinner spLocation;
    @BindView(R.id.etDegree)
    EditText etDegree;
    @BindView(R.id.etQualification)
    EditText etQualification;
    @BindView(R.id.formTitlebar)
    View formTitlebar;
    @BindView(R.id.tvNext)
    TextView tvNext;

    private ProfileEducationInfoModel profileEducationInfoModel;
    private OnEditProfileListener onEditProfileListener;
    private ArrayList<CountryModel> locationList = null;

    public PersonalEducationFragment() {
    }


    @NonNull
    @Override
    public PersonalEducationPresenter createPresenter() {
        return new PersonalEducationPresenter();
    }

    @NonNull
    @Override
    public PersonalEducationView attachView() {
        return this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.partial_reg_education, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        init(view);
    }

    private void init(View view) {
        rlPersonalTitleBar = ButterKnife.findById(view, R.id.rlPersonalTitleBar);
        ivFormBack = ButterKnife.findById(view, R.id.ivFormBack);
        tvFormTitle = ButterKnife.findById(view, R.id.tvFormTitle);
        if (getActivity() instanceof OnNextPressedListener)
            onNextPressedListener = (OnNextPressedListener) getActivity();
        if (getActivity() instanceof OnEditProfileListener)
            onEditProfileListener = (OnEditProfileListener) getActivity();

        initFormTitleBar();
        setLocationSpinner();
        setDataFromPrefs();
        checkForEdit();
    }

    private void initFormTitleBar() {
        ivFormBack.setVisibility(View.VISIBLE);
        tvFormTitle.setText(R.string.title_education);
    }

    private void setDataFromPrefs() {
        profileEducationInfoModel = RMPrefs.getInstance(getActivity()).getEducationDataModel();
        if (profileEducationInfoModel != null) {
            setData();
        }
    }

    private void setLocationSpinner() {
        if (locationList != null && locationList.size() > 1) {
            spLocation.setAdapter(new SpinnerCustomAdapter(getActivity(), locationList));
            if (profileEducationInfoModel != null) {
                setLocation(profileEducationInfoModel.getUniversityLocation());
            } else {
                setLocation(getResources().getString(R.string.default_country));
            }
            return;
        }
        locationList = new ArrayList<>();

        addSpinnerHint();
        spLocation.setAdapter(new SpinnerCustomAdapter(getActivity(), locationList));
        getPresenter().callUniversityLocationApi();
    }

    private void addSpinnerHint() {
        CountryModel model = new CountryModel();
        model.setCountry_id("0");
        model.setCountry_name(getResources().getString(R.string.hint_sp_uni_location));
        locationList.add(0, model);
    }

    private void checkForEdit() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            if (bundle.getParcelable(AppConstants.SEND_DATA_EDIT_PROFILE) != null) {
                profileEducationInfoModel = bundle.getParcelable(AppConstants.SEND_DATA_EDIT_PROFILE);
                formTitlebar.setVisibility(View.GONE);
                tvNext.setText(R.string.update);
                setData();
            }
        }
    }

    private void setData() {
        etHighSchool.setText(profileEducationInfoModel.getHighschool());
        etUniversity.setText(profileEducationInfoModel.getUniversity());
        etDegree.setText(profileEducationInfoModel.getDegree());
        etQualification.setText(profileEducationInfoModel.getQualificationDetail());
        setLocation(profileEducationInfoModel.getUniversityLocation());
    }

    private void setLocation(String location) {
        for (int i = 0; i < spLocation.getAdapter().getCount(); i++) {
            if (location.equalsIgnoreCase(((CountryModel) spLocation.getAdapter().getItem(i)).getCountry_name())) {
                spLocation.setSelection(i);
            }
        }
    }

    @OnClick({R.id.tvNext, R.id.ivFormBack})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvNext:
                addEducationalDetails();
                break;

            case R.id.ivFormBack:
                if (onNextPressedListener != null) {
                    saveDataInPrefs();
                    onNextPressedListener.onPreviousClicked();
                }
                break;
        }
    }

    public void saveDataInPrefs() {
        ProfileEducationInfoModel model = new ProfileEducationInfoModel();
        model.setHighschool(AppUtils.getText(etHighSchool));
        model.setUniversity(AppUtils.getText(etUniversity));
        model.setDegree(AppUtils.getText(etDegree));
        model.setQualificationDetail(AppUtils.getText(etQualification));
        if (spLocation.getSelectedItemPosition() != 0) {
            model.setUniversityLocation(String.valueOf(locationList.get(spLocation.getSelectedItemPosition()).getCountry_name()));
        }
        RMPrefs.getInstance(getActivity()).setEducationDataModel(model);
    }

    private void addEducationalDetails() {
        AppUtils.hideKeyboard(getActivity());
        HashMap<String, Object> hmPersonalEducationalDetails = new HashMap<>();
        hmPersonalEducationalDetails.put(ApiParamEnum.HIGH_SCHOOL.getValue(), AppUtils.getText(etHighSchool));
        hmPersonalEducationalDetails.put(ApiParamEnum.UNIVERSITY.getValue(), AppUtils.getText(etUniversity));
        hmPersonalEducationalDetails.put(ApiParamEnum.DEGREE.getValue(), AppUtils.getText(etDegree));
        hmPersonalEducationalDetails.put(ApiParamEnum.QUALIFICATION.getValue(), AppUtils.getText(etQualification));
        if (spLocation.getSelectedItemPosition() != 0) {
            hmPersonalEducationalDetails.put(ApiParamEnum.UNIVERSITY_LOCATION_ID.getValue(), String.valueOf(locationList.get(spLocation.getSelectedItemPosition()).getCountry_id()));
        }
        if (profileEducationInfoModel != null) {
            UserDataModel userDataModel = RMPrefs.getInstance(getActivity()).getUserDataModel();
            String accessToken = RMPrefs.getInstance(getActivity()).getAccessToken();
            if (userDataModel != null) {
                hmPersonalEducationalDetails.put(ApiParamEnum.ACCESS_TOKEN.getValue(), accessToken);
                hmPersonalEducationalDetails.put(ApiParamEnum.USER_ID.getValue(), userDataModel.getUser_id());
                hmPersonalEducationalDetails.put(ApiParamEnum.PERSONAL_ID.getValue(), userDataModel.getUser_personal_id());
            }
        }
        getPresenter().isValidate(hmPersonalEducationalDetails, onNextPressedListener == null);
    }

    @Override
    public void onSuccess(HashMap<String, Object> personalEducationModel) {
        if (personalEducationModel != null) {
            if (onNextPressedListener != null) {
                onNextPressedListener.onNextPressed(RegisterForm.PERSONAL_LANGUAGE_SPOKEN, personalEducationModel);
            } else if (onEditProfileListener != null) {
                profileEducationInfoModel.setDegree(AppUtils.getText(etDegree));
                profileEducationInfoModel.setHighschool(AppUtils.getText(etHighSchool));
                profileEducationInfoModel.setUniversity(AppUtils.getText(etUniversity));
                profileEducationInfoModel.setQualificationDetail(AppUtils.getText(etQualification));
                if (spLocation.getSelectedItemPosition() == 0) {
                    profileEducationInfoModel.setUniversityLocation("");
                } else {
                    profileEducationInfoModel.setUniversityLocation(String.valueOf(locationList.get(spLocation.getSelectedItemPosition()).getCountry_name()));
                }
                onEditProfileListener.onEditProfileSuccess(profileEducationInfoModel);
            }
        }
    }


    @OnTouch({R.id.tvNext, R.id.spLocation})
    public boolean onTouch(View view, MotionEvent motionEvent) {
        AppUtils.hideKeyboard(getActivity());
        if (view.getId() == R.id.spLocation) {
            if (spLocation.getAdapter() == null || spLocation.getAdapter().getCount() <= 1) {
                getPresenter().callUniversityLocationApi();
            }
        }
        return false;
    }


    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
    }

    @Override
    public void onValidationError(ValidationErrorModel validationErrorModel) {
        AppUtils.showToast(getActivity(), validationErrorModel.getMsg());
        switch (validationErrorModel.getError()) {
            case QUALIFICATION:
                AppUtils.requestEdittextFocus(getActivity(), etQualification);
                break;
        }
    }

    @Override
    public void onLocationList(CountryResponse locationList) {
        this.locationList = locationList.getCountry_data();
        addSpinnerHint();
        spLocation.setAdapter(new SpinnerCustomAdapter(getActivity(), this.locationList));
        if (profileEducationInfoModel != null) {
            setLocation(profileEducationInfoModel.getUniversityLocation());
        } else {
            setLocation(getResources().getString(R.string.default_country));
        }
    }


}
