package com.recruitmentmatters.activities;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseActivity;
import com.recruitmentmatters.fragment.AdvanceSearchFragment;

import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Sameer Jani on 17/4/17.
 */

public class AdvanceSearchActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common);
        ButterKnife.bind(this);
        init();
    }

    private void init() {
        tvToolbarTitle.setText(getResources().getString(R.string.toolbar_advance_search));
        Fragment fragment = new AdvanceSearchFragment();
        replaceFragment(fragment, false, null);
    }

    private void replaceFragment(Fragment fragment, boolean addToBackStack, Bundle bundle) {

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, fragment, fragment.getClass().getSimpleName());
        if (addToBackStack) {
            fragmentTransaction.addToBackStack(fragment.getClass().getSimpleName());
        }
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        fragmentTransaction.commit();
    }

    @OnClick({R.id.ivToolbarLeft})
    public void onClick(View view) {
        finish();
    }
}
