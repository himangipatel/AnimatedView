package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Darshna Desai on 5/4/17.
 */

public class ViewProfileResponse extends Response {

    @SerializedName("data")
    ViewProfileModel viewProfileModel;

    public ViewProfileModel getViewProfileModel() {
        return viewProfileModel;
    }

    public void setViewProfileModel(ViewProfileModel viewProfileModel) {
        this.viewProfileModel = viewProfileModel;
    }
}

