package com.recruitmentmatters.interacter;

import android.util.Log;

import com.google.gson.Gson;
import com.recruitmentmatters.constants.ApiRequestUrlEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.model.CategoryResponse;
import com.recruitmentmatters.model.ContactUsResponse;
import com.recruitmentmatters.model.CountryResponse;
import com.recruitmentmatters.model.JobDetailResponse;
import com.recruitmentmatters.model.JobListResponse;
import com.recruitmentmatters.model.LoginResponse;
import com.recruitmentmatters.model.MyApplicationResponse;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.model.ViewProfileResponse;
import com.recruitmentmatters.utils.AppUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static com.recruitmentmatters.connection.RestClient.getPrimaryService;
import static com.recruitmentmatters.connection.RestClient.getService;

public class AppInteractor {

    public boolean isCancel;

    public AppInteractor() {

    }

    private void sendResponse(InterActorCallback callback, Response response) {
        if (!isCancel) {
            callback.onResponse(response);
        }
    }

    public boolean isCancel() {
        return isCancel;
    }

    public void cancel() {
        isCancel = true;
    }

    private void displayRequestParams(HashMap<String, String> hashMap) {
        Iterator it = hashMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            AppUtils.logD((String) pair.getKey(), (String) pair.getValue());
        }
    }

    //Call Api for Get verification Code
    public Subscription callLoginApi(final HashMap<String, String> params,
                                     final InterActorCallback<LoginResponse> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.USER_LOGIN.getValue(), params)
                .map(new Func1<String, LoginResponse>() {
                    @Override
                    public LoginResponse call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callLoginApi", "" + s);
                        Gson gson = new Gson();
                        LoginResponse response;
                        response = gson.fromJson(s, LoginResponse.class);
                        return response;
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<LoginResponse>(callback, this) {
                    @Override
                    public void onNext(LoginResponse response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callForgotPasswordApi(final HashMap<String, String> params,
                                              final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.USER_FORGOT_PASSWORD.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callForgotPasswordApi", "" + s);
                        Response response = new Gson().fromJson(s, Response.class);
                        return response;
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callGetAllCountriesApi(
            final InterActorCallback<CountryResponse> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.GET_ALL_COUNTRIES.getValue())
                .map(new Func1<String, CountryResponse>() {
                    @Override
                    public CountryResponse call(String s) {
                        AppUtils.logD("callCoutryApi", "" + s);
                        Gson gson = new Gson();
                        CountryResponse response;
                        response = gson.fromJson(s, CountryResponse.class);
                        return response;
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<CountryResponse>(callback, this) {
                    @Override
                    public void onNext(CountryResponse response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callGetAllCategoriesApi(String url, final InterActorCallback<CategoryResponse> callback) {

        return getPrimaryService().apiPost(url)
                .map(new Func1<String, CategoryResponse>() {
                    @Override
                    public CategoryResponse call(String s) {
                        AppUtils.logD("callGetAllCategoriesApi", "" + s);
                        return new Gson().fromJson(s, CategoryResponse.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<CategoryResponse>(callback, this) {
                    @Override
                    public void onNext(CategoryResponse response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callLogoutApi(final HashMap<String, String> params,
                                      final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.USER_LOGOUT.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callLogoutApi", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callRegistrationApi(final HashMap<String, Object> params,
                                            final InterActorCallback<Response> callback) {

        return getPrimaryService().apiObjectPost(ApiRequestUrlEnum.REGISTER.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callRegisterApi", "" + s);
                        Gson gson = new Gson();
                        Response response;
                        response = gson.fromJson(s, Response.class);
                        return response;
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callViewProfileApi(final HashMap<String, String> params,
                                           final InterActorCallback<ViewProfileResponse> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.VIEW_PROFILE.getValue(), params)
                .map(new Func1<String, ViewProfileResponse>() {
                    @Override
                    public ViewProfileResponse call(String s) {
                        Log.e("callViewProfileApi", "" + s);
                        ViewProfileResponse response = new Gson().fromJson(s, ViewProfileResponse.class);
                        return response;
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<ViewProfileResponse>(callback, this) {
                    @Override
                    public void onNext(ViewProfileResponse response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callEditEducationProfile(HashMap<String, Object> params,
                                                 final InterActorCallback<Response> callback) {

        return getPrimaryService().apiObjectPut(ApiRequestUrlEnum.EDIT_EDUCATION_PROFILE.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callEditEdicationProfile ", "" + s);
                        Gson gson = new Gson();
                        Response response;
                        response = gson.fromJson(s, Response.class);
                        return response;
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }


    public Subscription callEditGeneralProfileApi(HashMap<String, Object> params,
                                                  final InterActorCallback<Response> callback) {

        return getPrimaryService().apiObjectPut(ApiRequestUrlEnum.EDIT_GENERAL_PROFILE.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callEditGeberalProfile ", "" + s);
                        Gson gson = new Gson();
                        Response response;
                        response = gson.fromJson(s, Response.class);
                        return response;
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callEditEmploymentProfileApi(HashMap<String, Object> params,
                                                     final InterActorCallback<Response> callback) {

        return getPrimaryService().apiObjectPut(ApiRequestUrlEnum.EDIT_EMPLOYMENT_PROFILE.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callEditEmploymentProfile ", "" + s);
                        Gson gson = new Gson();
                        Response response;
                        response = gson.fromJson(s, Response.class);
                        return response;
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callEditLanguageProfileApi(HashMap<String, Object> params,
                                                   final InterActorCallback<Response> callback) {

        return getPrimaryService().apiObjectPut(ApiRequestUrlEnum.EDIT_LANGUAGE_PROFILE.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callEditLanguageProfile ", "" + s);
                        Gson gson = new Gson();
                        Response response;
                        response = gson.fromJson(s, Response.class);
                        return response;
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callEditJobCategoryApi(HashMap<String, Object> params,
                                               final InterActorCallback<Response> callback) {

        return getPrimaryService().apiObjectPut(ApiRequestUrlEnum.EDIT_JOB_CATEGORY.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callEditJobCategoryApi ", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callEditJobTypeApi(HashMap<String, Object> params,
                                           final InterActorCallback<Response> callback) {

        return getPrimaryService().apiObjectPut(ApiRequestUrlEnum.EDIT_JOB_TYPE.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callEditJobTypeApi ", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callEditReferenceApi(HashMap<String, Object> params,
                                             final InterActorCallback<Response> callback) {

        return getPrimaryService().apiObjectPut(ApiRequestUrlEnum.EDIT_REFERENCE.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callEditReferenceApi ", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callChangePasswordApi(final HashMap<String, Object> params,
                                              final InterActorCallback<Response> callback) {

        return getPrimaryService().apiObjectPut(ApiRequestUrlEnum.USER_CHANGE_PASSWORD.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callChangePasswordApi", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callUploadProfilePicApi(final HashMap<String, RequestBody> params, MultipartBody.Part body,
                                                final InterActorCallback<ViewProfileResponse> callback) {

        return getPrimaryService().apiMultipartPost(ApiRequestUrlEnum.USER_UPLOAD_PROFILE.getValue(), params, body)
                .map(new Func1<String, ViewProfileResponse>() {
                    @Override
                    public ViewProfileResponse call(String s) {
                        AppUtils.logD("callUploadProfilePicApi", "" + s);
                        return new Gson().fromJson(s, ViewProfileResponse.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<ViewProfileResponse>(callback, this) {
                    @Override
                    public void onNext(ViewProfileResponse response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callGetJobsApi(final HashMap<String, String> params,
                                       final InterActorCallback<JobListResponse> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.GET_ALL_JOBS.getValue(), params)
                .map(new Func1<String, JobListResponse>() {
                    @Override
                    public JobListResponse call(String s) {
                        AppUtils.logD("callGetJobsApi", "" + s);
                        return new Gson().fromJson(s, JobListResponse.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<JobListResponse>(callback, this) {
                    @Override
                    public void onNext(JobListResponse response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callJobDetailsApi(final HashMap<String, String> params,
                                          final InterActorCallback<JobDetailResponse> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.GET_JOB_DETAILS.getValue(), params)
                .map(new Func1<String, JobDetailResponse>() {
                    @Override
                    public JobDetailResponse call(String s) {
                        AppUtils.logD("callJobDetailsApi", "" + s);
                        return new Gson().fromJson(s, JobDetailResponse.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<JobDetailResponse>(callback, this) {
                    @Override
                    public void onNext(JobDetailResponse response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callJobApplyApi(final HashMap<String, String> params,
                                        final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.APPLY_JOB.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callJobApplyApi", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callUploadCVApi(final HashMap<String, RequestBody> params, MultipartBody.Part body,
                                        final InterActorCallback<Response> callback) {

        return getPrimaryService().apiMultipartPost(ApiRequestUrlEnum.USER_UPLOAD_CV.getValue(), params, body)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callUploadCVApi", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription downloadCV(final String url, final InterActorCallback<File> callback) {
        callback.onStart();
        return getService(AppConstants.CV_BASE_URL).downloadCV(AppConstants.CV_BASE_URL + url).map(new Func1<ResponseBody, File>() {
            @Override
            public File call(ResponseBody responseBody) {
                  File path = AppUtils.getWorkingDirectory();
                //File path = new File(Environment.getExternalStorageDirectory().toString());
                File file = new File(path, String.valueOf(System.currentTimeMillis()) + url);
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    fileOutputStream.write(responseBody.bytes());
                    fileOutputStream.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return file;
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<File>(callback, this) {

                @Override
                public void onNext(File file) {
                    callback.onResponse(file);
                   // sendResponse(callback, file);
                }
        });

    }

public Subscription callFavouriteJobsApi(final HashMap<String, String> params,
                                             final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.FAVOURITE_JOB.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callFavouriteJobsApi", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callGetFavouriteJobsListApi(final HashMap<String, String> params,
                                                    final InterActorCallback<JobListResponse> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.GET_FAVOURITE_JOB.getValue(), params)
                .map(new Func1<String, JobListResponse>() {
                    @Override
                    public JobListResponse call(String s) {
                        AppUtils.logD("callGetFavouriteJobsListApi", "" + s);
                        return new Gson().fromJson(s, JobListResponse.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<JobListResponse>(callback, this) {
                    @Override
                    public void onNext(JobListResponse response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callGetMyApplicationJobsListApi(final HashMap<String, String> params,
                                                        final InterActorCallback<MyApplicationResponse> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.GET_MY_APPLICATIONS.getValue(), params)
                .map(new Func1<String, MyApplicationResponse>() {
                    @Override
                    public MyApplicationResponse call(String s) {
                        AppUtils.logD("callGetMyApplicationJobsListApi", "" + s);
                        return new Gson().fromJson(s, MyApplicationResponse.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<MyApplicationResponse>(callback, this) {
                    @Override
                    public void onNext(MyApplicationResponse response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callContactUsApi(
            final InterActorCallback<ContactUsResponse> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.CONTACT_US_VIEW.getValue())
                .map(new Func1<String, ContactUsResponse>() {
                    @Override
                    public ContactUsResponse call(String s) {
                        AppUtils.logD("callCoutryApi", "" + s);
                        return new Gson().fromJson(s, ContactUsResponse.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<ContactUsResponse>(callback, this) {
                    @Override
                    public void onNext(ContactUsResponse response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callSendMessageApi(final HashMap<String, String> params,
                                           final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.SEND_MESSAGE.getValue(), params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        AppUtils.logD("callSendMessageApi", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }


    public Subscription callUniversityLocationApi(
            final InterActorCallback<CountryResponse> callback) {

        return getPrimaryService().apiPost(ApiRequestUrlEnum.GET_ALL_UNI_LOCATION.getValue())
                .map(new Func1<String, CountryResponse>() {
                    @Override
                    public CountryResponse call(String s) {
                        AppUtils.logD("callUniversityLocationApi", "" + s);
                        Gson gson = new Gson();
                        CountryResponse response;
                        response = gson.fromJson(s, CountryResponse.class);
                        return response;
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<CountryResponse>(callback, this) {
                    @Override
                    public void onNext(CountryResponse response) {
                        sendResponse(callback, response);
                    }
                });
    }

}

