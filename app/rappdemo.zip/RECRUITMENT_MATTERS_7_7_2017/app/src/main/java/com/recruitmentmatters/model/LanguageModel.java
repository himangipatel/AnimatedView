package com.recruitmentmatters.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Sameer Jani on 28/3/17.
 */

public class LanguageModel implements Parcelable {

    public static final Creator<LanguageModel> CREATOR = new Creator<LanguageModel>() {
        @Override
        public LanguageModel createFromParcel(Parcel in) {
            return new LanguageModel(in);
        }

        @Override
        public LanguageModel[] newArray(int size) {
            return new LanguageModel[size];
        }
    };
    @SerializedName("languages")
    String languageName;
    boolean isSelected;

    protected LanguageModel(Parcel in) {
        languageName = in.readString();
        isSelected = in.readByte() != 0;
    }

    public LanguageModel() {
    }

    public String getLanguageName() {
        return languageName;
    }

    public void setLanguageName(String languageName) {
        this.languageName = languageName;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(languageName);
        parcel.writeByte((byte) (isSelected ? 1 : 0));
    }
}
