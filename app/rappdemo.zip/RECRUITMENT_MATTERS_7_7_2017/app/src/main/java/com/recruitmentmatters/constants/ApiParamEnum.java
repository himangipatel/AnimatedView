package com.recruitmentmatters.constants;

/**
 * Created by Darshna Desai on 27/3/17.
 */

public enum ApiParamEnum {

    /* HEADERS */
    AUTHENTICATION("Authorization"),
    SECURE_STAMP("SecureStamp"),
    CONTENT_TYPE("Content-Type"),

    DEVICE_TYPE("device_type"),
    DEVICE_TOKEN("device_token"),

    USER_ID("user_id"),
    ACCESS_TOKEN("access_token"),
    PERSONAL_ID("personal_id"),

    CANDIDATE_REF_NO("reference_number"),
    PASSWORD("password"),
    EMAIL("email"),
    FIRST_NAME("first_name"),
    LAST_NAME("last_name"),
    GENDER("gender"),
    DRIVER_LICENSE("driver_license"),
    DOB("dob"),
    TELEPHONE("telephone"),
    CELLPHONE("cellphone"),
    SKYPE_ID("skype_id"),
    ADDRESS_LINE1("address_line1"),
    ADDRESS_LINE2("address_line2"),
    CITY_NAME("city_name"),
    COUNTRY_NAME("country_name"),
    HIGH_SCHOOL("high_school"),
    UNIVERSITY("university"),
    UNIVERSITY_LOCATION_ID("university_location_id"),
    DEGREE("degree"),
    QUALIFICATION("qualification"),
    LANGUAGES_SPOKEN("languages_spoken"),
    CATEGORY_NAME("category_name"),
    INDUSTRIES_WORKED("industries_worked"),
    SKILLS("skills"),
    AVAILABILITY("availability"),
    JOB_TYPE("job_type"),
    CURRENT_SALARY("current_salary"),
    EXPECTED_SALARY("expected_salary"),
    NOTICE_PERIOD("notice_period"),
    EMPLOYMENTS("employments"),
    REFERENCES("references"),
    EMPLOYER("employer"),
    POSITION("position"),
    START_DATE("start_date"),
    END_DATE("end_date"),
    START_DATE_DURATION("start_date_duration"),
    END_DATE_DURATION("end_date_duration"),
    KEY_SKILLS("key_skills"),
    CONTACT_NAME("contact_name"),
    COMPANY_NAME("company_name"),
    CURRENT_PASSWORD("current_password"),
    NEW_PASSWORD("new_password"),
    CONFIRM_PASSWORD("confirm_password"),
    PHOTO("photo"),
    JOB_ID("job_id"),
    SEARCH_WORD("search_word"),
    CAT_ID("cat_id"),
    PAGE("page"),
    PER_PAGE("per_page"),
    IS_FAVOURITE("is_fav"),
    NAME("name"),
    HELP_TEXT("help_text"),
    WEBSITE("website"),
    LOCATION_ID("location_id"),
    LOCATION_NAME("location_name"),
    CV("cv"),
    QUESTION("q");


    private String value;

    ApiParamEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
