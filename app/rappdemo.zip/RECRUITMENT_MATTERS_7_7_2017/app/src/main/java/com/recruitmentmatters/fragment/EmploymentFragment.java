package com.recruitmentmatters.fragment;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.recruitmentmatters.R;
import com.recruitmentmatters.adapter.EmploymentAdapter;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.constants.RegisterForm;
import com.recruitmentmatters.customview.CustomDialog;
import com.recruitmentmatters.customview.CustomRecycleview;
import com.recruitmentmatters.listeners.OnEditProfileListener;
import com.recruitmentmatters.listeners.OnNextPressedListener;
import com.recruitmentmatters.model.ProfileEmploymentModel;
import com.recruitmentmatters.model.UserDataModel;
import com.recruitmentmatters.model.ViewProfileModel;
import com.recruitmentmatters.presenter.EmploymentPresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.views.EmploymentView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Sameer Jani on 28/3/17.
 */

public class EmploymentFragment extends MVPFragment<EmploymentPresenter, EmploymentView<HashMap<String, Object>>> implements EmploymentView<HashMap<String, Object>> {

    @BindView(R.id.rvEmploymentDetailsContainer)
    CustomRecycleview rvEmploymentDetailsContainer;
    @BindView(R.id.etEmployer)
    EditText etEmployer;
    @BindView(R.id.etPosition)
    EditText etPosition;
    @BindView(R.id.tvStartDate)
    TextView tvStartDate;
    @BindView(R.id.tvEndDate)
    TextView tvEndDate;
    @BindView(R.id.ivPresentSelection)
    ImageView ivPresentSelection;
    @BindView(R.id.etSkills)
    EditText etSkills;
    @BindView(R.id.tvAddRef)
    TextView tvAddRef;
    @BindView(R.id.tvNext)
    TextView tvNext;
    @BindView(R.id.scrollEmployment)
    ScrollView scrollEmployment;


    @BindView(R.id.llAddEmployment)
    LinearLayout llAddEmployment;


    @BindView(R.id.rlPersonalTitleBar)
    RelativeLayout rlPersonalTitleBar;
    @BindView(R.id.tvFormTitle)
    TextView tvFormTitle;
    @BindView(R.id.ivFormBack)
    ImageView ivFormBack;

    private boolean isPresentSelected = false;
    OnNextPressedListener onNextPressedListener = null;
    ArrayList<JSONObject> employmentList = new ArrayList<>();
    EmploymentAdapter adapter = null;
    int intEventPos = -1;
    Calendar startCalendar = Calendar.getInstance();
    Calendar endCalendar = Calendar.getInstance();
    private boolean isEditable = false;
    private long lngStartDate = 0l;
    private long lngEndDate = 0l;
    private BaseRecyclerAdapter.RecycleOnItemEventListener mRecycleviewEventListener = new BaseRecyclerAdapter.RecycleOnItemEventListener() {
        @Override
        public void onItemClick(View view, int position) {
            AppUtils.hideKeyboard(getActivity());
        }

        @Override
        public void onItemLongPress(View view, int position) {
            AppUtils.hideKeyboard(getActivity());
            switch (view.getId()) {
                case R.id.llEmployerMain:
                    if (!isEditable) {
                        intEventPos = position;
                        askForEditOrDelete(position);
                    }
                    break;
            }
        }
    };
    private ArrayList<ProfileEmploymentModel> profileEmploymentModels = null;
    private OnEditProfileListener onEditProfileListener = null;

    public EmploymentFragment() {
    }

    private void askForEditOrDelete(final int position) {
        final CustomDialog dialog = new CustomDialog(getActivity(),
                getResources().getString(R.string.dialog_title_employer_details)
                , getResources().getString(R.string.dialog_message_employer)
                , getResources().getString(R.string.edit)
                , getResources().getString(R.string.delete)) {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.tvPositive:
                        dismiss();
                        llAddEmployment.setVisibility(View.VISIBLE);
                        setData(position);
                        scrollEmployment.post(new Runnable() {
                            @Override
                            public void run() {
                                scrollEmployment.fullScroll(ScrollView.FOCUS_DOWN);
                            }
                        });
                        break;
                    case R.id.tvNegative:
                        dismiss();
                        tvAddRef.setVisibility(View.VISIBLE);
                        askForDeleteConfirmation(position);
                        break;
                }
            }
        };
        dialog.show();
        dialog.setCancelable(true);
    }

    private void setData(int pos) {
        isEditable = true;
        tvAddRef.setVisibility(View.VISIBLE);
        tvAddRef.setText(R.string.action_edit_employment);
        JSONObject jsonEmployer = employmentList.get(pos);
        etEmployer.setText(jsonEmployer.optString(ApiParamEnum.EMPLOYER.getValue()));
        etPosition.setText(jsonEmployer.optString(ApiParamEnum.POSITION.getValue()));
        tvStartDate.setText(jsonEmployer.optString(ApiParamEnum.START_DATE.getValue()));
        etSkills.setText(jsonEmployer.optString(ApiParamEnum.KEY_SKILLS.getValue()));
        Date startDate = AppUtils.stringToDate(jsonEmployer.optString(ApiParamEnum.START_DATE.getValue()), "d/M/yyyy");
        if (startDate != null)
            startCalendar.setTime(startDate);
        if (jsonEmployer.optString(ApiParamEnum.END_DATE.getValue()).equalsIgnoreCase(getResources().getString(R.string.title_present))) {
            ivPresentSelection.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.tick_selected));
            isPresentSelected = true;
        } else {
            tvEndDate.setText(jsonEmployer.optString(ApiParamEnum.END_DATE.getValue()));
            Date endDate = AppUtils.stringToDate(jsonEmployer.optString(ApiParamEnum.END_DATE.getValue()), "d/M/yyyy");
            if (endDate != null)
                endCalendar.setTime(endDate);
        }

    }

    private void askForDeleteConfirmation(final int pos) {
        final CustomDialog dialog = new CustomDialog(getActivity(),
                getResources().getString(R.string.dialog_title_employer_details)
                , getResources().getString(R.string.dialog_employer_conirm_delete_msg)
                , getResources().getString(R.string.yes)
                , getResources().getString(R.string.no)) {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.tvPositive:
                        dismiss();
                        employmentList.remove(pos);
                        adapter.notifyDataSetChanged();
                        if (adapter.getItemCount() == 0) {
                            tvNext.setEnabled(false);
                            tvNext.setAlpha(0.7f);
                        }
                        llAddEmployment.setVisibility(View.VISIBLE);
                        AppUtils.showToast(getActivity(), getResources().getString(R.string.msg_delete_employment));
                        break;
                    case R.id.tvNegative:
                        dismiss();
                        break;
                }
            }
        };
        dialog.show();
    }

    @NonNull
    @Override
    public EmploymentPresenter createPresenter() {
        return new EmploymentPresenter();
    }

    @NonNull
    @Override
    public EmploymentView attachView() {
        return this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.partial_reg_employment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        rlPersonalTitleBar = ButterKnife.findById(view, R.id.rlPersonalTitleBar);
        ivFormBack = ButterKnife.findById(view, R.id.ivFormBack);
        tvFormTitle = ButterKnife.findById(view, R.id.tvFormTitle);
        rvEmploymentDetailsContainer.setLayoutManager(new LinearLayoutManager(getActivity()));
        if (getActivity() instanceof OnNextPressedListener)
            onNextPressedListener = (OnNextPressedListener) getActivity();
        if (getActivity() instanceof OnEditProfileListener)
            onEditProfileListener = (OnEditProfileListener) getActivity();
        if (onEditProfileListener == null) initFormTitleBar();
        setDataFromPrefs();
        checkForEdit();
    }

    private void setDataFromPrefs() {
        if (RMPrefs.getInstance(getActivity()).getEmploymentModel() != null) {
            profileEmploymentModels = RMPrefs.getInstance(getActivity()).getEmploymentModel().getEmploymentData();
            if (profileEmploymentModels != null) {
                setData();
            }
        }
    }


    private void checkForEdit() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            profileEmploymentModels = bundle.getParcelableArrayList(AppConstants.SEND_DATA_EDIT_PROFILE);
            if (profileEmploymentModels != null) {
                rlPersonalTitleBar.setVisibility(View.GONE);
                tvNext.setText(R.string.update);
                setData();
            }
        }
    }

    private void setData() {
        employmentList = new ArrayList<>();
        for (int i = 0; i < profileEmploymentModels.size(); i++) {
            JSONObject jsonObject = profileEmploymentModels.get(i).toJSONObject();
            employmentList.add(jsonObject);
        }
        if (employmentList.size() >= 4) {
            llAddEmployment.setVisibility(View.GONE);
        }
        adapter = new EmploymentAdapter(getActivity(), employmentList);
        rvEmploymentDetailsContainer.setAdapter(adapter);
        adapter.setRecycleOnItemEventListener(mRecycleviewEventListener);
    }

    private void initFormTitleBar() {
        ivFormBack.setVisibility(View.VISIBLE);
        tvFormTitle.setText(R.string.title_employment_details);
    }

    @OnClick({R.id.tvNext, R.id.tvAddRef, R.id.tvStartDate, R.id.tvEndDate, R.id.ivFormBack, R.id.ivPresentSelection})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvNext:
                askForConfirmation();
                break;

            case R.id.tvAddRef:
                addEmployer();
                break;

            case R.id.tvStartDate:
                showStartDatePickerDialog();
                break;

            case R.id.tvEndDate:
                showEndDatePickerDialog();
                break;

            case R.id.ivPresentSelection:
                tvEndDate.setText("");
                if (isPresentSelected) {
                    ivPresentSelection.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.tick_unselected));
                } else {
                    ivPresentSelection.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.tick_selected));
                }
                isPresentSelected = !isPresentSelected;
                break;

            case R.id.ivFormBack:
                if (onNextPressedListener != null) {
                    saveDataInPrefs();
                    onNextPressedListener.onPreviousClicked();
                }
                break;
        }
    }

    public void saveDataInPrefs() {
        ViewProfileModel model = new ViewProfileModel();
        ArrayList<ProfileEmploymentModel> employmentModels = new ArrayList<>();
        for (int i = 0; i < employmentList.size(); i++) {
            ProfileEmploymentModel employmentModel = new ProfileEmploymentModel();
            try {
                employmentModel.setEmpCompany(String.valueOf(employmentList.get(i).get(ApiParamEnum.EMPLOYER.getValue())));
                employmentModel.setEmpPosition(String.valueOf(employmentList.get(i).get(ApiParamEnum.POSITION.getValue())));
                employmentModel.setEmpStartDate(String.valueOf(employmentList.get(i).get(ApiParamEnum.START_DATE.getValue())));
                employmentModel.setEmpEndDate(String.valueOf(employmentList.get(i).get(ApiParamEnum.END_DATE.getValue())));
                employmentModel.setEmpKeySkills(String.valueOf(employmentList.get(i).get(ApiParamEnum.KEY_SKILLS.getValue())));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            employmentModels.add(employmentModel);
        }
        model.setEmploymentData(employmentModels);
        RMPrefs.getInstance(getActivity()).setEmploymentModel(model);
    }

    private void askForConfirmation() {
        final CustomDialog dialog = new CustomDialog(getActivity(),
                getResources().getString(R.string.dialog_title_employer_details)
                , getResources().getString(R.string.dialog_employer_confirmation)
                , getResources().getString(R.string.action_continue)
                , getResources().getString(R.string.cancel)) {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.tvPositive:
                        addEmployerDetails();
                        dismiss();
                        break;
                    case R.id.tvNegative:
                        dismiss();
                        break;
                }
            }
        };
        dialog.show();
    }

    private void showStartDatePickerDialog() {
        DatePickerDialog mDatePicker = new DatePickerDialog(
                getActivity(), R.style.DatePickerDialogTheme, new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker datepicker,
                                  int selected_year, int selected_month, int selected_day) {
                startCalendar.set(Calendar.YEAR, selected_year);
                startCalendar.set(Calendar.MONTH, selected_month);
                startCalendar.set(Calendar.DAY_OF_MONTH, selected_day);
                lngStartDate = startCalendar.getTimeInMillis();
                tvStartDate.setText(selected_day + "/" + (selected_month + 1) + "/" + selected_year);
            }
        }, startCalendar.get(Calendar.YEAR), startCalendar.get(Calendar.MONTH), startCalendar.get(Calendar.DAY_OF_MONTH));
        mDatePicker.setTitle(getString(R.string.select_start_date));
        mDatePicker.getDatePicker().setMaxDate(System.currentTimeMillis());
        mDatePicker.show();
    }

    private void showEndDatePickerDialog() {
        DatePickerDialog mDatePicker = new DatePickerDialog(
                getActivity(), R.style.DatePickerDialogTheme, new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker datepicker,
                                  int selected_year, int selected_month, int selected_day) {
                endCalendar.set(Calendar.YEAR, selected_year);
                endCalendar.set(Calendar.MONTH, selected_month);
                endCalendar.set(Calendar.DAY_OF_MONTH, selected_day);
                lngEndDate = endCalendar.getTimeInMillis();
                tvEndDate.setText(selected_day + "/" + (selected_month + 1) + "/" + selected_year);
                ivPresentSelection.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.tick_unselected));
                isPresentSelected = false;
            }
        }, endCalendar.get(Calendar.YEAR), endCalendar.get(Calendar.MONTH), endCalendar.get(Calendar.DAY_OF_MONTH));
        mDatePicker.setTitle(getString(R.string.select_end_date));
        mDatePicker.getDatePicker().setMaxDate(System.currentTimeMillis());
        mDatePicker.show();
    }

    private void addEmployerDetails() {
        HashMap<String, Object> hmEmploymentDetails = new HashMap<>();
        if (profileEmploymentModels != null) {
            UserDataModel userDataModel = RMPrefs.getInstance(getActivity()).getUserDataModel();
            String accessToken = RMPrefs.getInstance(getActivity()).getAccessToken();
            if (userDataModel != null) {
                hmEmploymentDetails.put(ApiParamEnum.ACCESS_TOKEN.getValue(), accessToken);
                hmEmploymentDetails.put(ApiParamEnum.USER_ID.getValue(), userDataModel.getUser_id());
                hmEmploymentDetails.put(ApiParamEnum.PERSONAL_ID.getValue(), userDataModel.getUser_personal_id());
            }
        }
        getPresenter().addEmployerDetails(employmentList, profileEmploymentModels != null, hmEmploymentDetails);
    }

    private void addEmployer() {
        AppUtils.hideKeyboard(getActivity());
        HashMap<String, Object> hmEmploymentDetails = new HashMap<>();
        hmEmploymentDetails.put(ApiParamEnum.EMPLOYER.getValue(), AppUtils.getText(etEmployer));
        hmEmploymentDetails.put(ApiParamEnum.POSITION.getValue(), AppUtils.getText(etPosition));
        hmEmploymentDetails.put(ApiParamEnum.START_DATE.getValue(), AppUtils.getText(tvStartDate));
        if (isPresentSelected) {
            hmEmploymentDetails.put(ApiParamEnum.END_DATE.getValue(), getResources().getString(R.string.title_present));
        } else {
            hmEmploymentDetails.put(ApiParamEnum.END_DATE.getValue(), AppUtils.getText(tvEndDate));
        }
        //hmEmploymentDetails.put(ApiParamEnum.END_DATE.getValue(), AppUtils.getText(tvEndDate));
        hmEmploymentDetails.put(ApiParamEnum.KEY_SKILLS.getValue(), AppUtils.getText(etSkills));
        hmEmploymentDetails.put(ApiParamEnum.START_DATE_DURATION.getValue(), lngStartDate);
        hmEmploymentDetails.put(ApiParamEnum.END_DATE_DURATION.getValue(), lngEndDate);
        getPresenter().isValidate(hmEmploymentDetails, isPresentSelected);
    }

    @Override
    public void onValidationError(ValidationErrorModel validationErrorModel) {
        AppUtils.showToast(getActivity(), validationErrorModel.getMsg());
        switch (validationErrorModel.getError()) {
            case EMPLOYER:
                AppUtils.requestEdittextFocus(getActivity(), etEmployer);
                break;
            case POSITION:
                AppUtils.requestEdittextFocus(getActivity(), etPosition);
                break;
            case SKILLS:
                AppUtils.requestEdittextFocus(getActivity(), etSkills);
                break;
        }
    }

    @Override
    public void onSuccess(HashMap<String, Object> response) {
        if (response != null && response.size() > 0) {
            if (onNextPressedListener != null)
                onNextPressedListener.onNextPressed(RegisterForm.REFERENCE, response);
            else if (onEditProfileListener != null) {
                profileEmploymentModels = new ArrayList<>();
                for (int i = 0; i < employmentList.size(); i++) {
                    Gson gson = new Gson();
                    String jsonString = "";
                    try {
                        jsonString = String.valueOf(employmentList.get(i));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (jsonString != null && !jsonString.equalsIgnoreCase("")) {
                        ProfileEmploymentModel profileEmploymentModel = gson.fromJson(jsonString, ProfileEmploymentModel.class);
                        profileEmploymentModels.add(profileEmploymentModel);
                    }
                }
                ViewProfileModel viewProfileModel = new ViewProfileModel();
                viewProfileModel.setEmploymentData(profileEmploymentModels);
                onEditProfileListener.onEditProfileSuccess(viewProfileModel);
            }
        }
    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
    }

    @Override
    public void onEmployerAdded(JSONObject jsonEmploymentDetails) {
        if (isEditable && intEventPos < employmentList.size()) {
            employmentList.set(intEventPos, jsonEmploymentDetails);
        } else {
            employmentList.add(jsonEmploymentDetails);
        }

        if (isEditable) {
            AppUtils.showToast(getActivity(), getResources().getString(R.string.msg_edit_employment));
        } else {
            AppUtils.showToast(getActivity(), getResources().getString(R.string.msg_add_employment));
        }

        tvAddRef.setText(R.string.action_add_employment);
        isEditable = false;
        if (employmentList.size() == 4) {
            tvAddRef.setVisibility(View.INVISIBLE);
            llAddEmployment.setVisibility(View.GONE);
        }
        addEmployerDetail();
        clearForm();
        scrollEmployment.post(new Runnable() {
            @Override
            public void run() {
                scrollEmployment.fullScroll(ScrollView.FOCUS_UP);
            }
        });
    }

    private void addEmployerDetail() {
        if (adapter == null) {
            adapter = new EmploymentAdapter(getActivity(), employmentList);
            rvEmploymentDetailsContainer.setAdapter(adapter);
            adapter.setRecycleOnItemEventListener(mRecycleviewEventListener);
        } else {
            if (rvEmploymentDetailsContainer.getAdapter() == null) {
                rvEmploymentDetailsContainer.setAdapter(adapter);
                adapter.setRecycleOnItemEventListener(mRecycleviewEventListener);
            }
            adapter.notifyDataSetChanged();
        }
        if (rvEmploymentDetailsContainer.getAdapter() != null && rvEmploymentDetailsContainer.getAdapter().getItemCount() > 0) {
            tvNext.setEnabled(true);
            tvNext.setAlpha(1.0f);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        addEmployerDetail();
    }

    private void clearForm() {
        etEmployer.setText("");
        etPosition.setText("");
        tvStartDate.setText("");
        tvEndDate.setText("");
        etSkills.setText("");
        etEmployer.requestFocus();
        etEmployer.setCursorVisible(true);
        isPresentSelected = false;
        ivPresentSelection.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.tick_unselected));
    }
}
