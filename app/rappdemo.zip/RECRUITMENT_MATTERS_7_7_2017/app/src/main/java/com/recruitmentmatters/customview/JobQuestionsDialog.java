package com.recruitmentmatters.customview;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.model.JobQuestions;

import java.util.ArrayList;

/**
 * Created by Darshna Desai on 8/5/17.
 */

public class JobQuestionsDialog extends Dialog implements View.OnClickListener {

    private TextView tvPositive, tvNegative, tvSend, tvQue1, tvQue2, tvQue3;
    private LinearLayout llDynamicQue;
    private ArrayList<JobQuestions> jobQuestions;

    public JobQuestionsDialog(Context context, ArrayList<JobQuestions> jobQuestions) {
        super(context);
        this.jobQuestions = jobQuestions;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setContentView(R.layout.dialog_job_questions);

        tvPositive = (TextView) findViewById(R.id.tvPositive);
        tvNegative = (TextView) findViewById(R.id.tvNegative);

        llDynamicQue = (LinearLayout) findViewById(R.id.llDynamicQue);

        setData();

        tvPositive.setOnClickListener(this);
        tvNegative.setOnClickListener(this);
    }

    private void setData() {
        for (int i = 0; i < jobQuestions.size(); i++) {
            LinearLayout rowTextView = (LinearLayout) getLayoutInflater().inflate(R.layout.partial_dynamic_que, null);
            TextView textView = (TextView) rowTextView.findViewById(R.id.tvQue);
            textView.setText(jobQuestions.get(i).getQue());
            llDynamicQue.addView(rowTextView);
        }
    }


    @Override
    public void onClick(View v) {

    }

    public String getData() {

        String answers = "";
        for (int i = 0; i < jobQuestions.size(); i++) {
            LinearLayout rootView = (LinearLayout) llDynamicQue.getChildAt(i);
            RadioButton radioButton = (RadioButton) rootView.findViewById(R.id.radioYes);
            if (radioButton.isChecked()) {
                answers = answers + "1";
            } else {
                answers = answers + "0";
            }
            if (i != jobQuestions.size()) {
                answers = answers + ",";
            }
        }
        return answers;
    }

}