package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Sameer Jani on 01/04/17.
 */

public class CountryResponse extends Response {
    @SerializedName("country_data")
    ArrayList<CountryModel> country_data;

    public ArrayList<CountryModel> getCountry_data() {
        return country_data;
    }

    public void setCountry_data(ArrayList<CountryModel> country_data) {
        this.country_data = country_data;
    }
}
