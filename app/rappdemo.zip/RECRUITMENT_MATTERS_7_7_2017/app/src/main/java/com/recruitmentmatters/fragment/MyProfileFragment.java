package com.recruitmentmatters.fragment;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.nbsp.materialfilepicker.MaterialFilePicker;
import com.nbsp.materialfilepicker.ui.FilePickerActivity;
import com.recruitmentmatters.R;
import com.recruitmentmatters.activities.ChangePasswordActivity;
import com.recruitmentmatters.activities.EditProfileActivity;
import com.recruitmentmatters.adapter.ProfileEmploymentAdapter;
import com.recruitmentmatters.adapter.ProfileReferenceAdapter;
import com.recruitmentmatters.baseclasses.LifeCycleCallBackManager;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.customview.CircleImageView;
import com.recruitmentmatters.customview.DialogChooseView;
import com.recruitmentmatters.model.LanguageModel;
import com.recruitmentmatters.model.ProfileEducationInfoModel;
import com.recruitmentmatters.model.ProfileEmploymentModel;
import com.recruitmentmatters.model.ProfileGeneralInfoModel;
import com.recruitmentmatters.model.ProfileJobCategoryModel;
import com.recruitmentmatters.model.ProfileJobTypeModel;
import com.recruitmentmatters.model.ProfileReferenceModel;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.model.UserDataModel;
import com.recruitmentmatters.model.ViewProfileResponse;
import com.recruitmentmatters.presenter.MyProfilePresenter;
import com.recruitmentmatters.tagview.Tag;
import com.recruitmentmatters.tagview.TagView;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.FilePickUtils;
import com.recruitmentmatters.utils.RMPrefs;
import com.recruitmentmatters.views.MyProfileView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;


/**
 * Created by Darshna Desai on 28/3/17.
 */

public class MyProfileFragment extends MVPFragment<MyProfilePresenter, MyProfileView<ViewProfileResponse>> implements MyProfileView<ViewProfileResponse> {


    @BindView(R.id.tvUserName)
    TextView tvUserName;
    @BindView(R.id.tvCandidateNo)
    TextView tvCandidateNo;
    @BindView(R.id.ivUserProfile)
    CircleImageView ivUserProfile;
    @BindView(R.id.progressProfilePic)
    ProgressBar progressProfilePic;
    @BindView(R.id.tvCVName)
    TextView tvCVName;
    @BindView(R.id.ivClearCv)
    ImageView ivClearCv;
    @BindView(R.id.tvUploadCv)
    TextView tvUploadCv;

    @BindView(R.id.tvEmailValue)
    TextView tvEmailValue;
    @BindView(R.id.tvDOBValue)
    TextView tvDOBValue;
    @BindView(R.id.tvAddressValue)
    TextView tvAddressValue;
    @BindView(R.id.tvGenderValue)
    TextView tvGenderValue;
    @BindView(R.id.tvMobileNumberValue)
    TextView tvMobileNumberValue;
    @BindView(R.id.tvTelephoneValue)
    TextView tvTelephoneValue;
    @BindView(R.id.tvSkypeIdValue)
    TextView tvSkypeIdValue;

    @BindView(R.id.tvHighSchoolValue)
    TextView tvHighSchoolValue;
    @BindView(R.id.tvUniversityValue)
    TextView tvUniversityValue;
    @BindView(R.id.tvUniLocationValue)
    TextView tvUniLocationValue;
    @BindView(R.id.tvDegreeValue)
    TextView tvDegreeValue;

    @BindView(R.id.tvMainCategoryValue)
    TextView tvMainCategoryValue;
    @BindView(R.id.tvIndustriesWorkedValue)
    TextView tvIndustriesWorkedValue;
    @BindView(R.id.tvSkillsValue)
    TextView tvSkillsValue;
    @BindView(R.id.tvAvailabilityValue)
    TextView tvAvailabilityValue;

    @BindView(R.id.tvJobTypeValue)
    TextView tvJobTypeValue;
    @BindView(R.id.tvCurrentSalaryValue)
    TextView tvCurrentSalaryValue;
    @BindView(R.id.tvExpectedSalaryValue)
    TextView tvExpectedSalaryValue;
    @BindView(R.id.tvNoticePeriodValue)
    TextView tvNoticePeriodValue;

    @BindView(R.id.gridLanguages)
    TagView gridLanguages;

    @BindView(R.id.listEmployments)
    RecyclerView listEmployments;

    @BindView(R.id.listReferences)
    RecyclerView listReferences;

    private ProfileGeneralInfoModel profileGeneralInfoModel = null;
    private ProfileEducationInfoModel profileEducationInfoModel = null;
    private ArrayList<ProfileEmploymentModel> profileEmploymentModels = null;
    private LanguageModel languageModel;
    private ProfileJobCategoryModel profileJobCategoryModel = null;
    private ProfileJobTypeModel profileJobTypeModel = null;
    private ArrayList<ProfileReferenceModel> profileReferenceModels = null;

    private LifeCycleCallBackManager lifeCycleCallBackManager;

    private FilePickUtils.OnFileChoose mOnFileChoose = new FilePickUtils.OnFileChoose() {
        @Override
        public void onFileChoose(String fileUri, int requestCode) {
            Glide.with(getActivity()).load(fileUri).asBitmap().centerCrop().placeholder(R.drawable.profile_icon)
                    .into(ivUserProfile);
            File file = new File(fileUri);
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            MultipartBody.Part body = MultipartBody.Part.createFormData(ApiParamEnum.PHOTO.getValue(), file.getName(), reqFile);
            callUploadProfilePicApi(body);
        }
    };

    private void callUploadProfilePicApi(MultipartBody.Part body) {
        HashMap<String, RequestBody> params = new HashMap<>();
        params.put(ApiParamEnum.USER_ID.getValue(), AppUtils.getRequestBody(RMPrefs.getInstance(getActivity()).getUserDataModel().getUser_id()));
        params.put(ApiParamEnum.ACCESS_TOKEN.getValue(), AppUtils.getRequestBody(RMPrefs.getInstance(getActivity()).getAccessToken()));
        getPresenter().callUploadProfilePicApi(params, body);
    }

    @NonNull
    @Override
    public MyProfilePresenter createPresenter() {
        return new MyProfilePresenter();
    }

    @NonNull
    @Override
    public MyProfileView attachView() {
        return this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_profile, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        init(view);
    }

    private void init(View view) {
        ButterKnife.bind(this, view);
        RMPrefs.getInstance(getActivity()).clearRegData();
        setUserData();
    }

    private void setUserData() {
        UserDataModel user = RMPrefs.getInstance(getActivity()).getUserDataModel();
        if (user != null) {
            tvUserName.setText(user.getUser_first_name().concat(" ").concat(user.getUser_last_name()));
            tvCandidateNo.setText("#".concat(user.getUser_candidate_ref_number()));
            Glide.with(getActivity()).load(AppConstants.IMAGE_BASE_URL + user.getUser_id() + "/" + user.getImage_url()).asBitmap().centerCrop().placeholder(R.drawable.profile_icon).into(ivUserProfile);
            if (!user.getCv_url().equalsIgnoreCase("")) {
                tvCVName.setVisibility(View.VISIBLE);
                tvCVName.setText(user.getCv_url());
                ivClearCv.setVisibility(View.VISIBLE);
                tvUploadCv.setText(getResources().getString(R.string.title_view_cv));
            }
            callViewProfileApi(user);
        }
    }

    private void callViewProfileApi(UserDataModel user) {
        HashMap<String, String> params = new HashMap<>();
        params.put(ApiParamEnum.CANDIDATE_REF_NO.getValue(), user.getUser_candidate_ref_number());
        params.put(ApiParamEnum.USER_ID.getValue(), user.getUser_id());
        params.put(ApiParamEnum.ACCESS_TOKEN.getValue(), RMPrefs.getInstance(getActivity()).getAccessToken());
        getPresenter().callViewProfileApi(params);
    }

    @OnClick({R.id.tvGeneral, R.id.tvEducation, R.id.tvEmployments, R.id.tvLanguages, R.id.tvJobCategories
            , R.id.tvJobTypes, R.id.tvReferences, R.id.tvChangePassword, R.id.ivUserProfile, R.id.tvUploadCv
            , R.id.ivClearCv})
    public void onClick(View view) {
        Intent editProfileIntent = null;
        switch (view.getId()) {
            case R.id.tvGeneral:
                editProfileIntent = new Intent(getContext(), EditProfileActivity.class);
                editProfileIntent.putExtra(AppConstants.SEND_DATA_EDIT_PROFILE, profileGeneralInfoModel);
                editProfileIntent.putExtra(AppConstants.SEND_REQUEST_ID_EDIT_PROFILE, AppConstants.GENERAL_FORM);
                startActivityForResult(editProfileIntent, AppConstants.GENERAL_FORM);
                break;
            case R.id.tvEducation:
                editProfileIntent = new Intent(getContext(), EditProfileActivity.class);
                editProfileIntent.putExtra(AppConstants.SEND_DATA_EDIT_PROFILE, profileEducationInfoModel);
                editProfileIntent.putExtra(AppConstants.SEND_REQUEST_ID_EDIT_PROFILE, AppConstants.EDUCATION_FORM);
                startActivityForResult(editProfileIntent, AppConstants.EDUCATION_FORM);
                break;
            case R.id.tvEmployments:
                editProfileIntent = new Intent(getContext(), EditProfileActivity.class);
                editProfileIntent.putParcelableArrayListExtra(AppConstants.SEND_DATA_EDIT_PROFILE, profileEmploymentModels);
                editProfileIntent.putExtra(AppConstants.SEND_REQUEST_ID_EDIT_PROFILE, AppConstants.EMPLOYMENT_FORM);
                startActivityForResult(editProfileIntent, AppConstants.EMPLOYMENT_FORM);
                break;
            case R.id.tvLanguages:
                editProfileIntent = new Intent(getContext(), EditProfileActivity.class);
                editProfileIntent.putExtra(AppConstants.SEND_DATA_EDIT_PROFILE, languageModel);
                editProfileIntent.putExtra(AppConstants.SEND_REQUEST_ID_EDIT_PROFILE, AppConstants.LANGUAGE_FORM);
                startActivityForResult(editProfileIntent, AppConstants.LANGUAGE_FORM);
                break;
            case R.id.tvJobCategories:
                editProfileIntent = new Intent(getContext(), EditProfileActivity.class);
                editProfileIntent.putExtra(AppConstants.SEND_DATA_EDIT_PROFILE, profileJobCategoryModel);
                editProfileIntent.putExtra(AppConstants.SEND_REQUEST_ID_EDIT_PROFILE, AppConstants.JOB_CATEGORY_FORM);
                startActivityForResult(editProfileIntent, AppConstants.JOB_CATEGORY_FORM);
                break;
            case R.id.tvJobTypes:
                editProfileIntent = new Intent(getContext(), EditProfileActivity.class);
                editProfileIntent.putExtra(AppConstants.SEND_DATA_EDIT_PROFILE, profileJobTypeModel);
                editProfileIntent.putExtra(AppConstants.SEND_REQUEST_ID_EDIT_PROFILE, AppConstants.JOB_TYPE_FORM);
                startActivityForResult(editProfileIntent, AppConstants.JOB_TYPE_FORM);
                break;
            case R.id.tvReferences:
                editProfileIntent = new Intent(getContext(), EditProfileActivity.class);
                editProfileIntent.putExtra(AppConstants.SEND_DATA_EDIT_PROFILE, profileReferenceModels);
                editProfileIntent.putExtra(AppConstants.SEND_REQUEST_ID_EDIT_PROFILE, AppConstants.REFERENCES_FORM);
                startActivityForResult(editProfileIntent, AppConstants.REFERENCES_FORM);
                break;
            case R.id.tvChangePassword:
                editProfileIntent = new Intent(getContext(), ChangePasswordActivity.class);
                startActivity(editProfileIntent);
                break;
            case R.id.ivUserProfile:
                List<String> items = new ArrayList<>();
                items.add(getString(R.string.add_photo_from_lib));
                items.add(getString(R.string.take_picture));
                final DialogChooseView dialog = new DialogChooseView(getActivity(), items
                        , new DialogChooseView.OnDialogItemChoose() {
                    @Override
                    public void onItemChoose(Dialog dialog, int position) {
                        dialog.dismiss();
                        FilePickUtils mFilePickUtils = new FilePickUtils(MyProfileFragment.this, mOnFileChoose);
                        lifeCycleCallBackManager = mFilePickUtils.getCallBackManager();
                        switch (position) {
                            case 0:
                                mFilePickUtils.requestImageGallery(1, true);
                                break;
                            case 1:
                                mFilePickUtils.requestImageCamera(2, true);
                                break;
                        }
                    }
                });
                dialog.visible_option_menu();
                break;
            case R.id.tvUploadCv:
                if (tvCVName.getVisibility() == View.VISIBLE) {
                    checkFileWritePermission();
                } else {
                    checkFileReadPermission();
                }
                break;
            case R.id.ivClearCv:
                tvCVName.setText("");
                tvCVName.setVisibility(View.GONE);
                ivClearCv.setVisibility(View.GONE);
                tvUploadCv.setText(getResources().getString(R.string.title_add_cv));
                break;

        }
    }

    private void checkFileReadPermission() {
        int permissionCheck = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, AppConstants.PERMISSION_READ_STORAGE);
        } else {
            // Your app already has the permission to access files and folders
            // so you can simply open FileChooser here.
            selectFile();
        }
    }

    private void checkFileWritePermission() {
        int permissionCheck = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, AppConstants.PERMISSION_WRITE_STORAGE);
        } else {
            // Your app already has the permission to write files and folders
            getPresenter().downloadCV(RMPrefs.getInstance(getActivity()).getUserDataModel().getCv_url());
        }
    }

    private void selectFile() {
        new MaterialFilePicker()
                .withSupportFragment(this)
                .withRequestCode(AppConstants.SELECT_FILE)
                //.withFilter(Pattern.compile(".*\\.txt$")) // Filtering files and directories by file name using regexp
                .withFilterDirectories(true) // Set directories filterable (false by default)
                .withHiddenFiles(true) // Show hidden files and folders
                .start();
    }

    @Override
    public void onSuccess(ViewProfileResponse response) {
        setViewData(response);
    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(getActivity(), message);
        tvUploadCv.setEnabled(true);
    }

    @Override
    public void onProfilePicUploaded(Response response) {
        AppUtils.showToast(getActivity(), response.getMessage());
        UserDataModel userDataModel = RMPrefs.getInstance(getActivity()).getUserDataModel();
        if (userDataModel != null) {
            userDataModel.setImage_url(response.getImage_url());
            RMPrefs.getInstance(getActivity()).setUserDataModel(userDataModel);
        }
    }

    @Override
    public void onCVUploaded(Response response) {
        AppUtils.showToast(getActivity(), response.getMessage());
        tvCVName.setVisibility(View.VISIBLE);
        tvCVName.setText(response.getCv_url());
        ivClearCv.setVisibility(View.VISIBLE);
        tvUploadCv.setEnabled(true);
        tvUploadCv.setText(getResources().getString(R.string.title_view_cv));
        UserDataModel userDataModel = RMPrefs.getInstance(getActivity()).getUserDataModel();
        if (userDataModel != null) {
            userDataModel.setCv_url(response.getCv_url());
            RMPrefs.getInstance(getActivity()).setUserDataModel(userDataModel);
        }
    }

    @Override
    public void onCVDownloaded(File file) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(file), AppUtils.getMimeType(file.getAbsolutePath()));
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
    }

    @Override
    public void onCVDownloadFailure(int message) {
        AppUtils.showToast(getActivity(), message);
        tvUploadCv.setEnabled(true);
    }

    @Override
    public void showPicProgress(boolean show) {
        if (show) {
            progressProfilePic.setVisibility(View.VISIBLE);
            ivUserProfile.setEnabled(false);
        } else {
            progressProfilePic.setVisibility(View.GONE);
            ivUserProfile.setEnabled(true);
        }
    }

    private void setViewData(ViewProfileResponse response) {
        setGeneralData(response.getViewProfileModel().getGeneralInfoModel());
        setEducationData(response.getViewProfileModel().getEducationInfoModel());
        setLanguageData(response.getViewProfileModel().getLanguageModel());
        setJobCategoryData(response.getViewProfileModel().getJobCategoryModel());
        setJobTypeData(response.getViewProfileModel().getJobTypeModel());
        setEmploymentData(response.getViewProfileModel().getEmploymentData());
        setReferenceData(response.getViewProfileModel().getReferenceData());
    }

    private void setEmploymentData(ArrayList<ProfileEmploymentModel> employmentData) {
        profileEmploymentModels = employmentData;
        listEmployments.setLayoutManager(new LinearLayoutManager(getActivity()));
        ProfileEmploymentAdapter employmentAdapter = new ProfileEmploymentAdapter(getActivity(), employmentData);
        listEmployments.setAdapter(employmentAdapter);
    }

    private void setReferenceData(ArrayList<ProfileReferenceModel> referenceData) {
        profileReferenceModels = referenceData;
        listReferences.setLayoutManager(new LinearLayoutManager(getActivity()));
        ProfileReferenceAdapter referenceAdapter = new ProfileReferenceAdapter(getActivity(), referenceData);
        listReferences.setAdapter(referenceAdapter);
    }

    private void setEducationData(ProfileEducationInfoModel response) {
        profileEducationInfoModel = response;
        tvHighSchoolValue.setText(response.getHighschool());
        tvUniversityValue.setText(response.getUniversity());
        tvUniLocationValue.setText(response.getUniversityLocation());
        tvDegreeValue.setText(response.getDegree());
    }

    private void setGeneralData(ProfileGeneralInfoModel response) {
        profileGeneralInfoModel = response;
        tvEmailValue.setText(response.getUserEmail());
        tvDOBValue.setText(response.getUserDob());
        String address = " ";
        if (!response.getUserAddressLine1().equalsIgnoreCase("")) {
            address = response.getUserAddressLine1().concat(", ");
        }
        if (!response.getUserAddressLine2().equalsIgnoreCase("")) {
            address = address + (response.getUserAddressLine2()).concat(", ");
        }
        address = address + (response.getUserCity()).concat(", ");
        address = address + (response.getUserCountry());

        tvAddressValue.setText(address);
        if (response.getUserGender().equalsIgnoreCase("1")) {
            tvGenderValue.setText(getResources().getString(R.string.title_male));
        } else if (response.getUserGender().equalsIgnoreCase("2")) {
            tvGenderValue.setText(getResources().getString(R.string.title_female));
        }
        tvMobileNumberValue.setText(response.getUserMobile());
        tvTelephoneValue.setText(response.getUserTelephone());
        tvSkypeIdValue.setText(response.getUserSkypeId());
        UserDataModel user = RMPrefs.getInstance(getActivity()).getUserDataModel();
        if (user != null) {
            Glide.with(getActivity()).load(AppConstants.IMAGE_BASE_URL + user.getUser_id() + "/" + response.getUserImage())
                    .asBitmap().centerCrop().placeholder(R.drawable.profile_icon).into(ivUserProfile);
        }

    }

    private void setLanguageData(LanguageModel languageModel) {
        this.languageModel = languageModel;
        String[] numbers = languageModel.getLanguageName().split("/");
        gridLanguages.removeAllTags();
        for (int i =0; i<numbers.length; i++){
            Tag tag = new Tag(numbers[i]);
            tag.background = ContextCompat.getDrawable(getActivity(), R.drawable.tag_shape);
            tag.isDeletable = false;
            tag.setTagTextColor(R.color.themeGray);
            gridLanguages.addTag(tag);
        }

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                gridLanguages.getLayoutParams().height = LinearLayout.LayoutParams.WRAP_CONTENT;
                gridLanguages.requestLayout();
            }
        }, 100);
    }

    /*private void setLanguageData(LanguageModel languageModel) {
        this.languageModel = languageModel;
        gridLanguages.getLayoutParams().width = AppUtils.getScreenWidth(getActivity());
        int padding = (int) getResources().getDimension(R.dimen._10sdp);
        //  gridLanguages.setPadding(padding / 2, padding, padding * 2, padding);
        String[] numbers = languageModel.getLanguageName().split("/");
        gridLanguages.setTags(numbers);
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(AppUtils.getScreenWidth(getActivity()), LinearLayout.LayoutParams.WRAP_CONTENT);
                gridLanguages.setLayoutParams(lp);            }
        }, 100);
       *//* LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(AppUtils.getScreenWidth(getActivity()), LinearLayout.LayoutParams.WRAP_CONTENT);
        gridLanguages.setLayoutParams(lp);*//*
    }*/

    private void setJobCategoryData(ProfileJobCategoryModel response) {
        profileJobCategoryModel = response;
        tvMainCategoryValue.setText(response.getJobCategory());
        tvIndustriesWorkedValue.setText(response.getJobIndustries());
        tvSkillsValue.setText(response.getJobSkills());
        tvAvailabilityValue.setText(response.getJobAvailability());
    }

    private void setJobTypeData(ProfileJobTypeModel response) {
        profileJobTypeModel = response;
        tvJobTypeValue.setText(response.getJobType());
        tvCurrentSalaryValue.setText(response.getCurrentSalary());
        tvExpectedSalaryValue.setText(response.getExpectedSalary());
        tvNoticePeriodValue.setText(response.getNoticePeriod());
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AppConstants.GENERAL_FORM && resultCode == Activity.RESULT_OK) {
            if (data != null && data.hasExtra(AppConstants.SEND_DATA_EDIT_PROFILE)) {
                profileGeneralInfoModel = data.getParcelableExtra(AppConstants.SEND_DATA_EDIT_PROFILE);
                setGeneralData(profileGeneralInfoModel);
                UserDataModel user = RMPrefs.getInstance(getActivity()).getUserDataModel();
                user.setUser_first_name(profileGeneralInfoModel.getUserFirstName());
                user.setUser_last_name(profileGeneralInfoModel.getUserLastName());
                RMPrefs.getInstance(getActivity()).setUserDataModel(user);
                tvUserName.setText(user.getUser_first_name().concat(" ").concat(user.getUser_last_name()));
            }
        } else if (requestCode == AppConstants.EDUCATION_FORM && resultCode == Activity.RESULT_OK) {
            if (data != null && data.hasExtra(AppConstants.SEND_DATA_EDIT_PROFILE)) {
                profileEducationInfoModel = data.getParcelableExtra(AppConstants.SEND_DATA_EDIT_PROFILE);
                setEducationData(profileEducationInfoModel);
            }
        } else if (requestCode == AppConstants.EMPLOYMENT_FORM && resultCode == Activity.RESULT_OK) {
            if (data != null && data.hasExtra(AppConstants.SEND_DATA_EDIT_PROFILE)) {
                profileEmploymentModels = data.getParcelableArrayListExtra(AppConstants.SEND_DATA_EDIT_PROFILE);
                if (profileEmploymentModels != null && profileEmploymentModels.size() > 0)
                    setEmploymentData(profileEmploymentModels);
            }
        } else if (requestCode == AppConstants.LANGUAGE_FORM && resultCode == Activity.RESULT_OK) {
            if (data != null && data.hasExtra(AppConstants.SEND_DATA_EDIT_PROFILE)) {
                languageModel = data.getParcelableExtra(AppConstants.SEND_DATA_EDIT_PROFILE);
                setLanguageData(languageModel);
            }
        } else if (requestCode == AppConstants.JOB_CATEGORY_FORM && resultCode == Activity.RESULT_OK) {
            if (data != null && data.hasExtra(AppConstants.SEND_DATA_EDIT_PROFILE)) {
                profileJobCategoryModel = data.getParcelableExtra(AppConstants.SEND_DATA_EDIT_PROFILE);
                setJobCategoryData(profileJobCategoryModel);
            }
        } else if (requestCode == AppConstants.JOB_TYPE_FORM && resultCode == Activity.RESULT_OK) {
            if (data != null && data.hasExtra(AppConstants.SEND_DATA_EDIT_PROFILE)) {
                profileJobTypeModel = data.getParcelableExtra(AppConstants.SEND_DATA_EDIT_PROFILE);
                setJobTypeData(profileJobTypeModel);
            }
        } else if (requestCode == AppConstants.REFERENCES_FORM && resultCode == Activity.RESULT_OK) {
            if (data != null && data.hasExtra(AppConstants.SEND_DATA_EDIT_PROFILE)) {
                profileReferenceModels = data.getParcelableArrayListExtra(AppConstants.SEND_DATA_EDIT_PROFILE);
                setReferenceData(profileReferenceModels);
            }
        } else if (requestCode == AppConstants.SELECT_FILE && resultCode == Activity.RESULT_OK) {
            String path = data.getStringExtra(FilePickerActivity.RESULT_FILE_PATH);
            if (path != null) {
                File file = new File(path);
                if (AppUtils.getMimeType(file.getAbsolutePath()) != null) {
                    RequestBody reqFile = RequestBody.create(MediaType.parse(AppUtils.getMimeType(file.getAbsolutePath())), file);
                    MultipartBody.Part body = MultipartBody.Part.createFormData(ApiParamEnum.CV.getValue(), file.getName(), reqFile);
                    callUploadCVApi(body);
                } else {
                    AppUtils.showToast(getActivity(), getResources().getString(R.string.invalid_file_type));
                }
            }
        }
        if (lifeCycleCallBackManager != null) {
            lifeCycleCallBackManager.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void callUploadCVApi(MultipartBody.Part body) {
        tvUploadCv.setEnabled(false);
        HashMap<String, RequestBody> params = new HashMap<>();
        UserDataModel user = RMPrefs.getInstance(getActivity()).getUserDataModel();
        if (user != null) {
            params.put(ApiParamEnum.USER_ID.getValue(), AppUtils.getRequestBody(user.getUser_id()));
            params.put(ApiParamEnum.PERSONAL_ID.getValue(), AppUtils.getRequestBody(user.getUser_personal_id()));
            params.put(ApiParamEnum.ACCESS_TOKEN.getValue(), AppUtils.getRequestBody(RMPrefs.getInstance(getActivity()).getAccessToken()));
            getPresenter().callUploadCVApi(params, body);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AppConstants.PERMISSION_READ_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted.
                selectFile();
            }
        } else if (requestCode == AppConstants.PERMISSION_WRITE_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted.
                getPresenter().downloadCV(RMPrefs.getInstance(getActivity()).getUserDataModel().getCv_url());
            }
        }
        if (lifeCycleCallBackManager != null) {
            lifeCycleCallBackManager.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (lifeCycleCallBackManager != null) {
            lifeCycleCallBackManager.onDestroy();
        }
    }

}