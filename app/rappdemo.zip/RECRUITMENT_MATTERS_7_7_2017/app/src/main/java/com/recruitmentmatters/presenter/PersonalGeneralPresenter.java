package com.recruitmentmatters.presenter;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.CountryModel;
import com.recruitmentmatters.model.CountryResponse;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.validator.ValidationErrorModel;
import com.recruitmentmatters.validator.Validator;
import com.recruitmentmatters.views.PersonalGeneralView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Sameer Jani on 29/3/17.
 */

public class PersonalGeneralPresenter extends BasePresenter<PersonalGeneralView<HashMap<String, Object>>> {

    public void isValidate(HashMap<String, Object> params, boolean isEdit, String countryHint) {
        ValidationErrorModel validationErrorModel = null;
        if ((validationErrorModel = (Validator.validateFirstName(String.valueOf(params.get(ApiParamEnum.FIRST_NAME.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateLastName(String.valueOf(params.get(ApiParamEnum.LAST_NAME.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateGender(Integer.parseInt(String.valueOf(params.get(ApiParamEnum.GENDER.getValue())))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateDrivingLicence(String.valueOf(params.get(ApiParamEnum.DRIVER_LICENSE.getValue()))))) != null && !isEdit) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateDateOfBirth(String.valueOf(params.get(ApiParamEnum.DOB.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateEmail(String.valueOf(params.get(ApiParamEnum.EMAIL.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateTelephone(String.valueOf(params.get(ApiParamEnum.TELEPHONE.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateCellphone(String.valueOf(params.get(ApiParamEnum.CELLPHONE.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateCityName(String.valueOf(params.get(ApiParamEnum.CITY_NAME.getValue()))))) != null) {
            getView().onValidationError(validationErrorModel);
        } else if ((validationErrorModel = (Validator.validateCountryName(String.valueOf(params.get(ApiParamEnum.COUNTRY_NAME.getValue())),countryHint))) != null) {
            getView().onValidationError(validationErrorModel);
        } else {
            if (isEdit) {
                callEditGeneralProfile(params);
            } else {
                getView().onSuccess(params);
            }
        }
    }

    private void callEditGeneralProfile(final HashMap<String, Object> params) {
        if (hasInternet()) {//If no internet it will show toast automatically.

            addSubscription(getAppInteractor().callEditGeneralProfileApi(params, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onSuccess(params);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }

    public void onCountryList() {
        if (hasInternet()) {//If no internet it will show toast automatically.

            addSubscription(getAppInteractor().callGetAllCountriesApi(new InterActorCallback<CountryResponse>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(CountryResponse response) {
                    if (response.isStatus()) {
                        ArrayList<CountryModel> countryModels = response.getCountry_data();
                        String[] countryList = new String[countryModels.size() + 1];
                        countryList[0] = getView().getActivity().getString(R.string.hint_country);
                        int count = 1;
                        for (CountryModel countryModel : countryModels) {
                            countryList[count] = countryModel.getCountry_name();
                            count++;
                        }
                        getView().onCountryList(countryList);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }
}
