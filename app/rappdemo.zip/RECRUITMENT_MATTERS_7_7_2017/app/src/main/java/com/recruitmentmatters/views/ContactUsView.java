package com.recruitmentmatters.views;

import com.recruitmentmatters.customview.CustomDialog;

/**
 * Created by imobdev on 20/4/17.
 */

public interface ContactUsView<T> extends ValidationErrorView<T> {

    void onMessageSendSuccess(String message, CustomDialog customDialog);
}
