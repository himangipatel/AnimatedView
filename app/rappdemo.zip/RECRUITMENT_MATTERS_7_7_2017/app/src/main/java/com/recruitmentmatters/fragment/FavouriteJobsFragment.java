package com.recruitmentmatters.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.activities.JobDetailsActivity;
import com.recruitmentmatters.adapter.JobListingAdapter;
import com.recruitmentmatters.baseclasses.BaseRecyclerAdapter;
import com.recruitmentmatters.baseclasses.MVPFragment;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.customview.CustomSwipeRefreshLayout;
import com.recruitmentmatters.model.JobModel;
import com.recruitmentmatters.model.UserDataModel;
import com.recruitmentmatters.presenter.JobFavouritePresenter;
import com.recruitmentmatters.utils.RMPrefs;
import com.recruitmentmatters.views.JobFavouriteView;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Sameer Jani on 18/4/17.
 */

public class FavouriteJobsFragment extends MVPFragment<JobFavouritePresenter, JobFavouriteView<ArrayList<JobModel>>> implements JobFavouriteView<ArrayList<JobModel>> {


    @BindView(R.id.commonRecyclerView)
    RecyclerView commonRecyclerView;
    @BindView(R.id.swipeRefreshLayout)
    CustomSwipeRefreshLayout swipeRefreshLayout;
    @BindView(R.id.tvNoJobs)
    TextView tvNoJobs;


    private JobListingAdapter adapter;
    private ArrayList<JobModel> jobModelArrayList = new ArrayList<>();
    private int totalRecords = 0;

    private boolean isPullToRefresh = false;
    private boolean isLoadMore = false;
    private BaseRecyclerAdapter.RecycleOnItemEventListener mRecycleviewEventListener = new BaseRecyclerAdapter.RecycleOnItemEventListener() {
        @Override
        public void onItemClick(View view, int position) {
            switch (view.getId()) {
                case R.id.ivFavourite:
                    callFavouriteJobApi(((JobListingAdapter) commonRecyclerView.getAdapter()).getData(position), position);
                    break;
                default:
                    Intent redirectIntent = new Intent(getContext(), JobDetailsActivity.class);
                    redirectIntent.putExtra(ApiParamEnum.JOB_ID.getValue(),
                            ((JobListingAdapter) commonRecyclerView.getAdapter()).getData(position).getJobId());
                    redirectIntent.putExtra(AppConstants.SEND_JOB_DETAILS_POSITION,
                            position);
                    startActivityForResult(redirectIntent, AppConstants.SEND_JOB_DETAILS);
            }
        }

        @Override
        public void onItemLongPress(View view, int position) {
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.app_recyclerview, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        swipeRefreshLayout.setEnabled(false);
        init(view, savedInstanceState);
    }

    private void init(View v, Bundle savedInstanceState) {
        commonRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        callGetFavouriteJobsApi();
    }

    private void callFavouriteJobApi(JobModel jobModel, int position) {
        HashMap<String, String> params = new HashMap<>();
        UserDataModel user = RMPrefs.getInstance(getActivity()).getUserDataModel();
        if (user != null) {
            params.put(ApiParamEnum.USER_ID.getValue(), user.getUser_id());
            params.put(ApiParamEnum.ACCESS_TOKEN.getValue(), RMPrefs.getInstance(getActivity()).getAccessToken());
            params.put(ApiParamEnum.PERSONAL_ID.getValue(), user.getUser_personal_id());
            params.put(ApiParamEnum.JOB_ID.getValue(), jobModel.getJobId());
            params.put(ApiParamEnum.IS_FAVOURITE.getValue(), AppConstants.UNFAVOURITE);
            getPresenter().callFavouriteJobsApi(params, position);
        } else {

        }
    }


    private void callGetFavouriteJobsApi() {
        UserDataModel userDataModel = RMPrefs.getInstance(getActivity()).getUserDataModel();
        String accessToken = RMPrefs.getInstance(getActivity()).getAccessToken();
        if (userDataModel != null && accessToken != null) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put(ApiParamEnum.USER_ID.getValue(), userDataModel.getUser_id());
            hashMap.put(ApiParamEnum.PERSONAL_ID.getValue(), userDataModel.getUser_personal_id());
            hashMap.put(ApiParamEnum.ACCESS_TOKEN.getValue(), accessToken);
            getPresenter().callGetFavouriteJobsListApi(hashMap);
        } else {

        }
    }

    @Override
    public void onSuccess(ArrayList<JobModel> favouriteJobs) {
        if (favouriteJobs != null && !favouriteJobs.isEmpty())
            commonRecyclerView.setAdapter(new JobListingAdapter(getActivity(), favouriteJobs).setRecycleOnItemEventListener(mRecycleviewEventListener));
        if (favouriteJobs.size() == 0) {
            tvNoJobs.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onFailure(String message) {

    }

    @NonNull
    @Override
    public JobFavouritePresenter createPresenter() {
        return new JobFavouritePresenter();
    }

    @NonNull
    @Override
    public JobFavouriteView attachView() {
        return this;
    }

    @Override
    public void onFavouriteJobSucess(String message, int pos) {
        ((JobListingAdapter) commonRecyclerView.getAdapter()).removeJob(pos);
        if (commonRecyclerView.getAdapter().getItemCount() == 0) {
            tvNoJobs.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AppConstants.SEND_JOB_DETAILS && resultCode == Activity.RESULT_OK && data != null) {
            if (commonRecyclerView.getAdapter() != null) {
                int pos = data.getIntExtra(AppConstants.SEND_JOB_DETAILS_POSITION, -1);
                JobModel jobModel = data.getParcelableExtra(AppConstants.RETURNED_JOB_DETAIL);
                if (pos >= 0 && jobModel != null && !jobModel.isJobFav()) {
                    ((JobListingAdapter) commonRecyclerView.getAdapter()).removeJob(pos);
                }
                if (commonRecyclerView.getAdapter().getItemCount() == 0) {
                    tvNoJobs.setVisibility(View.VISIBLE);
                }
            }
        }
    }
}
