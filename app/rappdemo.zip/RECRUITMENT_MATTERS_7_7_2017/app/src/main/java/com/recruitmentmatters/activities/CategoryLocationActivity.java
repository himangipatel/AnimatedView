package com.recruitmentmatters.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseActivity;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.fragment.CategoryFragment;
import com.recruitmentmatters.fragment.LocationFragment;

import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Sameer Jani on 15/4/17.
 */

public class CategoryLocationActivity extends BaseActivity {

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common);
        ButterKnife.bind(this);
        init();
    }

    private void init() {
        Fragment fragment = null;
        if (getIntent().hasExtra(ApiParamEnum.CATEGORY_NAME.getValue())) {
            tvToolbarTitle.setText(getResources().getString(R.string.toolbar_categories));
            fragment = new CategoryFragment();
        } else if (getIntent().hasExtra(ApiParamEnum.LOCATION_NAME.getValue())) {
            tvToolbarTitle.setText(getResources().getString(R.string.toolbar_location));
            fragment = new LocationFragment();
        }
        Bundle bundle = new Bundle();
        bundle.putBoolean(AppConstants.SEND_IS_FROM_ADVANCE_SEARCH, true);
        replaceFragment(fragment, false, bundle);
    }

    private void replaceFragment(Fragment fragment, boolean addToBackStack, Bundle bundle) {

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, fragment, fragment.getClass().getSimpleName());
        if (addToBackStack) {
            fragmentTransaction.addToBackStack(fragment.getClass().getSimpleName());
        }
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        fragmentTransaction.commit();
    }

    @OnClick({R.id.ivToolbarLeft})
    public void onClick(View view) {
        finish();
    }
}
