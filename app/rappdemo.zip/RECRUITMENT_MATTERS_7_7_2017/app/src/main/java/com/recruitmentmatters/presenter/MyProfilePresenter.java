package com.recruitmentmatters.presenter;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BasePresenter;
import com.recruitmentmatters.interacter.InterActorCallback;
import com.recruitmentmatters.model.Response;
import com.recruitmentmatters.model.ViewProfileResponse;
import com.recruitmentmatters.views.MyProfileView;

import java.io.File;
import java.util.HashMap;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;

/**
 * Created by Sameer Jani on 5/4/17.
 */

public class MyProfilePresenter extends BasePresenter<MyProfileView<ViewProfileResponse>> {

    public void callViewProfileApi(HashMap<String, String> params) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callViewProfileApi(params, new InterActorCallback<ViewProfileResponse>() {
                @Override
                public void onStart() {
                    getView().showProgressDialog(true);
                }

                @Override
                public void onResponse(ViewProfileResponse response) {
                    if (response.isStatus()) {
                        getView().onSuccess(response);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressDialog(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }

    public void callUploadProfilePicApi(HashMap<String, RequestBody> params, MultipartBody.Part body) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callUploadProfilePicApi(params, body, new InterActorCallback<ViewProfileResponse>() {
                @Override
                public void onStart() {
                    getView().showPicProgress(true);
                }

                @Override
                public void onResponse(ViewProfileResponse response) {
                    if (response.isStatus()) {
                        getView().onProfilePicUploaded(response);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showPicProgress(false);

                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }

    public void callUploadCVApi(HashMap<String, RequestBody> params, MultipartBody.Part body) {

        if (hasInternet()) {

            addSubscription(getAppInteractor().callUploadCVApi(params, body, new InterActorCallback<Response>() {
                @Override
                public void onStart() {
                    getView().showProgressToolBar(true);
                }

                @Override
                public void onResponse(Response response) {
                    if (response.isStatus()) {
                        getView().onCVUploaded(response);
                    } else {
                        getView().onFailure(response.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressToolBar(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }

    public void downloadCV(String url){
        if (hasInternet()) {

            addSubscription(getAppInteractor().downloadCV(url, new InterActorCallback<File>() {
                @Override
                public void onStart() {
                    getView().showProgressToolBar(true);
                }

                @Override
                public void onResponse(File response) {
                    if (response != null) {
                        getView().onCVDownloaded(response);
                    } else {
                        getView().onCVDownloadFailure(R.string.file_download_failure);
                    }
                }

                @Override
                public void onFinish() {
                    getView().showProgressToolBar(false);
                }

                @Override
                public void onError(String message) {
                    getView().onFailure(message);
                }
            }));
        }
    }
}
