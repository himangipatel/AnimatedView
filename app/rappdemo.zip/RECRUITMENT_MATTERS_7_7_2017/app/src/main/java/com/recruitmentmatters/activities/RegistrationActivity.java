package com.recruitmentmatters.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.recruitmentmatters.R;
import com.recruitmentmatters.baseclasses.BaseView;
import com.recruitmentmatters.baseclasses.MVPActivity;
import com.recruitmentmatters.constants.ApiParamEnum;
import com.recruitmentmatters.constants.AppConstants;
import com.recruitmentmatters.constants.RegisterForm;
import com.recruitmentmatters.customview.CustomDialog;
import com.recruitmentmatters.fragment.EmploymentFragment;
import com.recruitmentmatters.fragment.PersonalEducationFragment;
import com.recruitmentmatters.fragment.PersonalGeneralFragment;
import com.recruitmentmatters.fragment.PersonalJobCategoryFragment;
import com.recruitmentmatters.fragment.PersonalJobTypeFragment;
import com.recruitmentmatters.fragment.PersonalLanguageSpokenFragment;
import com.recruitmentmatters.fragment.ReferenceFragment;
import com.recruitmentmatters.listeners.OnNextPressedListener;
import com.recruitmentmatters.presenter.RegistrationPresenter;
import com.recruitmentmatters.utils.AppUtils;
import com.recruitmentmatters.utils.RMPrefs;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Sameer Jani on 27/3/17.
 */


public class RegistrationActivity extends MVPActivity<RegistrationPresenter, BaseView<String>> implements BaseView<String>, OnNextPressedListener {

    @BindView(R.id.tvPersonalTab)
    TextView tvPersonalTab;
    @BindView(R.id.tvEmploymentTab)
    TextView tvEmploymentTab;
    @BindView(R.id.tvReferencesTab)
    TextView tvReferencesTab;
    @BindView(R.id.pbRegisterProgress)
    ProgressBar pbRegisterProgress;
    @BindView(R.id.frmRegisterStepViewContainer)
    FrameLayout frmRegisterStepViewContainer;
    Fragment fragment = null;
    FragmentTransaction fragmentTransaction;

    private HashMap<String, Object> hmRegister = new HashMap<>();

    private HashMap<String, Object> hmGeneral = new HashMap<>();
    private HashMap<String, Object> hmEducation = new HashMap<>();
    private HashMap<String, Object> hmLanguageSpoken = new HashMap<>();
    private HashMap<String, Object> hmJobCategory = new HashMap<>();
    private HashMap<String, Object> hmJobType = new HashMap<>();
    private HashMap<String, Object> hmEmploymentDetails = new HashMap<>();
    private HashMap<String, Object> hmReferences = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        init();
        RMPrefs.getInstance(RegistrationActivity.this).clearRegData();
        displayForm(RegisterForm.PERSONAL_GENERAL, hmGeneral);
    }

    @NonNull
    @Override
    public RegistrationPresenter createPresenter() {
        return new RegistrationPresenter();
    }

    @NonNull
    @Override
    public BaseView attachView() {
        return this;
    }

    private void init() {
        ButterKnife.bind(this);
        tvToolbarTitle.setText(getString(R.string.toolbar_candidate_profile));
    }

    public void displayForm(RegisterForm registerForm, HashMap<String, Object> hashMap) {
        fragmentTransaction = getSupportFragmentManager().beginTransaction();
        if (registerForm == RegisterForm.PERSONAL_GENERAL) {
            fragment = new PersonalGeneralFragment();
            Bundle bundle = new Bundle();
            fragment.setArguments(bundle);
            showStepTitleBar(ContextCompat.getColor(this, android.R.color.white), ContextCompat.getColor(this, R.color.titleTextLightGray), ContextCompat.getColor(this, R.color.titleTextLightGray), 33);
        } else if (registerForm == RegisterForm.PERSONAL_EDUCATION) {
            fragment = new PersonalEducationFragment();
            Bundle bundle = new Bundle();
            fragment.setArguments(bundle);
            hmGeneral.clear();
            hmGeneral.putAll(hashMap);
            showStepTitleBar(ContextCompat.getColor(this, android.R.color.white), ContextCompat.getColor(this, R.color.titleTextLightGray), ContextCompat.getColor(this, R.color.titleTextLightGray), 33);
        } else if (registerForm == RegisterForm.PERSONAL_LANGUAGE_SPOKEN) {
            fragment = new PersonalLanguageSpokenFragment();
            Bundle bundle = new Bundle();
            fragment.setArguments(bundle);
            hmEducation.clear();
            hmEducation.putAll(hashMap);
            showStepTitleBar(ContextCompat.getColor(this, android.R.color.white), ContextCompat.getColor(this, R.color.titleTextLightGray), ContextCompat.getColor(this, R.color.titleTextLightGray), 33);
        } else if (registerForm == RegisterForm.PERSONAL_JOB_CATEGORY) {
            fragment = new PersonalJobCategoryFragment();
            Bundle bundle = new Bundle();
            fragment.setArguments(bundle);
            hmLanguageSpoken.clear();
            hmLanguageSpoken.putAll(hashMap);
            showStepTitleBar(ContextCompat.getColor(this, android.R.color.white), ContextCompat.getColor(this, R.color.titleTextLightGray), ContextCompat.getColor(this, R.color.titleTextLightGray), 33);
        } else if (registerForm == RegisterForm.PERSONAL_JOB_TYPE) {
            fragment = new PersonalJobTypeFragment();
            Bundle bundle = new Bundle();
            fragment.setArguments(bundle);
            hmJobCategory.clear();
            hmJobCategory.putAll(hashMap);
            showStepTitleBar(ContextCompat.getColor(this, android.R.color.white), ContextCompat.getColor(this, R.color.titleTextLightGray), ContextCompat.getColor(this, R.color.titleTextLightGray), 33);
        } else if (registerForm == RegisterForm.EMPLOYMENT_DETAIL) {
            fragment = new EmploymentFragment();
            Bundle bundle = new Bundle();
            fragment.setArguments(bundle);
            hmJobType.clear();
            hmJobType.putAll(hashMap);
            showStepTitleBar(ContextCompat.getColor(this, R.color.red), ContextCompat.getColor(this, android.R.color.white), ContextCompat.getColor(this, R.color.titleTextLightGray), 66);
        } else if (registerForm == RegisterForm.REFERENCE) {
            fragment = new ReferenceFragment();
            Bundle bundle = new Bundle();
            fragment.setArguments(bundle);
            hmEmploymentDetails.clear();
            hmEmploymentDetails.putAll(hashMap);
            showStepTitleBar(ContextCompat.getColor(this, R.color.red), ContextCompat.getColor(this, R.color.red), ContextCompat.getColor(this, android.R.color.white), 100);
        } else if (registerForm == RegisterForm.REGISTER_ALL_FORM_COMPLETED) {
            hmReferences.clear();
            hmReferences.putAll(hashMap);
            hmRegister.putAll(hmGeneral);
            hmRegister.putAll(hmEducation);
            hmRegister.putAll(hmLanguageSpoken);
            hmRegister.putAll(hmJobCategory);
            hmRegister.putAll(hmJobType);
            hmRegister.putAll(hmEmploymentDetails);
            hmRegister.putAll(hmReferences);
            hmRegister.put(ApiParamEnum.DEVICE_TYPE.getValue(), String.valueOf(AppConstants.DEVICE_TYPE));
            hmRegister.put(ApiParamEnum.DEVICE_TOKEN.getValue(), String.valueOf(""));
            callRegisterApi();
            return;
        }
        fragmentTransaction.replace(R.id.frmRegisterStepViewContainer, fragment);
        /*if (registerForm == RegisterForm.EMPLOYMENT_DETAIL || registerForm == RegisterForm.REFERENCE) {
            getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        } else {
            fragmentTransaction.addToBackStack(fragment.getClass().getName());
        }*/
        fragmentTransaction.addToBackStack(fragment.getClass().getName());
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        fragmentTransaction.commit();
    }

    private void callRegisterApi() {
        getPresenter().callRegistrationApi(hmRegister);
    }

    public void showStepTitleBar(int personalTextColor, int employmentTextColor, int referenceTextColor, int progressCompleted) {
        tvPersonalTab.setTextColor(personalTextColor);
        tvEmploymentTab.setTextColor(employmentTextColor);
        tvReferencesTab.setTextColor(referenceTextColor);
        pbRegisterProgress.setProgress(progressCompleted);
    }


    @Override
    public void onNextPressed(RegisterForm registerForm, HashMap<String, Object> saveObjectData) {
        displayForm(registerForm, saveObjectData);
    }

    @Override
    public void onPreviousClicked() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 1) {
            super.onBackPressed();
        } else {
            finish();
        }
    }


    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 1) {
            Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.frmRegisterStepViewContainer);
            if (fragment instanceof PersonalEducationFragment) {
                ((PersonalEducationFragment) fragment).saveDataInPrefs();
            } else if (fragment instanceof PersonalLanguageSpokenFragment) {
                ((PersonalLanguageSpokenFragment) fragment).saveDataInPrefs();
            } else if (fragment instanceof PersonalJobCategoryFragment) {
                ((PersonalJobCategoryFragment) fragment).saveDataInPrefs();
            } else if (fragment instanceof PersonalJobTypeFragment) {
                ((PersonalJobTypeFragment) fragment).saveDataInPrefs();
            } else if (fragment instanceof EmploymentFragment) {
                ((EmploymentFragment) fragment).saveDataInPrefs();
            } else if (fragment instanceof ReferenceFragment) {
                ((ReferenceFragment) fragment).saveDataInPrefs();
            }
            super.onBackPressed();
        } else {
            showBackDialog();
        }
    }

    @Override
    public void onSuccess(String response) {
        showRegSuccessDialog(response);
    }

    @Override
    public void onFailure(String message) {
        AppUtils.showToast(this, message);
    }

    private void showRegSuccessDialog(String msg) {
        final CustomDialog dialog = new CustomDialog(RegistrationActivity.this,
                getResources().getString(R.string.title_registration_success), msg, getResources().getString(android.R.string.ok)
                , "") {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.tvPositive:
                        dismiss();
                        Intent redirectIntent = new Intent(RegistrationActivity.this, LoginActivity.class);
                        startActivity(redirectIntent);
                        finish();
                        break;
                }
            }
        };
        dialog.show();
    }

    private void showBackDialog() {
        final CustomDialog dialog = new CustomDialog(RegistrationActivity.this,
                getResources().getString(R.string.registration), getResources().getString(R.string.are_you_sure_registration_back_msgs),
                getResources().getString(R.string.yes)
                , getResources().getString(R.string.no)) {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.tvPositive:
                        finish();
                        dismiss();
                        break;
                    case R.id.tvNegative:
                        dismiss();
                        break;
                }
            }
        };
        dialog.show();
    }

    @OnClick({R.id.ivToolbarLeft})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivToolbarLeft:
                showBackDialog();
                break;
        }
    }


    @Override
    public void onDestroy() {
        RMPrefs.getInstance(RegistrationActivity.this).clearRegData();
        super.onDestroy();
    }
}
