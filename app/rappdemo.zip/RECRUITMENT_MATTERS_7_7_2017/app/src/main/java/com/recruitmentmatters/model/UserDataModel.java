package com.recruitmentmatters.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Sameer Jani on 1/4/17.
 */

public class UserDataModel {
    @SerializedName("user_id")
    String user_id = "";
    @SerializedName("user_candidate_ref_number")
    String user_candidate_ref_number = "";
    @SerializedName("user_email")
    String user_email = "";
    @SerializedName("user_personal_id")
    String user_personal_id = "";
    @SerializedName("image_url")
    String image_url = "";
    @SerializedName("user_first_name")
    String user_first_name = "";
    @SerializedName("user_last_name")
    String user_last_name = "";
    @SerializedName("cv_url")
    String cv_url = "";

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_candidate_ref_number() {
        return user_candidate_ref_number;
    }

    public void setUser_candidate_ref_number(String user_candidate_ref_number) {
        this.user_candidate_ref_number = user_candidate_ref_number;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getUser_personal_id() {
        return user_personal_id;
    }

    public void setUser_personal_id(String user_personal_id) {
        this.user_personal_id = user_personal_id;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getUser_first_name() {
        return user_first_name;
    }

    public void setUser_first_name(String user_first_name) {
        this.user_first_name = user_first_name;
    }

    public String getUser_last_name() {
        return user_last_name;
    }

    public void setUser_last_name(String user_last_name) {
        this.user_last_name = user_last_name;
    }

    public String getCv_url() {
        return cv_url;
    }

    public void setCv_url(String cv_url) {
        this.cv_url = cv_url;
    }
}