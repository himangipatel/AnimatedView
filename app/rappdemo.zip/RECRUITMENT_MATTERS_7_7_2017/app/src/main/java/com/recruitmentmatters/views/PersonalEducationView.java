package com.recruitmentmatters.views;

import com.recruitmentmatters.model.CountryResponse;

/**
 * Created by Darshna Desai on 2/5/17.
 */

public interface PersonalEducationView<T> extends ValidationErrorView<T> {
    public void onLocationList(CountryResponse locationList);
}
