package com.admin.validator;

import android.widget.EditText;
import android.widget.Toast;

import com.mowadcom.R;

import java.util.regex.Pattern;

/**
 * Created by Darshna Desai on 6/3/17.
 */

public class Validator {

    public static final String EMAIL_PATTERN = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
            "\\@" +
            "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
            "(" +
            "\\." +
            "[a-zA-Z]{2,8}" +
            ")+";
    public static final String PHONE_PATTERN = "^[+0-9][0-9]*$";

    //6-len alpha-numeric pattern with optional special characters
    public static final String PASSWORD_PATTERN = "^.*(?=.{6,20})(?=.*\\d)(?=.*[a-zA-Z])(^[a-zA-Z0-9._@!&$*%+-:/><#]+$)";
    public static Toast toast = null;

    /* User Validation */
    public static ValidationErrorModel generateError(int msg, ValidationError error) {
        return new ValidationErrorModel(msg, error);
    }

    public static ValidationErrorModel validateFirstName(String firstName) {
        return isBlank(firstName) ? new ValidationErrorModel(R.string.blank_fname, ValidationError.FIRST_NAME)
                : isValidName(firstName) ? null : new ValidationErrorModel(R.string.invalid_fname, ValidationError.FIRST_NAME);
    }

    public static ValidationErrorModel validateName(String name) {
        return isBlank(name) ? new ValidationErrorModel(R.string.blank_name, ValidationError.NAME)
                : isValidName(name) ? null : new ValidationErrorModel(R.string.invalid_name, ValidationError.NAME);
    }

    public static ValidationErrorModel validateMessage(String message) {
        return isBlank(message) ? new ValidationErrorModel(R.string.blank_message, ValidationError.MESSAGE) : null;
    }


    public static ValidationErrorModel validateLastName(String lastName) {
        return isBlank(lastName) ? new ValidationErrorModel(R.string.blank_lname, ValidationError.LAST_NAME) :
                isValidName(lastName) ? null : new ValidationErrorModel(R.string.invalid_lname, ValidationError.LAST_NAME);
    }

    public static ValidationErrorModel validateDateOfBirth(String dob) {
        return isBlank(dob) ? new ValidationErrorModel(R.string.blank_dob, ValidationError.DOB) : null;
    }

    public static ValidationErrorModel validateCityId(String cityId) {
        return isBlank(cityId) ? new ValidationErrorModel(R.string.select_city_validation, ValidationError.CITY_NAME) : null;
    }

    public static ValidationErrorModel validateHospitalId(String hospitalId) {
        return isBlank(hospitalId) ? new ValidationErrorModel(R.string.select_hospital_validation, ValidationError.HOSPITAL_NAME) : null;
    }

    public static ValidationErrorModel validateDepartmentId(String departmentId) {
        return isBlank(departmentId) ? new ValidationErrorModel(R.string.select_dept_validation, ValidationError.DEPARTMENT_NAME) : null;
    }

    public static ValidationErrorModel validateDoctorId(String doctorId) {
        return isBlank(doctorId) ? new ValidationErrorModel(R.string.select_doctor_validation, ValidationError.DOCTOR_NAME) : null;
    }

    public static ValidationErrorModel validateEmailPattern(String email) {
        return !isValidEmail(email) ? new ValidationErrorModel(R.string.invalid_email_msg, ValidationError.EMAIL) : null;
    }

    public static ValidationErrorModel validateEmail(String email) {
        return isBlank(email) ?
                new ValidationErrorModel(R.string.blank_email, ValidationError.EMAIL)
                : !Pattern.compile(EMAIL_PATTERN).matcher(email).matches()
                ? new ValidationErrorModel(R.string.invalid_email_msg, ValidationError.EMAIL)
                : null;
    }

    public static ValidationErrorModel validateDescription(String description) {
        return isBlank(description) ? new ValidationErrorModel(R.string.blank_description, ValidationError.DESCRIPTION) : null;
    }

    public static ValidationErrorModel validatePatientId(String patientId) {
        return isBlank(patientId) ? new ValidationErrorModel(R.string.select_family_member_validation, ValidationError.PATIENT_ID) : null;
    }



/*
    public static ValidationErrorModel validateCountryName(String countryName, String countryHint) {
        return isBlank(countryName) ? new ValidationErrorModel(R.string.blank_country, ValidationError.COUNTRY_NAME)
                : ((countryName.equalsIgnoreCase(countryHint))
                ? new ValidationErrorModel(R.string.blank_country, ValidationError.COUNTRY_NAME) : null);
    }



    public static ValidationErrorModel validateEmail(String email) {
        return isBlank(email) ?
                new ValidationErrorModel(R.string.blank_email, ValidationError.EMAIL)
                : !Pattern.compile(EMAIL_PATTERN).matcher(email).matches()
                ? new ValidationErrorModel(R.string.invalid_email, ValidationError.EMAIL)
                : null;
    }

    public static ValidationErrorModel validateCellphone(String phone) {
        return isBlank(phone) ?
                new ValidationErrorModel(R.string.blank_cellphone, ValidationError.CELLPHONE)
                : ((!(phone.length() >= 10 && phone.length() <= 15))
                ? new ValidationErrorModel(R.string.invalid_cellphone, ValidationError.CELLPHONE) : null);
    }*/

    public static ValidationErrorModel validatePhone(String phone) {
        return isBlank(phone) ?
                new ValidationErrorModel(R.string.blank_phone, ValidationError.TELEPHONE)
                : ((!(phone.length() >= 6 && phone.length() <= 15))
                ? new ValidationErrorModel(R.string.invalid_phone, ValidationError.PHONE) : null);
    }

    public static boolean isBlank(String text) {
        if (text == null || text.trim().length() == 0)
            return true;

        return false;
    }

    public static boolean isValidEmail(String email) {
        return Pattern.compile(EMAIL_PATTERN).matcher(email).matches()
                ? true
                : false;
    }

    public static boolean isValidName(String name) {
        String regex = "[a-zA-Z 0-9]+";
        String regex_arabic = "^[\\u0621-\\u064A 0-9]+$";
        String english_arabic="^[\\u0621-\\u064A\\u0660-\\u0669 [a-zA-Z 0-9]+]+$";

        if (name.matches(english_arabic)) return true;
        else if (name.matches(regex_arabic)) return true;
        else if (name.matches(regex)) return true;

        return false;


    }

    public static boolean isBlank(EditText editText) {
        if (editText.getText() == null || editText.getText().toString().trim().length() == 0)
            return true;

        return false;
    }

    /*public static String validateData(Context context, String str, String strKey) {
        if (isBlank(str)) {
            return context.getResources().getString(R.string.invalid) + strKey;
        }
        return "";
    }*/

    public static boolean validateNumber(String strNumber, int min, int max) {
        if (strNumber.length() >= min && strNumber.length() <= max) {
            return true;
        }
        return false;
    }
}
