package com.admin.interacter;

import android.location.Location;
import android.util.Log;

import com.google.gson.Gson;
import com.mowadcom.connection.RestClient;
import com.mowadcom.connection.RestConstant;
import com.mowadcom.connection.RestService;
import com.mowadcom.model.AppSetting;
import com.mowadcom.model.BookAppointment;
import com.mowadcom.model.CalenderAvailablity;
import com.mowadcom.model.Department;
import com.mowadcom.model.DoctorList;
import com.mowadcom.model.FamilyMember;
import com.mowadcom.model.FamilyMemberModel;
import com.mowadcom.model.GoogleAddressResponse;
import com.mowadcom.model.Hospital;
import com.mowadcom.model.HospitalDetail;
import com.mowadcom.model.Login;
import com.mowadcom.model.MyAppointment;
import com.mowadcom.model.NotificationCount;
import com.mowadcom.model.NotificationResponse;
import com.mowadcom.model.Promotion;
import com.mowadcom.model.Rating;
import com.mowadcom.model.Response;
import com.mowadcom.model.Result;
import com.mowadcom.model.SpinnerData;
import com.mowadcom.model.Timeslot;
import com.mowadcom.utils.AppUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static com.mowadcom.connection.RestClient.getPrimaryService;


public class AppInteractor {

    public boolean isCancel;

    public AppInteractor() {

    }

    private void sendResponse(InterActorCallback callback, Response response) {
        if (!isCancel) {
            callback.onResponse(response);
        }
    }

    public boolean isCancel() {
        return isCancel;
    }

    public void cancel() {
        isCancel = true;
    }

    private void displayRequestParams(HashMap<String, String> hashMap) {
        Iterator it = hashMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            AppUtils.logD((String) pair.getKey(), (String) pair.getValue());
        }
    }

    //Call Api for Get verification Code
    public Subscription callLoginApi(final HashMap<String, String> params,
                                     final InterActorCallback<Login> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.LOGIN, params)
                .map(new Func1<String, Login>() {
                    @Override
                    public Login call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callLoginApi", "" + s);
                        return new Gson().fromJson(s, Login.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Login>(callback, this) {
                    @Override
                    public void onNext(Login response) {
                        sendResponse(callback, response);
                    }
                });
    }

    //Call Api for Get veryfiy family member otp Code
    public Subscription callSendverifyOtp(final HashMap<String, String> params,
                                          final InterActorCallback<Login> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.SENDVERIFY_OTP, params)
                .map(new Func1<String, Login>() {
                    @Override
                    public Login call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callSendverifyOtp", "" + s);
                        return new Gson().fromJson(s, Login.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Login>(callback, this) {
                    @Override
                    public void onNext(Login response) {
                        sendResponse(callback, response);
                    }
                });
    }


    //Call Api for Get HospitalList
    public Subscription callHospitalListApi(final HashMap<String, String> params,
                                            final InterActorCallback<Hospital> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_NEAR_BY_HOSPITAL, params)
                .map(new Func1<String, Hospital>() {
                    @Override
                    public Hospital call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callHospitalListApi", "" + s);
                        return new Gson().fromJson(s, Hospital.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Hospital>(callback, this) {
                    @Override
                    public void onNext(Hospital response) {
                        sendResponse(callback, response);
                    }
                });
    }


    //Call Api for Get auto Search HospitalList
    public Subscription callSearchHospitalListApi(final HashMap<String, String> params,
                                                  final InterActorCallback<Hospital> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_HOSPITAL_LIST, params)
                .map(new Func1<String, Hospital>() {
                    @Override
                    public Hospital call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callSearchHospitalListApi", "" + s);
                        return new Gson().fromJson(s, Hospital.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Hospital>(callback, this) {
                    @Override
                    public void onNext(Hospital response) {
                        sendResponse(callback, response);
                    }
                });
    }


    //Call Api for Get Department List
    public Subscription callDepartmentApi(final HashMap<String, String> params,
                                          final InterActorCallback<Department> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_DEPARTMENT_LIST, params)
                .map(new Func1<String, Department>() {
                    @Override
                    public Department call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callDepartmentApi", "" + s);
                        return new Gson().fromJson(s, Department.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Department>(callback, this) {
                    @Override
                    public void onNext(Department response) {
                        sendResponse(callback, response);
                    }
                });
    }


    //Call Api for Get callHospitalDetail

    public Subscription callHospitalDetailApi(final HashMap<String, String> params,
                                              final InterActorCallback<HospitalDetail> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_HOSPITAL_DETAILS, params)
                .map(new Func1<String, HospitalDetail>() {
                    @Override
                    public HospitalDetail call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callHospitalDetail", "" + s);
                        return new Gson().fromJson(s, HospitalDetail.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<HospitalDetail>(callback, this) {
                    @Override
                    public void onNext(HospitalDetail response) {
                        sendResponse(callback, response);
                    }
                });
    }

    //Call Api for Get call get Time Slote
    public Subscription callGetTimeSlotApi(final HashMap<String, String> params,
                                           final InterActorCallback<Timeslot> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_HOSPITAL_TIMESLOT_LIST, params)
                .map(new Func1<String, Timeslot>() {
                    @Override
                    public Timeslot call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callGetTimeSlote", "" + s);
                        return new Gson().fromJson(s, Timeslot.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Timeslot>(callback, this) {
                    @Override
                    public void onNext(Timeslot response) {
                        sendResponse(callback, response);
                    }
                });
    }

    //Call Api for Get call get Availability of calender Api
    public Subscription callCalenderAvailabilityApi(final HashMap<String, String> params,
                                                    final InterActorCallback<CalenderAvailablity> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_HOSPITAL_AVAILABILITY, params)
                .map(new Func1<String, CalenderAvailablity>() {
                    @Override
                    public CalenderAvailablity call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("CalenderAvailablity", "" + s);
                        return new Gson().fromJson(s, CalenderAvailablity.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<CalenderAvailablity>(callback, this) {
                    @Override
                    public void onNext(CalenderAvailablity response) {
                        sendResponse(callback, response);
                    }
                });
    }


    //Call Api for Get call Edit Appointment
    public Subscription callEditAppointmentApi(final HashMap<String, String> params,
                                               final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPut(RestConstant.BASE_URL + RestConstant.EDIT_APPOINTMENT, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callEditAppointmentApi", "" + s);
                        return new Gson().fromJson(s, BookAppointment.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }


    //Call Api for Get call to book Appointment
    public Subscription callBookAppointment(final HashMap<String, String> params,
                                            final InterActorCallback<BookAppointment> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.BOOK_APPOINTMENT, params)
                .map(new Func1<String, BookAppointment>() {
                    @Override
                    public BookAppointment call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callBookAppointment", "" + s);
                        return new Gson().fromJson(s, BookAppointment.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<BookAppointment>(callback, this) {
                    @Override
                    public void onNext(BookAppointment response) {
                        sendResponse(callback, response);
                    }
                });
    }
    //Call Api for Get call Confirmation Api

    public Subscription callConfirmationApi(final HashMap<String, String> params,
                                            final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPut(RestConstant.BASE_URL + RestConstant.CONFIRM_APPOINTMENT, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callConfirmationApi", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }


    //Call Api for Get call to my Appointment

    public Subscription callMyAppointment(final HashMap<String, String> params,
                                          final InterActorCallback<MyAppointment> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_MY_APPOINTMENTS, params)
                .map(new Func1<String, MyAppointment>() {
                    @Override
                    public MyAppointment call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callMyAppointment", "" + s);
                        return new Gson().fromJson(s, MyAppointment.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<MyAppointment>(callback, this) {
                    @Override
                    public void onNext(MyAppointment response) {
                        sendResponse(callback, response);
                    }
                });
    }

    //Call Api for Get call Cancel Api
    public Subscription callCancelApi(final HashMap<String, String> params,
                                      final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.CANCEL_APPOINMENT, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callCancelApi", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    //Call Api for Get call callRatingAppointmentApi
    public Subscription callRatingAppointmentApi(final HashMap<String, String> params,
                                                 final InterActorCallback<Rating> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GIVE_DOCTOR_RATING, params)
                .map(new Func1<String, Rating>() {
                    @Override
                    public Rating call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callRatingAppointmentApi", "" + s);
                        return new Gson().fromJson(s, Rating.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Rating>(callback, this) {
                    @Override
                    public void onNext(Rating response) {
                        sendResponse(callback, response);
                    }
                });
    }

    /*cal get_my_favorites doctor Api*/
    public Subscription callGetFavoritesDoctor(final HashMap<String, String> params,
                                               final InterActorCallback<DoctorList> callback) {
        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_MY_FAVORITES, params)
                .map(new Func1<String, DoctorList>() {
                    @Override
                    public DoctorList call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("get_my_favorites_doctor", "" + s);
                        return new Gson().fromJson(s, DoctorList.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<DoctorList>(callback, this) {
                    @Override
                    public void onNext(DoctorList response) {
                        sendResponse(callback, response);
                    }
                });
    }


    /*cal get_my_favorites hospital Api*/
    public Subscription callGetFavoritesHospital(final HashMap<String, String> params,
                                                 final InterActorCallback<Hospital> callback) {
        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_MY_FAVORITES, params)
                .map(new Func1<String, Hospital>() {
                    @Override
                    public Hospital call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("get_my_favorites_hospital", "" + s);
                        return new Gson().fromJson(s, Hospital.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Hospital>(callback, this) {
                    @Override
                    public void onNext(Hospital response) {
                        sendResponse(callback, response);
                    }
                });
    }


    public Subscription callRegisterApi(final HashMap<String, String> params,
                                        final InterActorCallback<Login> callback) {
        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.REGISTER_API, params)
                .map(new Func1<String, Login>() {
                    @Override
                    public Login call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callregisterApi", "" + s);
                        return new Gson().fromJson(s, Login.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Login>(callback, this) {
                    @Override
                    public void onNext(Login response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callNationalityAPI(final HashMap<String, String> params,
                                           final InterActorCallback<SpinnerData> callback) {
        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.NATIONALITY_LIST, params)
                .map(new Func1<String, SpinnerData>() {
                    @Override
                    public SpinnerData call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callNationalityApi", "" + s);
                        return new Gson().fromJson(s, SpinnerData.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<SpinnerData>(callback, this) {
                    @Override
                    public void onNext(SpinnerData response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callCitiesAPI(final HashMap<String, String> params,
                                      final InterActorCallback<SpinnerData> callback) {
        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_CITY_LIST, params)
                .map(new Func1<String, SpinnerData>() {
                    @Override
                    public SpinnerData call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("get_city_list", "" + s);
                        return new Gson().fromJson(s, SpinnerData.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<SpinnerData>(callback, this) {
                    @Override
                    public void onNext(SpinnerData response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callHospitalsByCityAPI(final HashMap<String, String> params,
                                               final InterActorCallback<SpinnerData> callback) {
        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_HOSPITAL_BY_CIITY, params)
                .map(new Func1<String, SpinnerData>() {
                    @Override
                    public SpinnerData call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("get_hospital_by_city", "" + s);
                        return new Gson().fromJson(s, SpinnerData.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<SpinnerData>(callback, this) {
                    @Override
                    public void onNext(SpinnerData response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callDepartmentsByHospitalAPI(final HashMap<String, String> params,
                                                     final InterActorCallback<SpinnerData> callback) {
        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_DEPT_BY_HOSPITAL, params)
                .map(new Func1<String, SpinnerData>() {
                    @Override
                    public SpinnerData call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("get_departments_by_hospital", "" + s);
                        return new Gson().fromJson(s, SpinnerData.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<SpinnerData>(callback, this) {
                    @Override
                    public void onNext(SpinnerData response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callDoctorsListByDepartmentAPI(final HashMap<String, String> params,
                                                       final InterActorCallback<SpinnerData> callback) {
        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_DEPT_DETAILS, params)
                .map(new Func1<String, SpinnerData>() {
                    @Override
                    public SpinnerData call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("get_department_details", "" + s);
                        return new Gson().fromJson(s, SpinnerData.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<SpinnerData>(callback, this) {
                    @Override
                    public void onNext(SpinnerData response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callDoctorsListByDepartmentAPIWithDoctorDetails(final HashMap<String, String> params,
                                                                        final InterActorCallback<DoctorList> callback) {
        return getPrimaryService().apiPost(RestConstant.BASE_URL + "get_department_details", params)
                .map(new Func1<String, DoctorList>() {
                    @Override
                    public DoctorList call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("get_department_details", "" + s);
                        return new Gson().fromJson(s, DoctorList.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<DoctorList>(callback, this) {
                    @Override
                    public void onNext(DoctorList response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Subscription callGetFamilyMemberAPI(final HashMap<String, String> params,
                                               final InterActorCallback<FamilyMember> callback) {
        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_FAMILY_MEMBERS, params)
                .map(new Func1<String, FamilyMember>() {
                    @Override
                    public FamilyMember call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("get_department_details", "" + s);
                        return new Gson().fromJson(s, FamilyMember.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<FamilyMember>(callback, this) {
                    @Override
                    public void onNext(FamilyMember response) {
                        sendResponse(callback, response);
                    }
                });
    }


    /*App Setting Api*/
    public Subscription callAppSettingApi(final HashMap<String, String> params,
                                          final InterActorCallback<AppSetting> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_APP_SETTINGS, params)
                .map(new Func1<String, AppSetting>() {
                    @Override
                    public AppSetting call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callAppSettingApi", "" + s);
                        return new Gson().fromJson(s, AppSetting.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<AppSetting>(callback, this) {
                    @Override
                    public void onNext(AppSetting response) {
                        sendResponse(callback, response);
                    }
                });
    }



/*Logout Api*/

    public Subscription callLogoutApi(final HashMap<String, String> params,
                                      final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.LOGOUT, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("logout_api", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }


    /*  callAddRemoveFavDoctor Api*/
    public Subscription callAddRemoveFavDoctor(final HashMap<String, String> params,
                                               final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.ADDREMOVE_FAVORITE_DOCTOR, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callAddRemoveFavDoctor", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }


    /*  callAddRemoveFavDoctor Api*/
    public Subscription callAddRemoveFavHospital(final HashMap<String, String> params,
                                                 final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.ADDREMOVE_FAVORITE_HOSPITAL, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callAddRemoveFavHospital", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }


    /*call for device update token*/

    public Subscription callUpdateDeviceTokenApi(final HashMap<String, String> params,
                                                 final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.UPDATE_DEVICE_TOKEN, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callUpdateDeviceTokenApi", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }


    //Get my profile API

    public Subscription callGetMyProfileAPI(final HashMap<String, String> params,
                                            final InterActorCallback<Login> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_MY_PROFILE, params)
                .map(new Func1<String, Login>() {
                    @Override
                    public Login call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callGetMyProfileApi", "" + s);
                        return new Gson().fromJson(s, Login.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Login>(callback, this) {
                    @Override
                    public void onNext(Login response) {
                        sendResponse(callback, response);
                    }
                });
    }

    //Edit my profile API

    public Subscription callEditMyProfileAPI(final HashMap<String, String> params,
                                             final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPut(RestConstant.BASE_URL + RestConstant.EDIT_MY_PROFILE, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callEditMyProfileApi", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }


    //upload_profile_pic API

    public Subscription callUploadProfilePicAPI(final HashMap<String, RequestBody> params, MultipartBody.Part body,
                                                final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPostWithUpload(RestConstant.BASE_URL + RestConstant.UPLOAD_PROFILE_PIC, params, body)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        //displayRequestParams(params);
                        AppUtils.logD("callUploadProfilePicAPI", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    // add family member API

    public Subscription callAddFamilyMember(final HashMap<String, RequestBody> params, MultipartBody.Part body,
                                            final InterActorCallback<FamilyMemberModel> callback) {

        return getPrimaryService().apiPostWithUpload(RestConstant.BASE_URL + RestConstant.ADD_FAMILY_MEMBER, params, body)
                .map(new Func1<String, FamilyMemberModel>() {
                    @Override
                    public FamilyMemberModel call(String s) {
                        AppUtils.logD("callAddFamilyMember", "" + s);
                        return new Gson().fromJson(s, FamilyMemberModel.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<FamilyMemberModel>(callback, this) {
                    @Override
                    public void onNext(FamilyMemberModel response) {
                        sendResponse(callback, response);
                    }
                });
    }

    // edit family member api


    public Subscription callEditFamilyMember(final HashMap<String, String> params,
                                             final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPut(RestConstant.BASE_URL + RestConstant.EDIT_FAMILY_MEMBER, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("calleditfamilymember", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    // Remove family member API

    public Subscription callDeleteFamilyMember(final HashMap<String, String> params,
                                               final InterActorCallback<Response> callback) {

        return getPrimaryService().apiDelete(RestConstant.BASE_URL + RestConstant.DELETE_FAMILY_MEMBER, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        // displayRequestParams(deleteMemberModel);
                        AppUtils.logD("callDeleteFamilyMember", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    // Send Contactus email API

    public Subscription callSendContactUsEmailAPI(final HashMap<String, String> params,
                                                  final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.SEND_CONTACT_US_MAIL, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callSendContactUsEmailAPI", "" + s);
                        return new Gson().fromJson(s, Response.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    // update_user_settings API

    public Subscription callUpdateUserSettings(final HashMap<String, Object> params,
                                               final InterActorCallback<Login> callback) {

        return getPrimaryService().apiupdateSettingsPut(RestConstant.BASE_URL + RestConstant.UPDATE_USER_SETTINGS, params)
                .map(new Func1<String, Login>() {
                    @Override
                    public Login call(String s) {
                        // displayRequestParams(params);
                        AppUtils.logD("callUpdateUserSettingsAPI", "" + s);
                        return new Gson().fromJson(s, Login.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Login>(callback, this) {
                    @Override
                    public void onNext(Login response) {
                        sendResponse(callback, response);
                    }
                });
    }

    public Observable<GoogleAddressResponse> getLocationName(final Location location, String language) {
        RestService service = RestClient.getService();
        HashMap<String, String> locationParams = new HashMap<>();
        locationParams.put(RestConstant.LATLNG,
                location.getLatitude() + "," + location.getLongitude());
        locationParams.put(RestConstant.LANGUAGE, language);

        return service.getLocationNameFromLatLng(RestConstant.MAPS_BASE_URL + "AIzaSyCVUjLywbNwcpxBgH60dt80bjBvrgj96cs", locationParams)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .map(new Func1<String, GoogleAddressResponse>() {
                    @Override
                    public GoogleAddressResponse call(String s) {
                        GoogleAddressResponse googleAddressResponse =
                                new GoogleAddressResponse(location.getLatitude(), location.getLongitude());
                        try {
                            JSONObject jsonObject = new JSONObject(s);
                            Log.e("getLocationName", ":-" + jsonObject.toString());
                            if (jsonObject.has(RestConstant.STATUS)) {
                                String status = jsonObject.getString(RestConstant.STATUS);
                                if (status.equalsIgnoreCase(RestConstant.GOOGLE_OK)) {
                                    if (jsonObject.has(RestConstant.RESULTS)) {
                                        JSONArray resultsArray = jsonObject.getJSONArray(RestConstant.RESULTS);
                                        /*if(resultsArray != null && resultsArray.length() >0) {
                                            Result result = new Gson().fromJson(resultsArray.getJSONObject(0).toString(), Result.class);
                                        }*/
                                        for (int i = 0; i < resultsArray.length(); i++) {
                                            JSONObject addressJson = resultsArray.getJSONObject(i);
                                            Result googleAddressModel = new Gson().fromJson(addressJson.toString(), Result.class);
                                            googleAddressResponse.addAddress(googleAddressModel);
                                        }
                                    }
                                } else if (status.equalsIgnoreCase(RestConstant.ZERO_RESULTS)) {
                                    googleAddressResponse.setAddresses(new ArrayList<Result>());
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        return googleAddressResponse;
                    }
                });
    }


    // Notification list API

    public Subscription callNotificationListApi(final HashMap<String, String> params,
                                                final InterActorCallback<NotificationResponse> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_NOTIFICATION_LIST, params)
                .map(new Func1<String, NotificationResponse>() {
                    @Override
                    public NotificationResponse call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callNotificationListApi", "" + s);
                        return new Gson().fromJson(s, NotificationResponse.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<NotificationResponse>(callback, this) {
                    @Override
                    public void onNext(NotificationResponse response) {
                        sendResponse(callback, response);
                    }
                });
    }


    // Delete Notification API

    public Subscription calldeleteNotificationAPI(final HashMap<String, String> params,
                                                  final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.DELETE_NOTIFICATION, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("deleteNotificationAPI", "" + s);
                        return new Gson().fromJson(s, NotificationResponse.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    // Clear Notification List API
    public Subscription clearNotificationAPI(final HashMap<String, String> params,
                                             final InterActorCallback<Response> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.CLEAR_NOTIFICATION_LIST, params)
                .map(new Func1<String, Response>() {
                    @Override
                    public Response call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("clearNotificationAPI", "" + s);
                        return new Gson().fromJson(s, NotificationResponse.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Response>(callback, this) {
                    @Override
                    public void onNext(Response response) {
                        sendResponse(callback, response);
                    }
                });
    }

    // Get Notification count API
    public Subscription callGetNotifcationCountAPI(final HashMap<String, String> params,
                                                   final InterActorCallback<NotificationCount> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_NOTIFICATION_COUNT, params)
                .map(new Func1<String, NotificationCount>() {
                    @Override
                    public NotificationCount call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("getNotifcationCountAPI", "" + s);
                        return new Gson().fromJson(s, NotificationCount.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<NotificationCount>(callback, this) {
                    @Override
                    public void onNext(NotificationCount response) {
                        sendResponse(callback, response);
                    }
                });
    }

    // Get promotions API
    public Subscription callGetPromotionsListAPI(final HashMap<String, String> params,
                                                 final InterActorCallback<Promotion> callback) {

        return getPrimaryService().apiPost(RestConstant.BASE_URL + RestConstant.GET_PROMOTIONS_LIST, params)
                .map(new Func1<String, Promotion>() {
                    @Override
                    public Promotion call(String s) {
                        displayRequestParams(params);
                        AppUtils.logD("callpromotionslistapi", "" + s);
                        return new Gson().fromJson(s, Promotion.class);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new InterActorOnSubscribe<>(callback))
                .subscribe(new InterActorSubscriber<Promotion>(callback, this) {
                    @Override
                    public void onNext(Promotion response) {
                        sendResponse(callback, response);
                    }
                });
    }


}

