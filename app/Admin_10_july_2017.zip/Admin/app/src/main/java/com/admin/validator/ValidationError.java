package com.admin.validator;

/**
 * Created by Darshna Desai on 6/3/17.
 */

public enum ValidationError {


    EMAIL,
    PHONE,

    FIRST_NAME,
    LAST_NAME,
    NAME,
    MESSAGE,
    DOB,
    TELEPHONE,

    CITY_NAME,
    HOSPITAL_NAME,
    DEPARTMENT_NAME,
    DOCTOR_NAME,
    DESCRIPTION,
    PATIENT_ID,

}
