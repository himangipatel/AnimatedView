package com.admin.customviews;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.support.annotation.IdRes;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.mowadcom.R;
import com.mowadcom.connection.RestConstant;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by vikas on 18/3/17.
 */

public class DialogSortBy extends Dialog implements RadioGroup.OnCheckedChangeListener {

    private View view;
    private Animation slide_down_anim, slide_up_anim;
    OnRadioButtonCheckedListener onRadioButtonCheckedListener;
    @BindView(R.id.dialog)
    LinearLayout dialog;
    @BindView(R.id.radioSortByGroup)
    RadioGroup radioSortByGroup;
    @BindView(R.id.rbtnDistance)
    RadioButton rbtnDistance;
    @BindView(R.id.rbtnName)
    RadioButton rbtnName;
    @BindView(R.id.rbtnRating)
    RadioButton rbtnRating;


    private boolean isDialogCreated;

    public DialogSortBy(Context context, OnRadioButtonCheckedListener onRadioButtonCheckedListener, String mSortBy) {
        super(context, R.style.ThemeDialogCustomBottom);
        init(context, onRadioButtonCheckedListener);
        isDialogCreated = true;
        setCheked(mSortBy);
    }

    @SuppressLint("InflateParams")
    private void init(Context context, OnRadioButtonCheckedListener mOnRadioButtonClickListener) {
        this.onRadioButtonCheckedListener = mOnRadioButtonClickListener;
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.dialog_layout_sort_by, null);
        ButterKnife.bind(this, view);


        initAnimation();
        setContentView(view);
        setCancelable(true);
        visible_option_menu();
        Window window = getWindow();
        if (window != null) {
            window.setGravity(Gravity.BOTTOM);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(window.getAttributes());
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            window.setAttributes(lp);
        }
        radioSortByGroup.setOnCheckedChangeListener(this);

    }


    @Override
    public void onBackPressed() {
        hide_option_menu();
    }

    private void initAnimation() {
        slide_down_anim = AnimationUtils.loadAnimation(getContext(), R.anim.slide_down);
        slide_down_anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        DialogSortBy.this.dismiss();
                    }
                }, 0);
            }
        });
        slide_up_anim = AnimationUtils.loadAnimation(getContext(), R.anim.slide_up);

    }


    public void hide_option_menu() {
        dialog.startAnimation(slide_up_anim);
        dismiss();

    }

    public void visible_option_menu() {
        if (!isShowing()) {
            show();
            dialog.setVisibility(View.VISIBLE);
            dialog.startAnimation(slide_up_anim);
        }
    }

    @Override
    public void dismiss() {
        dialog.startAnimation(slide_down_anim);
        super.dismiss();
    }

    @Override
    public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
        if (!isDialogCreated) {
            onRadioButtonCheckedListener.onRadioButtonChecked(checkedId);
            hide_option_menu();
        }
        isDialogCreated = false;
    }

    public interface OnRadioButtonCheckedListener {
        void onRadioButtonChecked(int view);
    }



    private void setCheked(String checked) {
        switch (checked) {
            case RestConstant.SORT_BY_DISTANCE:
                rbtnDistance.setChecked(true);
                break;

            case RestConstant.SORT_BY_NAME:
                rbtnName.setChecked(true);
                break;

            case RestConstant.SORT_BY_RATING:
                rbtnRating.setChecked(true);
                break;
        }



    }

}

