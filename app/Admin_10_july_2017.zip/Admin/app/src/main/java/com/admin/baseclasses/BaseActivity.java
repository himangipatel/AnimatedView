
package com.admin.baseclasses;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.admin.R;
import com.admin.customviews.CircleImageView;
import com.admin.utils.AppUtils;

import butterknife.BindView;
import butterknife.OnClick;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;


public class BaseActivity extends AppCompatActivity {

    @BindView(R.id.toolbar)
    public Toolbar toolbar;
    @BindView(R.id.rlToolbarIcon)
    public RelativeLayout rlToolbarIcon;
    @BindView(R.id.ivToolbarLeft)
    public ImageView ivToolbarLeft;
    @BindView(R.id.tvToolbarTitle)
    public TextView tvToolbarTitle;
    @BindView(R.id.ivToolbarRight)
    public ImageView ivToolbarRight;
    @BindView(R.id.tvToolbarRight)
    TextView tvToolbarRight;
    @BindView(R.id.ivToolbarFirstRight)
    ImageView ivToolbarFirstRight;
    @BindView(R.id.ivToolbarMenu)
    ImageView ivToolbarMenu;
    @BindView(R.id.tvList)
    public TextView tvList;
    @BindView(R.id.rlMenuLayout)
    RelativeLayout rlMenuLayout;
    @BindView(R.id.tvNotificationCount)
    public TextView tvNotificationCount;
    @BindView(R.id.progressToolbar)
    public ProgressBar progressToolbar;
    @BindView(R.id.ivToolbarUerProfile)
    public CircleImageView ivToolbarUerProfile;

    private Dialog progressDialog;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setSupportActionBar(toolbar);



/*
        if (!AppConstants.isEnglishLang){

            AppUtils.setLanguage(this, AppConstant.ARABIC‬‬_VALUE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            }
        }*/

        //    setSupportActionBar(toolbar);
      /*  userId= PreferenceUtils.getInstance(this).getUserId();
        accessToken= PreferenceUtils.getInstance(this).getAccessToken();
        AppUtils.loge("id : "+userId);
        AppUtils.loge("token : "+accessToken);*/

    }


    public void setIvLeftVisible(boolean show) {
        ivToolbarLeft.setVisibility(show ? View.VISIBLE : View.GONE);

    }

    public void setIvRightVisible(boolean show) {
        tvList.setVisibility(View.GONE);
        ivToolbarRight.setVisibility(show ? View.VISIBLE : View.GONE);

    }


    public void setMenuVisible(boolean show) {
        ivToolbarMenu.setVisibility(show ? View.VISIBLE : View.GONE);
        rlMenuLayout.setVisibility(show ? View.VISIBLE : View.GONE);


    }

    public void setTvListVisible(boolean show) {
        tvList.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    public void setIvFirstRightVisible(boolean show) {
        ivToolbarFirstRight.setVisibility(show ? View.VISIBLE : View.GONE);

    }


    public void setRightImage(int rightImage) {
        ivToolbarRight.setImageResource(rightImage);
       /* AppUtils.setMirroredEnable(true, ivToolbarRight);*/
    }

    public void setFirstRightImage(int rightImage) {
        ivToolbarFirstRight.setImageResource(rightImage);
 /*       AppUtils.setMirroredEnable(true, ivToolbarFirstRight);*/
    }

    public void setLeftImage(int leftImage) {
        ivToolbarLeft.setImageResource(leftImage);

    }

    public void setToolbarTitle(int string) {
        ivToolbarUerProfile.setVisibility(View.GONE);
        tvToolbarTitle.setVisibility(View.VISIBLE);
        tvToolbarTitle.setText(string);
    }

    public void setTvToolbarRightVisible(boolean show) {
        tvToolbarRight.setVisibility(show ? View.VISIBLE : View.GONE);

    }

    public void setToolbarTitle(String string) {
        ivToolbarUerProfile.setVisibility(View.GONE);
        tvToolbarTitle.setVisibility(View.VISIBLE);
        tvToolbarTitle.setText(string);
    }

    /*public HashMap<String, String> getDefaultParameter() {
        HashMap<String, String> params = new HashMap<>();
        params.put(RestConstant.DEVICE_TYPE, RestConstant.DEVICE_TYPE_VALUE);
        params.put(RestConstant.LANGUAGE, PreferenceUtils.getInstance(this).getLanguage());
        return params;
    }


    public HashMap<String, String> getDefaultParamWithIdAndToken() {
        HashMap<String, String> params = getDefaultParameter();
        params.put(RestConstant.USER_ID, PreferenceUtils.getInstance(this).getUserId());
        params.put(RestConstant.ACCESS_TOKEN, PreferenceUtils.getInstance(this).getAccessToken());
        return params;
    }
*/

    public void showProgressDialog(boolean show) {
        //Show Progress bar here
        if (show) {
            showProgressDialog();
        } else {
            hideProgressDialog();
        }
    }

    public void showProgressToolBar(boolean show, View view) {
        if (show) {
            progressToolbar.setVisibility(View.VISIBLE);
            if (view != null)
                view.setVisibility(View.GONE);

        } else {
            progressToolbar.setVisibility(View.GONE);
            if (view != null)
                view.setVisibility(View.VISIBLE);
        }
    }


    protected final void showProgressDialog() {
        if (progressDialog == null) {
            progressDialog = new Dialog(this);
        } else {
            return;
        }
        View view = LayoutInflater.from(this).inflate(R.layout.app_loading_dialog, null, false);

        ImageView imageView1 = (ImageView) view.findViewById(R.id.imageView2);
        Animation a1 = AnimationUtils.loadAnimation(this, R.anim.progress_anim);
        a1.setDuration(1500);
        imageView1.startAnimation(a1);

        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(view);
        Window window = progressDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(ContextCompat.getDrawable(this, android.R.color.transparent));
        }
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
    }

    /**
     * hide progress bar
     */
    protected final void hideProgressDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
            progressDialog = null;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public Activity getActivity() {
        return this;
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }


    @OnClick({R.id.ivToolbarLeft})
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.ivToolbarLeft:
                finish();
                break;
        }
    }

    public void onAuthenticationFailure(String message) {

    }

    public boolean hasInternetWithoutMessage() {
        if (AppUtils.hasInternetConnection(this)) {
            return true;
        } else {
            return false;
        }

    }


}

