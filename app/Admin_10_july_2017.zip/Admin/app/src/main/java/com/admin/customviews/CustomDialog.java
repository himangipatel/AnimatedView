package com.admin.customviews;


import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.mowadcom.R;
import com.mowadcom.connection.RestConstant;
import com.mowadcom.model.RatingData;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by imobdev-1 on 28/3/17.
 */

public abstract class CustomDialog extends Dialog implements View.OnClickListener {

    private String strYes, strCancel, strInstruction;

    @BindView(R.id.tvInstruction)
    TextView tvInstruction;
    @BindView(R.id.ll_bottom_layout)
    LinearLayout llBottomLayout;
    @BindView(R.id.ratingBar)
    RatingBar ratingBar;
    @BindView(R.id.tvGreenBtn)
    TextView tvGreenBtn;
    @BindView(R.id.tvBlackBtn)
    TextView tvBlackBtn;
    @BindView(R.id.llBtns)
    LinearLayout llBtns;
    @BindView(R.id.etComment)
    EditText etComment;
    private Context context;
    private RatingData ratingData;


    public CustomDialog(Context context, String strYes, String strCancel, String strInstruction) {
        super(context);
        this.strYes = strYes;
        this.strCancel = strCancel;
        this.strInstruction = strInstruction;
        this.context = context;

    }

    public CustomDialog(Context context, String strYes, String strCancel, RatingData ratingData) {
        super(context);
        this.strYes = strYes;
        this.strCancel = strCancel;
        this.context = context;
        this.ratingData = ratingData;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setCancelable(false);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.app_dialog);
        ButterKnife.bind(this);
        getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        setText();
        tvGreenBtn.setOnClickListener(this);
        tvBlackBtn.setOnClickListener(this);

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {

                if (rating > 0) {
                    tvGreenBtn.setEnabled(true);
                    tvGreenBtn.setAlpha(1);
                } else {
                    tvGreenBtn.setEnabled(false);
                    tvGreenBtn.setAlpha(.5f);
                }


            }
        });
        if (ratingData != null) {
            setData();
        }

    }

    private void setData() {

        if (ratingData.isRating_given()) {
            ratingBar.setRating(Float.parseFloat(ratingData.getRatingcount()));
            etComment.setText(ratingData.getComment());
            etComment.setEnabled(false);
            tvGreenBtn.setEnabled(false);
            tvGreenBtn.setAlpha(.5f);
            ratingBar.setIsIndicator(true);

        }
    }

    private void setText() {

        if (strYes != null) {
            tvGreenBtn.setText(strYes);
        }
        if (strCancel != null) {
            tvBlackBtn.setText(strCancel);
        } else {
            tvBlackBtn.setVisibility(View.GONE);
            tvGreenBtn.setWidth(0);
        }
        if (strInstruction != null) {
            tvInstruction.setText(strInstruction);
            llBottomLayout.setVisibility(View.GONE);
        } else {
            tvInstruction.setVisibility(View.GONE);
            llBottomLayout.setVisibility(View.VISIBLE);
            tvGreenBtn.setEnabled(false);
            tvGreenBtn.setAlpha(.5f);
        }
    }

    public HashMap<String, String> getRatingData(HashMap<String, String> hashMap) {
        hashMap.put(RestConstant.D_RATING, String.valueOf(ratingBar.getRating()));
        hashMap.put(RestConstant.COMMENT, etComment.getText().toString().trim());
        return hashMap;
    }

}
