package com.admin.interacter;


import com.mowadcom.model.Response;

/**
 * Created on 23/8/16.
 */

public interface InterActorCallback<T extends Response> {

  public void onStart();

  public void onResponse(T response);

  public void onFinish();

  public void onError(String message);

}
