package com.admin.baseclasses;

import android.app.Activity;
import android.view.View;

import java.util.HashMap;

/**
 * Created by Darshna Desai on 6/3/17.
 */

public interface BaseView<T> {
    boolean hasInternet();

    boolean hasInternetWithoutMessage();

    void showProgressDialog(boolean show);

    void showProgressToolBar(boolean show, View view);

    void onSuccess(T response);

    void onFailure(String message);

    void setInternetError();

    void onAuthenticationFailure(String message);

    HashMap<String, String> getDefaultParameter();

    Activity getActivity();
}