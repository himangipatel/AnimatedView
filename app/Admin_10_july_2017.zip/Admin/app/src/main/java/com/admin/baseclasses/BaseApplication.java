package com.admin.baseclasses;

import android.app.Application;

import com.admin.R;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;


/**
 * Created by  bhoomika on 19/12/16.
 */

public class BaseApplication extends Application {



    private static BaseApplication baseApplication = null;

    public static BaseApplication getBaseApplication() {
        return baseApplication;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        baseApplication = this;

        setFont();

//        JodaTimeAndroid.init(this);



    }

    private void setFont() {

        CalligraphyConfig.initDefault(
                new CalligraphyConfig.Builder().setDefaultFontPath("fonts/ubuntu_regular.ttf").setFontAttrId(R.attr.fontPath).build());

        /*String language = PreferenceUtils.getInstance(getApplicationContext()).getLanguage();
        if (language.equals(AppConstant.ENGLISH_VALUE)) {

            CalligraphyConfig.initDefault(
                    new CalligraphyConfig.Builder().setDefaultFontPath("fonts/ubuntu_regular.ttf").setFontAttrId(R.attr.fontPath).build());
        } else {
            CalligraphyConfig.initDefault(
                    new CalligraphyConfig.Builder().setDefaultFontPath("fonts/arabic_medium.ttf").setFontAttrId(R.attr.fontPath).build());
        }*/
    }


    /**
     * Gets the default {@link Tracker} for this {@link Application}.
     * @return tracker
     */
   /* synchronized public Tracker getDefaultTracker() {
        // To enable debug logging use: adb shell setprop log.tag.GAv4 DEBUG
        if (sTracker == null) {
            sTracker = sAnalytics.newTracker(R.xml.global_tracker);
        }

        return sTracker;
    }*/
}
