package com.admin.customviews;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.mowadcom.R;


/**
 * Created by imobdev on 11/5/16.
 */
public class DividerItemColorDecoration extends RecyclerView.ItemDecoration {
  private final int margin;
  private GradientDrawable mDivider;

  private int padding = 0;

  public DividerItemColorDecoration(Context context, int color) {
    mDivider = new GradientDrawable();
    mDivider.setShape(GradientDrawable.RECTANGLE);
    mDivider.setSize(0, context.getResources().getDimensionPixelSize(R.dimen._1sdp));
    mDivider.setColor(color);
     margin= (int) context.getResources().getDimension(R.dimen.regular);
  }

/*  public DividerItemColorDecoration(Context context, int color, int padding) {
    this(context, color);
    this.padding = padding;
  }*/

  @Override
  public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
    int left = margin;

    int right = parent.getWidth() -margin;

    int childCount = parent.getChildCount();
    for (int i = 0; i < childCount; i++) {

      View child = parent.getChildAt(i);
      int top = child.getBottom() - mDivider.getIntrinsicHeight() + (padding);
      int bottom = child.getBottom() + (padding);

      if (i == childCount - 1) {
        mDivider.setBounds(left, top - mDivider.getIntrinsicHeight(), right, bottom - mDivider.getIntrinsicHeight());
      } else {
        mDivider.setBounds(left, top, right, bottom);
      }
      mDivider.draw(c);
    }
  }

  @Override
  public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
    super.getItemOffsets(outRect, view, parent, state);
    outRect.top = padding;
    outRect.left = padding;
    outRect.right = padding;
    outRect.bottom = padding;
  }
}
