package com.admin.constant;

/**
 * Created by bhoomika on 21/3/17.
 */

public class AppConstant {

    /*Api Constant*/
    public static final String CRITICISM_ID = "1a25d9e893ac4641ad15a310f456798900555300";
    public static final String DECRYPTED_KEYS = "e8ffc7e56311679f12b6fc91aa77a5eb";
    public static final String ENGLISH_VALUE = "en";
    public static final String ARABIC‬‬_VALUE = "ar";
    public static final String LUNGUAGE_SELECTED = "lunguage_selected";
    public static final String SOURCE = "source";
    public static final String MONTH = "month";
    public static final String YEAR = "year";
    public static final String isSelect = "isSelect";
    public static final String TERMS_CONDITION_DATA = "terms_condition_data";

    public static final String isMyAppointment = "isMyAppointment";
    public static final String isEditAppointment = "isEditAppointment";
    public static final String isBookAppointment = "isBookAppointment";
    public static final int REQUEST_CODE_FILTER = 88;
    public static final String FILTER_DATA = "filter_data";
    public static final String FILTER_DATA_DEFULT = "filter_data_defult";
    public static final String isAddFamilyMember = "isAddFamilyMember";
    public static final String isFavDoctorFlow = "isFavDoctorFlow";

    public static final String HOME_DATA = "home_data";
    public static final String HOME_DATA_COUNT = "home_data_count";
    public static final String DOCTOR_DATA = "doctor_data";
    public static final String EDIT_APPOINTMENT_DATA = "EDIT_APPOINTMENT_DATA";


    public static final String EDIT_FAMILY_MEMBER = "EDIT_FAMILY_MEMBER";
    public static final String EDIT_PROFILE = "EDIT_PROFILE";
    public static final String ADD_FAMILY_MEMBER = "ADD_FAMILY_MEMBER";
    public static final String MALE = "1";
    public static final String FEMALE = "2";
    public static final String DATE_FORMAT = "dd MMMM yyyy";
    public static final String SHORT_DATE_FORMAT = "dd MMM yyyy";
    public static final String USER_DATA = "user_data";
    public static final String BOOK_APPOINTMENT_DATA = "book_appointment_data";
    public static final String COUNTRY_PICKER = "COUNTRY_PICKER";

    public static final String IS_USER_REGISTER = "is_user_register";


    public static final String DEPT_NAME = "dept_name";
    public static final String DEPT_DETAILS_NOT_NEEDED = "2";


    public static final String ABOUT_US = "http://moawadcom.reviewprototypes.com/pages/CONTACT_US_";
    public static final String FAQ = "http://moawadcom.reviewprototypes.com/pages/FAQ_";
    public static final String T_AND_C = "http://moawadcom.reviewprototypes.com/pages/T&C_";
    public static final String HTML = ".html";


    public static final String ENGLISH_LANGUAGE = "1";
    public static final String AREBIC_LANGUAGE = "2";
    public static final String ISNOTIFICATION = "isNotification";
    public static final String NOTIFICATION_COUNT ="notification_count" ;
    public static boolean isRecreated = false;

    public static final String IS_DISPLAY_TUTORIAL_ACTIVITY = "is_display_tutorial_activity";

    public static final String SEND_PUSH_NOTIFICATION_MODEL = "sendPushNotificationModel";


    public static final String LOOGED_IN_USER = "1";
    public static final String FAMILY_MEMBER = "2";
    public static final String FAMILY_MEMBER_DATA = "family_member_data";
    public static final int REQUEST_CODE_ADD_FAMILY_MEMBER = 1;
    public static final int REQUEST_CODE_EDIT_FAMILY_MEMBER = 2;
    public static final String HOSPITAL_DATA = "hospital_data";
    public static final String INDEX = "index";
    public static final String NO_BLOOD_GROUP = "0";
    public static final int REQUEST_CODE_EDIT_PROFILE = 3;


    /*for New Book Appointment Flow*/
    public static final int BOOK_APPOINTMENT_FRAGMENT = 1;
    public static final int HOSPITAL_DETAIL_ACTIVITY = 2;
    public static final int FAVORITE_HOSPITAL = 3;
    public static final String BOOK_APPOINTMENT_FLOW = "book_appointment_flow";
    public static final String IS_PROMOTION = "is_promotion";
    public static final String IS_REMOVE_FAVORITE = "is_remove_favorite";

    public static final String USER_RADIUS = "user_redius";
    public static final String MAX_RADIUS = "max_redius";

    public static final String ABOUT_US_EN = "http://moawadcom.reviewprototypes.com/contact_us_en";
    public static final String ABOUT_US_AR = "http://moawadcom.reviewprototypes.com/contact_us_ar";

    public static final String TERMS_CONDITION_EN="http://moawadcom.reviewprototypes.com/hospital_terms_conditions_en/";
    public static final String TERMS_CONDITION_AR="http://moawadcom.reviewprototypes.com/hospital_terms_conditions_ar/";

    public static final String FAQ_EN = "http://moawadcom.reviewprototypes.com/faq_en";
    public static final String FAQ_AR = "http://moawadcom.reviewprototypes.com/faq_ar";

    public static final String T_AND_C_EN = "http://moawadcom.reviewprototypes.com/terms_conditions_en";
    public static final String T_AND_C_AR = "http://moawadcom.reviewprototypes.com/terms_conditions_ar";

    public static final String LATITUDE = "latitude";
    public static final String LONGITUDE = "longitude";


}

