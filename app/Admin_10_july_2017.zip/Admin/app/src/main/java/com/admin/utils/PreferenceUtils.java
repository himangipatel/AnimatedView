package com.admin.utils;

import android.content.Context;
import android.content.SharedPreferences;

;


public class PreferenceUtils {
    private final static String SP_NAME = "mowadcom";
    private static PreferenceUtils preferenceUtils;
    private SharedPreferences sharedPreferences;
    private Context mContext;

    public PreferenceUtils(Context mContext) {
        this.mContext = mContext;
        sharedPreferences = mContext.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
    }

  /*  public String getDeviceToken() {
        return sharedPreferences.getString(RestConstant.DEVICE_TOKEN, "");
    }

    public void setDeviceToken(String device_token) {
        sharedPreferences.edit().putString(RestConstant.DEVICE_TOKEN, device_token).apply();
    }


    public static PreferenceUtils getInstance(Context mContext) {
        return preferenceUtils = (preferenceUtils == null ? new PreferenceUtils(mContext) : preferenceUtils);
    }

    private static void removeInstance() {
        preferenceUtils = null;
    }


    public String getLanguage() {
        return sharedPreferences.getString(AppConstant.LUNGUAGE_SELECTED, "");
    }

    public void setLanguage(String language) {
        sharedPreferences.edit().putString(AppConstant.LUNGUAGE_SELECTED, language).apply();
    }

    public boolean isTutorialActivity() {
        return sharedPreferences.getBoolean(AppConstant.IS_DISPLAY_TUTORIAL_ACTIVITY, true);
    }

    public void setTutorialActivity(boolean isTutorials) {
        sharedPreferences.edit().putBoolean(AppConstant.IS_DISPLAY_TUTORIAL_ACTIVITY, isTutorials).apply();
    }


    public String getHospitalId() {
        return sharedPreferences.getString(RestConstant.APPOINTMENT_H_ID, "");
    }

    public void setHospitalId(String HospitalId) {
        sharedPreferences.edit().putString(RestConstant.APPOINTMENT_H_ID, HospitalId).apply();
    }


    public String getDeptId() {
        return sharedPreferences.getString(RestConstant.APPOINTMENT_DEPT_ID, "");
    }

    public void setDeptId(String deptId) {
        sharedPreferences.edit().putString(RestConstant.APPOINTMENT_DEPT_ID, deptId).apply();
    }


    public String getDoctorId() {
        return sharedPreferences.getString(RestConstant.APPOINTMENT_DOCTOR_ID, "");
    }

    public void setDoctorId(String doctorId) {
        sharedPreferences.edit().putString(RestConstant.APPOINTMENT_DOCTOR_ID, doctorId).apply();
    }


    public String getAppointmentTime() {
        return sharedPreferences.getString(RestConstant.APPOINTMENT_FROM_TIME, "");
    }

    public void setAppointmentTime(String appointmentTime) {
        sharedPreferences.edit().putString(RestConstant.APPOINTMENT_FROM_TIME, appointmentTime).apply();
    }


    public FilterData getFilterData() {
        Gson gson = new Gson();
        String json = sharedPreferences.getString(AppConstant.FILTER_DATA, "");
        FilterData filterData = gson.fromJson(json, FilterData.class);
        if (filterData == null) {
            filterData = getDefultFilterData();
        }
        return filterData;
    }

    public void setFilterData(FilterData filterData) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(filterData);
        editor.putString(AppConstant.FILTER_DATA, json);
        editor.apply();

    }

    public FilterData setDefultFilterData() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        FilterData filterData = new FilterData();
        filterData.setRadius(Integer.parseInt(getUserRadius()));
        filterData.setRating(RestConstant.RATING_ALL);
        filterData.setSupport_insurance(false);
        filterData.setDeptIds("");
        filterData.setSortBy(RestConstant.SORT_BY_NAME);
        filterData.setSearchKeyword(null);
        Gson gson = new Gson();
        String json = gson.toJson(filterData);
        editor.putString(AppConstant.FILTER_DATA_DEFULT, json);
        editor.apply();
        return filterData;
    }

    public FilterData getDefultFilterData() {
      *//*  Gson gson = new Gson();
        String json = sharedPreferences.getString(AppConstant.FILTER_DATA_DEFULT, "");*//*
        // FilterData filterData =

        return setDefultFilterData();
    }


    public void setLoginResponse(Login response) {
        if (response.getUserData() != null) {
            sharedPreferences.edit().putString(RestConstant.USER_ID, response.getUserData().getUser_id()).apply();
            sharedPreferences.edit().putString(RestConstant.ACCESS_TOKEN, response.getAccess_token()).apply();
            sharedPreferences.edit().putBoolean(AppConstant.IS_USER_REGISTER, response.isUser_is_registered()).apply();

        }
        sharedPreferences.edit().putString(AppConstant.USER_DATA, new Gson().toJson(response)).apply();

    }


    public Login getLoginResponse() {
        return new Gson().fromJson(sharedPreferences.getString(AppConstant.USER_DATA, ""), Login.class);
    }

    public String getAccessToken() {
        return sharedPreferences.getString(RestConstant.ACCESS_TOKEN, "");
    }


    public String getUserId() {
        return sharedPreferences.getString(RestConstant.USER_ID, "");
    }

    public boolean isUserRegister() {
        return sharedPreferences.getBoolean(AppConstant.IS_USER_REGISTER, false);
    }


    public boolean isBookAppointmentFlow() {
        return sharedPreferences.getBoolean(AppConstant.isBookAppointment, false);
    }

    public void setBookAppointmentFlow(boolean isBookAppointment) {
        sharedPreferences.edit().putBoolean(AppConstant.isBookAppointment, isBookAppointment).apply();
    }

    public boolean isDoctorFavFlow() {
        return sharedPreferences.getBoolean(AppConstant.isFavDoctorFlow, false);
    }

    public void setDoctorFavFlow(boolean isFav) {
        sharedPreferences.edit().putBoolean(AppConstant.isFavDoctorFlow, isFav).apply();
    }


    public void removeBookAppointment() {
        sharedPreferences.edit().remove(AppConstant.isMyAppointment).apply();
    }


    public void clearAllPrefs() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String userRadius = getUserRadius();
        String maxRadius = getMaxRadius();
        boolean isTutorial = isTutorialActivity();
        String language = getLanguage();


        editor.clear();
        editor.apply();
        removeInstance();
        setUserRedius(userRadius);
        setMaxRedius(maxRadius);
        setTutorialActivity(isTutorial);
        setLanguage(language);
    }

    public void clearAppointmentData() {
        sharedPreferences.edit().remove(RestConstant.APPOINTMENT_DEPT_ID).apply();
        sharedPreferences.edit().remove(RestConstant.APPOINTMENT_H_ID).apply();
        sharedPreferences.edit().remove(RestConstant.APPOINTMENT_FROM_TIME).apply();
        sharedPreferences.edit().remove(RestConstant.APPOINTMENT_DOCTOR_ID).apply();
    }

    public void setNotificationCount(int counts) {
        sharedPreferences.edit().putInt(AppConstant.NOTIFICATION_COUNT, counts).apply();
    }

    public int getNotificationCounts() {
        return sharedPreferences.getInt(AppConstant.NOTIFICATION_COUNT, 0);
    }

    public void setUserRedius(String userRedius) {
        sharedPreferences.edit().putString(AppConstant.USER_RADIUS, userRedius).apply();
    }

    public String getUserRadius() {
        return sharedPreferences.getString(AppConstant.USER_RADIUS, "50");
    }

    public void setMaxRedius(String maxRedius) {
        sharedPreferences.edit().putString(AppConstant.MAX_RADIUS, maxRedius).apply();
    }

    public String getMaxRadius() {
        return sharedPreferences.getString(AppConstant.MAX_RADIUS, "100");
    }
*/

}
