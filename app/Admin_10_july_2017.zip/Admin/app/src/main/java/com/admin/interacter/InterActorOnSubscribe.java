package com.admin.interacter;




import com.mowadcom.model.Response;

import rx.functions.Action0;

/**
 * Created by krupal on 8/9/16. This class is used for indicating InterActor process has been
 * started.
 */

class InterActorOnSubscribe<T extends Response> implements Action0 {

  private InterActorCallback<T> mInterActorCallback;

  InterActorOnSubscribe(InterActorCallback<T> mInterActorCallback) {
    this.mInterActorCallback = mInterActorCallback;
  }

  @Override
  public void call() {
    mInterActorCallback.onStart();
  }
}
