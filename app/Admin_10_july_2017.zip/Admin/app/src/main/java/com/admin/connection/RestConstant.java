package com.admin.connection;


public class RestConstant {


    //   public static final String BASE_URL = "http://moawadcom.reviewprototypes.com/api/v1/";

   // public static final String BASE_URL = "http://moawadcom.reviewprototypes.com/api/v6/";
    public static final String BASE_URL ="http://195.154.44.110:2224/mowadcom/api/v6/";
    //  http://moawadcom.reviewprototypes.com/api/v3/
    //  public static final String BASE_URL = "http://reviewprototypes.com/projects_dev/moawadcom/api/v1/";
   // public static final String IMAGE_BASE_URL = "http://moawadcom.reviewprototypes.com/uploads/";
   // public static final String IMAGE_BASE_URL = "http://moawadcom.reviewprototypes.com/image.php?url=";

    public static final String IMAGE_BASE_URL = "http://195.154.44.110:2224/mowadcom/image.php?url=";

    public static final String MAPS_BASE_URL = "https://maps.googleapis.com/maps/api/geocode/json?key=";

    /*Api name Constant*/
    public static final String LOGIN = "login";
    public static final String SENDVERIFY_OTP = "sendverify_otp";
    public static final String GET_NEAR_BY_HOSPITAL = "get_near_by_hospital";
    /*    public static final String GET_NEAR_BY_HOSPITAL = "get_near_by_hospital";*/
    public static final String GET_HOSPITAL_LIST = "get_hospital_list";
    public static final String GET_DEPARTMENT_LIST = "get_department_list";
    public static final String GET_HOSPITAL_DETAILS = "get_hospital_details";
    public static final String REGISTER_API = "register";
    public static final String NATIONALITY_LIST = "get_nationality_list";
    public static final String GET_CITY_LIST = "get_city_list";
    public static final String GET_HOSPITAL_BY_CIITY = "get_hospital_by_city";
    public static final String GET_DEPT_BY_HOSPITAL = "get_departments_by_hospital";
    public static final String GET_DEPT_DETAILS = "get_department_details";
    public static final String GET_HOSPITAL_AVAILABILITY = "get_hospital_availability";
    public static final String GET_FAMILY_MEMBERS = "get_family_members";
    public static final String GET_HOSPITAL_TIMESLOT_LIST = "get_hospital_timeslot_list";
    public static final String BOOK_APPOINTMENT = "book_appointment";
    public static final String CONFIRM_APPOINTMENT = "confirm_appointment";
    public static final String GET_MY_APPOINTMENTS = "get_my_appointments";
    public static final String UPDATE_DEVICE_TOKEN = "update_device_token";
    public static final String EDIT_APPOINTMENT = "edit_appointment";

    public static final String CANCEL_APPOINMENT = "cancel_appoinment";
    public static final String GIVE_DOCTOR_RATING = "give_doctor_rating";
    public static final String GET_MY_PROFILE = "get_my_profile";
    public static final String EDIT_MY_PROFILE = "edit_my_profile";
    public static final String UPLOAD_PROFILE_PIC = "upload_profile_pic";
    public static final String PHOTO = "photo";
    public static final String MEMBER_ID = "member_id";
    public static final String USER_TYPE = "user_type";
    public static final String ADD_FAMILY_MEMBER = "add_family_member";
    public static final String EDIT_FAMILY_MEMBER = "edit_family_member";
    public static final String DELETE_FAMILY_MEMBER = "delete_family_member";
    public static final String SEND_CONTACT_US_MAIL = "send_contact_us_mail";
    public static final String UPDATE_USER_SETTINGS = "update_user_settings";
    public static final String ADDREMOVE_FAVORITE_HOSPITAL = "addremove_favorite_hospital";
    public static final String ADDREMOVE_FAVORITE_DOCTOR = "addremove_favorite_doctor";
    public static final String GET_MY_FAVORITES = "get_my_favorites";

    /*comman */
    public static final String LANGUAGE = "language";
    public static final String DEVICE_TYPE = "device_type";
    public static final String DEVICE_TOKEN = "device_token";
    public static final String USER_ID = "user_id";
    public static final String ACCESS_TOKEN = "access_token";
    /*values*/
    public static final String DEVICE_TYPE_VALUE = "2";//Android
    public static final String SORT_BY_NAME = "2";//Name
    public static final String SORT_BY_DISTANCE = "1";//Distance
    public static final String SORT_BY_RATING = "3";//Rating

    public static final String SUPPORT_INSURANCE_NOT = "1"; //All data
    public static final String SUPPORT_INSURANCE_YES = "2";//support insurance

    public static final String RATING_LESS_THAN_3_STAR = "1";//Distance
    public static final String RATING_MORE_THEN_3_STAR = "2";//Rating
    public static final String RATING_ALL = "3";//Rating

    public static final String DEPT_VELUE = "2";//not required department detail that time


    /*Login Api params*/
    public static final String COUNTRY_CODE = "country_code";
    public static final String PHONE_NO = "phone_no";
    public static final String OTP_CODE = "otp_code";

    /*Hospital List*/

    public static final String LATITUDE = "latitude";
    public static final String LONGITUDE = "longitude";
    public static final String RADIUS = "radius";
    public static final String SEARCH_KEYWORD = "search_keyword";
    public static final String DEPARTMENTS = "departments";
    public static final String SUPPORT_INSURANCE = "support_insurance";
    public static final String SHORT_BY = "short_by";
    public static final String RATING = "rating";
    public static final String PAGINATION_ROWS = "pagination_rows";
    public static final String OFFSET = "offset";
    public static final String LOCATION_LATITUDE = "location_latitude";
    public static final String LOCATION_LONGITUDE = "location_longitude";

    /*Hospital Detail*/
    public static final String H_ID = "h_id";


    /* Signup API params */
    public static final String FIRST_NAME = "first_name";
    public static final String LAST_NAME = "last_name";
    public static final String GENDER = "gender";
    public static final String DOB = "dob";
    public static final String NATIONALITY_ID = "nationality_id";
    public static final String EMAIL = "email";
    public static final String MEDICAL_HISTORY = "medical_history";
    public static final String BLOOD_GROUP = "blood_group";

    /*Get Hospitals by city params*/
    public static final String CITY_ID = "c_id";
    /*Get Dept by Hospitals params*/
    public static final String HOSPITAL_ID = "h_id";
    /*Get Dept details params*/
    public static final String DEPARTMENT_ID = "dept_id";
    public static final String DEPT_DETAILS = "dept_details";
    public static final String DOCTOR_ID = "doctor_id";

    public static final String DESCRIPTION = "descriiption";
    public static final String PATIENT_ID = "ufm_id";
    /*Book Appointment*/

    public static final String APPOINTMENT_U_FM_ID = "appointment_u_fm_id";
    public static final String APPOINTMENT_H_ID = "appointment_h_id";
    public static final String APPOINTMENT_DEPT_ID = "appointment_dept_id";
    public static final String APPOINTMENT_DOCTOR_ID = "appointment_doctor_id";
    public static final String APPOINTMENT_DESCRIPTION = "appointment_description ";
    public static final String APPOINTMENT_DATE = "appointment_date";
    public static final String APPOINTMENT_FROM_TIME = "appointment_from_time";

    /*Time Slote*/

    public static final String DATE = "date";
    public static final String DEPT_ID = "dept_id";
    public static final String D_ID = "d_id";




    /*Confirm Appointment*/
    public static final String APPOINTMENT_ID = "appointment_id";


    public static final String LOGOUT = "logout";
    // Send contact us params
    public static final String NAME = "name";
    public static final String MESSAGE = "message";

    public static final String GET_APP_SETTINGS = "get_app_settings";

    // update user settings API parameters


    public static final String BOOKED_APPOINTMENT_PUSH = "user_booked_appointment_push";

    public static final String BOOKED_APPOINTMENT_REMIND = "user_booked_appointment_remind_push";
    public static final String USER_LANGUAGE = "user_language";

    /*My Appointment*/
    public static final String TYPE = "type";
    public static final String UPCOMING_APPOINTMENT = "1";
    public static final String PAST_APPOINTMENT = "2";

    /*Rating */

    public static final String D_RATING = "d_rating";
    public static final String COMMENT = "comment";


    public static final String APPOINTMENT_STATUS_APPROVED = "1";
    public static final String APPOINTMENT_STATUS_PENDING = "2";
    public static final String APPOINTMENT_STATUS_CANCEL = "9";

    //Google Constants
    public static final String LATLNG = "latlng";
    public static final String GOOGLE_API_KEY = "AIzaSyCWQbcG1WXMR6qwtIh-5sPNfvt906oD4eo";
    public static final String STATUS = "status";
    public static final String RESULTS = "results";
    public static final String FORMATTED_ADDRESS = "formatted_address";
    public static final String ZERO_RESULTS = "ZERO_RESULTS";
    public static final String GOOGLE_OK = "OK";


    //Notification
    public static final String GET_NOTIFICATION_LIST = "get_notification_list";
    public static final String DELETE_NOTIFICATION = "delete_notification";
    public static final String CLEAR_NOTIFICATION_LIST = "clear_notification_list";
    public static final String GET_NOTIFICATION_COUNT = "get_notification_count";

    public static final String NOTIFICATION_ID = "nt_id";
    public static final String NOTIFICATION_READ = "2";
    public static final String NOTIFICATION_UNREAD = "5";

    /*get_my_favorites doctor/hospital values*/
    public static final String DOCTOR_FAVORITES = "2";
    public static final String HOSPITAL_FAVORITES = "1";

    /*Add remove fav hospital*/
    public static final String OPERATION_TYPE = "operation_type";

    /*Add remove fav hospital values*/
    public static final String ADD_FAVORITES = "1";
    public static final String REMOVE_FAVORITES = "2";

    //Promotion
    public static final String GET_PROMOTIONS_LIST = "get_promotions_list";

    // Notification types
    /*
    1)appointment_reminder (typeid= 2)2)appointment_cancelled (typeid=3)3)global_notification (tupeid=4)4)promotions (typeid=5)5)approved_appointment (typeid=6)6)appointment_edited (typeid=7)
     */
    public static final String PROMOTIONS = "5";
    public static final String GLOBAL_NOTIFICATION = "4";


}
